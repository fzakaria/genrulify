module {
  %sandbox_720:3 = splice.literal "sandbox" at 720 -> [
      #splice.entry<"/build" dir 700 mtime 1795046400>,
      #splice.entry<"/build/.attrs.json" file 644 mtime 1795046400 "7e9ceaca78ed37d2d67d2c528c2d74f57b003b126855e58a32ef7750aac32a37">,
      #splice.entry<"/build/.attrs.sh" file 644 mtime 1795046400 "f1990c12a459f052f226bdbe4bc49b2ea1577b187723f1604ae3a4ea199cfd46">
  ]
  %tar_xz_1467:64 = splice.literal "tar|xz" at 1467 folded -> [
      #splice.entry<"/build/gawk-5.4.1" dir 755 mtime 1783615763>,
      #splice.entry<"/build/gawk-5.4.1/README_d" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/awklib" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/build-aux" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/doc" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/doc/it" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/extension" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/extension/po" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/extras" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/m4" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/missing_d" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/pc" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/po" dir 755 mtime 1783615763>,
      #splice.entry<"/build/gawk-5.4.1/posix" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/support" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/support/malloc" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/test" dir 755 mtime 1783615765>,
      #splice.entry<"/build/gawk-5.4.1/test/arrayprm2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/arynocls.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm9.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/backsmalls2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/csv2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval4.awk" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/delarprm.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/delmessy.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/eofsplit.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/exit2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/filefuncs.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtspcl-mpfr.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fordel.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fork.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fork2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fr" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin6.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall3.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/intarray.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/iobug1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/lib" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/test/mdim5.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim7.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/membug1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak3.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nfldstr.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1a.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1b.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1c.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/onlynl.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/prmreuse.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/randtest.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/reg" dir 755 mtime 1783240706>,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack.in" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/rri1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest3.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/switch2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/tradanch.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/vms" dir 755 mtime 1783615671>
  ]
  %tar_xz_1467_0:2285 = splice.exec "tar|xz" at 1467(%sandbox_720#0) -> [
      #splice.entry<"/build/gawk-5.4.1" dir 755 mtime 1783615763>,
      #splice.entry<"/build/gawk-5.4.1/ABOUT-NLS" file 644 mtime 1782131302 "fbe8681a07eab3934d302edb4db8fbcea014b460232e3638e7f4cdb7da53e5aa">,
      #splice.entry<"/build/gawk-5.4.1/AUTHORS" file 644 mtime 1782131302 "e3c25acbdb1de25778f2c57e7baeb9fc7bc7e8c5c4a3fc6541f2cc701c44f7b7">,
      #splice.entry<"/build/gawk-5.4.1/COPYING" file 644 mtime 1782131302 "8ceb4b9ee5adedde47b31e975c1d90c73ad27b6b165a1dcd80c7c545eb65b903">,
      #splice.entry<"/build/gawk-5.4.1/ChangeLog" file 644 mtime 1783615671 "1adcf94e0bcefde5b926c17a6c0bbe87cac2169379fd4ab37c400df81560c6db">,
      #splice.entry<"/build/gawk-5.4.1/ChangeLog.0" file 644 mtime 1782131302 "c6287d94a5ce35dcbf97114c12034bedbf881fe2efe1402e5829640996511bf9">,
      #splice.entry<"/build/gawk-5.4.1/ChangeLog.1" file 644 mtime 1782131302 "0302bf2865249c244eea786fbd41be7b82c90055f70fe7ac91392f371538dfe5">,
      #splice.entry<"/build/gawk-5.4.1/INSTALL" file 644 mtime 1782131302 "54be5efe708bd5a7b433ab227130c5548221151698d17eb7eb142f640cf291ec">,
      #splice.entry<"/build/gawk-5.4.1/Makefile.am" file 644 mtime 1783364624 "df9aec79b86e912376a4d5cc7217c61cba1cb1351960ec0b12bd103bb6fc6d84">,
      #splice.entry<"/build/gawk-5.4.1/Makefile.in" file 644 mtime 1783615715 "5883da7708c8f9c8aa8fc66cb9327639bc0731b52892f576bc58075faa94c5ef">,
      #splice.entry<"/build/gawk-5.4.1/NEWS" file 644 mtime 1783615620 "cd74a1db7ef3803979a0c77981ace36e4998b0000c27f9af5622aa0822abac82">,
      #splice.entry<"/build/gawk-5.4.1/NEWS.0" file 644 mtime 1782131302 "9fc74ef074a85312aa8aea43ec4d3361a6b6bc9f9be32279ac408b8596f6b9cb">,
      #splice.entry<"/build/gawk-5.4.1/NEWS.1" file 644 mtime 1782131302 "2396766cd832606f1c4420510b379a923a9c8834857fe1e6265912c935eaafa8">,
      #splice.entry<"/build/gawk-5.4.1/POSIX.STD" file 644 mtime 1782131302 "88501d8e4253697d9b7fc64a69c630e007c6342eb88f3bf4248f74ec3da7d79c">,
      #splice.entry<"/build/gawk-5.4.1/README" file 644 mtime 1782131302 "f14e82ad3dfe1f731df5672b58626d9931203db216515b6ba2f56395bd9f3a95">,
      #splice.entry<"/build/gawk-5.4.1/README_d" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/README_d/ChangeLog" file 644 mtime 1783615671 "f8b126026efe201a6f274262432d689bb7176c8607b629cd8520510b26e7239d">,
      #splice.entry<"/build/gawk-5.4.1/README_d/ChangeLog.0" file 644 mtime 1782131302 "42ef112442c97e2d8906e30a5f19ed4c841b90aa3d283f3eea27e91df7f4b05c">,
      #splice.entry<"/build/gawk-5.4.1/README_d/ChangeLog.1" file 644 mtime 1782131302 "28065f95d9be3cf68ad4c840601c70c32f02c8b53ea4715142f3e8a4e1ab0e36">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.VMS" file 644 mtime 1782131302 "dcbf3ee30659418c4c5fa1a74b6ec66be5200f76ef29104d5c70e02995f490bf">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.aix" file 644 mtime 1782131302 "e15e6bbf003d4e9c6f4bae1df887c2a9d3dba0660034f291f03dd115cc4e466b">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.alpine" file 644 mtime 1782131302 "1b9a711da720745a78fb64bab615b0a7959dceaba5766be0dad2603805811346">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.bootstrap" file 644 mtime 1782131302 "cd3d895f908dcdd79e37a2cee445c14931279635cd5a484e5c002439524453fd">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.development" file 644 mtime 1782131302 "26cd0648bfda964ea05f2ce265bbfbbbd55c0fe7f920d38668d3bbfe29fc9662">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.freebsd" file 644 mtime 1782131302 "3eb4e62df49bb4084c2ecc9df5d2ba084acdb41e4bf23657b72d9c9b7498f65e">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.hacking" file 644 mtime 1783328483 "a55672ed9867f7d3b83a1213cb9789df46a8056cd7834501c6e4cb12e7478598">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.locales" file 644 mtime 1783328483 "9ed247af94d0f4d24e3a475c3723875174905d33fd6414682dad98f7fd41fd03">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.macosx" file 644 mtime 1782131302 "9b0411f6671ff15c4be04121355aed77e88edfa79b9f4d227a468686e18d9327">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.matchers" file 644 mtime 1783241692 "428b5fab6db7987dcf084ac640abd62ecd771deecbca1b2a3a6437f8d6340793">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.mpfr" file 644 mtime 1782131302 "f0724adc14d5f5a10c9f387938890268dd96f07ad7daedd80f6c0acd57e244f1">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.multibyte" file 644 mtime 1782131302 "1ada4fed2f91ddf841edafdadfb7a79601c68ca266cc31ecf84b8bc39f60b8c1">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.pc" file 644 mtime 1782131302 "cab0a3ffcbd510fe9eb2d31fe33ab38861d1c1d800cbadb4344a727b2ecf38a4">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.rpm" file 644 mtime 1782131302 "dc02e21f6fc2c720139b4376505c874679c5829e46125d18b4721668e677c42d">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.solaris" file 644 mtime 1782131302 "bdd9cba95d70134ac91a9d29356b2f9f59a101fbcbda22e46e50acabe069cad1">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.tests" file 644 mtime 1782131302 "94d0716b4f1b6dd93759aad634de1676ca9250c37b69beb6983fce7f6cf0eeb6">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.zLinux" file 644 mtime 1782131302 "f4290ece961fbbd1c569d0539a53f5845823629ab1a2c7eb61b533e1c7578cb3">,
      #splice.entry<"/build/gawk-5.4.1/README_d/README.zos" file 644 mtime 1782131302 "fc1fa979a0ac8f98a83556a8a1cbb5ba1b650e75cae26a2e892579882deba8aa">,
      #splice.entry<"/build/gawk-5.4.1/TODO" file 644 mtime 1783615620 "c87ab4c21d84edaa96cda12e58b9d05f200953310c01dc9a70348aebfcb127b4">,
      #splice.entry<"/build/gawk-5.4.1/aclocal.m4" file 644 mtime 1783615715 "b4ff592bd9cde4276b239aa06b2bc3ff55e0b9cf9586e08e847ce9a8ed55c586">,
      #splice.entry<"/build/gawk-5.4.1/array.c" file 644 mtime 1783615620 "56d2da05c028aa9fd841c354275a940ddcba634db83cf2d5ca73cff3364acb40">,
      #splice.entry<"/build/gawk-5.4.1/awk.h" file 644 mtime 1783615620 "0e5a7e161f782dc60d2047938b8202bcd4e78325e3a77809a34aa78367499fcf">,
      #splice.entry<"/build/gawk-5.4.1/awkgram.c" file 644 mtime 1783615724 "12723122071f25c9d7f20ca9f524738a178190c403a4de1fb70e9636950b8e05">,
      #splice.entry<"/build/gawk-5.4.1/awkgram.y" file 644 mtime 1783615620 "f423382415c351f7d88e9199e52ca67b0f5501c1b11d0e87568a8eb41b15cc0e">,
      #splice.entry<"/build/gawk-5.4.1/awklib" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/awklib/ChangeLog" file 644 mtime 1783615671 "a1dc1c2c54b4ce68223d974697cc8c2b14bcb7cb5b3eeef81d3eb69ff5f9075b">,
      #splice.entry<"/build/gawk-5.4.1/awklib/ChangeLog.0" file 644 mtime 1783512255 "ba2c323553a49e6721e07e62674171e680d8b2e712e59ae9b1ea47bd494c9112">,
      #splice.entry<"/build/gawk-5.4.1/awklib/ChangeLog.1" file 644 mtime 1783512255 "15dc11ab7cd403a3763ef737aad7903e21d9c445d2aadf932a611b24a4100708">,
      #splice.entry<"/build/gawk-5.4.1/awklib/Makefile.am" file 644 mtime 1783512255 "ccb4867cc7fbd6f5b2432ed26b03bd33da40c885dcead4f3b78c6d06b60ee3b4">,
      #splice.entry<"/build/gawk-5.4.1/awklib/Makefile.in" file 644 mtime 1783615715 "8340503100c714bc5bd8084fada03053a349c4daa3112dddc4e50039846df446">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data/class_data1" file 644 mtime 1783615734 "8fbb378675cf5ff153d17c4969a3fc1a6f853e4568100833e7792b8522f1333f">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data/class_data2" file 644 mtime 1783615734 "9f5e222bcadbf41e04c17f4542d0eb5ad4df05153e5fe48507897cedf48b2d59">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data/guide-mellow.po" file 644 mtime 1783615734 "bc62166f04c90d728993f10869175475979ecafff577f40fc2c6c09db637bf25">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data/guide.po" file 644 mtime 1783615734 "ee46abe52a7988aabe383488e66968d4b34c33eef67c228a3e588091b2047fcb">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data/inventory-shipped" file 644 mtime 1783615734 "04ec3209fc5cb8b7f057905e8f3aa61b6643c1651428029cc05210a404883ae6">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/data/mail-list" file 644 mtime 1783615734 "3fccfd1fbc6dcf5b2a90c7b5bf178406a9241ffd9295523b1ffdd9484893a3ff">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/assert.awk" file 644 mtime 1783615734 "6c4b3f24dd0c225f3ece786eee7fa75f4ef2fb7ffedddaacbc2edb03c68c90b9">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/bits2str.awk" file 644 mtime 1783615734 "77c2504aa2d6385d4d3c0d350515b8791070060ace1414bccc6dc99153743237">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/cliff_rand.awk" file 644 mtime 1783615734 "c405417ad13fe4ca0ba783b6fdcf90c1e2a8ae80ffebc0f2107ddd6ac22ecd82">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/ctime.awk" file 644 mtime 1783615734 "2e20e707381b7cd48abdd70e8f7aed8d86db28a35193bf296964e82de3b754f8">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/ftrans.awk" file 644 mtime 1783615734 "11b367afeda7cc11b3f829d931965ea56b10fcfe87b3833ac4a9ccfce5830ee1">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/getopt.awk" file 644 mtime 1783615734 "7394647d52ed67c12097db732a96f25c808e5d432d74a8c3f0724602f7d41bb6">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/gettime.awk" file 644 mtime 1783615734 "bc0fe06e7fb41531748177f255a20c0db6732472851154b0370532fc302c1864">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/grcat.c" file 644 mtime 1783615734 "dd5d3f25c95387a45413d2d14c5d6c4f348aef2ccb9f803df14d566e64e17f30">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/groupawk.in" file 644 mtime 1783615734 "f97bac947d4972d51487e6762fdcc9b2d6cf033d1d54ee459a5a531c38295150">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/have_mpfr.awk" file 644 mtime 1783615734 "a017c0ef4b5311bd94228c366a896a4a5af417c41930f7ea2b46d9d67f2a663b">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/inplace.awk" file 644 mtime 1783615734 "c74afe20269e7747b55211dd48bef10fb1b9177dbd2997905ba261f2f4fe1243">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/intdiv0.awk" file 644 mtime 1783615734 "26b599f90636b540d77e36724f7339c1330307cf2fafe32d00e7977764bc87ad">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/isnumeric.awk" file 644 mtime 1783615734 "8749b7f590a8997387fbb1cb7317352f05089778d8223b03b8a7891f4c55dfed">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/join.awk" file 644 mtime 1783615734 "49de451cda05448408cb6e5210eb7d886dea05f182e57edd1ecd65afabee8a66">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/libintl.awk" file 644 mtime 1783615734 "293d54512ccf8b6eb41c3f0c9e7ae6d1a20b1c9e7eb559d4975de45ba478f6e1">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/noassign.awk" file 644 mtime 1783615734 "63a84996567a8be236bb4955ee55d525387d0513b12e2121e92267ad72a9c20d">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/ns_passwd.awk" file 644 mtime 1783615734 "6d4b76c1cb895dd7cdae0f1e9e34f474003486e653693684784d0bbcbb18389b">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/ord.awk" file 644 mtime 1783615734 "23bf677aa27bed203790002eeade4996910505445d560ac330236a11b63884e8">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/passwdawk.in" file 644 mtime 1783615734 "ca6dd8e11b69e12ef1f17f706f9e1131bf791afc5dd61826211fa7dca6ae646c">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/processarray.awk" file 644 mtime 1783615734 "8aba77f62a7d63ee84717fa019175bb3f389406f8266188aaaaa0544d08ba302">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/pwcat.c" file 644 mtime 1783615734 "c3aedb25f3bbd6e9cfe0c84fe4d8d00866080ad7a2ce117a30a576eb6ece50ea">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/quicksort.awk" file 644 mtime 1783615734 "c04bc6a885680793fc06a9fb3c0d57903c36383ecf3a5b1c5b05d137b141d7e7">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/readable.awk" file 644 mtime 1783615734 "dfb704d2168f9a1742c4f662c8ae3d17cee8844829fd92249bff79c5f5152942">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/readfile.awk" file 644 mtime 1783615734 "d7c4f63b17c19b2a769ed0c0cd80c94d594e7c413d774ddf629e7464b06f961d">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/rewind.awk" file 644 mtime 1783615734 "6b16e49c6a1e99da1d3c05f5ea9b9128a130002f5c67e1f94e81e6e697b15a61">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/round.awk" file 644 mtime 1783615734 "024ed109f713670ddfa752de0379019f95d6b10cd774a181943f2cf0ea024f80">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/shellquote.awk" file 644 mtime 1783615734 "2efde58fd4fca1f0b27eeec6c04fb7869f9abb1ddaf2f776ec9553ca18b2728e">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/strtonum.awk" file 644 mtime 1783615734 "4af52a0653670b997a3365713bbed43737a07cd6b5064434e863484a0a074122">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/tocsv.awk" file 644 mtime 1783615734 "022016e528bae702238cfc65a6a466cb3ac4883ea7f542a9dbcf8530776761d8">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/walkarray.awk" file 644 mtime 1783615734 "90a9543fa6e49afb453a41e00dce7353d44e2c189ec7cc1c640585bcf1398c54">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/lib/zerofile.awk" file 644 mtime 1783615734 "2aaae54a27113af872b61cd969196be9d21a309cac9d5307a1db3b33530eda86">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/addresses.csv" file 644 mtime 1783615734 "938d217ff39d73aaac8cd56bd0396282a9f6807906a5836fcd7a1d5ee7fc9555">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/arrayorder.awk" file 644 mtime 1783615734 "87cf19284b8c2e8baacf8d0ac33a87cc28e4d42f6fcfe40a875024267f8cd809">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/arrayorder.data" file 644 mtime 1783615734 "8925a78166830420b9634ac62200b39fccaccf08cffd028b7722f0eb5624be09">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/findpat.awk" file 644 mtime 1783615734 "83fb2fcc10313cc2553a98a90df6b0b89822612c192f7a07a715956d6f841d76">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/findpat.data" file 644 mtime 1783615734 "f8ae5ec3212cb77e301f934611e10eca4176044f2ce5ff47a2b5c7a833abbbdd">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/quoted-csv.awk" file 644 mtime 1783615734 "a3b3f388fb946db85ebef24ad8c678598d6b46465e951701c857cfc324fb0949">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/sample.csv" file 644 mtime 1783615734 "818d8f082b36098fc861206f98f7b5307411a41b94638ea2290fc843a3e59469">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/misc/simple-csv.awk" file 644 mtime 1783615734 "44072af36b1ce05589e1d642999c5c6f8d3fc7b16a22fe82d1b63f5638f434cb">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/PostAgent.sh" file 644 mtime 1783615734 "622f5977809e76fe46358abda5032d3dad9fe4fed5af1782cd4efd79fe646ad1">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/catpipeclient.awk" file 644 mtime 1783615734 "ee864dc10f05f93258c4a13d0917331e022de8d8962632aae0334376d47a2981">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/catpipeserver.awk" file 644 mtime 1783615734 "0d79a771c3212f3267137798dc5899f9961da1f1a0824a91ae1c2483813d85a0">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/coreserv.awk" file 644 mtime 1783615734 "506d881a4410cae660458f0960290bb7f17530e766ce3afde37691bf8073e3e6">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/daytimeclient.awk" file 644 mtime 1783615734 "8b5ea56302c131e04ee568ca9cd355c835be3f9556b90e9c6dba2a2b2401d363">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/daytimeserver.awk" file 644 mtime 1783615734 "947618cf8979048e2be01e810d41bb8e2e9ed1165cdf7b1daf23f5ebc049335b">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/eliza.awk" file 644 mtime 1783615734 "a5de6c9a7187b6c247445f6ccc6215f7cfd6745e2eadadf0ad94c75de13f196f">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/fingerclient.awk" file 644 mtime 1783615734 "86ea6ac5f6848f1cecb2a400e4985f617b1fdd33599392cb9425f2dfe3ed4cf7">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/geturl.awk" file 644 mtime 1783615734 "7508602782938f9710af816135fce211af9811d5be1beb47e75af4ff6f11eba0">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/hello-serv.awk" file 644 mtime 1783615734 "bfda6bc264f564491da41d3405d847e1d3632ba200a2c5ac61acd6f52f61b7be">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/mailpopclient.awk" file 644 mtime 1783615734 "023ef22517fb3aa508154215629e8d27e2b117f85c628212f628ecb80134e69d">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/maze.awk" file 644 mtime 1783615734 "83aadff1454fde80fe6776edd66c9434ecdd27565f5e42d2caadc432be95837a">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/mobag.awk" file 644 mtime 1783615734 "585d426671151e3d7b3ca8ee13455bcc20c0a340277d3c1d24977aa0b02c572e">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/panic.awk" file 644 mtime 1783615734 "3fe29f67a45c65a78223a46655c05c7224145c8f0719a2eb986404df56cebaa0">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/protbase.awk" file 644 mtime 1783615734 "c3975038c495d9a611c6342f55d9d7540c4653d2392c808862723d443f66b9e8">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/protbase.request" file 644 mtime 1783615734 "f904dcc0c6ab9fe801bc17404ab6529c1cb3592d82ecd01a49c9c39beb5746b6">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/protbase.result" file 644 mtime 1783615734 "70c10cf0a7cd55460d2af8b91236d5211785fcb2bf7ca3225ba6a6bd679b74fd">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/remconf.awk" file 644 mtime 1783615734 "c04959d030c8384e84995a99539d3a476658c83da25e824940e49d1645c58a32">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/statist.awk" file 644 mtime 1783615734 "3ace4598e2615bc0876ed8b0ed46b9d147bb6fbb85c700ae6349cd638a6db697">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/stoxdata.txt" file 644 mtime 1783615734 "94e6fc4b2984ddf6d347094e3e811201758bbaf08ea4e5b801c15e2cc4b660c9">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/stoxpred.awk" file 644 mtime 1783615734 "12939c12cbb2ce4701c78c28565ec9f5c17289d734d9bd643364f7bd35dd8356">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/testserv.awk" file 644 mtime 1783615734 "56bb85511f9b227f9b3b4d4370483fe73ffe67d475070a3347251141366f74d8">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/urlchk.awk" file 644 mtime 1783615734 "e86649ec9e80a2aadd6f4793d8c1778b2b3dad81f3dfa769f9d3c7312f5ae443">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/network/webgrab.awk" file 644 mtime 1783615734 "53fce48262adf40524b134089d3dcc6b3b9369baecb10ba1411b1a2bea453c0a">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/alarm.awk" file 644 mtime 1783615734 "b807eae641c3e5481556ab0d5c3284ac284779b355b0acda4cd4719c6fe21089">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/anagram.awk" file 644 mtime 1783615734 "d20bde15f749ff4a608e2e6c770881fee25a25c7e001220f70fd694847d27923">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/awksed.awk" file 644 mtime 1783615734 "04d84b4ed6b214eaa521f1cb5b907c4aa319960655f31552b43ed94ae43bce7d">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/cut.awk" file 644 mtime 1783615734 "2ee5d3572a980137848e9b38f372155267608a56bf8526751485476d5edc375e">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/dupword.awk" file 644 mtime 1783615734 "cae7a61bad285b08e44f91d4f0ba0be889474df42b62433ae0354312b904f860">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/egrep.awk" file 644 mtime 1783615734 "7d089defa0abdc232f4323a1969a6b6c1f5ddffd8acb10509bfae9885699461e">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/extract.awk" file 644 mtime 1783615734 "981cf319e4caffcaab332dc97f80561c0f563954197fd0850bdfe26bd5f1a67d">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/guide.awk" file 644 mtime 1783615734 "3cea2c2db0c011cda787bbd61ec73929ad127e90c6c40e2f515514307becd70a">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/histsort.awk" file 644 mtime 1783615734 "847d035f2583fee1cf9ee89edbd50a548cb6082c837d7ded279a1061f928922c">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/id.awk" file 644 mtime 1783615734 "93cdcd0a5ca97354bab71356606deb7bbf4a3e2777f3609b997224fa9c8cbcda">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/igawk.sh" file 644 mtime 1783615734 "c85bf63bbada51150e2102b6f3a75dcb549fbc019946d64a8f89a03d774ecd36">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/indirectcall.awk" file 644 mtime 1783615734 "a660363fb361b9b8a243b705f7d264d9bd0dd72da13a11ec140d1874cc1d9e46">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/labels.awk" file 644 mtime 1783615734 "44c7f1cd203aefd8a14f55c40d5b8a787f5b7271b0b532d61f11c888399e309f">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/pi.awk" file 644 mtime 1783615734 "1127f3b3169e795d47748ae5a36a34bdd38edf8e1901332e0d0c95f67c52e05f">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/shortest-match.awk" file 644 mtime 1783615734 "69e704e266811fe226f3215db10646d7bab9f424cbe80665a301da3e6e400250">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/split.awk" file 644 mtime 1783615734 "f17311c2163f123d64676217962f593f51d62d936823542df13697cf59be3e34">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/tee.awk" file 644 mtime 1783615734 "a9ec44e19db309b84c9a6b5c2f63e416e338756e6ee5a3a304edf2721f25d397">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/testbits.awk" file 644 mtime 1783615734 "0363852242da98a7e470954bc9b842befe44b5b103b61af4e45633b3ad8a71b5">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/translate.awk" file 644 mtime 1783615734 "ed9b1747f4fda6461a2f6a8f759c3e9c393cf50b1f5d57007f8a631565093cba">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/uniq.awk" file 644 mtime 1783615734 "8334470a189191213d3becd01746c04bc1117377fab7ca82b0c112eeb615bc5e">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/wc.awk" file 644 mtime 1783615734 "6a70824cddbeb95d7552ed17c62b996b2be30ce74cd67929f5f7d2d3bd9c1739">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/prog/wordfreq.awk" file 644 mtime 1783615734 "957d5a8c1cdbdaa9a66e1103b6eda3e736a6247bea640ffb70a726a935349578">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/test-programs" dir 755 mtime 1783615734>,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/test-programs/gen-float-table.awk" file 644 mtime 1783615734 "1318cdbdbaa0ae7f4092fef32399b23d77d970f97d57331d12f63a6a432a9e12">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/test-programs/gen-float-table.c" file 644 mtime 1783615734 "485e684167d3f740804595557fb5ca5d12b10e6f2d66c1a85783ab92173fb249">,
      #splice.entry<"/build/gawk-5.4.1/awklib/eg/test-programs/gen-float-table.py" file 644 mtime 1783615734 "2a643e3186a260329ceb966a7c8a79cdc99d082c1f00efe4500c8ebf0f9479d0">,
      #splice.entry<"/build/gawk-5.4.1/awklib/extract.awk" file 644 mtime 1783512255 "2fa333dab538a516fc8792571aca3262747b26cfe8dfb3950df6491b6af78585">,
      #splice.entry<"/build/gawk-5.4.1/awklib/stamp-eg" file 644 mtime 1783615734 "bf7f846bcf3d73e9fd6d8eccd70d50ddfcc524a8d45f37f5c7a9da5d8b319794">,
      #splice.entry<"/build/gawk-5.4.1/build-aux" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/build-aux/ChangeLog" file 644 mtime 1783615671 "a4a805b83cd2ebf1714c2d2a7c0544f97566718d0e95a56930d906d488cc9bfd">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/ar-lib" file 755 mtime 1783249447 "bb022e4c4e9b5d4b0e8a3f7eeaf1cba9f340618ed6ea24babff8157402838112">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/compile" file 755 mtime 1783328483 "ca2177d6b85b76639352270d694bc28b9ba348c315b2427242af886c1d9945f9">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.guess" file 755 mtime 1783328483 "ac18bbd7dc3769e1646af49ebba331a391829f4a73579b735dc8d439bd1c7f07">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.rpath" file 755 mtime 1782830234 "fc70d6138bc62e8ea8080602b607f38d56c4def03ec4d523d516b338cff41df9">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.sub" file 755 mtime 1783328483 "f9a31e9a3f5b7cbeb8d8c3f2015895a51e7222130114c9c363fcbccd78e4bf6b">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/depcomp" file 755 mtime 1783328483 "e3d3ec05f44de5e3f6100d2894c453a1254a8ad9e2ba3a3aa046476187d9179b">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/install-sh" file 755 mtime 1782830234 "776876b3909b096439109a4c7642eb0f9100f6ba3fb42fa93d05351e50a0a7ef">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/ltmain.sh" file 644 mtime 1782131302 "76d58793835f70be2fe69308f0f62b2ff07edd5c45f5255ed42265e147693761">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/missing" file 755 mtime 1782131302 "7b3b653a3b256dec2d25ffaa12ce557dcade2b8fe57c969b3e53f025a5a806a4">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/texinfo.tex" file 644 mtime 1783328483 "8f4866c1f10359b78e1c61a3300e7bbc94e7dd329b0f439698508e537da1bf11">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/ylwrap" file 755 mtime 1782131302 "f8bd7901b53dbd3a3cb823ad2766639ca19341555b12c189d206b20b84695dba">,
      #splice.entry<"/build/gawk-5.4.1/builtin.c" file 644 mtime 1783615620 "2364370b349b7b36e6a8f6e11134f152fa18612bbf504a22b703ce4002f23f3f">,
      #splice.entry<"/build/gawk-5.4.1/cint_array.c" file 644 mtime 1783615620 "8a51ce65f0e09c3e90397af0980b89c08a594f310c6e5cdcf558d59c3d39cb98">,
      #splice.entry<"/build/gawk-5.4.1/cmd.h" file 644 mtime 1783329604 "a0eafa8a48803bdc9fd363e63b74884411a4a50f194163c4722306db7f30158b">,
      #splice.entry<"/build/gawk-5.4.1/command.c" file 644 mtime 1783512260 "dc1135a5578c45595df210536fe74cdfd0249977b69e13a9a41f08c664c26cfd">,
      #splice.entry<"/build/gawk-5.4.1/command.y" file 644 mtime 1783241692 "80e786973010517e1d879ac1d8b407325da068d50287ab704371fede5da83ae2">,
      #splice.entry<"/build/gawk-5.4.1/configh.in" file 644 mtime 1783615722 "ad0eefb133a3ee539d77a0ddfba71291fb66b0115644cbc4e21a11798a69cb9d">,
      #splice.entry<"/build/gawk-5.4.1/configure" file 755 mtime 1783615715 "d04365f773b20e2e0ceaf6c2b5c696a1858730c18ccad3602a1afdbc1b408af6">,
      #splice.entry<"/build/gawk-5.4.1/configure.ac" file 644 mtime 1783615671 "d7d471e58ad959dccdb260c936089fbc08bd1a77bdd13295349be156bb8a500a">,
      #splice.entry<"/build/gawk-5.4.1/custom.h" file 644 mtime 1783615620 "ec6005b3fd3a8668a80d74d367e3c09d5ab8291c6b2743c4dd0e7ebe9f143049">,
      #splice.entry<"/build/gawk-5.4.1/debug.c" file 644 mtime 1783615620 "b39aa6aca998c75e3dd037d71e29090154375dfaa861d86f6e747c88cd6261eb">,
      #splice.entry<"/build/gawk-5.4.1/doc" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/doc/ChangeLog" file 644 mtime 1783615671 "b5a9e5ab03b7dee47caf5b0088be632058bf086c45efacce91e87b2f6a64a90e">,
      #splice.entry<"/build/gawk-5.4.1/doc/ChangeLog.0" file 644 mtime 1782131302 "c76d2fc2019bf3a3431367e4dc1b6cf817111488a63bbdf85e832e997029d57d">,
      #splice.entry<"/build/gawk-5.4.1/doc/ChangeLog.1" file 644 mtime 1782131302 "ea13d548dddc31253978a95189f8fe106f2b254f9d67c740f324d17416387ad2">,
      #splice.entry<"/build/gawk-5.4.1/doc/Makefile.am" file 644 mtime 1783241692 "65ad3b2fceabf22b31264b8c3edd3b79231abe26cf133bc44a008b2986e88908">,
      #splice.entry<"/build/gawk-5.4.1/doc/Makefile.in" file 644 mtime 1783615715 "0b9d5bc33b7e2e404ea82b5a3ff4e902d8c622d96274c5cc221c1345603eb582">,
      #splice.entry<"/build/gawk-5.4.1/doc/README.card" file 644 mtime 1782131302 "a2f605418f0366504a373aa9e8caec8f202a990a89236b795fccbd40c1b04d92">,
      #splice.entry<"/build/gawk-5.4.1/doc/ad.block" file 644 mtime 1783249447 "9814c568a9f58d83d67f2c93bfeb6e352588f91a892b03e4a6697ae9e5804923">,
      #splice.entry<"/build/gawk-5.4.1/doc/awkcard.in" file 644 mtime 1783615671 "b45fbcb824c5137457ad2322766e96978c506e17b597ee2a1f490c0473fe7500">,
      #splice.entry<"/build/gawk-5.4.1/doc/awkforai.txt" file 644 mtime 1782131302 "4a4bafd95b4233abfa9ce4e48a7edb92cc8e8ad714df9b3b95b519d7cce1717b">,
      #splice.entry<"/build/gawk-5.4.1/doc/bc_notes" file 644 mtime 1782131302 "c91936bea4539b9cee2361c2a79acdc5fe6ecc39f92cdd3d7e0d7391071c08d1">,
      #splice.entry<"/build/gawk-5.4.1/doc/cardfonts" file 644 mtime 1782131302 "a28fb0cb27e12ef89920a75d240801cc7044a5ef511cb5be76dfbd3c801ea265">,
      #splice.entry<"/build/gawk-5.4.1/doc/colors" file 644 mtime 1782131302 "98638e06038be4e39e80c11e5d3195ba6fad6aa5c922979e1a0e680f39e52bcf">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk.1" file 644 mtime 1783615620 "db0f483e496c8cf3bceb5848f52726f5020210518cbd3f9c56b3223f39c23df6">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk.info" file 644 mtime 1783615733 "f1d0e6e94809016338209f905cde6efbad12fa040994feb6abc691d131ed41b9">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk.texi" file 644 mtime 1783615671 "cabbf477e7835a6393d3b0f5edc55801bddca312182ee8fd79d24b9f0ad7094f">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.eps" file 644 mtime 1782131302 "4ca79347627bb423e04767e17424c9ccb62a31d237ca09b7e949d602eccb68d6">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.fig" file 644 mtime 1782131302 "26e18f2dd61926010c50e0180db64903217b3fb5fb8070cb208fa8d31f69fa7e">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.jpg" file 644 mtime 1782131302 "563bf52a4518b9e6946e9edb162a65adb3bc47537c0acb70a9fe0d5a01b243ee">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.pdf" file 644 mtime 1782131302 "743a6c0126a3243e19d60db47fa52d662b50727e7a2a08fd0e1d028d8ccbfe1b">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.png" file 644 mtime 1782131302 "41e42a3d6934d030133f6cd2c3efdcf41c6bb01ce9c3efbec095dc001fdccbb2">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.svg" file 644 mtime 1782131302 "e668c430d7f049d39f06758793226bb3721c94f048e4fa4df159ada97f45e52e">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure1.txt" file 644 mtime 1782131302 "447903e54090ac75991b1e2d3e1a71d6dee3901ab2497588bd414ee4dbe3f0c9">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.eps" file 644 mtime 1782131302 "edbbb005a41c8ea430876552da26684779071266c3c3280998cb6917669ffb26">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.fig" file 644 mtime 1782131302 "eb8e546e03726af834077d91f3629d128c6c94e6e8ee27116e7fb4d9176705a2">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.jpg" file 644 mtime 1782131302 "35b274a953665def7f1acef4527b4eff926ef18606b91df218124cbacd88f541">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.pdf" file 644 mtime 1782131302 "0af42d2bcf5ba03396de5017ea15452b423f8a85b65eb3a965f1cc0203532dd0">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.png" file 644 mtime 1782131302 "041787ff295495430fcb207791ed9be2a790609b7b403b0b97ff4908d457b67a">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.svg" file 644 mtime 1782131302 "10b57ba2d78a06d9e5bfb6f0670141001e9aeee8e459c4a0755b6655d7adb022">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure2.txt" file 644 mtime 1782131302 "0e79b0e2b5fbd2d0d747a44fbaa54c60709244e0808a8957129486e12ef08ba6">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.eps" file 644 mtime 1782131302 "6adfd521925f9c01605e66647b3ec9694a85c6b34aa9f443b3c0c6528c11abf5">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.fig" file 644 mtime 1782131302 "53c304e653d6cb72f2fbd61c4d18d32f9022081b49dfe54231a0cb7ad2504f44">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.jpg" file 644 mtime 1782131302 "525a707a720efd0ee43c4924253030a455c65201b56808b384ef189b02757963">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.pdf" file 644 mtime 1782131302 "5c5587628ed1129508dbd8052b35ff719f57bcf5c36286b3116269a277fa6475">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.png" file 644 mtime 1782131302 "98e28671fe6b83eb18af7942d29b730638c556b548b78a8a38d2c639919d9afa">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.svg" file 644 mtime 1782131302 "436ba9168936907bbcf307b1f247255ec0cefe1cec28b9e294a97a8f5366ba4b">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_api-figure3.txt" file 644 mtime 1782131302 "e04c60037876b86ba488282aaa266e65b5e01838d355d0bff2120b5a12cf054b">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.eps" file 644 mtime 1782131302 "e76e20349115a94f76d2de7fc7f0d8cf0bf0408b20db92c6021210ea8d57ad88">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.fig" file 644 mtime 1782131302 "82fccbea8d3dc8f1d4a08937c4d270b008b3db2fc1412ab838b74066291667e0">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.jpg" file 644 mtime 1782131302 "81654e1709937a11c06243c636ea8ce2289f2d93774e8ed2e0dcd28ec643213a">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.pdf" file 644 mtime 1782131302 "4b12ece5c711a5fdbfca4021f3225925bfe50912f2c12601c6f0db7ca5518101">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.png" file 644 mtime 1782131302 "452e2a51e60558f5bbe744c14bf085328c89b1b66e112835b3b6c98c9b9a4f58">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.svg" file 644 mtime 1782131302 "1016f5c20004c7639ff744a98475cfdaa72d5012e8a55a357cbdb5f1f95fbc61">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_array-elements.txt" file 644 mtime 1782131302 "32fd257555aa5c1fe62d6b5e02fe8a6037221e30c706403ec61ae8d3e242710e">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.eps" file 644 mtime 1782131302 "f7f70199eb09e3f3e862366a4a1a15d8b4e08805ad76f09850456725e2b23b51">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.fig" file 644 mtime 1782131302 "c06421df1107a65d97121b832ff53acd1d9d83386cf52d0740f8648c0a74ff41">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.jpg" file 644 mtime 1782131302 "35dbfe620ad2d48d4b49df2e784b3622aa4ec6940246ec11248c30dc69913dca">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.pdf" file 644 mtime 1782131302 "78eeb5463d6390c326f2d5a16298ced3224c2c09b05174e53b81cb2824ae775d">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.png" file 644 mtime 1782131302 "98a9ea38ab5764a614273faf5aa5b359f95a2b9d8782d77986cbbfc3515e0f90">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.svg" file 644 mtime 1782131302 "a21fe0e3591beb958be0b4e7e4b8d740d7f1002a5fff561b19539a370433b3da">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_general-program.txt" file 644 mtime 1782131302 "9577ea265e826a9a830273adcb6327876f93c94e277dcf82ee39fa937335bc59">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.eps" file 644 mtime 1782131302 "07b47d83d783b60508f474d76ed3738f4d81c018ef2e0f6d45a9f06f7d05a59a">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.fig" file 644 mtime 1782131302 "a5593b3de3550c981bd8f909c69146d5595a1d28186eefca33a44cdead44e812">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.jpg" file 644 mtime 1782131302 "bc1afa347bd3493a301ff0a1f901f4b6fc48412cc67a2223eb3319953f930dea">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.pdf" file 644 mtime 1782131302 "0259d3ff0cc343f431c9ab3720b1bf81bd57504ac433a843f694c09cd72e80ad">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.png" file 644 mtime 1782131302 "33dd3a96fb977c56aeab7d63893ac72a0ce1f157667e88cd5cb2b7cf93c596fb">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.svg" file 644 mtime 1782131302 "751ed83e0bcf6e6f3720cbf6b43571dd03e4036a1c173abf72bc9ad086c0ffab">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_process-flow.txt" file 644 mtime 1782131302 "a211d6fabe0fd80355b4530f9b90d93e051b9e11afb621bbc8bc50e52d20c5fd">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_statist.eps" file 644 mtime 1782131302 "6112e774fcda2b4e120ac443cd4d483cabc0666bbb58b0cf10d1958b43a11773">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_statist.jpg" file 644 mtime 1782131302 "99c2883a5fb95fa4e69f929cc12f4dca039af30da85c30970af5f18d81f1c4ce">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_statist.pdf" file 644 mtime 1782131302 "068a9cc728f1ae640eb731950ee1b924222fd1b397dfc2b534af440ad2b8c037">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_statist.svg" file 644 mtime 1782131302 "914ba4b795e2aceea9530315c89cee01c1c150e421b7971474b64580a96928f9">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawk_statist.txt" file 644 mtime 1782131302 "8e1a1e8d7520ce56d1d0e1f236643de44632fbedd8ccd261eb77ffc5fb35bc72">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawkbug.1" file 644 mtime 1782131302 "a38b98a8f092a13b0e8af51a64cf1cd81cab2cbbb86b0bf8e09ee7d294b292a6">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawkinet.info" file 644 mtime 1783615733 "441dff55ce3c51278c0f20ddd6f52ad795cb5d9d464b9b10dbd60baecfabb131">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawkinet.texi" file 644 mtime 1783615620 "07759fb42b7f882f391d73278bde9138bf894fbcdeb93d2eb9a073ad3d51ff1b">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawknotes.info" file 644 mtime 1783241753 "cc3121516b0c5a402723dab3a14df21d6b2fe356caefb8faf17f020772f4d03d">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawknotes.texi" file 644 mtime 1783241692 "3ee93a491fca699461caddbfb6e0bda856bbee61245fc81d0e36214377a17c55">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawkworkflow.info" file 644 mtime 1783512260 "ea14f7170d410f563dd3249e0772cc05d052c53afd0e1886dc5ee8d256e57edf">,
      #splice.entry<"/build/gawk-5.4.1/doc/gawkworkflow.texi" file 644 mtime 1783249699 "96920cadfe413e96b1965ad5d7d2ca78939efc40f11eace094773b7fe99e043e">,
      #splice.entry<"/build/gawk-5.4.1/doc/it" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/doc/it/ChangeLog" file 644 mtime 1783615671 "3d5639aa8cde3bc0953973b9140db91793da986885892d69c24052117f040bf2">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/README.txt" file 755 mtime 1782131302 "feb414621f202520c74c65c4e6f2705de130b30599caa114d4e03a487ac38a85">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/compila_gawk.sh" file 755 mtime 1782131302 "b1175b575785bd91857d46e4e8e84e8ce732e1930eaade732403f9d24df659ae">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/compila_pma.sh" file 755 mtime 1782131302 "6b02d862f7bcb250dd3b188704e0dae378806ca31fa7f15f306c5763abebf4de">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/epsf.tex" file 644 mtime 1782131302 "9a55d3c3842a62de74423621369943e9d06bc47db4fdf15dd4bcb2f0974a37f9">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura1.eps" file 644 mtime 1782131302 "fcf042efc9ad2ece69611e510a1529c62fb030eeb3095e2df3eca086cca58aab">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura1.fig" file 644 mtime 1782131302 "a3fa058f06c3dea136397bd8cf37f4b79d3095bb144d1ec0a54ed2ac115daefb">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura1.pdf" file 644 mtime 1782131302 "d8e58874c811005b30767f57e3d1735490c6e137dd1d1dabf3c110245ec91793">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura1.png" file 644 mtime 1782131302 "a8976d64f91524269027696296f12a693334c40109010e366214f2937361f3db">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura1.txt" file 644 mtime 1782131302 "0d0a8e16aba08a90832e25253005aedecc6fced582097234d64e14f27f679be5">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura2.eps" file 644 mtime 1782131302 "9bc5a4664b84bad5f80a99d458e004ea1a3e3d74d5b46a16e9ce8790f4f6da20">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura2.fig" file 644 mtime 1782131302 "4eeb734f2a5adcdf60c8b2ad218d17fc30cc2d93d8b700bba34baadb9f9978e0">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura2.pdf" file 644 mtime 1782131302 "c9a862573bcaf69f10256ce6a07d625220b74fbbf1b4b7b15d4464c6dc415434">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura2.png" file 644 mtime 1782131302 "26c547121a166c1153eeb3295db37d60bdaf9ff1c0e651cde45fae77c2a36675">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura2.txt" file 644 mtime 1782131302 "4d3a55ef0c9f2ee1107ea082658e6c0a5cb4eb71d0f963cf500637f3daf7e167">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura3.eps" file 644 mtime 1782131302 "ff439d24000b3bcb2600347b485bad520579bca7fd9e7018a73533e459ed9648">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura3.fig" file 644 mtime 1782131302 "8c53a7fbf697e225512f7bdb921f9331eac8839cdd17e1ce04415cf1e1d0bf48">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura3.pdf" file 644 mtime 1782131302 "4dff9883b8308d568fa85f2656f4748358542675dad97f160d7095acd500b0ff">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura3.png" file 644 mtime 1782131302 "1f633cae0d1399b5c1f73834d2175f938778462d20c28f2551e2c0a22af41954">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-api-figura3.txt" file 644 mtime 1782131302 "55152361bc168dfcf17ab2f2260431b164336bfede771c92f370c78b0785b20f">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-flusso-elaborazione.eps" file 644 mtime 1782131302 "5baeff2e76203b57aacdad2bedfbba68afe5c2271aa9be2578fc5e1336f386ad">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-flusso-elaborazione.fig" file 644 mtime 1782131302 "13bd913d417d827e95e85ab3b8298d02b88858b00ec3af7e5b16a0f2d1ddfda5">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-flusso-elaborazione.pdf" file 644 mtime 1782131302 "224f26c592e72c2a7a3978a360b366f6d76aef1bad18e82a526a7c71799cf492">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-flusso-elaborazione.png" file 644 mtime 1782131302 "6fc410043e70e19696c740c5581f2721d1049a1963d0dddf35bda94c04f1ca18">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-flusso-elaborazione.txt" file 644 mtime 1782131302 "61fbb42058d8d06f13c827fe79793923ce534ed8f2075713881eefc2b1bbc3a8">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-programma-generico.eps" file 644 mtime 1782131302 "d54de7648e03790c083de1d9cf2e88a91f1d9572cfaf4ce7b0411fecc81473d8">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-programma-generico.fig" file 644 mtime 1782131302 "83e59f5afc99df591db24041fb9ceadf3894ca9b833fb45044b79e2ae7e1f5d0">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-programma-generico.pdf" file 644 mtime 1782131302 "306d6a90c11948a5ca70657659d182d2886e464d4b0abd20d43efedb4cbc247c">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-programma-generico.png" file 644 mtime 1782131302 "82e810c7c65a746cb32af2030804991a2b79016fc154cda1354d0ba54a316e07">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-programma-generico.txt" file 644 mtime 1782131302 "f529780cf79c3d84b81daa3596e38df3b476a49a93d5be79f1f09afa6a856c31">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-vettore-elementi.eps" file 644 mtime 1782131302 "ad274d8234175cbfa2189462d955a7d71df401a20dee98ec167d4a98c98b4240">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-vettore-elementi.fig" file 644 mtime 1782131302 "5c6cebf1c4f02bf19f0f18ab5023dabd73d6c6d30720663b8e48c874da4bd434">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-vettore-elementi.pdf" file 644 mtime 1782131302 "7e0ab7560d927e4db3cc5d2f765436323b1e196652033b1002954133615f3fd1">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-vettore-elementi.png" file 644 mtime 1782131302 "dec0b1c75a2de018832dca4b97b285390260c6f9ed25437a5ca1111afd1bfe39">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk-vettore-elementi.txt" file 644 mtime 1782131302 "fc411640c658391e9e905f4584d7f0e97f1fb95204b8fc32210df359e156454e">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk.1" file 644 mtime 1783615620 "1270ca06dfafcd4883104b26205b4239caaba3c028868895a9fbca7a218bcb23">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawk.texi" file 644 mtime 1783615620 "dbe43ceee73b3e30904a94a68efad092e57644a76e252446a8d03c967cc4fa1e">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gawkbug.1" file 644 mtime 1782131302 "d109840a894de74c7eac4ef60459f25aa552f8f6dcf718bf7cb34647efa3891e">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gendocs.sh" file 755 mtime 1782131302 "7f4d245919687b4789245dd299ade7d5470174a8a4871b79c35062aaf8cc6c73">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/gendocs_template" file 755 mtime 1782131302 "e38fd8db31a3f8f433dcc71545035bdde5ac00d5343bf8a513f30375a6b444a6">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/genera_formati.sh" file 755 mtime 1782131302 "2cdee64cc41076efaf7f9ab99d5bba1b114ef334bba902fa392e5207a29bdaf9">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/lflashlight-small.xpic" file 644 mtime 1782131302 "d8a4b1d848cc1d2e62e6841784fe6d6213f64510b9fb6d299b4484e3bf5c5428">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/lflashlight.eps" file 644 mtime 1782131302 "82051cfa36908a08b7e8a40089dda28c7d6341d74623f2bd3bde6a36e3688ce0">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/lflashlight.pdf" file 644 mtime 1782131302 "c5a59665197f23c79911e498e3aac7e034feacfd44ae6a9ba1313b930ecd40cd">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/margini.texi" file 644 mtime 1782131302 "baac3f4fd2038ee31f58df06f9703b60f02974e68c557bcf3ae7c2f27a3aa8e1">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/pm-gawk.1" file 644 mtime 1782131302 "c283dfa5d0ab249d010bb58d17dc11a834c572b75f1e1ca73a8462b6eb95702f">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/pm-gawk.texi" file 755 mtime 1783615620 "f0e11d77b6ddd816cc1f8ba6f6f1dc575278796eb338588b0d75bc9801382dbe">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/rflashlight-small.xpic" file 644 mtime 1782131302 "b732e1d3ef925a45a0c0b4b4a8b4023308daab8cb06cb84eac1f3a8e2504ba14">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/rflashlight.eps" file 644 mtime 1782131302 "0a2a96626f7728d05c95a5b2a2573ec9b7c1559734a4472d5b15f530d1e1595c">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/rflashlight.pdf" file 644 mtime 1782131302 "b8f4ce61925d73b4616328840fd9ab2affe36af366f90b481b8b6103a1522fe5">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/texinfo.tex" file 644 mtime 1783615620 "8a0d4a512e6d6323aeae03d841142aae43d4a07ca002432cd7e01b0a5ea3e24d">,
      #splice.entry<"/build/gawk-5.4.1/doc/it/txi-it.tex" file 644 mtime 1782131302 "1adf0921bcb7515ba5a10afb8e68904512661e78f04dc6aecf3f137874f72f4f">,
      #splice.entry<"/build/gawk-5.4.1/doc/lflashlight-small.xpic" file 644 mtime 1782131302 "d8a4b1d848cc1d2e62e6841784fe6d6213f64510b9fb6d299b4484e3bf5c5428">,
      #splice.entry<"/build/gawk-5.4.1/doc/lflashlight.eps" file 644 mtime 1782131302 "82051cfa36908a08b7e8a40089dda28c7d6341d74623f2bd3bde6a36e3688ce0">,
      #splice.entry<"/build/gawk-5.4.1/doc/lflashlight.jpg" file 644 mtime 1782131302 "f54ffb20e4b22973dc435ef03e36b3966cd649afc6d6748895fb02b08a7a5767">,
      #splice.entry<"/build/gawk-5.4.1/doc/lflashlight.pdf" file 644 mtime 1782131302 "d872b4cfff7ae0865c8d8de2f5f98484617a604730fa2ea0146c20d610982b15">,
      #splice.entry<"/build/gawk-5.4.1/doc/lflashlight.svg" file 644 mtime 1782131302 "012ee4346ba53f8e4f4ac2acc77a98919fdb99109d53844f4df63b767f6ecd20">,
      #splice.entry<"/build/gawk-5.4.1/doc/macros" file 644 mtime 1783241692 "61bdd995ee85b5308a2a5846a5f35e82b98621d1ffb6d1484487bd93b1ebce1d">,
      #splice.entry<"/build/gawk-5.4.1/doc/no.colors" file 644 mtime 1782131302 "300c81f4c5b69bd8939646e34e40a594ec2c53f905154207b7172366ee996d13">,
      #splice.entry<"/build/gawk-5.4.1/doc/pm-gawk.1" file 644 mtime 1782131302 "bfabb30f69222ed9f9f9bd960158fd95b938ed3535275bf5c32f3282aa20730e">,
      #splice.entry<"/build/gawk-5.4.1/doc/pm-gawk.info" file 644 mtime 1783512260 "77e2fc87fdf547f82210796fbf6396b90fe854df7602f4abd8d49a6c76557e28">,
      #splice.entry<"/build/gawk-5.4.1/doc/pm-gawk.texi" file 644 mtime 1783249699 "1deb7ddf1df2b297f51211efc6407c1ae59233f22e763f44b7b33eb764efba53">,
      #splice.entry<"/build/gawk-5.4.1/doc/rflashlight-small.xpic" file 644 mtime 1782131302 "b732e1d3ef925a45a0c0b4b4a8b4023308daab8cb06cb84eac1f3a8e2504ba14">,
      #splice.entry<"/build/gawk-5.4.1/doc/rflashlight.eps" file 644 mtime 1782131302 "0a2a96626f7728d05c95a5b2a2573ec9b7c1559734a4472d5b15f530d1e1595c">,
      #splice.entry<"/build/gawk-5.4.1/doc/rflashlight.jpg" file 644 mtime 1782131302 "98e01ad661991f8b87b3fade9bdfefa3b2b6dcd8e85819704eca8e2d7b03cb72">,
      #splice.entry<"/build/gawk-5.4.1/doc/rflashlight.pdf" file 644 mtime 1782131302 "7582d356584d8783561293e2afa38bb3f1db38d7b8abc00fe61c4fee5607d644">,
      #splice.entry<"/build/gawk-5.4.1/doc/rflashlight.svg" file 644 mtime 1782131302 "5ade7749214beebee34f8a3642cf7aa841c7f8a1c50b9957c4485796052b739f">,
      #splice.entry<"/build/gawk-5.4.1/doc/setter.outline" file 644 mtime 1783241692 "04fd484eade39595fabe348d624ec875de1915267c5c5d162b21dff5de30393d">,
      #splice.entry<"/build/gawk-5.4.1/doc/texinfo.tex" file 644 mtime 1783328483 "8f4866c1f10359b78e1c61a3300e7bbc94e7dd329b0f439698508e537da1bf11">,
      #splice.entry<"/build/gawk-5.4.1/doc/wordlist" file 644 mtime 1783329604 "3a13301c719cef3cb7ba97f7c09eac13dd5e42066245b0cb4962cc058c166b34">,
      #splice.entry<"/build/gawk-5.4.1/doc/wordlist2" file 644 mtime 1782131302 "ae22eb136cf8a23fc84d5e7a75509292475b3ef96945e40fc1ed5aa1b75e6ff3">,
      #splice.entry<"/build/gawk-5.4.1/doc/wordlist3" file 644 mtime 1783241692 "36342817605df5dd637ba0c1757e793f6a2effa8769a7d468d93daf2b86cba6f">,
      #splice.entry<"/build/gawk-5.4.1/doc/wordlist4" file 644 mtime 1782131302 "e91c35121fd65e83b2dd6c731f185f425760784b67cd77c226325f0b57c91f22">,
      #splice.entry<"/build/gawk-5.4.1/doc/wordlist5" file 644 mtime 1782131302 "6dcc425816b82f920fd57d379649cfb6849f270ca3597745798a87769834e7bd">,
      #splice.entry<"/build/gawk-5.4.1/doc/wordlist6" file 644 mtime 1782131302 "2af0bfcf8552fd3783f29cf64ac04ef7e608a51469281f90b68725f0305e431c">,
      #splice.entry<"/build/gawk-5.4.1/eval.c" file 644 mtime 1783615620 "473e2e599e351ea67a837a4cf57c7ed224254c1d25187cb5fbfbff1eee8cb6a8">,
      #splice.entry<"/build/gawk-5.4.1/ext.c" file 644 mtime 1783241692 "29e44b51998b0fe51c7f5b54ca2219fb4517a919afef6e32ffe564a77ba9b384">,
      #splice.entry<"/build/gawk-5.4.1/extension" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/extension/ABOUT-NLS" file 644 mtime 1782131302 "fbe8681a07eab3934d302edb4db8fbcea014b460232e3638e7f4cdb7da53e5aa">,
      #splice.entry<"/build/gawk-5.4.1/extension/AUTHORS" file 644 mtime 1782131302 "e3c25acbdb1de25778f2c57e7baeb9fc7bc7e8c5c4a3fc6541f2cc701c44f7b7">,
      #splice.entry<"/build/gawk-5.4.1/extension/COPYING" file 644 mtime 1782131302 "8ceb4b9ee5adedde47b31e975c1d90c73ad27b6b165a1dcd80c7c545eb65b903">,
      #splice.entry<"/build/gawk-5.4.1/extension/ChangeLog" file 644 mtime 1783615671 "ab71465eca21b3deb43347e7fa7fe5c65586a6707b8d6cf0ff6922076d53fc05">,
      #splice.entry<"/build/gawk-5.4.1/extension/ChangeLog.0" file 644 mtime 1782131302 "623c702bf4dff07315f582817f8d8a3a2f35f6029b772cd7d0029e6324b06873">,
      #splice.entry<"/build/gawk-5.4.1/extension/ChangeLog.1" file 644 mtime 1782131302 "98d26131010c6e40f0d8c9973cf826aefa2dd3af72006ed2b2585c83e31f62bd">,
      #splice.entry<"/build/gawk-5.4.1/extension/INSTALL" file 644 mtime 1782131302 "54be5efe708bd5a7b433ab227130c5548221151698d17eb7eb142f640cf291ec">,
      #splice.entry<"/build/gawk-5.4.1/extension/Makefile.am" file 644 mtime 1783615620 "4a7521fb195b3ca83a34e1d4917ba0d529f3fd7f0e5e6208545458e32264c5c5">,
      #splice.entry<"/build/gawk-5.4.1/extension/Makefile.in" file 644 mtime 1783615727 "7c8c60811ba84495975ee03c7f3fbbe9ca18746fe619aa204337eb173ef85d4d">,
      #splice.entry<"/build/gawk-5.4.1/extension/NEWS" file 644 mtime 1782131302 "c86d711b2f32d6f772d48e3d726bde72f1615b9b4fa5baf2761548710f6fba4a">,
      #splice.entry<"/build/gawk-5.4.1/extension/README" file 644 mtime 1782131302 "37342895114934813066c433cbfaf2ac152e5dbd88d00c18e861ca3532844bba">,
      #splice.entry<"/build/gawk-5.4.1/extension/README.fts" file 644 mtime 1782131302 "f68245e0219193634bddf4acae1811114e6388ef2fe14ad5e1d66f6dab384acb">,
      #splice.entry<"/build/gawk-5.4.1/extension/aclocal.m4" file 644 mtime 1783615727 "0495bf6fdb67b5d6f22be1026787953a09d90bf5a3052f8ff4ff32622c631d0d">,
      #splice.entry<"/build/gawk-5.4.1/extension/configh.in" file 644 mtime 1783615732 "5c5b1466b6da98ac95a0c065d326e465a697ff4ab610a66507d56829d275f47f">,
      #splice.entry<"/build/gawk-5.4.1/extension/configure" file 755 mtime 1783615727 "52d694871263d8d24924b7663d12950b0f7d6ba692ca79f86e3d24b031f660ac">,
      #splice.entry<"/build/gawk-5.4.1/extension/configure.ac" file 644 mtime 1783615671 "3c91966479ebf26988574e6e17ed635cb62057492a689fd52fc13e8211bc2040">,
      #splice.entry<"/build/gawk-5.4.1/extension/ext_custom.h" file 644 mtime 1783241692 "70293c4c5e662cd2980b7d29112134aa2102347960471dcb16fd677c3e70af07">,
      #splice.entry<"/build/gawk-5.4.1/extension/filefuncs.3am" file 644 mtime 1783241692 "b7a6a3d383ba5023d87729841fe3ab5ecdeedecd80d56f43a8a9f7d68c2ef3f0">,
      #splice.entry<"/build/gawk-5.4.1/extension/filefuncs.c" file 644 mtime 1783329604 "a847860a78d43c3eb4dc4b53e71bf382a30bb340b6decc117c78804bb55fe227">,
      #splice.entry<"/build/gawk-5.4.1/extension/fnmatch.3am" file 644 mtime 1783241692 "82bed00452298d35b380fae5e9d9cc6116cdb4be847af92304851e425915f65d">,
      #splice.entry<"/build/gawk-5.4.1/extension/fnmatch.c" file 644 mtime 1783615620 "1e8cbcb74bb1d1083d624783b76a8dfe8ba07f336f7f3bf6a816a454828bde49">,
      #splice.entry<"/build/gawk-5.4.1/extension/fork.3am" file 644 mtime 1783241692 "6087be91a06c38fb0d88164d66c6a243b01cfa74ef296592ea088762ca2f96ee">,
      #splice.entry<"/build/gawk-5.4.1/extension/fork.c" file 644 mtime 1783329604 "1cf5adacac45da76e2d67f7ff8c85c13a946a493c201d76492bdfd5af890efd6">,
      #splice.entry<"/build/gawk-5.4.1/extension/fts.3" file 644 mtime 1782131302 "ce3713d0607164a1a29adf7e29902a8ad983a630f4376aa91698808e4103b4b4">,
      #splice.entry<"/build/gawk-5.4.1/extension/gawkdirfd.h" file 644 mtime 1782131302 "c16d17e5baa0b2b780e9dfcb29ca87dd8f3cdcbb6eeeeb3b9c052bf27b54d102">,
      #splice.entry<"/build/gawk-5.4.1/extension/gawkfts.c" file 644 mtime 1782131302 "4c0b2b8d8767a6276debfc468bc233abccb86cae41ce93b359e4d9a20557c29a">,
      #splice.entry<"/build/gawk-5.4.1/extension/gawkfts.h" file 644 mtime 1782131302 "41925fa51e4ac52aaf679b49cfa01d77bc3ef25471b7302cd344157f7a1ab839">,
      #splice.entry<"/build/gawk-5.4.1/extension/inplace.3am" file 644 mtime 1783241692 "6c1986772fbd61a2c01efc6e27903580585f57459faac2b1a204f9f9abed41c9">,
      #splice.entry<"/build/gawk-5.4.1/extension/inplace.c" file 644 mtime 1783329604 "38a20dec46ee85fa1691349257b621a44f8b00d28d1911c2e74bd8c87b81ec7b">,
      #splice.entry<"/build/gawk-5.4.1/extension/intdiv.3am" file 644 mtime 1783241692 "5d58913b34a1136d9132f6fb43e9e363b3d84a8cc17c3c596e96de304a506d9b">,
      #splice.entry<"/build/gawk-5.4.1/extension/intdiv.c" file 644 mtime 1783329604 "c4404d4881fed2c950f7d626ea1c319d74d623dd8ea217251ea538f0353efd59">,
      #splice.entry<"/build/gawk-5.4.1/extension/ordchr.3am" file 644 mtime 1783241692 "a6dc5edfdc0143e5ccb31e82cada9a3ad00813f5c9ceedaede39795a81034705">,
      #splice.entry<"/build/gawk-5.4.1/extension/ordchr.c" file 644 mtime 1783615620 "89b33aba83474c71dae3594863fb2c1dc050f96b259b142373cbddae77982688">,
      #splice.entry<"/build/gawk-5.4.1/extension/po" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/extension/po/ChangeLog" file 644 mtime 1783615671 "6e71d12e1ab136c37d93ba1641e4dc70f9b03ccb9105227e01bc5653f04eea6b">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/Makefile.in.in" file 644 mtime 1782131302 "b9146b0739ad3c5c319a4b072a02a8cdfd31f107376857cfb299fb2ea319784b">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/Makevars" file 644 mtime 1782131302 "133674bca1cb6237ab0482182a7cdaccb25dcf05b3296551187ff9e38415ba30">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/POTFILES.in" file 644 mtime 1782131302 "c130a8f9d4af41b0c38889250a48b4983322bc5470b204c2d78f6057bcac24c8">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/Rules-quot" file 644 mtime 1782131302 "8ced8cd2b86458be88c38322db49df53f41f87200a79233ce34499cb031db0cd">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/boldquot.sed" file 644 mtime 1782131302 "33234736a58f1610c73e1c8c08faf1b2ef1397d878dd7d2cbd888ca0f2da4ffc">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/en@boldquot.header" file 644 mtime 1782131302 "99ad82767e9b1b4dd1e413664e06c686c8ab70eaadb129ac08a8b8b76f9173d2">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/en@quot.header" file 644 mtime 1782131302 "6f4df89908e6e413db10738ff01e0c7046922c2a4aa4f9e64d376235745a4af5">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/insert-header.sin" file 644 mtime 1782131302 "87041830aa4c5e87cedd35a2a95cf94c4e889604580481430b214422a5e8dc98">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/quot.sed" file 644 mtime 1782131302 "d19ab2cc69000c1206f1b8460952857f05d154158da8b89273ac2900a5c80ec0">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/remove-potcdate.sin" file 644 mtime 1782131302 "d582513385c800f75224f4041fbff207053d4229be6038c6810af382420ac362">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/stamp-po" file 644 mtime 1782131302 "2cd8ec3de6a07e1fd39676100db57ba62372e820c19812fee55899f65746e192">,
      #splice.entry<"/build/gawk-5.4.1/extension/readdir.3am" file 644 mtime 1783241692 "4422a0ea43f96678c193b03c34da368214b1db6d6a080774bde3798a081e0cf6">,
      #splice.entry<"/build/gawk-5.4.1/extension/readdir.c" file 644 mtime 1783241692 "e0981e96b63ee9dd662751e4ada01dc6702966b14b56d8fb84d0f581916b5516">,
      #splice.entry<"/build/gawk-5.4.1/extension/readfile.3am" file 644 mtime 1783241692 "104dc74f6470fafe24e76a1c2b5208ba2af4d2efa1075807206bfd06d20a9325">,
      #splice.entry<"/build/gawk-5.4.1/extension/readfile.c" file 644 mtime 1783329604 "3dc83885438b7bda94bdf99fb0c2ce04183ef311ee96f00ac5a19cbe5b0bc1b9">,
      #splice.entry<"/build/gawk-5.4.1/extension/revoutput.3am" file 644 mtime 1783241692 "2edd40390f8014bb4de42f0df9fb1635016946337d5534c98870aa4449b74766">,
      #splice.entry<"/build/gawk-5.4.1/extension/revoutput.c" file 644 mtime 1783329604 "c900d118aba93d0f061fd8119df7aec0daaeb5037e85b20403d6b983a139ad50">,
      #splice.entry<"/build/gawk-5.4.1/extension/revtwoway.3am" file 644 mtime 1783241692 "88ce804829dc66d684c287a327cd49ce44eae77cee26566886805d1919dad5f9">,
      #splice.entry<"/build/gawk-5.4.1/extension/revtwoway.c" file 644 mtime 1783329604 "509666506405ed3dcb53c7a2e840a6ec64266d2106867a179a6e9d32de9b4dcd">,
      #splice.entry<"/build/gawk-5.4.1/extension/rwarray.3am" file 644 mtime 1783241692 "18cfd1aa5bdb1781abbb2bf51d1e7003ab3410fdc0f994b5119d195739d88c53">,
      #splice.entry<"/build/gawk-5.4.1/extension/rwarray.c" file 644 mtime 1783329604 "50916830ce13b22e988e2396c929a5a91c8bbd0372ed6f001d2f371d88c563e2">,
      #splice.entry<"/build/gawk-5.4.1/extension/stack.c" file 644 mtime 1783329604 "bdcee0132971c4b44cb4cdbe40fd9ca59c101218d6df3de83eefc9c1c3b7b18b">,
      #splice.entry<"/build/gawk-5.4.1/extension/stack.h" file 644 mtime 1783329604 "17319501b7e30c1e925fcce50f614b083b9751610ff586a20fa01c094f7939e1">,
      #splice.entry<"/build/gawk-5.4.1/extension/testext.c" file 644 mtime 1783329604 "bb3038d3ad091ee8153eaf693a42159179d5906af3ae91f3a2e29b246ef818ad">,
      #splice.entry<"/build/gawk-5.4.1/extension/time.3am" file 644 mtime 1783241692 "67b05e73ba18d68e27a6d99f8fbdae39916a68150c3924d9464c6f55abbafeb8">,
      #splice.entry<"/build/gawk-5.4.1/extension/time.c" file 644 mtime 1783615620 "1a7cd95e5ec5b5ac98095ec8fb882a471c41433601a47b438f105f006b36a3e7">,
      #splice.entry<"/build/gawk-5.4.1/extras" dir 755 mtime 1783615762>,
      #splice.entry<"/build/gawk-5.4.1/extras/ChangeLog" file 644 mtime 1783615671 "a22351a9c6530ebd7ca7dedd2be58ad75c2de072e5df1b0f6248f294cbfe2f9f">,
      #splice.entry<"/build/gawk-5.4.1/extras/Makefile.am" file 644 mtime 1783329604 "a53d78da3675abca8d2a9e58313998654f9a4a1d21d3aa29ef60b77307def649">,
      #splice.entry<"/build/gawk-5.4.1/extras/Makefile.in" file 644 mtime 1783615715 "24c608b8a236cf35ce8aecfd2b28395953fd320916cef75c692cd2999599cc84">,
      #splice.entry<"/build/gawk-5.4.1/extras/gawk.csh" file 644 mtime 1782131302 "9ba2af9853121df6dd5edff9254a2946e39eab8dc6513348fea28f739ee96648">,
      #splice.entry<"/build/gawk-5.4.1/extras/gawk.sh" file 644 mtime 1782131302 "70621a3b586d3d523b020e76977633b444a70013ba50e1ea901a3a07a676f15f">,
      #splice.entry<"/build/gawk-5.4.1/field.c" file 644 mtime 1783615620 "79e3c396615bd7423aeb903b7db77a14878012a392516c8b920910496fbe05f6">,
      #splice.entry<"/build/gawk-5.4.1/floatcomp.c" file 644 mtime 1783615620 "80f4d72c55888a67734401854d4e661b94958b569c84dc5ee65631ce23dfdc12">,
      #splice.entry<"/build/gawk-5.4.1/floatmagic.h" file 644 mtime 1783329604 "a551d8d0be7618223f4ad1624e91c4fe00e5353c4b75c3ffa52812864806254c">,
      #splice.entry<"/build/gawk-5.4.1/gawkapi.c" file 644 mtime 1783615620 "f7822f29b8bc9180924b16d355e7eff4112ab41c97d241fb93cbef977aa92a49">,
      #splice.entry<"/build/gawk-5.4.1/gawkapi.h" file 644 mtime 1783615620 "3480eb870c9b88cca3f4df58e069ba91c944954d7f1610944ef557350c8b0713">,
      #splice.entry<"/build/gawk-5.4.1/gawkbug.in" file 644 mtime 1782131302 "cc65e2cd31873b6bea1a532daa02106565e719053d60d8531c747cd4d03c35b5">,
      #splice.entry<"/build/gawk-5.4.1/gawkmisc.c" file 644 mtime 1783241692 "0a49ce4946165ddc6ede420e826836723de172ba917dd77e9b407778837bf384">,
      #splice.entry<"/build/gawk-5.4.1/gettext.h" file 644 mtime 1782131302 "d9d2efcd8865ed25b0976aee699b4f82f88fc9acf2b706886027b4a6f5daadf7">,
      #splice.entry<"/build/gawk-5.4.1/int_array.c" file 644 mtime 1783615620 "73bb4e0d2bf726007c0f710f0c7498f5b35634e37283940c3cd44f330a2e4c2a">,
      #splice.entry<"/build/gawk-5.4.1/interpret.h" file 644 mtime 1783615620 "0a9d22c77f9e65b809806696f33ee0e9f21ccaa17a9fc9889998d46331b70f56">,
      #splice.entry<"/build/gawk-5.4.1/io.c" file 644 mtime 1783615620 "c95f823950b82bd6d0dc83f08444282e5b434469fb248b8e3b967ff11aa41e81">,
      #splice.entry<"/build/gawk-5.4.1/m4" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/m4/ChangeLog" file 644 mtime 1783615671 "d30e35177f4efe3a567cfa10eaa5a235f8947df79b960f237dc3a59760285de5">,
      #splice.entry<"/build/gawk-5.4.1/m4/ChangeLog.0" file 644 mtime 1782131302 "78053978337b72371cb60ada1fd3e5279f4a5b48694729931df9f8fa98e2af8c">,
      #splice.entry<"/build/gawk-5.4.1/m4/ChangeLog.1" file 644 mtime 1782131302 "dcb365b7b7dce863aee05b510a105c0cc290a061669e56a76766eab1f75e5862">,
      #splice.entry<"/build/gawk-5.4.1/m4/arch.m4" file 644 mtime 1783241692 "386be7e008f878a86cc2310c09a7add3474ae9140b576b51445211eda88143f9">,
      #splice.entry<"/build/gawk-5.4.1/m4/ax_check_compile_flag.m4" file 644 mtime 1783615620 "629dc6835eb1e2bd586fd842a4db66541bc442bcc2b13d6f24907631c5a688b0">,
      #splice.entry<"/build/gawk-5.4.1/m4/c-bool.m4" file 644 mtime 1783615620 "708cbc1ff7aa2253db7e238e70085611da5895371bb2fb50e43e9df26f1580d5">,
      #splice.entry<"/build/gawk-5.4.1/m4/codeset.m4" file 644 mtime 1783615620 "7415e53efd179f4ee07f64ac8b730cb43f1d1861e6aabf4052072cda7e6dc9cc">,
      #splice.entry<"/build/gawk-5.4.1/m4/dirfd.m4" file 644 mtime 1782131302 "165225ca807fc43d36e3c68449b3b4c4cb9490ce7551a58a3b2a6bd8ae19d5da">,
      #splice.entry<"/build/gawk-5.4.1/m4/extern-inline.m4" file 644 mtime 1783615620 "c8e2e48b384fa101aa33f3e5e01dd4669fe1d7ca7667e25bae21994bdc303456">,
      #splice.entry<"/build/gawk-5.4.1/m4/fcntl-o.m4" file 644 mtime 1783615620 "f3a67e2ee733c0b4c0b3eb8a88d2216fba198457b32a246c4d1d2598184f8dca">,
      #splice.entry<"/build/gawk-5.4.1/m4/gettext.m4" file 644 mtime 1782131302 "6b8ca63d019cf362cfeb9d4b52e7d431b4feb14d5f3f03f97bef824319c0375b">,
      #splice.entry<"/build/gawk-5.4.1/m4/glibc2.m4" file 644 mtime 1783615620 "2cdc1f74727bbee58c1229e9b3343a48fccc94ba54f4f8031316f688c36073e2">,
      #splice.entry<"/build/gawk-5.4.1/m4/glibc21.m4" file 644 mtime 1783615620 "d8a71189f6912c789fdb9263569059a1af670af9d8689af7676d04601a319968">,
      #splice.entry<"/build/gawk-5.4.1/m4/host-cpu-c-abi.m4" file 644 mtime 1783249447 "3a2c00ee66efb28f98119dc836586dd76802c03fa7bcd2345a33a51d58cc1a41">,
      #splice.entry<"/build/gawk-5.4.1/m4/iconv.m4" file 644 mtime 1783615620 "56b1f2de17e73f0e3a65634570b2c9032f912c54df09bfa6d40d1422f02b4d8f">,
      #splice.entry<"/build/gawk-5.4.1/m4/intdiv0.m4" file 644 mtime 1783615620 "872ef0d575609e0168a47fcde9f6516382a75e9edae067f4e2a86adccb0f7237">,
      #splice.entry<"/build/gawk-5.4.1/m4/intl.m4" file 644 mtime 1783615620 "a5079b8454bd3443ac6ce6e70f1a5e15a5c3fde370ac52707ace994953cf08a3">,
      #splice.entry<"/build/gawk-5.4.1/m4/intldir.m4" file 644 mtime 1783615620 "d606538effe2100eb31c02b095d84594f49b43b2a3f02e6a56930639b82ba21a">,
      #splice.entry<"/build/gawk-5.4.1/m4/intlmacosx.m4" file 644 mtime 1783587436 "21b4e06f5f326a1bf178e07a0b47ebdece34418a0ade38469b07fd86bb50e513">,
      #splice.entry<"/build/gawk-5.4.1/m4/intmax.m4" file 644 mtime 1783615620 "2cf110d3e98d25c58b0481ec3ec26db3d4d8d3a68f61d136d62de79d48e40b5e">,
      #splice.entry<"/build/gawk-5.4.1/m4/intmax_t.m4" file 644 mtime 1783615620 "417a6dc95b7ff9ef948c708ca91efc7e7e428541f27b23cd88cf197469dbbb47">,
      #splice.entry<"/build/gawk-5.4.1/m4/inttypes-pri.m4" file 644 mtime 1783615620 "b7f4f7f8ac2164cbf4db48575021c5b09a186d97695b64b5a48428ea5676c999">,
      #splice.entry<"/build/gawk-5.4.1/m4/inttypes.m4" file 644 mtime 1783615620 "75d10ed4eff774c09e289a776e2740921fa6bd9acb258ec5a9d35da13860ea40">,
      #splice.entry<"/build/gawk-5.4.1/m4/inttypes_h.m4" file 644 mtime 1783615620 "1a64e5ef039bb202b30627e7adcb8734249ee6dd40a0f3c2ca4215945fac4137">,
      #splice.entry<"/build/gawk-5.4.1/m4/lcmessage.m4" file 644 mtime 1783615620 "9f8d7956e4fc07da4b9c7181aa3539621e5dca466b8c28c8dcc2692fc1338e91">,
      #splice.entry<"/build/gawk-5.4.1/m4/lib-ld.m4" file 644 mtime 1783249447 "2cfcbcd1232eebcfb93a63324afd8bdc96213814bc423f9367e927ff9ea10510">,
      #splice.entry<"/build/gawk-5.4.1/m4/lib-link.m4" file 644 mtime 1783249447 "7c67c311d0ffe0bb97fb0bbae1a32b93127ff87e2f43cfc50a73f022b1335ff8">,
      #splice.entry<"/build/gawk-5.4.1/m4/lib-prefix.m4" file 644 mtime 1783249447 "4e123a4c3d45374e97b8be4a8bab6b29a8b41052ea6dc568f4ca57790253f134">,
      #splice.entry<"/build/gawk-5.4.1/m4/libtool.m4" file 644 mtime 1782131302 "9d339ec012f506838bcb0013ad2b74b300e6b24543bb59e68b644506bcb1cde7">,
      #splice.entry<"/build/gawk-5.4.1/m4/lock.m4" file 644 mtime 1783615620 "061d8774530bdb7e09978079ccffe414f160ed4b34ba493f04897d84ce599c4e">,
      #splice.entry<"/build/gawk-5.4.1/m4/longdouble.m4" file 644 mtime 1783615620 "f07b97c83dceb831be2dce55638f576e5a0226e8512d33dc6b6fd6643e1de227">,
      #splice.entry<"/build/gawk-5.4.1/m4/longlong.m4" file 644 mtime 1783615620 "d69a64b3f2abc63a974493f6a6131f44a3317e1bd812f54a295e9b81c56c90ff">,
      #splice.entry<"/build/gawk-5.4.1/m4/ltoptions.m4" file 644 mtime 1783615620 "f3d4ed0426501308028dd7690cf343cb280479d637a2ebee6c289ec2e708df3b">,
      #splice.entry<"/build/gawk-5.4.1/m4/ltsugar.m4" file 644 mtime 1783615620 "0896f153a5a40546566028a4272642ae291532f3e65c25fcae950c8812b8c265">,
      #splice.entry<"/build/gawk-5.4.1/m4/ltversion.m4" file 644 mtime 1783615620 "2a6baf40b64f34234e0b76c7ff62b01a1f6bbf60089f4f74506b49f800ffaf9e">,
      #splice.entry<"/build/gawk-5.4.1/m4/lt~obsolete.m4" file 644 mtime 1783615620 "8533006830e1ea9625fc5e4c060e653eedf9d5464a9b2f5f494244ee272e2e2f">,
      #splice.entry<"/build/gawk-5.4.1/m4/mpfr.m4" file 644 mtime 1782131302 "843b610a40c76f7aeb263f55215047281da888158fcd16bfed66d37c0de15abe">,
      #splice.entry<"/build/gawk-5.4.1/m4/nls.m4" file 644 mtime 1783249447 "f727c8ea4af7b3ca541329c08d51b6288a0e2df5fe415ffcac994117638567ba">,
      #splice.entry<"/build/gawk-5.4.1/m4/noreturn.m4" file 644 mtime 1782131302 "bb8e50ae6218efba2d76c57f041257a61830850e836d111516ad067ffeea4190">,
      #splice.entry<"/build/gawk-5.4.1/m4/pma.m4" file 644 mtime 1783615620 "dcb43bac10dae699fbbad813e08d6ce4d0f1fdf3abe8a5a684bdefdf60b73248">,
      #splice.entry<"/build/gawk-5.4.1/m4/po.m4" file 644 mtime 1782131302 "2b0014754884aa7aaa581a9dd848ca83e3420781ad76ed2bef8a733e811ea112">,
      #splice.entry<"/build/gawk-5.4.1/m4/printf-posix.m4" file 644 mtime 1783615620 "914aabd36493c03cccaf5476c72be3e4fada00e7f68f1ae4fe7c2ebf797fe5c7">,
      #splice.entry<"/build/gawk-5.4.1/m4/progtest.m4" file 644 mtime 1783598640 "30d63275d7bee9e04787087dccd49508024cf8ec27263da9adf925a595804183">,
      #splice.entry<"/build/gawk-5.4.1/m4/readline.m4" file 644 mtime 1782131302 "9cf1f6d5093e1943dd548a9c568dfaafdef824d28a3ceac1cea69297e6bff31f">,
      #splice.entry<"/build/gawk-5.4.1/m4/signed.m4" file 644 mtime 1783615620 "0bf99ebe1c1b29656fc9a7c235b20b56dd82503168815df6b02805e687673985">,
      #splice.entry<"/build/gawk-5.4.1/m4/size_max.m4" file 644 mtime 1783249447 "1b8de3a3e7890f797dd9f8f6405ed4df48f32905eeda621b89806035aaa44b1c">,
      #splice.entry<"/build/gawk-5.4.1/m4/socket.m4" file 644 mtime 1783241692 "b215a3430397721378be52851c999789a652b3a067c030f1c420e2bff057e3dc">,
      #splice.entry<"/build/gawk-5.4.1/m4/stdint_h.m4" file 644 mtime 1783249447 "e2501e7b014197e33d38d76931c8cc67873677d2df5b0be721ce284efad6112c">,
      #splice.entry<"/build/gawk-5.4.1/m4/threadlib.m4" file 644 mtime 1783615620 "662e956571a313658e441b30c8563a83290f1e94538873f48c3fb4d5633d8270">,
      #splice.entry<"/build/gawk-5.4.1/m4/triplet-transformation.m4" file 644 mtime 1783602868 "079f590e01ffed797d216995849585a56c4301c01a0e84aa4f5a65445ac9604e">,
      #splice.entry<"/build/gawk-5.4.1/m4/uintmax_t.m4" file 644 mtime 1783615620 "f86dba0ce3c36d90f1011f0f5814a6de1423cc3eb1bdb26fb2853d156d5e8812">,
      #splice.entry<"/build/gawk-5.4.1/m4/visibility.m4" file 644 mtime 1783615620 "afa44e0cb091795caaf92ab89cf75dcc7693a4bf9e720cdf6589df854c5fda6d">,
      #splice.entry<"/build/gawk-5.4.1/m4/wchar_t.m4" file 644 mtime 1783615620 "c22d74abaa99ed2f542f47780a1725d7a72c882d05df1a5fea5b3fc9cfb6e621">,
      #splice.entry<"/build/gawk-5.4.1/m4/wint_t.m4" file 644 mtime 1783615620 "8865ac6c07fb6710f2e292f17ddc3e50b4869626068c24d1da98b3d9c6e1b350">,
      #splice.entry<"/build/gawk-5.4.1/m4/xsize.m4" file 644 mtime 1783615620 "fd8d06ef52c18fa5b55870c8d78b150ec9f2b51dbbd40c68d9dbdfb989ac371c">,
      #splice.entry<"/build/gawk-5.4.1/main.c" file 644 mtime 1783615620 "0542fce6748ae8b476b8c39952ab749e65525dd983f88cd7ff8a096aef929c16">,
      #splice.entry<"/build/gawk-5.4.1/missing_d" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/missing_d/COPYING.LIB" file 644 mtime 1783241692 "9d5d268bbcbdcd395a8b74ed9028ef7b326b915bb06196ea01c78685e3f57bba">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/ChangeLog" file 644 mtime 1783615671 "3b803aa72f6d46db3d88c797a729fd1c54263902d952dc97585a5bc4f551b7fa">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/ChangeLog.0" file 644 mtime 1782131302 "7927b02bcf4756256b4ccf3c4210f453c0305d67cb1d744239c16d2e924dc7cb">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/ChangeLog.1" file 644 mtime 1782131302 "a02ef45b2254de57819cee368eb19f9e3eb1058558d49b46bcedf4391694b6b2">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/README" file 644 mtime 1782131302 "16a84b196b4947e54dcde6d1c97d2397a9ebba75afd931d80858fda968052f5b">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/fnmatch.c" file 644 mtime 1783329604 "f25894ec3a7b4b3a5609dd314234c37b77baa90b2c0582b92213e249e9764006">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/fnmatch.h" file 644 mtime 1783329604 "a57bb07a3d04d030329ca19b91c5745a76974ba6ca0ffdb91da05778b7e562cb">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/getaddrinfo.c" file 644 mtime 1782131302 "ffc4999d197826a922414dd1b8f2c7fcfc2a94fb9da5cb968f71e3a5cb57158d">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/getaddrinfo.h" file 644 mtime 1782131302 "f2f3ddc4ff30f321356d7c76012df38e93faa266aa45542eff05c3e9086887fe">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/stdio-consolesafe.c" file 644 mtime 1782131302 "304f5ac2249beaf758b37d2dc2d90c797595d6a599d70ad0b408478af2ba35ad">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/strcoll.c" file 644 mtime 1782131302 "639c5609ea3909fa64a8dab607719195cef751ef8b689f7260e745c39b7d5f79">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/strftime.c" file 644 mtime 1783329604 "c14c94e67fa24406628b4092f9a67052c6c4d9746013cdd8b13cc6153674b69e">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/strncasecmp.c" file 644 mtime 1783329604 "34f04b86b13c922ae23d45ec72709fdbc5da676807c3276dfe1d9578967e599e">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/strptime.c" file 644 mtime 1782131302 "07ed1c23aefb6e319a06b4d48ef0a338856dadb2b665bf2b62257ad9b03d1d60">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/strsignal.c" file 644 mtime 1782131302 "a4cd4196421b71d4016d1ad5b01efcd61c48bce9875125d1487a4f478b785046">,
      #splice.entry<"/build/gawk-5.4.1/missing_d/timegm.c" file 644 mtime 1782131302 "aaf1cf02228e3a159eb47e56b3b5ac94ee3efe44ea592c16b704dedd3ce27923">,
      #splice.entry<"/build/gawk-5.4.1/mpfr.c" file 644 mtime 1783615620 "d699b3c90e8e5e3b3e6d1ac3c1ca2c0152a8cc03c235c4ad685b581a6ee764ac">,
      #splice.entry<"/build/gawk-5.4.1/msg.c" file 644 mtime 1783365061 "bea82f279e9b6e5211bed50f9499638c16cfaacf3fc348972bf61e1ea21cc118">,
      #splice.entry<"/build/gawk-5.4.1/node.c" file 644 mtime 1783615620 "b64f32b7b3e31e6d6afb12a8035f7d5c98f0e85358d50b111d04e71fe2efa809">,
      #splice.entry<"/build/gawk-5.4.1/nonposix.h" file 644 mtime 1783241692 "676f226b5012f903a2223aa13a6b01a5a92411f60be1d242d7ac081926624da2">,
      #splice.entry<"/build/gawk-5.4.1/pc" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/pc/ChangeLog" file 644 mtime 1783615671 "83def29f1f5231176418163a88e8667b7fc057f4e6deb62952fe6efde0d5b5dc">,
      #splice.entry<"/build/gawk-5.4.1/pc/ChangeLog.0" file 644 mtime 1782131302 "f7ca6df858f90b98a3a9299ae2ac5d32065f9dba6fc78b954148ca9b6a53d40f">,
      #splice.entry<"/build/gawk-5.4.1/pc/ChangeLog.1" file 644 mtime 1782131302 "aaaee9ad247599022f70bdb33a42d76a07f8f0fb41949aafda0933788050ce2a">,
      #splice.entry<"/build/gawk-5.4.1/pc/GenMakefileTst.awk" file 644 mtime 1783241692 "df2b3d8d916d748d66497e55fa1b459ce8fd6399c33dd54eac731b1f66fa56ec">,
      #splice.entry<"/build/gawk-5.4.1/pc/Makefile" file 644 mtime 1782131302 "33c8b9b94f5fb624f2dcb908cfa8b74870c7902f99d2cec78363a8f2de85c843">,
      #splice.entry<"/build/gawk-5.4.1/pc/Makefile.ext" file 644 mtime 1782131302 "ff39953f7879fd0b38b1fc29ffb5576059192333f1d3eb330d13dbb2eeb3a827">,
      #splice.entry<"/build/gawk-5.4.1/pc/Makefile.tst" file 644 mtime 1783615722 "13fcc948a5db5cee4cba2eca4e6d3208b153dcfd217df454cf92a2a5682412aa">,
      #splice.entry<"/build/gawk-5.4.1/pc/Makefile.tst.prologue" file 644 mtime 1783249447 "f9ed92ca19952d80d665d70562714bb7397b21302b18e77a02c0d9784e0d516f">,
      #splice.entry<"/build/gawk-5.4.1/pc/awklib" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/pc/awklib/igawk" file 644 mtime 1782131302 "ec178a57a4e10a5aea4a85fdb039cc64a4abe58935437e773d62e319913c5974">,
      #splice.entry<"/build/gawk-5.4.1/pc/awklib/igawk.awk" file 644 mtime 1782131302 "9963737afd070ecc45277684789da1d0815bd993f6a4d94f18a1c174f246fbbf">,
      #splice.entry<"/build/gawk-5.4.1/pc/awklib/igawk.bat" file 644 mtime 1782131302 "7346232f88078d5f0ede6fbf51cee496f8e4bcc5ea110781b273be7524d02a0a">,
      #splice.entry<"/build/gawk-5.4.1/pc/config.h" file 644 mtime 1783615765 "25dbed8b8a7e6cd921deb76dce09d675063d269a0e86b0f2176d244306ec9964">,
      #splice.entry<"/build/gawk-5.4.1/pc/config.sed" file 644 mtime 1783329604 "86d9815ce3cb9fcc847729c126dd111f9a8bf74932c033b8df61ab62be8716d5">,
      #splice.entry<"/build/gawk-5.4.1/pc/configpk.sed" file 644 mtime 1782131302 "787e55ba6eed3bb4a2f0b29594af3c91fdb077208b02e3b90a5bf7a8a4c3a440">,
      #splice.entry<"/build/gawk-5.4.1/pc/dlfcn.h" file 644 mtime 1783329604 "a41042c66c0627f0906a7ff32fd2e0d865a30bee3a79e96573bf7ea96a137a46">,
      #splice.entry<"/build/gawk-5.4.1/pc/gawk.def" file 644 mtime 1782131302 "cc0e9fed10e0febea5710ee3dc05dcc579e2b89234ccd0a527cb78010e0fb2ff">,
      #splice.entry<"/build/gawk-5.4.1/pc/gawkmisc.pc" file 644 mtime 1783241692 "03ffcf77978de029be4920a1bbd84502dceb62ba77e4754665d16f00bc70295f">,
      #splice.entry<"/build/gawk-5.4.1/pc/getid.c" file 644 mtime 1783329604 "e4a8e429bd2fd7fd49c0aece8bc72656c1f13041fa04183dc9e25de6fbb154ff">,
      #splice.entry<"/build/gawk-5.4.1/pc/in.h" file 644 mtime 1782131302 "7575c9ff31dcff450828142ebabf301a17639b75e9011499afeff8848c526abd">,
      #splice.entry<"/build/gawk-5.4.1/pc/install.awk" file 644 mtime 1782131302 "1ad668bdedd3806f1c96a725efdcde9800338a224c030bf5859c93114cf4165b">,
      #splice.entry<"/build/gawk-5.4.1/pc/langinfo.h" file 644 mtime 1782131302 "0369a8e10e4f7cd8b7402118adecf1ed3ec2ee5275220c2260cd838e9b9c267a">,
      #splice.entry<"/build/gawk-5.4.1/pc/make-config.bat" file 644 mtime 1782131302 "5d8d65c30a4c93b3afa56ea5c5f1af29d212abcc3a6442c1bee3e3626e2e04bf">,
      #splice.entry<"/build/gawk-5.4.1/pc/make-config.sh" file 755 mtime 1782131302 "2cf7728abf113f8edc21619ad3f305ea456472c8eff9bc9ace031b7082ea0f1a">,
      #splice.entry<"/build/gawk-5.4.1/pc/mbc32.c" file 644 mtime 1783241692 "f9cf9cd02644e6ecab0e18d824ac057d207c694af6b6409f019d25e4e23b44de">,
      #splice.entry<"/build/gawk-5.4.1/pc/mbc32.h" file 644 mtime 1783241692 "f3e05f1eff1fffc05ebf997c21ab69c8bed29c96dad931555e02011679f53fb6">,
      #splice.entry<"/build/gawk-5.4.1/pc/mkinstal.sh" file 644 mtime 1782131302 "bc7b71ab013235ae50fa15738664f958ac5abf92ce880552b9d79ba47181036b">,
      #splice.entry<"/build/gawk-5.4.1/pc/nl_langinfo.c" file 644 mtime 1783241692 "969dea645e16bb76131cc17bc2f08cdf61edf120d5beba62d97a45c1411cbff2">,
      #splice.entry<"/build/gawk-5.4.1/pc/popen.c" file 644 mtime 1783241692 "fa8e4bbd604168266fd770a45e98bd84c91f7b7a2abb1c5655bf59a994782e52">,
      #splice.entry<"/build/gawk-5.4.1/pc/popen.h" file 644 mtime 1783329604 "700154d2d2d2f4b26ba41973b4ab66f1c858ca61b7dbe3f92e313f57d50a9757">,
      #splice.entry<"/build/gawk-5.4.1/pc/socket.h" file 644 mtime 1783329604 "d4fda453539450278630713e8e45b16ee66da0c7a74fab4d0d250d69362ea27a">,
      #splice.entry<"/build/gawk-5.4.1/pc/testoutcmp.awk" file 644 mtime 1783329604 "1c1423a3f2c25b030268ce603057d3a79f1a919b3a4180779f25952917baebee">,
      #splice.entry<"/build/gawk-5.4.1/po" dir 755 mtime 1783615763>,
      #splice.entry<"/build/gawk-5.4.1/po/ChangeLog" file 644 mtime 1783615671 "f526e3310a8d6c3a123cee76373a66407e20dc48dbba15863393710bee0d2217">,
      #splice.entry<"/build/gawk-5.4.1/po/ChangeLog.0" file 644 mtime 1782131302 "593772703f5843a35ff61061df4711ed4a5a30b6c1fec68f4ceb825d1de8c7c7">,
      #splice.entry<"/build/gawk-5.4.1/po/ChangeLog.1" file 644 mtime 1782131302 "45625beac1211fa6b717b9fab24b2770d6c9522233a2fdd6f65b7a56500fd519">,
      #splice.entry<"/build/gawk-5.4.1/po/LINGUAS" file 644 mtime 1783241692 "378324156579468fc9edf1298e259aa2edd1d8d2c22b937ded0f405052ca396a">,
      #splice.entry<"/build/gawk-5.4.1/po/Makefile.in.in" file 644 mtime 1782131302 "b9146b0739ad3c5c319a4b072a02a8cdfd31f107376857cfb299fb2ea319784b">,
      #splice.entry<"/build/gawk-5.4.1/po/Makevars" file 644 mtime 1782131302 "133674bca1cb6237ab0482182a7cdaccb25dcf05b3296551187ff9e38415ba30">,
      #splice.entry<"/build/gawk-5.4.1/po/POTFILES.in" file 644 mtime 1782131302 "de3335e5a18a99cf0c4ff6ef04b6ea5932b61e892e286e11312ee8f80a54d6e4">,
      #splice.entry<"/build/gawk-5.4.1/po/README" file 644 mtime 1782131302 "203737098b6eac152dac27d3c35a9da8353130686d644ff2c3ea7a77ee85dfd2">,
      #splice.entry<"/build/gawk-5.4.1/po/Rules-quot" file 644 mtime 1782131302 "8ced8cd2b86458be88c38322db49df53f41f87200a79233ce34499cb031db0cd">,
      #splice.entry<"/build/gawk-5.4.1/po/ar.gmo" file 644 mtime 1783615734 "48774da3bf925455bebef55f1ebbc19ac081c8c6008c548ae940c13377fbe27b">,
      #splice.entry<"/build/gawk-5.4.1/po/ar.po" file 644 mtime 1783615671 "53556739811a626e5b25934b963675183595ed9feeb1a25fb80bfea1cdbdebf8">,
      #splice.entry<"/build/gawk-5.4.1/po/bg.gmo" file 644 mtime 1783615734 "21a707a9a95f70d2e1aa6ada17b914c5e273d5f2737d15031067d7b95145e225">,
      #splice.entry<"/build/gawk-5.4.1/po/bg.po" file 644 mtime 1783615671 "49b3cc3246775f6239e66d6d290e28ed39c1b2760cbb611407ac9f8b567bc62e">,
      #splice.entry<"/build/gawk-5.4.1/po/boldquot.sed" file 644 mtime 1782131302 "33234736a58f1610c73e1c8c08faf1b2ef1397d878dd7d2cbd888ca0f2da4ffc">,
      #splice.entry<"/build/gawk-5.4.1/po/de.gmo" file 644 mtime 1783615734 "09b71d7cd3b3fce323e223525648a321c055076ad21a637e1aa9b56b7256f329">,
      #splice.entry<"/build/gawk-5.4.1/po/de.po" file 644 mtime 1783615671 "fe8694091b6e952d30efd55e2dfac9d9903fbf96a6a5b98aed29af00b4dbe5fe">,
      #splice.entry<"/build/gawk-5.4.1/po/en@boldquot.header" file 644 mtime 1782131302 "99ad82767e9b1b4dd1e413664e06c686c8ab70eaadb129ac08a8b8b76f9173d2">,
      #splice.entry<"/build/gawk-5.4.1/po/en@quot.header" file 644 mtime 1782131302 "6f4df89908e6e413db10738ff01e0c7046922c2a4aa4f9e64d376235745a4af5">,
      #splice.entry<"/build/gawk-5.4.1/po/es.gmo" file 644 mtime 1783615734 "5a5fa47c0bdb475a4b70ae5172ee71c2cd27e215d375da8b88bf18a82e0520a4">,
      #splice.entry<"/build/gawk-5.4.1/po/es.po" file 644 mtime 1783615671 "2365ee9e4d6f230a0cff866d024195015d4dbf9061ae22f36f9ec7cadfb1a04a">,
      #splice.entry<"/build/gawk-5.4.1/po/fr.gmo" file 644 mtime 1783615734 "a83a91fcbd637f2076670d995931e408cb80201f1dab9e6f1b86a6139868d6e7">,
      #splice.entry<"/build/gawk-5.4.1/po/fr.po" file 644 mtime 1783615671 "e93efc21aaa77b7d7a8ed3c0821abac4e92218b399bf338501ad489e60066d0a">,
      #splice.entry<"/build/gawk-5.4.1/po/gawk.pot" file 644 mtime 1783615671 "2b5ad10b96f5e384a9c3b8bbcd0b0d9b4dbede67cfd8e695e5acc96704810f39">,
      #splice.entry<"/build/gawk-5.4.1/po/he.gmo" file 644 mtime 1783615734 "cc7ddfe25cabfb02a0c2f195ef6a300c60be9a267c8fcd3e56826779b6ef0d45">,
      #splice.entry<"/build/gawk-5.4.1/po/he.po" file 644 mtime 1783615671 "af53433220b4a4ab5557edf56274f17c0cccd9fc235899e8cca8b36c238691c6">,
      #splice.entry<"/build/gawk-5.4.1/po/id.gmo" file 644 mtime 1783615734 "c98cd37fedf7a085b7bfbbaec5756ae9504efe4ff7da729ba7b54aa51313a8a4">,
      #splice.entry<"/build/gawk-5.4.1/po/id.po" file 644 mtime 1783615671 "6e470952031dd23651dad8f29034a5a65ce7567f76f20219f578af3aa00c1232">,
      #splice.entry<"/build/gawk-5.4.1/po/insert-header.sin" file 644 mtime 1782131302 "87041830aa4c5e87cedd35a2a95cf94c4e889604580481430b214422a5e8dc98">,
      #splice.entry<"/build/gawk-5.4.1/po/it.gmo" file 644 mtime 1783615734 "3e8be808adadb94e4cee366fc624a837d941595e440076d85edee1158eb3c6cb">,
      #splice.entry<"/build/gawk-5.4.1/po/it.po" file 644 mtime 1783615671 "d14680cd1e4c2fa2ff5091abb7976b8c5b37c2f9391fe915126a14eac2b11dd6">,
      #splice.entry<"/build/gawk-5.4.1/po/ka.gmo" file 644 mtime 1783615734 "59df374f5479e9b930ec2df12603a6eb97c552049c2cfe18ee562dd3d626521f">,
      #splice.entry<"/build/gawk-5.4.1/po/ka.po" file 644 mtime 1783615671 "21132cc0a41ee43b0fed3bbe01496d672b1bfd3c3e32fe3a948cc4f2aedd5fde">,
      #splice.entry<"/build/gawk-5.4.1/po/ko.gmo" file 644 mtime 1783615734 "b77447a805997385ab9f5b3ca9fcba0da801dce5c90395774ba31b797b70d194">,
      #splice.entry<"/build/gawk-5.4.1/po/ko.po" file 644 mtime 1783615671 "cd109f3b1befe9d33fbed101af404aa190e3ec30e6675bae0e695f8554ea0126">,
      #splice.entry<"/build/gawk-5.4.1/po/nl.gmo" file 644 mtime 1783615734 "2fdea38e0f249490f67c21743d277e9ff7d87520a54181403f19ffbbde8b2546">,
      #splice.entry<"/build/gawk-5.4.1/po/nl.po" file 644 mtime 1783615671 "ee996300a981388d38f3783e02b3ffa99caeb1a416956ab9fa64dd3f23cd98f5">,
      #splice.entry<"/build/gawk-5.4.1/po/pl.gmo" file 644 mtime 1783615734 "ee0548d4f8c9abd2336c25747956ab53e0addeb2daee58e3799fb6af4e4ab45b">,
      #splice.entry<"/build/gawk-5.4.1/po/pl.po" file 644 mtime 1783615671 "18ea432ecc2030771dc254e3fee069499e59dcebf359e5af2689dbbd5687c4dd">,
      #splice.entry<"/build/gawk-5.4.1/po/pt.gmo" file 644 mtime 1783615734 "27605ef60422d0fd9b471151ef4bd6071a5ccc528f7a05e83f03bfc04b86ec0c">,
      #splice.entry<"/build/gawk-5.4.1/po/pt.po" file 644 mtime 1783615671 "ab0bfa83fc111ab7644d509703b69b02da66b4e4ac4ee89a206f543e85584c41">,
      #splice.entry<"/build/gawk-5.4.1/po/pt_BR.gmo" file 644 mtime 1783615734 "1eb3db2211cbdfe6d1b095ce014907494183aee8de017c22d8dd73a80774c3c9">,
      #splice.entry<"/build/gawk-5.4.1/po/pt_BR.po" file 644 mtime 1783615671 "1d0f399d6b3f986a61d0604d6a68b6b0ebd292670a7a0a0cbb2d77f4a6de136e">,
      #splice.entry<"/build/gawk-5.4.1/po/quot.sed" file 644 mtime 1782131302 "d19ab2cc69000c1206f1b8460952857f05d154158da8b89273ac2900a5c80ec0">,
      #splice.entry<"/build/gawk-5.4.1/po/remove-potcdate.sin" file 644 mtime 1782131302 "d582513385c800f75224f4041fbff207053d4229be6038c6810af382420ac362">,
      #splice.entry<"/build/gawk-5.4.1/po/ro.gmo" file 644 mtime 1783615734 "6f38622d4fb10de8e1ebb12e3f7d6b1dfa0d8190168a1ed57adee00f365b6b63">,
      #splice.entry<"/build/gawk-5.4.1/po/ro.po" file 644 mtime 1783615671 "9acdcad1a56b36c48cabf4868445adbfc9ba4617490ef0aa9aa019612c90275a">,
      #splice.entry<"/build/gawk-5.4.1/po/sr.gmo" file 644 mtime 1783615734 "0e480e50e37de7ca77ad7d802ccbc15994ba092d297c679e9f12466e89ac893f">,
      #splice.entry<"/build/gawk-5.4.1/po/sr.po" file 644 mtime 1783615671 "fff533fe70804b9561adad7ed79149e365882680a3bee4c320329a9e0421fb9f">,
      #splice.entry<"/build/gawk-5.4.1/po/stamp-po" file 644 mtime 1783615734 "2cd8ec3de6a07e1fd39676100db57ba62372e820c19812fee55899f65746e192">,
      #splice.entry<"/build/gawk-5.4.1/po/sv.gmo" file 644 mtime 1783615734 "97b8dfacb77e11e2b207188952c54408a6cae29812c0ef5ee006d68666cddd1b">,
      #splice.entry<"/build/gawk-5.4.1/po/sv.po" file 644 mtime 1783615671 "dba68dd956a4e6e15a85074e5bb9d2ced5119c72d0ddd48214a484bf4b7b0163">,
      #splice.entry<"/build/gawk-5.4.1/po/tr.gmo" file 644 mtime 1783615734 "2f2761eebdc66c30ea337480508cd0f1ffc5489b76f8f5042d7090fca7c7b734">,
      #splice.entry<"/build/gawk-5.4.1/po/tr.po" file 644 mtime 1783615671 "fb9ead7337418df4369d2889cd70e7d7308698f53be594c42a9669dda26f471f">,
      #splice.entry<"/build/gawk-5.4.1/po/uk.gmo" file 644 mtime 1783615734 "6b122a7d814f2eae300ce6fcaad4a650cb1970fda19c23945a5f3a90e6ed231f">,
      #splice.entry<"/build/gawk-5.4.1/po/uk.po" file 644 mtime 1783615671 "9b75ace1bc228787549322cd0d522c1047250b6e763f5e164dc48822751f7a39">,
      #splice.entry<"/build/gawk-5.4.1/po/zh_CN.gmo" file 644 mtime 1783615734 "9ac1b985c7cedb91be451e7bf7d7470ed84cdbe085cfb29262a5a9bcef542512">,
      #splice.entry<"/build/gawk-5.4.1/po/zh_CN.po" file 644 mtime 1783615671 "f4a94ff5ec7d9808d8dbe6a6e27d413b948f61e800bc53fadd5360ee04a284d6">,
      #splice.entry<"/build/gawk-5.4.1/posix" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/posix/ChangeLog" file 644 mtime 1783615671 "31e63d87b88c476eedda8d33422fcea2d74bcc8643f3d47978e10eabb1c1c7c6">,
      #splice.entry<"/build/gawk-5.4.1/posix/ChangeLog.0" file 644 mtime 1782131302 "de0d7cbf278c4e067b6e9cc99b6b49561aafbd71235b8683d03130b9cda93b4e">,
      #splice.entry<"/build/gawk-5.4.1/posix/ChangeLog.1" file 644 mtime 1782131302 "d186c35aace640225ccca5232e4e87bcc844a55570baaff3e71fc5ca5a5fcc0b">,
      #splice.entry<"/build/gawk-5.4.1/posix/gawkmisc.c" file 644 mtime 1783241692 "965bd70cbbd365a48e6e6037ee16fea201fe7756c8b311c206d6db3ce3cc1b45">,
      #splice.entry<"/build/gawk-5.4.1/printf.c" file 644 mtime 1783615620 "198e33b23af6ac89fae7daeab23958907eaf6e38ddca41223e537507a0e0dc3f">,
      #splice.entry<"/build/gawk-5.4.1/profile.c" file 644 mtime 1783365061 "8bf3bfaf036c35584b8eb6ca2545bb6745d797a13fbdc8c5a0f9f3f57348aba0">,
      #splice.entry<"/build/gawk-5.4.1/re.c" file 644 mtime 1783615620 "37b3c6340e17260e63fe799757ab13a71943ed012aa44c4d181a8fedbc3620ca">,
      #splice.entry<"/build/gawk-5.4.1/replace.c" file 644 mtime 1783241692 "32b05055740121b1f81a3c2982a20d71e1d3561bf12fdb882be945872e671491">,
      #splice.entry<"/build/gawk-5.4.1/str_array.c" file 644 mtime 1783615620 "6a4d67d28dc422d31d3c3c50c11251ca1fb39f51031e8082fc1a0f7a91a8824e">,
      #splice.entry<"/build/gawk-5.4.1/support" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/support/ChangeLog" file 644 mtime 1783615671 "f5c165a04f7d997485dd562a01878a4b4bc3aa3b31dbaf5eb0b0057b08e298d8">,
      #splice.entry<"/build/gawk-5.4.1/support/ChangeLog.0" file 644 mtime 1782131302 "211c80852c99eca0feee58d837d0b2fea2a0de5cd9f826bbdb10282416028dcc">,
      #splice.entry<"/build/gawk-5.4.1/support/Makefile.am" file 644 mtime 1783241692 "9963e43e0fe31d890556e8f3903d37dc0fc21226b31f688f4dfa9586e09ecf9b">,
      #splice.entry<"/build/gawk-5.4.1/support/Makefile.in" file 644 mtime 1783615715 "23b17affa9b11af264bf72a1c426df16e243523a8a79e2a88becdc9e9c95f386">,
      #splice.entry<"/build/gawk-5.4.1/support/attribute.h" file 644 mtime 1783241692 "cffd9e52eb49499e1710488018b077d501c61d7a2593cce63fcc3dc61b244888">,
      #splice.entry<"/build/gawk-5.4.1/support/cdefs.h" file 644 mtime 1783249447 "cc42b86c5d414ff3b487ea1c02e15973c5d1e7b310cbddff06a5cbfd6316a471">,
      #splice.entry<"/build/gawk-5.4.1/support/charset.c" file 644 mtime 1783249447 "380f0d45f60d07f2877cfeddd9946fb45fa62dd08e7446fe168bce331778d32c">,
      #splice.entry<"/build/gawk-5.4.1/support/charset.h" file 644 mtime 1783241692 "78cd7f01450963b26667c824b57424d885b52cfb688ea2c572e871706e2b9ac2">,
      #splice.entry<"/build/gawk-5.4.1/support/dfa.c" file 644 mtime 1783328483 "461e988a6f3d10b470167f2e8f1aa7b951339c2b3f4d96ec821817688a766b0b">,
      #splice.entry<"/build/gawk-5.4.1/support/dfa.h" file 644 mtime 1783615620 "cbad862573a65b4e6c8df72b840b4865dd79c49c8d113345fabe8f2844c21518">,
      #splice.entry<"/build/gawk-5.4.1/support/dynarray.h" file 644 mtime 1783241692 "9e6542a6dbd00d3b1b54042bfd39872a028089efe30a7ec0f82c1e2a192429e1">,
      #splice.entry<"/build/gawk-5.4.1/support/flexmember.h" file 644 mtime 1782830410 "a8ded8488adeab40968af801833303c7aa426629190414e5b1b1ce1be9b5a61e">,
      #splice.entry<"/build/gawk-5.4.1/support/getopt.c" file 644 mtime 1782131302 "4a97033af3a1914c8effc3871a723c04f94b0d632a99922b89b4c0fb2a11e22a">,
      #splice.entry<"/build/gawk-5.4.1/support/getopt.h" file 644 mtime 1782131302 "8b2f23629e87c29e1109309403590324bc653dd58d83f621d4c7eb36c7f22661">,
      #splice.entry<"/build/gawk-5.4.1/support/getopt1.c" file 644 mtime 1782131302 "fed53b3ced0a2e4227788a14a39155116ccbcbc9516a03af800346bb7c5ba3b3">,
      #splice.entry<"/build/gawk-5.4.1/support/getopt_int.h" file 644 mtime 1782131302 "728c394b52d85467897068420089ed7bb543ccc469c8573dcd753b2ab0ab9320">,
      #splice.entry<"/build/gawk-5.4.1/support/idx.h" file 644 mtime 1783249447 "54e9885422dcf95621253fb756081ccda186385e5f4fce97077034be981203d8">,
      #splice.entry<"/build/gawk-5.4.1/support/intprops-internal.h" file 644 mtime 1783328483 "5d4cba9f0a3a7996cac4c409b557787c0b34dc30b1a6e74f921f8402f094d1c4">,
      #splice.entry<"/build/gawk-5.4.1/support/intprops.h" file 644 mtime 1783249447 "2722c9eb6a43187d6c4d5b3075accf79112b7c214bc0ebcb27a5ba313aed1ef6">,
      #splice.entry<"/build/gawk-5.4.1/support/libc-config.h" file 644 mtime 1782830336 "afded288e17a752f7d2723f042d9def7487d980d40ab1afed3b7b1cb7c92eed7">,
      #splice.entry<"/build/gawk-5.4.1/support/localeinfo.c" file 644 mtime 1783328483 "352719f6548482df954aabcea4482476f48262d809a3e07053b5bf4889093fce">,
      #splice.entry<"/build/gawk-5.4.1/support/localeinfo.h" file 644 mtime 1783615620 "6febb6c50514aaaade5cbc39111bbb157c08e2e4b64a010c3aab69fcfbdcf873">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc" dir 755 mtime 1783615761>,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray-skeleton.c" file 644 mtime 1782830336 "b8257351f3a4eb46d9c69af125eba1cb6917f0fb31ad83648cc1332d6fcf6b4d">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray.h" file 644 mtime 1783615620 "395c055e9c682debdc643651d342ef371de4b5461aa0e6ec599962466b247587">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_at_failure.c" file 644 mtime 1782830336 "a6fc69bafbf953a961268f3eb90ea7d9ebd927c80ab7aeef51f70b4a597f8390">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_emplace_enlarge.c" file 644 mtime 1782830553 "85df1a4babd2828ee9ecee2f8c37a60d7e5ac3ab770a8a332f76357b4ff21997">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_finalize.c" file 644 mtime 1782830336 "eb724badd2ad871d0af0d38814fdfd8ecb5b055a3a32d0eb4fbebd6a3f5a5318">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_resize.c" file 644 mtime 1782830564 "104d9962dcedbfbeaad6ceac3f73b04d0f22a2b6ba6ed6590f17839e1c9a799e">,
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_resize_clear.c" file 644 mtime 1782830336 "60620888d1e3917ad45442b35b3d81876e4656158e899aff86171d236fc77182">,
      #splice.entry<"/build/gawk-5.4.1/support/minrx.c" file 644 mtime 1783249447 "f5bfdf65850708a536dfaa1d486015cee56229b9c85d9969da4b1756373bcb8a">,
      #splice.entry<"/build/gawk-5.4.1/support/minrx.h" file 644 mtime 1782131302 "441cc663cef041c3bc87b82b0090a0f8f9e31b79e6c790ad676496e2b7389aa2">,
      #splice.entry<"/build/gawk-5.4.1/support/pma.c" file 644 mtime 1783249447 "cf4aec6eadf5a9b9c14c36117746d68fe3399f3fdd0f22ec916a896e26cb9b3d">,
      #splice.entry<"/build/gawk-5.4.1/support/pma.h" file 644 mtime 1782830602 "dfca7b296f6cb298ea37561e01325acf143e65bfa7b900f850abd892e723d704">,
      #splice.entry<"/build/gawk-5.4.1/support/random.c" file 644 mtime 1782131302 "b307c4aa2b1c0806747e0b2505ccef3258e98a1b4e4e1b1f1b183de7f780f54d">,
      #splice.entry<"/build/gawk-5.4.1/support/random.h" file 644 mtime 1783365061 "d5cd22b7aab8beb25b81f03c46287da15304859ea7a837a5fd35636c2c8b483b">,
      #splice.entry<"/build/gawk-5.4.1/support/regcomp.c" file 644 mtime 1783328483 "c681f6934ce5438f21b4453f5383e6cbdaa4feed1ab80d7a9bede1e796ede821">,
      #splice.entry<"/build/gawk-5.4.1/support/regex.c" file 644 mtime 1783328483 "5480f6df554fa3a913f02a1eb952f37858a4649f024ff26532a3c8f6082123b8">,
      #splice.entry<"/build/gawk-5.4.1/support/regex.h" file 644 mtime 1783249447 "becfa1296f71daa47c2bf0ab1bdf579f62cfebae43fe7429f596829dfe9c237b">,
      #splice.entry<"/build/gawk-5.4.1/support/regex_internal.c" file 644 mtime 1783328483 "139c5a83f2b7b8ea0b490688d795d45b2c648e0061c9a571d34978c83452a091">,
      #splice.entry<"/build/gawk-5.4.1/support/regex_internal.h" file 644 mtime 1783615620 "232fe29aaefc5f30784cd07ed33e3f435db503cc91b6e6b96d9379185386f9d1">,
      #splice.entry<"/build/gawk-5.4.1/support/regexec.c" file 644 mtime 1783249447 "214b1aa9dc8ab3eb637fe2bbc274e9d67dba71a71ec8b9d9350e577966a672d7">,
      #splice.entry<"/build/gawk-5.4.1/support/verify.h" file 644 mtime 1782830336 "17b2baa879eb68155c790985d5a3189cf314b4d3482cd82258cb3a54e01ec258">,
      #splice.entry<"/build/gawk-5.4.1/support/xalloc.h" file 644 mtime 1782131302 "0c8a0593dd557a37f25402cd25b2221d4cd2b0d41e6b278a91caa9ce5343cee4">,
      #splice.entry<"/build/gawk-5.4.1/symbol.c" file 644 mtime 1783241692 "23fd3cf7e3a100d96523c36810447c1282b7ce935a62f57d944f837e905b264d">,
      #splice.entry<"/build/gawk-5.4.1/test" dir 755 mtime 1783615765>,
      #splice.entry<"/build/gawk-5.4.1/test/ChangeLog" file 644 mtime 1783615671 "69e425d397194158c02d48cd9cd932cae36bf0a9746521717626a8ad42b98bf6">,
      #splice.entry<"/build/gawk-5.4.1/test/ChangeLog.0" file 644 mtime 1782131302 "da4259e7d5a5b948450c020899b0f1a0e50b96dac889336cdc61496f1c57bd76">,
      #splice.entry<"/build/gawk-5.4.1/test/ChangeLog.1" file 644 mtime 1782131302 "89fa92df279087b97c38924fef89dc54a8007f89070f45369a37dc54d3e10ec0">,
      #splice.entry<"/build/gawk-5.4.1/test/Gentests" file 755 mtime 1783615620 "1897735db669a1a4abd3b6c967201a1e9897ecad31c175329d76993a5c8dd064">,
      #splice.entry<"/build/gawk-5.4.1/test/Makefile.am" file 644 mtime 1783615671 "447e3fdd76fe4ebb4b39427465aa727ed421a5818e568a00e00f2c5a90830ade">,
      #splice.entry<"/build/gawk-5.4.1/test/Makefile.in" file 644 mtime 1783615715 "90de3c026b441212dc3733a07fcacf4fe5f9d527b57fe7e76bb3af754c4692df">,
      #splice.entry<"/build/gawk-5.4.1/test/Maketests" file 644 mtime 1783615671 "902bf665d867dad5586dcd51c6010c42bdebe99a05462b283a71321b7bbd7d9c">,
      #splice.entry<"/build/gawk-5.4.1/test/README" file 644 mtime 1782131302 "0811f0dd18edf94041382065401979b5ba37661e53ee657f222ad4c9a8f2bba7">,
      #splice.entry<"/build/gawk-5.4.1/test/aadelete1.awk" file 644 mtime 1782131302 "71a93875cb69c5c32168a63f7310569a198602aa9e274b5b82ac41ba27118c56">,
      #splice.entry<"/build/gawk-5.4.1/test/aadelete1.ok" file 644 mtime 1782131302 "48449f71f8ae4b64bbfda8605978c3735782d66b9a563af05c00928be6725a88">,
      #splice.entry<"/build/gawk-5.4.1/test/aadelete2.awk" file 644 mtime 1782131302 "59656727ab87c2457843bbdc889df604152d542e77654a8ba9c6fac4f6ccf5b3">,
      #splice.entry<"/build/gawk-5.4.1/test/aadelete2.ok" file 644 mtime 1782131302 "e49bf7408ff2f90fb2da2d245e3075023aed373a7b883658b2b3eafbf85cffc1">,
      #splice.entry<"/build/gawk-5.4.1/test/aarray1.awk" file 644 mtime 1782131302 "cbc728bb1a5b7e285a03f0c1b1a9cadfcb269f1b72a7a34e96d7b39fe003a9d2">,
      #splice.entry<"/build/gawk-5.4.1/test/aarray1.ok" file 644 mtime 1782131302 "db6f67b8af745e8af9df4dc8cf96273feecf2d098c57658bfc2d55fc3b3f0dc3">,
      #splice.entry<"/build/gawk-5.4.1/test/aasort.awk" file 644 mtime 1782131302 "c6c413961b42ad1708b57c563dfadd5ab22c5f170817d877b87e01cb8680ac6b">,
      #splice.entry<"/build/gawk-5.4.1/test/aasort.ok" file 644 mtime 1782131302 "b216f1b04d849de5a9221c132ed5894682292fcb0591152b57d42111e9852dcc">,
      #splice.entry<"/build/gawk-5.4.1/test/aasorti.awk" file 644 mtime 1782131302 "49778b0d6fa1fc03cae223746cf0cc65907489df4ed75c3eb71f9409dec70215">,
      #splice.entry<"/build/gawk-5.4.1/test/aasorti.ok" file 644 mtime 1782131302 "bdf395ffc8607b2858a8b83fab400d21c19423bdcb2c85eeb79caaae00be53ba">,
      #splice.entry<"/build/gawk-5.4.1/test/addcomma.awk" file 644 mtime 1782131302 "c94d48296ec5f6a99e72f1472853a13403fac8046f750026e6d752c5f719aa82">,
      #splice.entry<"/build/gawk-5.4.1/test/addcomma.in" file 644 mtime 1782131302 "3697bc638682dff0c88e61d4f9ff81f97c92ba490a460d306594eb82e2991979">,
      #splice.entry<"/build/gawk-5.4.1/test/addcomma.ok" file 644 mtime 1782131302 "d7a017f66a1c0f64e8d59300599f865acc1cf3b72e4208372fdb73019d09f270">,
      #splice.entry<"/build/gawk-5.4.1/test/anchgsub.awk" file 644 mtime 1782131302 "35411e0a773a3293a611137f2ce596acca41dcf02a8c757d78d4794a3bbb1fb3">,
      #splice.entry<"/build/gawk-5.4.1/test/anchgsub.in" file 644 mtime 1782131302 "8e0cb18a0426dabe5dcd6a4e37862a32632915a092dc4c61b24e74de3e2ed5f6">,
      #splice.entry<"/build/gawk-5.4.1/test/anchgsub.ok" file 644 mtime 1782131302 "dca3839cd712b08be9bd8855a30862f41fb563def4721107575078af5fab10a1">,
      #splice.entry<"/build/gawk-5.4.1/test/anchor.awk" file 644 mtime 1782131302 "c969c5669f2a4e0256344daf71793f6f7000c47a8f0f29b3c246b48838d5e9e8">,
      #splice.entry<"/build/gawk-5.4.1/test/anchor.in" file 644 mtime 1782131302 "30c9eeb121d4b2d975c80d3b753c6340009025f7723908602c8e14e5b5dff8f0">,
      #splice.entry<"/build/gawk-5.4.1/test/anchor.ok" file 644 mtime 1782131302 "f50243709be69708a84d790d7552b435a8cff7ac7caad2c384a77f31f8ddd9ee">,
      #splice.entry<"/build/gawk-5.4.1/test/apiterm.awk" file 644 mtime 1782131302 "8350f4601632026b52734b3b3374a0dca812d191bd95a712ce111de4b38fcb74">,
      #splice.entry<"/build/gawk-5.4.1/test/apiterm.in" file 644 mtime 1782131302 "52f97780698e55ebcb8325dde3d318912a2b9829b622f88314d4d3cb2e98b710">,
      #splice.entry<"/build/gawk-5.4.1/test/apiterm.ok" file 644 mtime 1782131302 "9f21af38e4298dc7ede839a65698408af0735697101926c7e6ca7348999fcc70">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_elnew_sc.awk" file 644 mtime 1782131302 "cd92145c1590b86d7ca11cbafac858114c93a55bba9ea87b57962935b882f1ac">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_elnew_sc.ok" file 644 mtime 1782131302 "d40db04a3ce6842570341710187fee22e73044be38be04d5b0989e9cef2a3f64">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_elnew_sc2.awk" file 644 mtime 1782131302 "72d6aa94f17cb11e1ac02c33f63cd23b834f7cd65fe92762bf6bac1c2bf4f184">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_elnew_sc2.ok" file 644 mtime 1782131302 "16727d9b7b790bd19cef707adb66d3c6160ffc66bee72eae0afffeb3bb295336">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_fmod.awk" file 644 mtime 1782131302 "53357d9957815f1cfc07713ba5f56d3a68d9773c36f9aff843fd9dc8f2e02d2a">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_fmod.ok" file 644 mtime 1782131302 "ad81033c2242924339fee01819fd77c3ee9ec2810ac7592c4dc108be68737265">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_unxptyp_aref.awk" file 644 mtime 1782131302 "d9ca3fc01daec9b11e183e5da41d7fb40192e9ddb0f8ee954f582e0c718460b4">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_unxptyp_aref.ok" file 644 mtime 1782131302 "7f4c7f13296b57f926c7589688e282449021e2301937d809b00580e7ccceb591">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_unxptyp_val.awk" file 644 mtime 1782131302 "72d7491c0d48730a1a1dc2c5bd0e53ae04587fd566f02ed7671f09e1357b6c62">,
      #splice.entry<"/build/gawk-5.4.1/test/ar2fn_unxptyp_val.ok" file 644 mtime 1782131302 "758eb519367874242bfc53ad5269290a54df26055efbc29df2171dbb4fdb5731">,
      #splice.entry<"/build/gawk-5.4.1/test/argarray.awk" file 644 mtime 1782131302 "c0fa706f1db7e801dc06d2349d329705bbc0a3562f080f865119ecf4664e6db9">,
      #splice.entry<"/build/gawk-5.4.1/test/argarray.in" file 644 mtime 1782131302 "373002a85b3e92232828099a45892419689b90e3baf5b1c801d0126d43770f95">,
      #splice.entry<"/build/gawk-5.4.1/test/argarray.ok" file 644 mtime 1782131302 "28c2f128fe7f3a23fc9788d694452f30e83afe808552017e908a9f8979b69af8">,
      #splice.entry<"/build/gawk-5.4.1/test/argcasfile.awk" file 644 mtime 1782131302 "dcf2ce3529f851506741f69cdf9f99f4d91161a26c8025bd3c89902d26417017">,
      #splice.entry<"/build/gawk-5.4.1/test/argcasfile.in" file 644 mtime 1782131302 "b1b113c6ed8ab3a14779f7c54179eac2b87d39fcebbf65a50556b8d68caaa2fb">,
      #splice.entry<"/build/gawk-5.4.1/test/argcasfile.ok" file 644 mtime 1782131302 "707b10caf1cc5f8711925cdd37da5b732667af45400fe76561a7faccada12869">,
      #splice.entry<"/build/gawk-5.4.1/test/argtest.awk" file 644 mtime 1782131302 "21c789481e66d7c9f006ca5f457e049d1d53cf238e367aa788819959cf9bbb0e">,
      #splice.entry<"/build/gawk-5.4.1/test/argtest.ok" file 644 mtime 1782131302 "2745857c5220c2f4fa45badc3187afd5dad0c6e492d655e1aa5646e0a54a312d">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind1.awk" file 644 mtime 1782131302 "56f732c1eed7c317ad69077ae687185cde7e0d9ae3541b7a17178a196f688419">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind1.in" file 644 mtime 1782131302 "b32d1247c1618a11a234875da65c4800da873829b662d180f9090cc3af5bc2d7">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind1.ok" file 644 mtime 1782131302 "5530557a5189d59b433a681df5a90be2792f0a8b571dec9d9028106b6a286e73">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind2.awk" file 644 mtime 1782131302 "4975fc24d887d95777af83a6ce0b58eaaa70e40386c31187f5ec90da39f9e17e">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind2.ok" file 644 mtime 1782131302 "b971af5a692207a2777833430b3dd18820ec09032738f23b7a10660059e9294d">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind3.awk" file 644 mtime 1782131302 "86c3ee8dd56d3d5bc982f6cdfb7b45859eda41162b853e4d92d12b5c2a24f6ca">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayind3.ok" file 644 mtime 1782131302 "3c12fe54d72a8367b32e9790ef28fc275e579a72809e721bdaab61f41fd64c9e">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayparm.awk" file 644 mtime 1782131302 "8ba2b5a2d87a861168df6cc9b213f345ffec0b3aec26742d92a9aa7b471eca8f">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayparm.ok" file 644 mtime 1782131302 "fd8a9a7f1b753a1cf98f01ea842ae22e2cce0dcdb8f55edd2cae62d498b53adb">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayprm2.awk" file 644 mtime 1782131302 "d592cf1d5aeb15d51ac0b9a7b6ab13924c24decdecd17233d2140f85ed7bc42b">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayprm2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayprm3.awk" file 644 mtime 1782131302 "4250e1771b75c54427068fb5036c9f200a099244d8e6ab8b44e060884fdd5eb0">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayprm3.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayref.awk" file 644 mtime 1782131302 "4b43501ce076b3cd43c6800cc5f86c45bddebad6eee1c0e51ea235f120cb00ea">,
      #splice.entry<"/build/gawk-5.4.1/test/arrayref.ok" file 644 mtime 1782131302 "ad0fadf63cc7cd779ce475e345bf4063565b63a3c2efef1eebc89790aaa6acba">,
      #splice.entry<"/build/gawk-5.4.1/test/arraysort.awk" file 644 mtime 1782131302 "aed4f8e94819c6ac1002a3344e71377e6d481a9944f4be9d0f8b60e112099368">,
      #splice.entry<"/build/gawk-5.4.1/test/arraysort.ok" file 644 mtime 1782131302 "7ed4bcc2a0c1e6aa6c8ed8f95b0207f0994fe01a2f5ce1061f17a3268cfc1467">,
      #splice.entry<"/build/gawk-5.4.1/test/arraysort2.awk" file 644 mtime 1782131302 "ff74bf5dc6371003970a68799081905cafae2f8c665055c3be0e96b2919e17e7">,
      #splice.entry<"/build/gawk-5.4.1/test/arraysort2.ok" file 644 mtime 1782131302 "937579d03e2f0d33c67a1730c91bf50318b56acb527280955a261ce5304fe7c8">,
      #splice.entry<"/build/gawk-5.4.1/test/arraytype-mpfr.ok" file 644 mtime 1782131302 "7e2b1777d2a46773491dfb72ffe24e709c2959545dea7db7dad9f225a521eb7f">,
      #splice.entry<"/build/gawk-5.4.1/test/arraytype.awk" file 644 mtime 1782131302 "817384e3420d1694518033ea210c119153a17155aa99056de2c575710afabbb8">,
      #splice.entry<"/build/gawk-5.4.1/test/arraytype.ok" file 644 mtime 1782131302 "c44eb0b9963971ad4e36a30e9f21e1bf6bd0900a253c710671cecb650a61a074">,
      #splice.entry<"/build/gawk-5.4.1/test/arrdbg.awk" file 644 mtime 1782131302 "bee663b90badd81125714910601f93895ed832cecd36b24c949cec805a27e0c6">,
      #splice.entry<"/build/gawk-5.4.1/test/arrymem1.awk" file 644 mtime 1782131302 "de2ccec1d3bde6e1cfea0b6cc45eb10fae7efbadea6bd305198d175e7e1a4cd0">,
      #splice.entry<"/build/gawk-5.4.1/test/arrymem1.ok" file 644 mtime 1782131302 "d0f9d1c5a8307a2e83a4cc0209445fb820d796f2e8b63f6ead33e8d885937f7e">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref2.awk" file 644 mtime 1782131302 "be450b34ed8b3b28596d8671f79cc4ef4335826e1d96efa3a555c286bdded513">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref2.ok" file 644 mtime 1782131302 "b8771b894fc2ea230a27e73b3f50945dc77aa10ea34064de17395b007b933c93">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref3.awk" file 644 mtime 1782131302 "0f0b94203fd9f8a020621583e26f8b979bcff231bb9634ac484d90787f2f928f">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref3.ok" file 644 mtime 1782131302 "079800431b42b3bbb6ccfa967904284f3e1c49bfa824ae71d7ddaa585c57da12">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref4.awk" file 644 mtime 1782131302 "4ddd28a96c38014c0fb9dec5c2b4c0bf1ca170d82d77a84b3b2a04bba0a026bc">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref4.ok" file 644 mtime 1782131302 "09828a0fa596977a8cba99442f59f7defa323571f04e8e0748295e1036d497d1">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref5.awk" file 644 mtime 1782131302 "b6507d3353105165a1f97c59f86e9f960b1ae516f08bfd9e9baf5e89c487d1aa">,
      #splice.entry<"/build/gawk-5.4.1/test/arryref5.ok" file 644 mtime 1782131302 "67e4775ed12be675d9c96f9b4b28a7777142f15b14d4b0e3829f5763da580fed">,
      #splice.entry<"/build/gawk-5.4.1/test/arynasty.awk" file 644 mtime 1782131302 "00696c8013cacdad4a274a0841547e05e02228230094477974c5c0d2055b504f">,
      #splice.entry<"/build/gawk-5.4.1/test/arynasty.ok" file 644 mtime 1782131302 "db3dd543dac7d1b15a408088c63955aad6509b10fd0f8ed3c7ea291f8e907368">,
      #splice.entry<"/build/gawk-5.4.1/test/arynocls.awk" file 644 mtime 1782131302 "db10390881fde77d0e7b36c7cc05d067b7e99444a58683c0fa498b636a93d6e7">,
      #splice.entry<"/build/gawk-5.4.1/test/arynocls.in" file 644 mtime 1782131302 "ee516b5a2910cfeaf7fa576bccde348b53ed0a9f79b7af39eca88ca4e76609ef">,
      #splice.entry<"/build/gawk-5.4.1/test/arynocls.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm1.awk" file 644 mtime 1782131302 "b0519d7c24235c1000a41cd4a2b73833e4c411f0a3f342b1f3c131950e37a8a7">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm1.ok" file 644 mtime 1782131302 "07c3b56b4dfcb1e863eeed12f283afbca0e051ef81c1d781863a3ddea61b8a31">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm2.awk" file 644 mtime 1782131302 "e7f48350082c2f15825dcad7e0d323f3e8cf91bf5626a594700085a0bb2f71cf">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm2.ok" file 644 mtime 1782131302 "766aa75091d3240a3c2540cc96aaebd409b92d4989ecc23af505512b2b526c54">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm3.awk" file 644 mtime 1782131302 "bd7b0776214cfd56cdbf7447871065bffe47bf64bf2697e768bd379749f39a00">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm3.ok" file 644 mtime 1782131302 "232dd526c231c20c1993afa4d4d9a0ee563e83c41988c88da7d7c842dbecd36b">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm4.awk" file 644 mtime 1782131302 "4e797a3247118014855ac161031c21453c5b451d224b332d0a844f277041385b">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm4.ok" file 644 mtime 1782131302 "398042f045a269cbc23e8f6ca921706fa0d830e21ea3807ba0eaa84a7b5248e5">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm5.awk" file 644 mtime 1782131302 "86590669c168e7d5116fe45e80c9ba67a6ca891c52aa982282a5259aa3c54632">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm5.ok" file 644 mtime 1782131302 "5175d766e831f8bed3cc014c7a717942f4487fc655a51f18ab3fddb15affb699">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm6.awk" file 644 mtime 1782131302 "5fb1776e9440100b46fa8518e9b5c136e43da55c04412b476de64b0afc4c3a56">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm6.ok" file 644 mtime 1782131302 "4ba5eabf775c969dff26ff61c9167b02fd3526111c461f52a81297bcc4d9d8ce">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm7.awk" file 644 mtime 1782131302 "7763a6c6cd949ced1a11dd58d1b30961118b384a6d815e88c376eaf2d5c7c9ba">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm7.ok" file 644 mtime 1782131302 "18d3f14774762d2eac182c1008d94e9609e1ce151ffa6f7e98835727c9a42d78">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm8.awk" file 644 mtime 1782131302 "6e99bb4d99699301fcca95c4cda2a56d8ab13df15479230e738068eb2edd16cf">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm8.ok" file 644 mtime 1782131302 "ca88136a222d75770bf3260fb66ef973cfef2df6c1d463f9c3b9d95db0475674">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm9.awk" file 644 mtime 1782131302 "dec68d7772a44b2b3937588cd12558972a58500fbda76b07cd1daa13c54030f6">,
      #splice.entry<"/build/gawk-5.4.1/test/aryprm9.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/arysubnm.awk" file 644 mtime 1782131302 "d600afa69b7b471513f9fc898525722744a75f0f4c26dbfab96f99bd3a51130b">,
      #splice.entry<"/build/gawk-5.4.1/test/arysubnm.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/aryunasgn.awk" file 644 mtime 1782131302 "3f798908e4e98d95b8a7c83c238223063a01c30fb2dfa8c2ddbed4cc6a958078">,
      #splice.entry<"/build/gawk-5.4.1/test/aryunasgn.ok" file 644 mtime 1782131302 "a1f6f355c713afb144226df32f10815cfdefe14cb28eeba498679f44f4916e1a">,
      #splice.entry<"/build/gawk-5.4.1/test/asgext.awk" file 644 mtime 1782131302 "08ff459ebec9b32f8f23cf7aa973eb8949325360ef64722cc439087bb4fb24e3">,
      #splice.entry<"/build/gawk-5.4.1/test/asgext.in" file 644 mtime 1782131302 "eed478f59a7004b9e266071019e9381ca2ceb11fefcba738fc6730767f31569e">,
      #splice.entry<"/build/gawk-5.4.1/test/asgext.ok" file 644 mtime 1782131302 "fbee3ab7f54ddc6d9ff52196859c7ec7c1b63da02665598b6e6076cb0310fdfb">,
      #splice.entry<"/build/gawk-5.4.1/test/asort.awk" file 644 mtime 1782131302 "5605c1b176de43362f50eb8f8366cbaad54d788bc1be6e657d113d5c1f28cf67">,
      #splice.entry<"/build/gawk-5.4.1/test/asort.ok" file 644 mtime 1782131302 "4112347389aa050c3d279e94815cdbd8cfea01c94ee37a20fa6f59e334bcdc21">,
      #splice.entry<"/build/gawk-5.4.1/test/asortbool.awk" file 644 mtime 1782131302 "0e5cd7f8f04d27e06478077b09cc186415c776b2137f83704ff4fef77ad36c66">,
      #splice.entry<"/build/gawk-5.4.1/test/asortbool.ok" file 644 mtime 1782131302 "6cce1e9ab479d918ffd7ba758a88a2157a77c185da6041a14c979d36f451ce3e">,
      #splice.entry<"/build/gawk-5.4.1/test/asorti.awk" file 644 mtime 1782131302 "671d6334777dedf352f572a93c085cb9cda605200f96bc0246f702389dfc22b1">,
      #splice.entry<"/build/gawk-5.4.1/test/asorti.ok" file 644 mtime 1782131302 "4112347389aa050c3d279e94815cdbd8cfea01c94ee37a20fa6f59e334bcdc21">,
      #splice.entry<"/build/gawk-5.4.1/test/asortsymtab-mpfr.ok" file 644 mtime 1782131302 "a32d85b52f67a96b78c91ec4f3b27e47c668d81beda2502e031ee446515440d1">,
      #splice.entry<"/build/gawk-5.4.1/test/asortsymtab.awk" file 644 mtime 1782131302 "95714519c4bd559221026d70b0fb06d66e5495efc8b74c052491c3f95b1a1407">,
      #splice.entry<"/build/gawk-5.4.1/test/asortsymtab.ok" file 644 mtime 1782131302 "2badbb966b654b544b70bd0169260d0eee71e475ec27dc2604921ac5cc7cfd0c">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield.awk" file 644 mtime 1782131302 "0d6bcfdd9cc753ca1ee762986132fa619ce3935403a62ccb25035ab784524fcb">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield.in" file 644 mtime 1782131302 "8789d870e43591f2ddddcd2364bce8046a2a0cacf92c9f0b91874f53c74349fb">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield.ok" file 644 mtime 1782131302 "f6b49467f595b1a44e442c198b3df4d221e88efcaabc26254f8e0ad4f79b6242">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield2.awk" file 644 mtime 1782131302 "69dc507b87ed9ccd9d4b604bea2171d8e4c4e70dcd8227b520d0f16537fce1c1">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield2.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield3.awk" file 644 mtime 1783249818 "a30ee27e8ff3bf06fd42b7d9ae27b5239b9a25824c9467d5241541a3cd7055ff">,
      #splice.entry<"/build/gawk-5.4.1/test/assignnumfield3.ok" file 644 mtime 1783249818 "b86dde9375abe52a6ce92211ee4962be2aff8080e885decb629caf5d4fc9a775">,
      #splice.entry<"/build/gawk-5.4.1/test/awkpath.ok" file 644 mtime 1782131302 "cb0405a8d5daaca4648acf769379d53b71dcfe957b090f67b2de8110211ec712">,
      #splice.entry<"/build/gawk-5.4.1/test/back89.awk" file 644 mtime 1782131302 "495a2ebeb01320493a1179dfcf0f13800c0742f00e7f53bb59265a7b588d481c">,
      #splice.entry<"/build/gawk-5.4.1/test/back89.in" file 644 mtime 1782131302 "0674a710ab1775fb9ea441e0f2e11974ec9329b027367ea22efa752be0dee716">,
      #splice.entry<"/build/gawk-5.4.1/test/back89.ok" file 644 mtime 1782131302 "d0e1fddb88125970c94dea4319cbda982045724557c05dc67c1ea8baf4731667">,
      #splice.entry<"/build/gawk-5.4.1/test/backbigs1.awk" file 644 mtime 1782131302 "295d4cd33c3fe78e1b8dcd72d303ee4f4be2cad92d5235107744610eaf8cd4ae">,
      #splice.entry<"/build/gawk-5.4.1/test/backbigs1.in" file 644 mtime 1782131302 "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7">,
      #splice.entry<"/build/gawk-5.4.1/test/backbigs1.ok" file 644 mtime 1782131302 "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7">,
      #splice.entry<"/build/gawk-5.4.1/test/backgsub.awk" file 644 mtime 1782131302 "901a33be4288d19cd620178815ebc32673cf011eee6b1de28189015c413fc3fb">,
      #splice.entry<"/build/gawk-5.4.1/test/backgsub.in" file 644 mtime 1782131302 "5ef5c2468972c12025b502f451a5f3b4d250843cd29ca42be991e01629cd5eee">,
      #splice.entry<"/build/gawk-5.4.1/test/backgsub.ok" file 644 mtime 1782131302 "48bb3ab9e5ada1de5c997a16f96763157d01a808755e999d7c67fe9fd338518a">,
      #splice.entry<"/build/gawk-5.4.1/test/backsmalls1.awk" file 644 mtime 1782131302 "568d828aae7146f70885a82c89bf65a5172a079e6196f36c9ff92ce2bb283f86">,
      #splice.entry<"/build/gawk-5.4.1/test/backsmalls1.in" file 644 mtime 1782131302 "93d01a6b07fed32fcd74ca7d5aff981c1d7fedd91c2f672b74daefb30080739f">,
      #splice.entry<"/build/gawk-5.4.1/test/backsmalls1.ok" file 644 mtime 1782131302 "5a07aa2aa72b7a989fcefe20154b9e70c4cde86cf089aeae219edf1a51982106">,
      #splice.entry<"/build/gawk-5.4.1/test/backsmalls2.awk" file 644 mtime 1782131302 "f1e560aca94803f53de1fd6c4c9bee05aa0a455ffe021272e33ff2d87d39360b">,
      #splice.entry<"/build/gawk-5.4.1/test/backsmalls2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/backw.awk" file 644 mtime 1782131302 "406ab522ebe4d7dec9d08656289fa235fb35733670e7884d143137c691f617dc">,
      #splice.entry<"/build/gawk-5.4.1/test/backw.in" file 644 mtime 1782131302 "073426cffaa9587a4038156413338bbd4f403fc1955cd017ed4ebc142c890aca">,
      #splice.entry<"/build/gawk-5.4.1/test/backw.ok" file 644 mtime 1782131302 "073426cffaa9587a4038156413338bbd4f403fc1955cd017ed4ebc142c890aca">,
      #splice.entry<"/build/gawk-5.4.1/test/badargs.ok" file 644 mtime 1783615620 "19fbd44ab35f692c13fe466639f3c81237d7260bb66677c26441f443aefec1bb">,
      #splice.entry<"/build/gawk-5.4.1/test/badassign1.awk" file 644 mtime 1782131302 "7c8dc24f9d387a99fa24e0c04c6cc80fbeb43f80068dc3aae994bbea9f46db8b">,
      #splice.entry<"/build/gawk-5.4.1/test/badassign1.ok" file 644 mtime 1782131302 "8ac29089e560d1e3b8c646f03b16fbb880b7be69943bf88007fb085eb4f95bad">,
      #splice.entry<"/build/gawk-5.4.1/test/badbuild.awk" file 644 mtime 1782131302 "ecce8a6f1afa67db5239297677dd8c4657145b493a58b2406fbe7875761213d6">,
      #splice.entry<"/build/gawk-5.4.1/test/badbuild.in" file 644 mtime 1782131302 "a863c304d619b7e8d3816482b8c14cd0bce693cc6634499fac214b781fdf0d33">,
      #splice.entry<"/build/gawk-5.4.1/test/badbuild.ok" file 644 mtime 1782131302 "3d4ad81146504adf11ce12418095e12799d4ec5665880cbb277c187812c35334">,
      #splice.entry<"/build/gawk-5.4.1/test/beginfile1.awk" file 644 mtime 1782131302 "82973d5577f7ca2d8a67f2f6e0fdb269221f2c6d152e402a94b156a6be513561">,
      #splice.entry<"/build/gawk-5.4.1/test/beginfile1.ok" file 644 mtime 1782131302 "97b666366edeba6318d8cec365f2a4245397a1bb13962310d2fbc0bdbbc9806f">,
      #splice.entry<"/build/gawk-5.4.1/test/beginfile2.in" file 644 mtime 1782131302 "2e63521cefea50d17fde1c5b95d612f1f366c46e229cb95ad72404b6eb5c53f4">,
      #splice.entry<"/build/gawk-5.4.1/test/beginfile2.ok" file 644 mtime 1782131302 "0b916e07394f90b2f5b7a31d8dc8cbfc3de4066793a03a288917824adbaa9ae2">,
      #splice.entry<"/build/gawk-5.4.1/test/beginfile2.sh" file 755 mtime 1782131302 "f5104a61e3705060a33ff16ff30906b816fad561321c90737b88377ebee51537">,
      #splice.entry<"/build/gawk-5.4.1/test/binmode1.ok" file 644 mtime 1782131302 "1121cfccd5913f0a63fec40a6ffd44ea64f9dc135c66634ba001d10bcf4302a2">,
      #splice.entry<"/build/gawk-5.4.1/test/callparam.awk" file 644 mtime 1782131302 "3456e49c9ba1960b1d132a79c1d1a162f4aa99638fcbc82d19f88c10a004861b">,
      #splice.entry<"/build/gawk-5.4.1/test/callparam.ok" file 644 mtime 1782131302 "0c5a08764feebf295fbd74f89ed27532a5adc2e7488d6b51bcdd1398b6ed2e2a">,
      #splice.entry<"/build/gawk-5.4.1/test/case-check.awk" file 644 mtime 1783241692 "f954510a99653eb632bffebd7e03ff20dd9ef7d3336e01b0d7d316ebc3f587ca">,
      #splice.entry<"/build/gawk-5.4.1/test/case-check.ok" file 644 mtime 1783241692 "9c696993cc2cc5a24d786c3ab42870118a79c5f5690745996437035dd97f09e1">,
      #splice.entry<"/build/gawk-5.4.1/test/case-check.ok2" file 644 mtime 1783363468 "a1020b19dc580892976280711d19e2489932a9e19a5b4e80ddc30dba35ead8c7">,
      #splice.entry<"/build/gawk-5.4.1/test/case-check.ok3" file 644 mtime 1783365082 "39c9df18e23cfac47ea3fab3043e646c2dbadec6a0522797fc74f322068ef18e">,
      #splice.entry<"/build/gawk-5.4.1/test/charasbytes.awk" file 644 mtime 1782131302 "9acdaddabdd4ee92ebed638f63be16c8eb452839dc9008b9018d3a38bd1e626a">,
      #splice.entry<"/build/gawk-5.4.1/test/charasbytes.in" file 644 mtime 1782131302 "200429741da3bc9b3c9c581932bfe0371a6aef05d32a7ee3bf026786a0c26e24">,
      #splice.entry<"/build/gawk-5.4.1/test/charasbytes.ok" file 644 mtime 1782131302 "998f9b6b1edb9d9917f3dc4370ec57daa2e1fb5cee76f7e07767f19093403fa2">,
      #splice.entry<"/build/gawk-5.4.1/test/check_retest.awk" file 644 mtime 1782131302 "ba2080372a36ce38d2261f2c2c45342459bffa733e06f2945f93d521b29cfe81">,
      #splice.entry<"/build/gawk-5.4.1/test/checknegtime.awk" file 644 mtime 1782131302 "42dcbdc03d0c6d63364b311fcdabf97b73eb956ed2eee1c75110ba5b5fc7ad0d">,
      #splice.entry<"/build/gawk-5.4.1/test/childin.awk" file 644 mtime 1782131302 "c503ea6debfb42d40dfa873c80cefff561a5635be0ef748c0e58b88965202a89">,
      #splice.entry<"/build/gawk-5.4.1/test/childin.in" file 644 mtime 1782131302 "98ea6e4f216f2fb4b69fff9b3a44842c38686ca685f3f55dc48c5d3fb1107be4">,
      #splice.entry<"/build/gawk-5.4.1/test/childin.ok" file 644 mtime 1782131302 "98ea6e4f216f2fb4b69fff9b3a44842c38686ca685f3f55dc48c5d3fb1107be4">,
      #splice.entry<"/build/gawk-5.4.1/test/clobber.awk" file 644 mtime 1782131302 "097f5c2e756d5a85c4e6527c4884cb136f9c1914d7ed8cb1848887aa0eae809f">,
      #splice.entry<"/build/gawk-5.4.1/test/clobber.ok" file 644 mtime 1782131302 "b5fd467206ae73430cc8d75a91cbfdaca4dec5b04bac1c84b946bf67efdb473f">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way.awk" file 644 mtime 1782131302 "0a27e4c6de449e2e2fbe9fd24f66f228c5fdcd68b34c6ea437db8e8c0dfa5b3b">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way.ok" file 644 mtime 1782131302 "42f464b52933be29c7b2c134c04d3793752e79e9f697730df345ba5ccbf171eb">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way2.awk" file 644 mtime 1782131302 "9a518f72948935f951d020a0c8c6667b40b836248e3442e75618c782b8a71d3e">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way2.in" file 644 mtime 1782131302 "f2ca1bb6c7e907d06dafe4687e579fce76b37e4e93b7605022da52e6ccc26fd2">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way2.ok" file 644 mtime 1782131302 "7c187b4c101c45d4ff8c93488172aa5630f5036accf45f130339bdfe891e4e04">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way3.awk" file 644 mtime 1782131302 "c2f04273b6e7c1b894c111f990168da3dc7b9b7012654329dd1459d7cf3be6aa">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way3.ok" file 644 mtime 1782131302 "e3dfe71db7226d2439a8982488d396c9619511f953647bc2dbe77e3379feb51b">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way4.awk" file 644 mtime 1782131302 "cfb1e16f9e18d86205e8839ea7784a6dc2085d0606c3c6b3a3bdb206ea7e4183">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way4.ok" file 644 mtime 1782131302 "36e4fa18887e663e15ce68a1cd07ef4edcce668c40097a0b73330ce1c85c127e">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way5.awk" file 644 mtime 1782131302 "e7523608178805fe9575990589a69a73f6d7dd2efe5e9109ffa1d5b6b813ee3a">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way5.ok" file 644 mtime 1782131302 "7ac5d3a586637d0e3f6ca2315ab6382e115f2396216dee6ed0392d148f96c7fe">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way6.awk" file 644 mtime 1782131302 "893f50a05ee9b3c434a90ab651b243bbab716ed35983fd1bcdcc0a6540c0af69">,
      #splice.entry<"/build/gawk-5.4.1/test/clos1way6.ok" file 644 mtime 1782131302 "db876398ddad9a73d1ba985850c35a301dd4742d6f1fa64d8f482842cd3038fd">,
      #splice.entry<"/build/gawk-5.4.1/test/close_status.awk" file 644 mtime 1782131302 "52385618c024663976013ca394e9d39c4f8cc395d8d386496fbd5cd90b6f9cd2">,
      #splice.entry<"/build/gawk-5.4.1/test/close_status.ok" file 644 mtime 1782131302 "73df43b16a555d1275adff4f3c9b9e5722b19ccbde4b03948593bac74163846f">,
      #splice.entry<"/build/gawk-5.4.1/test/closebad.awk" file 644 mtime 1782131302 "78566a590e665a6a5abc1bd06954d96cf10bd5f619e2be6b396d3832fec3ebb0">,
      #splice.entry<"/build/gawk-5.4.1/test/closebad.ok" file 644 mtime 1782131302 "030b7ae8a3c46b69997bcc0c6ae1cbf25a31486544601b5d93e8ec4018b7f7a3">,
      #splice.entry<"/build/gawk-5.4.1/test/clsflnam.awk" file 644 mtime 1782131302 "0c4c01dbb256b301b24b956e9bb918737ab22404515a757c3bc96305fb1c8bf6">,
      #splice.entry<"/build/gawk-5.4.1/test/clsflnam.in" file 644 mtime 1782131302 "6ca9d5edb68deaadc1d3130c5fc3ec36e12db72ad54e93edcd63bdfb40a83300">,
      #splice.entry<"/build/gawk-5.4.1/test/clsflnam.ok" file 644 mtime 1782131302 "e6001c94e47ae69a18a68413304c7d9b3bc6b182dbdd3d2f85d901783b40197a">,
      #splice.entry<"/build/gawk-5.4.1/test/cmdlinefsbacknl.ok" file 644 mtime 1782131302 "bfde9df2ad667ae337d454e8245e9688073972d83a6f4a95a4e16a0c0664caa6">,
      #splice.entry<"/build/gawk-5.4.1/test/cmdlinefsbacknl.sh" file 755 mtime 1782131302 "3f3ec96ac37d1afaeaeb3f615bfa0c8382c784401f3fbce8fc52d09e9197187f">,
      #splice.entry<"/build/gawk-5.4.1/test/cmdlinefsbacknl2.ok" file 644 mtime 1782131302 "9097b8f17ad795b6948ac5937e07119113d6be06f45c7a7ebf90ffe63f9b8d82">,
      #splice.entry<"/build/gawk-5.4.1/test/cmdlinefsbacknl2.sh" file 755 mtime 1782131302 "202fdca99fc2f07640c75d00b96622ccf8fb967f52e508c4b0e078f2463722e8">,
      #splice.entry<"/build/gawk-5.4.1/test/colonwarn.awk" file 644 mtime 1782131302 "a0c08e6573fed697404c5bef936a0f0a85c4a56fa00d2a172389faeac6a70360">,
      #splice.entry<"/build/gawk-5.4.1/test/colonwarn.in" file 644 mtime 1782131302 "4578f45e959826e13785dc09282a0d29aa6a8302c29410f7958e11d4d2fe0bd8">,
      #splice.entry<"/build/gawk-5.4.1/test/colonwarn.ok" file 644 mtime 1782131302 "99a9b92faa625ba34ab04a6eda99ea7c11276c2f285d5fa02b9b2254f3c0b2ab">,
      #splice.entry<"/build/gawk-5.4.1/test/commas.awk" file 644 mtime 1782131302 "178beab63a8a74c316bbdfa647328ddfd60e47fd46560411a14b9fc7ef36015d">,
      #splice.entry<"/build/gawk-5.4.1/test/commas.ok" file 644 mtime 1782131302 "54dd383cfe4f5b4631f015c80e4a82d97ee7eedcd26fc242e67d12d30577931c">,
      #splice.entry<"/build/gawk-5.4.1/test/compare.awk" file 644 mtime 1782131302 "4e5fa514ae525f089dd24983eb426e4731e8ee31011c33bf4cd29db123b64fe5">,
      #splice.entry<"/build/gawk-5.4.1/test/compare.in" file 644 mtime 1782131302 "dbf545b613f8fc553b54e5b18da6ddc213a79d828b0828fbedfc068915a67679">,
      #splice.entry<"/build/gawk-5.4.1/test/compare.ok" file 644 mtime 1782131302 "8a4f59fbe413e8534d529cc468d6d3a144608ddab1e0da9409df94e52da41c03">,
      #splice.entry<"/build/gawk-5.4.1/test/compare2.awk" file 644 mtime 1782131302 "73ef34d3f563f01ff82dccd01f52f591d16912ea72a4d0a2e5e3bbdd338e6214">,
      #splice.entry<"/build/gawk-5.4.1/test/compare2.ok" file 644 mtime 1782131302 "2d3e163287bf068b27b87bb1ae1d112db0a4d3cc9491b53fb429153b83987d49">,
      #splice.entry<"/build/gawk-5.4.1/test/concat1.awk" file 644 mtime 1782131302 "94b87e6b52ffa42f46de07b0bb2f6566a3e7eec306ea3586fb224e8a93103199">,
      #splice.entry<"/build/gawk-5.4.1/test/concat1.in" file 644 mtime 1782131302 "a7f5cf19fdb779272b12bed17134c60d18d464fddfda599b8a70fdc5cab185d1">,
      #splice.entry<"/build/gawk-5.4.1/test/concat1.ok" file 644 mtime 1782131302 "ccba4a1c95bc100c7f857b40b585d3527c080879e55dcebd3fee77f84444122a">,
      #splice.entry<"/build/gawk-5.4.1/test/concat2.awk" file 644 mtime 1782131302 "b44312c13df085421c6ea79b8499e1ce684b0546c9a544d9d12e88a7c59a992f">,
      #splice.entry<"/build/gawk-5.4.1/test/concat2.ok" file 644 mtime 1782131302 "a0fcb4e161d5f009cea6e8d474d8e321b9c29527ede13f5c9233002df366dc11">,
      #splice.entry<"/build/gawk-5.4.1/test/concat3.awk" file 644 mtime 1782131302 "de809af733d9a01ba15df2cef59061dbf5c9709b94d4677d7a5a05006d35120d">,
      #splice.entry<"/build/gawk-5.4.1/test/concat3.ok" file 644 mtime 1782131302 "8f0ec1a9281617f1ce8164cc9b52af1abab5d21254b41dff1bc0278215eec5a3">,
      #splice.entry<"/build/gawk-5.4.1/test/concat4.awk" file 644 mtime 1782131302 "de3ad600a7a728c5251f63535abc902d37088a5c4f0283069005d186774d3ef6">,
      #splice.entry<"/build/gawk-5.4.1/test/concat4.in" file 644 mtime 1782131302 "d78931fcf2660108eec0d6674ecb4e02401b5256a6b5ee82527766ef6d198c67">,
      #splice.entry<"/build/gawk-5.4.1/test/concat4.ok" file 644 mtime 1782131302 "b5cdef0f8afbcec688490a476a1d1ed3c2037d28bbc6b910f9f172305d2f52f0">,
      #splice.entry<"/build/gawk-5.4.1/test/concat5.awk" file 644 mtime 1782131302 "65251c6adbd98000665fda1f6b6fa9126c3588300f862f8cf51a3b61f25f7e67">,
      #splice.entry<"/build/gawk-5.4.1/test/concat5.ok" file 644 mtime 1782131302 "8d9f989d5401a53205787e26b6a23d3d36542e05d24b4afe085d73140f8533f6">,
      #splice.entry<"/build/gawk-5.4.1/test/convfmt.awk" file 644 mtime 1782131302 "91455c2bf91b18acbce3eeb87e4139f78f4ea0db9622b56bbd69e4a8aca633eb">,
      #splice.entry<"/build/gawk-5.4.1/test/convfmt.ok" file 644 mtime 1782131302 "7883bdde906b5749bab24dd4b20d54cda254d4147452edbbdf8723d131d1b3dd">,
      #splice.entry<"/build/gawk-5.4.1/test/crlf.awk" file 644 mtime 1782131302 "7657f84bce12dac1cfa1a3328ab7a909db3226b359c2562e4314fc0080561821">,
      #splice.entry<"/build/gawk-5.4.1/test/crlf.ok" file 644 mtime 1782131302 "c360d3bc34611f9bb91923f9e8c180a94c0fa11aa60251e25c4ab8d1a9bb34e2">,
      #splice.entry<"/build/gawk-5.4.1/test/csv1.awk" file 644 mtime 1782131302 "28afdb0d17d1d8b45ac53329e41f3815e7ef55fa019a6c6c19147f55029341aa">,
      #splice.entry<"/build/gawk-5.4.1/test/csv1.in" file 644 mtime 1782131302 "944d225083e116a5f3122a380c79df884f08c06e7486fe91abf64ba4c471bfcd">,
      #splice.entry<"/build/gawk-5.4.1/test/csv1.ok" file 644 mtime 1782131302 "f369aa912dbbd244caee49c16e4d37413d3484515992b771ea3568d9468ad0f1">,
      #splice.entry<"/build/gawk-5.4.1/test/csv2.awk" file 644 mtime 1782131302 "0ae31179477a4de9632bce697a256a98e3a77113a04addcfc4d42ef1626f187f">,
      #splice.entry<"/build/gawk-5.4.1/test/csv2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/csv3.awk" file 644 mtime 1782131302 "19e362ba67debab6a31b0b63f77fe00f182bf309c9d2b6f8acb3df84bfac1e0b">,
      #splice.entry<"/build/gawk-5.4.1/test/csv3.in" file 644 mtime 1782131302 "b4fc5f73f6165c8a1d92ac77dc3b582df3ce4095901c4cd40064e529ec09ce4d">,
      #splice.entry<"/build/gawk-5.4.1/test/csv3.ok" file 644 mtime 1782131302 "4f13297a4aabc226debbfc5c4eba55219217203e9b51f59816ad1796b95376c0">,
      #splice.entry<"/build/gawk-5.4.1/test/csvodd.awk" file 644 mtime 1782131302 "5a3c93cd0ad2e8c151d5598587f79573d258203dd039f4f88f494010ef4b9d53">,
      #splice.entry<"/build/gawk-5.4.1/test/csvodd.in" file 644 mtime 1782131302 "2c12449c338fc787d6a56d1be4de91ec51a8237f88f6fb9afcb42ec83aedd0be">,
      #splice.entry<"/build/gawk-5.4.1/test/csvodd.ok" file 644 mtime 1782131302 "ddb09c69d57274db8b156aceac4a2293628789ffcd5fa5e420acaea033366ce6">,
      #splice.entry<"/build/gawk-5.4.1/test/datanonl.awk" file 644 mtime 1782131302 "8a8d66e216806b9678382543d065fa580f492f5d583392d7693ecc4d20fdd9e6">,
      #splice.entry<"/build/gawk-5.4.1/test/datanonl.in" file 644 mtime 1782131302 "2046c33d90bd17395c5a09ee96e02cdf2bb252060b9d1d1b667321a6239cf513">,
      #splice.entry<"/build/gawk-5.4.1/test/datanonl.ok" file 644 mtime 1782131302 "55c13832315910775e791a0aa999c419e957a1df861d2d402d2d76eee4acbe1b">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray1.awk" file 644 mtime 1782131302 "f728af86e5ebef9102702352573f06710e6383e60d23b3f65e19ac8ebe340fa6">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray1.in" file 644 mtime 1782131302 "32e74d22106e8bbebca3237ed6c7ad6a2420611472c0cceeb1fd41bdb887e161">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray1.ok" file 644 mtime 1782131302 "ea5f82e68bef64ed93c85927ab3acda53b47262e22c455d74826b20af5f2dbcf">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray2.awk" file 644 mtime 1782131302 "eef19cb50a6b97af4e2d6469d5ca087d507369bf30570bded7c19658aaa2908b">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray2.in" file 644 mtime 1782131302 "60f3ee67e0cdc601093ebe9894f3d758d1befc3222edfae6ff5a6e71c0d4a946">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray2.ok" file 644 mtime 1782131302 "0b9141e93436d3dac03c3270e7e80d8512663596dfd1a80518c9405036e4ba5f">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray3.awk" file 644 mtime 1782131302 "4b6d6955557ae351c81ab130a259acbbbe162c0de4bc4be6922d2daf008f74e7">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray3.in" file 644 mtime 1782131302 "60c469edd37bc69dc010c98be7869165fac2ae3ac1f09cc29c779eea4598cd53">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray3.ok" file 644 mtime 1782131302 "def9c276ff29283393cfd4c80d2dea05d6c4fb1aa117788d587fc7c67675bed3">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray4.awk" file 644 mtime 1782131302 "7a32a281c6e0233d28f8398afb8d78706bf68b2e8c4f4064f5fb8ca3e6d73c22">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray4.in" file 644 mtime 1782131302 "bc16a3c7da0536cbe64fffdddfbfa1c11b28393c15988a36a3698fcb968b8ac3">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugarray4.ok" file 644 mtime 1782131302 "98cbaafc2ae34e50401e8f9c92429b59d3196b56e728facf7abd33e83b0d2c3d">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval.in" file 644 mtime 1782131302 "b559d14bf987f074d2292e242f10b4f16dc00a53587717e479a97fbbcc3073b6">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval.ok" file 644 mtime 1782131302 "b767a079d1aeab23f2b2473d040f32d03b64dce8cf3c2defe280c7e96083e5ed">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval2.awk" file 644 mtime 1782131302 "9f7ac36b23b9d4332a54a6912739cf641a47c3cbad82ecc8bc81d9b0f9fa5c66">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval2.in" file 644 mtime 1782131302 "dd0dedb190a71a0d84da10a3f06e69fe4099c8927fb0a4220eea6006f5a66e18">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval2.ok" file 644 mtime 1782131302 "68181c43e748a76eee06e81598f903e993b1b74e852f70d4890a1a7e885323d7">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval3.awk" file 644 mtime 1782131302 "cf733d7e7201bcbac635b3d9991a685bbe5bdd07e63aba67e17654880600d62c">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval3.in" file 644 mtime 1782131302 "2a9e04d8f08004f988f70e47ad34b69ef0d7cd9a510365228ef7be9a1db44718">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval3.ok" file 644 mtime 1782131302 "f0a5131011403db85e52ac101cc32a9dce0554880dc719b26f62b681481dc89a">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval4.awk" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval4.in" file 644 mtime 1782131302 "78b84e6e2725ddc57685aec762903b10c1159a6d24b993990614b9e825f595a3">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugeval4.ok" file 644 mtime 1782131302 "a206e11a84ed3b195697b4f5dc043ba617049cb07038d774bdf4541ab1a7a1f3">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugtypedre1.awk" file 644 mtime 1782131302 "b56bd00e12153006434492bae2208b4af217a27f3a15d7118bd62d9f2cc6afbd">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugtypedre1.in" file 644 mtime 1782131302 "018edd24f07875894758d9c32d35b39c506cf25238f0ae9675a0071cdda1f1b2">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugtypedre1.ok" file 644 mtime 1782131302 "08530cb1a39ca604339c9d9ffd898b41f5775948438dd71928f4b49ec48698fb">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugtypedre2.awk" file 644 mtime 1782131302 "8874608d21cbfff0ca77eb0f3ec304262aced4f3ed7cf1b90feabf535d1259da">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugtypedre2.in" file 644 mtime 1782131302 "f2b074bfde0bcc78c5131544463ce220ca753b57dc8d729a507a4b7848938f5c">,
      #splice.entry<"/build/gawk-5.4.1/test/dbugtypedre2.ok" file 644 mtime 1782131302 "fe3b04e659b8e9aa801c0ed95463ebea1c07e6030d391d3d2c9e0d51c31b9b3e">,
      #splice.entry<"/build/gawk-5.4.1/test/defref.awk" file 644 mtime 1782131302 "2ec388143b528c7b6450d2752191190dae7dc20d7d855625ecb0417ebf589f84">,
      #splice.entry<"/build/gawk-5.4.1/test/defref.ok" file 644 mtime 1782131302 "fc41fdc52da951bf8d58eeb73803ba007f712d9dc22ddd8334442f2b9a917a9e">,
      #splice.entry<"/build/gawk-5.4.1/test/delargv.awk" file 644 mtime 1782131302 "f8737a76cb4b123ed0937576a7198dd5c41bbee9f528803884a3722190ec4c18">,
      #splice.entry<"/build/gawk-5.4.1/test/delargv.ok" file 644 mtime 1782131302 "fd6d5eb59df697a3591ea6d3e5ed33961e555eabd9a962806f8768d2367c2516">,
      #splice.entry<"/build/gawk-5.4.1/test/delarpm2.awk" file 644 mtime 1782131302 "fd7fab597227db2e47d175237c934f415880805bd8755a7a1c378b62ea97d4ce">,
      #splice.entry<"/build/gawk-5.4.1/test/delarpm2.ok" file 644 mtime 1782131302 "6de76028895ca1f2b0cdc980614dd28c90afa14bbd6c1a7848244bd6972dc6c1">,
      #splice.entry<"/build/gawk-5.4.1/test/delarprm.awk" file 644 mtime 1782131302 "77dfc122ad83cd82ef8e6ef56b3fd2b4f87ea537e79b1f1ef6101f0be9edf8d4">,
      #splice.entry<"/build/gawk-5.4.1/test/delarprm.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/delfunc.awk" file 644 mtime 1782131302 "d9a746295d1d6252cec895db70ccae8b0ec2bbefd6537eed9e385e8d7299653c">,
      #splice.entry<"/build/gawk-5.4.1/test/delfunc.ok" file 644 mtime 1782131302 "4cea909fa7c02deb31d61575d8a7af2876d3ed7034824aa8539f3a2db4589e30">,
      #splice.entry<"/build/gawk-5.4.1/test/delmessy.awk" file 644 mtime 1782131302 "08c8f4beda7e2be8d66e9b700671376be327a3b93cd6d4e3f4847beda32b2f0c">,
      #splice.entry<"/build/gawk-5.4.1/test/delmessy.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/delsub.awk" file 644 mtime 1782131302 "9285f8b0a6595e25f71361f6778ddea76be8ce65d2900f772ec2a6eeb944dc9d">,
      #splice.entry<"/build/gawk-5.4.1/test/delsub.ok" file 644 mtime 1782131302 "00ed79539e9fa015b4712a769f03965935725dc97203d4c0cb89724ff05007c9">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd.in1" file 644 mtime 1782131302 "a3f702f153d95b4d0b5766e346f5bf02a1116b61cfabe3b1287c2df66f6da911">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd.in2" file 644 mtime 1782131302 "f6cdfe7d4efb7a9dd880bfa3c333ab5d039f1fd756b5a90d81e1ad50055ec889">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd.in4" file 644 mtime 1782131302 "b4e030475a094d8fe4091cc9af2d104bf4a64197a15aeb463c53ca2f9fad234f">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd.in5" file 644 mtime 1782131302 "f3239fbd6c2563969d076ece11139f5794df1f567d5e3339d60bd4166aecf663">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd.ok" file 644 mtime 1782131302 "687f9ec7c6f54eaf5a31c6ef8dc2895750b1c123c3211faa7311096b8a70bcae">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd1.awk" file 644 mtime 1782131302 "9e6d6ca8644ffb2303da827de0e129a0ed5a113e6daa06de930741a890437226">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd1.ok" file 644 mtime 1782131302 "cf187cce88c365e1f52985b024663b882eca1b075d069423d91cff3fe1adb2e8">,
      #splice.entry<"/build/gawk-5.4.1/test/devfd2.ok" file 644 mtime 1782131302 "47e884cdd2655fddf06baa903f3a11d5145f174d2354d7ecf46277fa3e7c6e44">,
      #splice.entry<"/build/gawk-5.4.1/test/dfacheck1.awk" file 644 mtime 1782131302 "8aae09a9754c9263f3a9b508bc85d1b490618d073a162a8e13683015fdbe8e37">,
      #splice.entry<"/build/gawk-5.4.1/test/dfacheck1.in" file 644 mtime 1782131302 "f67385655f0b225a0ab7189e8ae65d5cf58c6c003ff8e8e331a7fc7f01fbb294">,
      #splice.entry<"/build/gawk-5.4.1/test/dfacheck1.ok" file 644 mtime 1782131302 "f67385655f0b225a0ab7189e8ae65d5cf58c6c003ff8e8e331a7fc7f01fbb294">,
      #splice.entry<"/build/gawk-5.4.1/test/dfacheck2.awk" file 644 mtime 1782131302 "a5ada7dd6fcba7015262fb8d46f8d1eba1bd6826e2624c864bf75d0d04a4a8ee">,
      #splice.entry<"/build/gawk-5.4.1/test/dfacheck2.in" file 644 mtime 1782131302 "f9a84e8068571aa93b739c9f88b4a9481f782009bed062c77e6db351c48a0004">,
      #splice.entry<"/build/gawk-5.4.1/test/dfacheck2.ok" file 644 mtime 1782131302 "2e578e9ea23408486908d412a8c785d27975395ad681425623d0b8bb0ae93b12">,
      #splice.entry<"/build/gawk-5.4.1/test/dfamb1.awk" file 644 mtime 1782131302 "1236bcdf4e7b0830e0018a4e5844551fdf96dbb118727bd7ab248b44c6c12bb3">,
      #splice.entry<"/build/gawk-5.4.1/test/dfamb1.in" file 644 mtime 1782131302 "ca4410cbc33a457a80ff37cea8a8ab64ea0ec778666f9f9b5b77fa9933939a3c">,
      #splice.entry<"/build/gawk-5.4.1/test/dfamb1.ok" file 644 mtime 1782131302 "2843b350bf0efdcbd1dc78d647f9a829b2cbf0d57cfcb5cbc71a9b5f11468501">,
      #splice.entry<"/build/gawk-5.4.1/test/dfastress.awk" file 644 mtime 1782131302 "ed6256a8a33fbba266d615d1013a10c1a587f5d86be7dbc854705876140eb4b4">,
      #splice.entry<"/build/gawk-5.4.1/test/dfastress.ok" file 644 mtime 1782131302 "9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa">,
      #splice.entry<"/build/gawk-5.4.1/test/divzero.awk" file 644 mtime 1782131302 "ddd8e500744f14f25ac5ffa72a24ca590a6448bae0ea3aadf1584aff50be7c24">,
      #splice.entry<"/build/gawk-5.4.1/test/divzero.ok" file 644 mtime 1783249447 "4a9a4c11dfc999a6e4e04311affdf06294ece267f998f0105905dc061a4eb5bf">,
      #splice.entry<"/build/gawk-5.4.1/test/divzero2.awk" file 644 mtime 1782131302 "30376e8b8cb1258f077c38138d40fcc7b7b604d44c2f4e1b14aa128a185cb84d">,
      #splice.entry<"/build/gawk-5.4.1/test/divzero2.ok" file 644 mtime 1782131302 "e02769de15d1badd6c2adfccad3a2360ca69025ea190fa01e2d3824bdd9663c6">,
      #splice.entry<"/build/gawk-5.4.1/test/double1.awk" file 644 mtime 1782131302 "cba2c663ae0bf43c38059ea357613fee9086a16fb675197bbcf52432207af405">,
      #splice.entry<"/build/gawk-5.4.1/test/double1.ok" file 644 mtime 1782131302 "3afd99e1828bde22843e213b4e52e252495c5da57b5dda3aac6c65d975215a33">,
      #splice.entry<"/build/gawk-5.4.1/test/double2.awk" file 644 mtime 1782131302 "21780ab8be3dfb5a80e8eb04d311457aaadceda6040928268b5c7c7bc9766538">,
      #splice.entry<"/build/gawk-5.4.1/test/double2.ok" file 644 mtime 1782131302 "1b71f148895b0575d5be85d085aa981bf6e847f43757cb981e23008976749184">,
      #splice.entry<"/build/gawk-5.4.1/test/dtdgport.awk" file 644 mtime 1782131302 "e38105219df54727c7ad0760e5c92aff98a50199b5c7fde893a11b93a503aadd">,
      #splice.entry<"/build/gawk-5.4.1/test/dumpvars.in" file 644 mtime 1782131302 "706204f15ce1834ad298c8e8d270315652bbd6e40cec489f65802db2fdd03167">,
      #splice.entry<"/build/gawk-5.4.1/test/dumpvars.ok" file 644 mtime 1782131302 "cf06b43d0dbf3a275cf97d5b936d5b157daac6d7280378033bf732d1ed3f5987">,
      #splice.entry<"/build/gawk-5.4.1/test/dynlj.awk" file 644 mtime 1782131302 "6762df8e2c2251a44fb8fe93f2ddb83b272ba62968a53e2d12c36c69606a0bc6">,
      #splice.entry<"/build/gawk-5.4.1/test/dynlj.ok" file 644 mtime 1782131302 "795309a0e4cefc242a17ba9c8325a740cc0c7032de1f444fb5646a013b6ab42d">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew1.awk" file 644 mtime 1782131302 "6014c843fc9aed688b9d88e37757d43181857647258f57e263ce8f0b5031910a">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew2.awk" file 644 mtime 1782131302 "575d5153241b833ed78ed8ea8b71092cb1563a9526f60960b87a6c8bd64951a5">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew2.ok" file 644 mtime 1782131302 "b2bb42ee7c51a3d4b8031df526219d666b62b3fdd5cda86894f841178021e9d0">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew3.awk" file 644 mtime 1782131302 "d3c3e2e60c225d112bc15863e142ae6b38b7cac770bd7fecfc1e90dba0d44d42">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew3.ok" file 644 mtime 1782131302 "4fc4b270ee49a7b12cd4c3d6c972603e4fd37e768850071cde1e175bd04170f7">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew4.awk" file 644 mtime 1782131302 "45c194de6b5e0167d2564214ca74bc2f0bbbbffd5ec3440bd16eb4e6bd088ddf">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew4.ok" file 644 mtime 1783249699 "365cfe4879e9bcd5849534f27102e0594960bf57cbeaf9dc0ff1f6d5bd553e3a">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew5.awk" file 644 mtime 1782131302 "d6604fc919ad8927639f6001f4b57724b32b4cf1423fa3bc6a706c2ad10ccbbc">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew5.ok" file 644 mtime 1782131302 "47dbd1252bd3ef4fe68887a02a825a63a9fa4b0fd165c5b86124388bcf945a4d">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew6.awk" file 644 mtime 1782131302 "dde7b36c8c40705dc1cb1d165bdf3a687d664d940d01158013d41fff14d9c597">,
      #splice.entry<"/build/gawk-5.4.1/test/elemnew6.ok" file 644 mtime 1782131302 "f23521e26ea1382195623209539f39e4e5cca9eb50424d69661acb2ffa96cb93">,
      #splice.entry<"/build/gawk-5.4.1/test/eofsplit.awk" file 644 mtime 1782131302 "90b25a278e62bac8ea24548547e2cccced1bb625d548e90982ab39d77369ea1b">,
      #splice.entry<"/build/gawk-5.4.1/test/eofsplit.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/eofsrc1.ok" file 644 mtime 1782131302 "aa57d5c7a8f65227216349410bd67e05b51e414993ab1d719089f8f1017c39aa">,
      #splice.entry<"/build/gawk-5.4.1/test/eofsrc1a.awk" file 644 mtime 1782131302 "52291580cbbb69a1a40a07a407e30e9f69a80b4ec7af7c0c204518734a1555f8">,
      #splice.entry<"/build/gawk-5.4.1/test/eofsrc1b.awk" file 644 mtime 1782131302 "635b21b1e81604ea521159e81c81c5e94f196da85ea1af89e96f3acf11e10971">,
      #splice.entry<"/build/gawk-5.4.1/test/equiv.awk" file 644 mtime 1782131302 "3a887fed4346b3df0c46361b26344b5e2a204970290bcee5a267e9de80579208">,
      #splice.entry<"/build/gawk-5.4.1/test/equiv.in" file 644 mtime 1782131302 "af1daf43f4c362fd8a1b37cddc3cfa9281dea911024bae0c905ab20a403102dc">,
      #splice.entry<"/build/gawk-5.4.1/test/equiv.ok" file 644 mtime 1782131302 "37ba58e158ac54726680851aefd43f882b1e465d51014abf1c563dac1f4f1907">,
      #splice.entry<"/build/gawk-5.4.1/test/errno.awk" file 644 mtime 1782131302 "5dcbc9f5d33bf82c1e89771e605627d09b61641b9b73bdac34dbe5ef4254fda1">,
      #splice.entry<"/build/gawk-5.4.1/test/errno.in" file 644 mtime 1782131302 "6ca9d5edb68deaadc1d3130c5fc3ec36e12db72ad54e93edcd63bdfb40a83300">,
      #splice.entry<"/build/gawk-5.4.1/test/errno.ok" file 644 mtime 1782131302 "b0329c36915588c648b0d2f7a4aec8c587a5711b9895f73b8889b851768abb11">,
      #splice.entry<"/build/gawk-5.4.1/test/escapebrace.awk" file 644 mtime 1782131302 "34817be3f2fb431141774e4937745047d55835ddc0756a0d6ebe841674ccac1d">,
      #splice.entry<"/build/gawk-5.4.1/test/escapebrace.in" file 644 mtime 1782131302 "4f6ec6666f50339e39c2aa1896a3db7b800bbeb517eeb5bc1d1d94b306a51588">,
      #splice.entry<"/build/gawk-5.4.1/test/escapebrace.ok" file 644 mtime 1782131302 "4f6ec6666f50339e39c2aa1896a3db7b800bbeb517eeb5bc1d1d94b306a51588">,
      #splice.entry<"/build/gawk-5.4.1/test/exit.ok" file 644 mtime 1782131302 "c47866a456450d224a2123808826901e875460d1d4b40a23d7e2c57dc6a762b4">,
      #splice.entry<"/build/gawk-5.4.1/test/exit.sh" file 755 mtime 1782131302 "8977c604e345251c56f7173044a379a4e2c6e1526fc9805ddac95cd2c0ca3fd3">,
      #splice.entry<"/build/gawk-5.4.1/test/exit2.awk" file 644 mtime 1782131302 "7f5c997c8faa65f46709999a8eb25e0e6f6b522ccfe8b9209d6687051e421b77">,
      #splice.entry<"/build/gawk-5.4.1/test/exit2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval1.awk" file 644 mtime 1782131302 "d749694c8fe44660cc83e45a5ea17d070ba717201a9bbfd106792cd68f1bd02c">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval1.ok" file 644 mtime 1782131302 "bf631b82762fd6f52c3c1d7b9e3b0b2278e3a2c05560ad96f5e2cf194f3fa588">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval2.awk" file 644 mtime 1782131302 "1563b4f8edc2f004a623fd7beaddffc73dbd45ca58b4baacea4eca854273ea34">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval2.ok" file 644 mtime 1782131302 "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval2.w32" file 644 mtime 1782131302 "0dd4108628687aa3f0bf7713e9f3e568a17954592a40d215a0abcc38cb86e6e4">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval3.awk" file 644 mtime 1782131302 "029b1060b6bf14c85473cbebcd950c4417a8b2d81f39110450e7f488f4e5150d">,
      #splice.entry<"/build/gawk-5.4.1/test/exitval3.ok" file 644 mtime 1782131302 "e3abd66dee50ceeec6c17cfc0618b3e707a4617cc565b35c1bc658fb271a862c">,
      #splice.entry<"/build/gawk-5.4.1/test/fcall_exit.awk" file 644 mtime 1782131302 "8ee419d02c940f1869e97b478f165dd01788975b6337a1d6282c9eca0f5fc5e5">,
      #splice.entry<"/build/gawk-5.4.1/test/fcall_exit.ok" file 644 mtime 1782131302 "223455f022dc67841c4e835e04f1fcaf368910e5ceb393633daf05c1f65f832c">,
      #splice.entry<"/build/gawk-5.4.1/test/fcall_exit2.awk" file 644 mtime 1782131302 "a78aa65dca414944bf47911c0d6449948b289a3c4b2febf4a10d8c357a0a64ed">,
      #splice.entry<"/build/gawk-5.4.1/test/fcall_exit2.in" file 644 mtime 1782131302 "910855a04bdf3594a747f4b50ae8400a3384cfa603e8b39edaea4d96da64a864">,
      #splice.entry<"/build/gawk-5.4.1/test/fcall_exit2.ok" file 644 mtime 1782131302 "ce1bf271d2e9f7a08c28eb28f443b9c6e26c3d0af227303851e86455f5a385ac">,
      #splice.entry<"/build/gawk-5.4.1/test/fflush.ok" file 644 mtime 1782131302 "5b2af44ba3ee13f1fe3f24e7a9a320e51103b414ea5c47b7ffab2d9ac712bb3c">,
      #splice.entry<"/build/gawk-5.4.1/test/fflush.sh" file 755 mtime 1782131302 "4a8710a43e4b00a969e6d9ef416dcfa1833e51c8eb79da67f52bc3514115d87f">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldassign.awk" file 644 mtime 1782131302 "ca021657422a3390be8f3e986c8342999db6c6d15cd889c2dc93ed173b8b7a20">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldassign.in" file 644 mtime 1782131302 "924d391c158a46409fdff363063d718ea0bc00b14556f129984942af91233bbe">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldassign.ok" file 644 mtime 1782131302 "0835ee9e3d79052e5af0c4af1e010d33f376ca2b048a48de2422b4db1d32be31">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldindex.awk" file 644 mtime 1783328483 "2349d7bfb57cd66aba344f62aee5e2e96f257e4c44add2177945bb3d4632977f">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldindex.in" file 644 mtime 1783328483 "f59d6081b232cdde7b6b13e44f8c1d41e968c7544fbbfc2d4f806107c8e30299">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldindex.ok" file 644 mtime 1783328483 "864a93b79abeab7fe17ce6ad313169f374abd0e47746cf00203767492331e690">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldwdth.awk" file 644 mtime 1782131302 "9e222080605161c90deca1ddf262bd8ff66ee9981c4cf95e378c0df702fda12b">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldwdth.in" file 644 mtime 1782131302 "6d78392a5886177fe5b86e585a0b695a2bcd01a05504b3c4e38bc8eeb21e8326">,
      #splice.entry<"/build/gawk-5.4.1/test/fieldwdth.ok" file 644 mtime 1782131302 "0c47cda934d53d7ca29d822a59531dcf6d36cbd9740a4fd0b867a0343910a715">,
      #splice.entry<"/build/gawk-5.4.1/test/filefuncs.awk" file 644 mtime 1782131302 "f0f8c1884f7827bfb30ba667b7b00340360c81d7c61cffd255f91fead27d0350">,
      #splice.entry<"/build/gawk-5.4.1/test/filefuncs.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fix-fmtspcl.awk" file 644 mtime 1782131302 "93608b030611556282b0de35e48c035f83b9ee3094b9973366bf64a1ab045d8f">,
      #splice.entry<"/build/gawk-5.4.1/test/fldchg.awk" file 644 mtime 1782131302 "fdcfde7aaf8d1e3d2579b6c1e02555185a7e2ca8a13827b69d1e4b0055ada1f6">,
      #splice.entry<"/build/gawk-5.4.1/test/fldchg.in" file 644 mtime 1782131302 "6b2733f5ec56d8fbae8ba8168b6c78819cd01391b98896346618aaf2eb0ed923">,
      #splice.entry<"/build/gawk-5.4.1/test/fldchg.ok" file 644 mtime 1782131302 "4064394a28beb78cbf4a904e45fe9ef0418df9a74b5d86fd20f7f0c1882018b0">,
      #splice.entry<"/build/gawk-5.4.1/test/fldchgnf.awk" file 644 mtime 1782131302 "b386d60dcc654de59cdddb25e96142e1be5801cf344348f29c596663039f3ef9">,
      #splice.entry<"/build/gawk-5.4.1/test/fldchgnf.in" file 644 mtime 1782131302 "4cb94c6c34547f5561769d978f4f8fd8a70621d80796fc8acaf2258bd13265d1">,
      #splice.entry<"/build/gawk-5.4.1/test/fldchgnf.ok" file 644 mtime 1782131302 "73ad8d6059d9cb77dbc64056540981b3fd7f0afe9e0f85fcda36d6e8430f71fe">,
      #splice.entry<"/build/gawk-5.4.1/test/fldterm.awk" file 644 mtime 1782131302 "555fd2948c426b29f7974db7c6ade37883c9f17a7e0328d0718815c02b5ee922">,
      #splice.entry<"/build/gawk-5.4.1/test/fldterm.in" file 644 mtime 1782131302 "0fc0f0638fbe12a24fd14f6978f118cedead965abcc4f94c6def7925cdc0dc1f">,
      #splice.entry<"/build/gawk-5.4.1/test/fldterm.ok" file 644 mtime 1782131302 "da4a03be1641bc2ce5fd8789a3273d99af29ceba71af310c3df6786e4ec2f0cd">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtmix.awk" file 644 mtime 1783249935 "fd7790fdb7e9db452bfcbdafc2225598c8b5920d364008b80e0f002ffa88f511">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtmix.in" file 644 mtime 1783249935 "8b2400d87bdbae9842fb0f3af97842ee8245fb64129e1b0aa046a0b299267505">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtmix.ok" file 644 mtime 1783249935 "ff14686effb1f0fd34a693a47a30178387a2fbdf6b6ef6c6da4f6426ae4c62a4">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtspcl-mpfr.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtspcl.awk" file 644 mtime 1782131302 "28fbcf0048b9c8278f5719043b87b87d6c5a38ab08cf8d601ccf63637a0157d8">,
      #splice.entry<"/build/gawk-5.4.1/test/fmtspcl.tok" file 644 mtime 1782131302 "9d7653ac100579febb8bca4e895e8bdb8679026e85543ff905e617a5bd50f6b8">,
      #splice.entry<"/build/gawk-5.4.1/test/fmttest.awk" file 644 mtime 1782131302 "0af8fc1c0f552849daf1d247c489d8faf6391cd2d92f758934f537b11a91cab4">,
      #splice.entry<"/build/gawk-5.4.1/test/fmttest.ok" file 644 mtime 1782131302 "3e6045999aa63ea63c10a477ec2517ab6c1d6e00d7b172757d14763a17f5f9d5">,
      #splice.entry<"/build/gawk-5.4.1/test/fnamedat.awk" file 644 mtime 1782131302 "e8fa70e9d767bd2a48384d6d56a922e5dbab33889c6a9f990d393993414b823f">,
      #splice.entry<"/build/gawk-5.4.1/test/fnamedat.in" file 644 mtime 1782131302 "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c">,
      #splice.entry<"/build/gawk-5.4.1/test/fnamedat.ok" file 644 mtime 1782131302 "5c6d31fae0caf1793042c8dc9256f4b670528f3305a5752d69aa8cfe0e4b02bc">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarray.awk" file 644 mtime 1782131302 "141ac7cc8921dce4610c3578672ca4531271f9b4f65d6597c277d53c95d93dee">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarray.ok" file 644 mtime 1782131302 "e4093b816e1145b969d4f7b6c7f071a36b5aee7eb1c1e1d8f3c36074d4f2e484">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarray2.awk" file 644 mtime 1782131302 "c020528e2cca5037f91459d7319807213155f51290ccbf6f21165c4924e86f22">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarray2.in" file 644 mtime 1782131302 "73cb3858a687a8494ca3323053016282f3dad39d42cf62ca4e79dda2aac7d9ac">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarray2.ok" file 644 mtime 1782131302 "181b0fed9f2d702f0939cf15e471a1e09d371a3d23d60c804c43083c757548fd">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarydel-mpfr.ok" file 644 mtime 1782131302 "45b179999e0173d46e663111485a66546ac8dbae39ce4c9b59ea9cf8b9f7494e">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarydel.awk" file 644 mtime 1782131302 "d4a30cccf47cb2a97a025a331a3af8a165ea7f42400effad4e1dd5d6bf0b8b1a">,
      #splice.entry<"/build/gawk-5.4.1/test/fnarydel.ok" file 644 mtime 1782131302 "4ff21d78e03f45e6dca338ebd0e9bcd414c62e436fc331de41d391a5fa3c92c0">,
      #splice.entry<"/build/gawk-5.4.1/test/fnaryscl.awk" file 644 mtime 1782131302 "c6aa6e6d45f8ec88978faa1da3fa8174f820eb356662ba9bf5088e4afde9d5b7">,
      #splice.entry<"/build/gawk-5.4.1/test/fnaryscl.ok" file 644 mtime 1782131302 "5106cde91493bc40194bc6e4e91d6529bb3f66f0a8cfbecc7748dd685d516e17">,
      #splice.entry<"/build/gawk-5.4.1/test/fnasgnm.awk" file 644 mtime 1782131302 "68234bda966888a7793bd719a07d87bd772cbc151f9283bd34859e19009577ab">,
      #splice.entry<"/build/gawk-5.4.1/test/fnasgnm.in" file 644 mtime 1782131302 "edff58f2a441868dc58c35d06f2b1c86e12e12bedfaa793a49c227672f77566e">,
      #splice.entry<"/build/gawk-5.4.1/test/fnasgnm.ok" file 644 mtime 1782131302 "85d391739defd81bc8294e7a392ca0359347243f41c455fff06a3069d74ff503">,
      #splice.entry<"/build/gawk-5.4.1/test/fnmatch.awk" file 644 mtime 1782131302 "298fea376e376e6a4b6d718505d3a0a53bb1aa82a2b1b790c30df3b0109bce67">,
      #splice.entry<"/build/gawk-5.4.1/test/fnmatch.ok" file 644 mtime 1782131302 "34485f3123b99f548819989d7ef9972d7d69194a326163dc55726f50c9185373">,
      #splice.entry<"/build/gawk-5.4.1/test/fnmisc.awk" file 644 mtime 1782131302 "554785a81ae007995fee7820884b109355ce038d9edcd39990d7cd53a3236b1a">,
      #splice.entry<"/build/gawk-5.4.1/test/fnmisc.ok" file 644 mtime 1782131302 "1d997f5e947c18457b77ab989d2924debc494b57b326a99c650e554894538804">,
      #splice.entry<"/build/gawk-5.4.1/test/fnparydl-mpfr.ok" file 644 mtime 1782131302 "e0b83e2c0c6ff326316b60e820b1c8f58b19db549ed08f3a23bd411b33d6b0a1">,
      #splice.entry<"/build/gawk-5.4.1/test/fnparydl.awk" file 644 mtime 1782131302 "16cd667abcbd123e1089176936674ad84e65a74969ab26370bd964b9c4c5a0cc">,
      #splice.entry<"/build/gawk-5.4.1/test/fnparydl.ok" file 644 mtime 1782131302 "4409902458f46301049ec59ffc97ae01e6a250bb93039c9df397ac2853f2af2d">,
      #splice.entry<"/build/gawk-5.4.1/test/forcenum.awk" file 644 mtime 1782131302 "fdf4ccdd4f96caa0b906823fe0eb30e79d73943adb093d95e40a50c4669c4c7e">,
      #splice.entry<"/build/gawk-5.4.1/test/forcenum.ok" file 644 mtime 1782131302 "7a3cb91cc8b11239988cdb9f44756ad8558e590f0a277b5547031cd0f15713ad">,
      #splice.entry<"/build/gawk-5.4.1/test/fordel.awk" file 644 mtime 1782131302 "03af9d494790c415c159b68db7bf06f58cb24ae88e50166f0266efcb9328fa00">,
      #splice.entry<"/build/gawk-5.4.1/test/fordel.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fork.awk" file 644 mtime 1782131302 "85f4e31c75e184b295ea8bbbacc44529232cd37fb12131a71c3236ac8aa1410f">,
      #splice.entry<"/build/gawk-5.4.1/test/fork.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/fork2.awk" file 644 mtime 1782131302 "75dfedcd9dcac8c0acb5cb72eaaff9eb859f2833efb6e73777aae9253f156050">,
      #splice.entry<"/build/gawk-5.4.1/test/fork2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/forref.awk" file 644 mtime 1782131302 "aa390586b42b5b91896ea9e24e9f75a61d46607b08f5f5c3ec3bfafdfd8c90f5">,
      #splice.entry<"/build/gawk-5.4.1/test/forref.ok" file 644 mtime 1782131302 "6bca7f49c59e4bedbd3b0189a4763d9613946331382828f7b5b9e6f68e7e23f6">,
      #splice.entry<"/build/gawk-5.4.1/test/forsimp.awk" file 644 mtime 1782131302 "1f2a0aa0877d418752aeb9f760a5ee9dd5cbf4cfbdcb0c77c352bdb31d9c8bc6">,
      #splice.entry<"/build/gawk-5.4.1/test/forsimp.ok" file 644 mtime 1782131302 "2e6d31a5983a91251bfae5aefa1c0a19d8ba3cf601d0e8a706b4cfa9661a6b8a">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat1.awk" file 644 mtime 1782131302 "6251c14e0da50793047236af6241c533fd198e50e1f16d6d01857396eeb56338">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat1.in" file 644 mtime 1782131302 "1d6aeda2d38f06521519b0ccf2f2aa98e34562ae917a6a244f5dc854a6e3aa7b">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat1.ok" file 644 mtime 1782131302 "37df8199a1aa920a85c1ce6ccf989c9aca5dece7b78ed3f82cd8f1498daffd93">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat2.awk" file 644 mtime 1782131302 "852f3e186bf4f488b002527417239428e3fc481e8a7f2b7fc48d9bcc681e172c">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat2.ok" file 644 mtime 1782131302 "c13932fbb0fa32654a96b61c8517ea4788d7f717c5bd1b6a65d477029dbb53ed">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat3.awk" file 644 mtime 1782131302 "1495fe361ab88d29a2abc864f141c202d760d5b2f9367626353cc232d39e5c18">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat3.in" file 644 mtime 1782131302 "396fba178da86333d281105998d8da8ffc0df6ccab3ef45a8017f88d6f8cc451">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat3.ok" file 644 mtime 1782131302 "0c21fce2b0cecf8783a758ccd71780190f716daf6730c9286cb618d8250aa12b">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat4.awk" file 644 mtime 1782131302 "cc101c077104c89c9ecac3358028eedd3d9a7c04833868ad355783b9b2c02122">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat4.ok" file 644 mtime 1782131302 "62c2ddd5b36e81151aa9b5dbaaccba6c3229bffcbda537eabb8109ee424a2a63">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat5.awk" file 644 mtime 1782131302 "c959cad4a2d0e7985da0692dd691715dc84b8da724f9897a4757ad8c665047d9">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat5.in" file 644 mtime 1782131302 "0f32aad400cfb36e4aca0891f7f3c06fa8db2e1ec7c92e4e57008f11c9af68c6">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat5.ok" file 644 mtime 1782131302 "3912b78b4662014dddf3da936e731669f4f0689343a9bf7e63bbd58013e3a457">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat6.awk" file 644 mtime 1782131302 "1d78b3c14c241316beb27b6a46df6ff259e84727b283399bc70edb263c23a065">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat6.in" file 644 mtime 1782131302 "fba86f8d1b66944faec8cdf6a73c46bad9c342bc87b30fbf35c8c70efc00dfe0">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat6.ok" file 644 mtime 1782131302 "09a53ab5a4bd80c16c49d4bf96ffa060e3f94e14d9ddf84a1d52eb99946a93f7">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat7.awk" file 644 mtime 1782131302 "a9ae01b0c1e36e6388680f6d1fc941db1541646de09f91e27f5d9a0c5e863bf3">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat7.in" file 644 mtime 1782131302 "72263339c9261d1ee40521d20a970ea8beb71c54ac9d047a388df0a047142781">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat7.ok" file 644 mtime 1782131302 "2c47f774aecc93f91872d0039ced819bbb907c0d8d0cb5ad81d69cdb611e84d0">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat8.awk" file 644 mtime 1782131302 "2de124be6067f9ae07d7a9461c0af611a8629a9d8442cd5fb97a99344d32b500">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat8.in" file 644 mtime 1782131302 "4cb94c6c34547f5561769d978f4f8fd8a70621d80796fc8acaf2258bd13265d1">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat8.ok" file 644 mtime 1782131302 "816d648195e4dadef12340e2d58e8f59bfc20825e882bf76a56d89291c33c10e">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat9.awk" file 644 mtime 1782131302 "743d1c4a97955df2b4ecc6d129e0cfa8021a52525fa5310c65ac75a42c4fa4a9">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat9.in" file 644 mtime 1782131302 "59bc9dcc0fc2647fe62de0a166d070a57f01f64a55dec4ff43e43029f84c0801">,
      #splice.entry<"/build/gawk-5.4.1/test/fpat9.ok" file 644 mtime 1782131302 "793b603c5ba2903399042c7d147ec954f7fc4c9d8b690f2a1d9f67afa6d7f5b9">,
      #splice.entry<"/build/gawk-5.4.1/test/fpatnull.awk" file 644 mtime 1782131302 "7ca76d7324b25bbae652bef4111f75d3a7cfd96256050efc92c541ea62b8eeb8">,
      #splice.entry<"/build/gawk-5.4.1/test/fpatnull.in" file 644 mtime 1782131302 "853ff93762a06ddbf722c4ebe9ddd66d8f63ddaea97f521c3ecc20da7c976020">,
      #splice.entry<"/build/gawk-5.4.1/test/fpatnull.ok" file 644 mtime 1782131302 "1a252402972f6057fa53cc172b52b9ffca698e18311facd0f3b06ecaaef79e17">,
      #splice.entry<"/build/gawk-5.4.1/test/fr" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/test/fr/LC_MESSAGES" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/test/fr/LC_MESSAGES/nlstringtest.mo" file 644 mtime 1782131302 "4caa7a09c1fbc946236acfad7ba373f89627966a00314143ccfc091f88523bd7">,
      #splice.entry<"/build/gawk-5.4.1/test/fsbs.awk" file 644 mtime 1782131302 "047b6baf01f864dc73547ac5124cef601b979183d97be5881d758756c18c1ce1">,
      #splice.entry<"/build/gawk-5.4.1/test/fsbs.in" file 644 mtime 1782131302 "23792183c88bdad05b4ec19d377ffef3fbb10c1c0014d6ebaf3d7917d06a8312">,
      #splice.entry<"/build/gawk-5.4.1/test/fsbs.ok" file 644 mtime 1782131302 "f251ddc12234e0da8d3b778bd0f7463fb477f16f47757f5617dc8b4ff4d4f14a">,
      #splice.entry<"/build/gawk-5.4.1/test/fscaret.awk" file 644 mtime 1782131302 "2575fe03bf52094521fb897aefe8b24caed1da650232a5ae6d9557bdf6c0785a">,
      #splice.entry<"/build/gawk-5.4.1/test/fscaret.in" file 644 mtime 1782131302 "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c">,
      #splice.entry<"/build/gawk-5.4.1/test/fscaret.ok" file 644 mtime 1782131302 "625337e242c32dae6d1f6d55710d953aaa06bbd82b22780d5038031f60b1a6c2">,
      #splice.entry<"/build/gawk-5.4.1/test/fsfwfs.awk" file 644 mtime 1782131302 "d2b2547b11344a8859dfbd002656bd5d90c323f9540f81eba9faef77ce910e34">,
      #splice.entry<"/build/gawk-5.4.1/test/fsfwfs.in" file 644 mtime 1782131302 "a687b72b0b2e125d058006ac5c46d77022df936c47fa406abca03f23ee7190af">,
      #splice.entry<"/build/gawk-5.4.1/test/fsfwfs.ok" file 644 mtime 1782131302 "820c6f07d375ad29a414edcf7767f94291808910cbbd6426696ab1e454ebd903">,
      #splice.entry<"/build/gawk-5.4.1/test/fsnul1.awk" file 644 mtime 1782131302 "96d3abc974e80e78a663a25269e7955acb843dd8d61abfacb8c3f9fea46f2e3e">,
      #splice.entry<"/build/gawk-5.4.1/test/fsnul1.in" file 644 mtime 1782131302 "b61c57a60e8cc2eb1274e304abd94813947a1ed3c60b4910363a1a5293dd02b4">,
      #splice.entry<"/build/gawk-5.4.1/test/fsnul1.ok" file 644 mtime 1782131302 "56cc5eec55dc58c7043ac724f962e41892ef591552dd023a9b81f95958bfff63">,
      #splice.entry<"/build/gawk-5.4.1/test/fsrs.awk" file 644 mtime 1782131302 "59c883a50f2a6e8ae987fc2bf406df6e15a2aa78190c33f33c80aa7c1d1bd253">,
      #splice.entry<"/build/gawk-5.4.1/test/fsrs.in" file 644 mtime 1782131302 "f416c414dcf935d8f37b2071f2ed52bfb0513327b705640b9c0ef2e935f28770">,
      #splice.entry<"/build/gawk-5.4.1/test/fsrs.ok" file 644 mtime 1782131302 "115135dfe83dc263f8499ab22b78e2b0c0a1df6726749824b4427b41e24f69c6">,
      #splice.entry<"/build/gawk-5.4.1/test/fsspcoln.awk" file 644 mtime 1782131302 "a2b16992628b612589dffee712335f84a3a2b7dd7a490fc98b05b0207683c19c">,
      #splice.entry<"/build/gawk-5.4.1/test/fsspcoln.in" file 644 mtime 1782131302 "caa019f91e6fca74781a52f87cf4df8c86e4421830839945f9c0f57e8c22179a">,
      #splice.entry<"/build/gawk-5.4.1/test/fsspcoln.ok" file 644 mtime 1782131302 "0263829989b6fd954f72baaf2fc64bc2e2f01d692d4de72986ea808f6e99813f">,
      #splice.entry<"/build/gawk-5.4.1/test/fstabplus.awk" file 644 mtime 1782131302 "ea7f55adaa6a409df05eaa36591c2b87067debc0656644bde9d240608a2e9c90">,
      #splice.entry<"/build/gawk-5.4.1/test/fstabplus.in" file 644 mtime 1782131302 "29f723338ac59174f4be8fff7c4bf22564b51c2d07368878a416e49735e404c9">,
      #splice.entry<"/build/gawk-5.4.1/test/fstabplus.ok" file 644 mtime 1782131302 "f251ddc12234e0da8d3b778bd0f7463fb477f16f47757f5617dc8b4ff4d4f14a">,
      #splice.entry<"/build/gawk-5.4.1/test/fts.awk" file 644 mtime 1782131302 "69a36c378343b29eea62ef4682132278cd9f4b2b0fc31af8bfddbda2b34ce2c9">,
      #splice.entry<"/build/gawk-5.4.1/test/functab1.awk" file 644 mtime 1782131302 "7a971f2447b1062a8d57a3fa9dbd04266aa0d20a390ecbcebd6a483b78c24bfd">,
      #splice.entry<"/build/gawk-5.4.1/test/functab1.ok" file 644 mtime 1782131302 "63cde3d88ffcebb77f3f511be119a3898796eca9e7fe48e4450ffd2197cd8071">,
      #splice.entry<"/build/gawk-5.4.1/test/functab2.awk" file 644 mtime 1782131302 "e20d89185cb6e2e34898a287471f69bed605c9dcd87cf6a685565b4733bcb634">,
      #splice.entry<"/build/gawk-5.4.1/test/functab2.ok" file 644 mtime 1782131302 "a43bd84c752afc53d4330bc2a54075b2925b5e46690673db8fc009837e3a0db6">,
      #splice.entry<"/build/gawk-5.4.1/test/functab3.awk" file 644 mtime 1782131302 "a15cdf810236737d1fe115f5eb84b1b1d7f4d4bd15f127e519f8b3bce6d45a6e">,
      #splice.entry<"/build/gawk-5.4.1/test/functab3.ok" file 644 mtime 1782131302 "b41ae3ae0c1fc9b2cc3b67f0433b5b6d8a203c8a5dd095f6173d0d5738ee0ca5">,
      #splice.entry<"/build/gawk-5.4.1/test/functab4.awk" file 644 mtime 1782131302 "85f32d84f4df41ec7336a2ba5ee49f7433ab1d17c32c9e9d147228483cab0763">,
      #splice.entry<"/build/gawk-5.4.1/test/functab4.ok" file 644 mtime 1782131302 "203bd607e893ac2301a26a311a3e4c41f40d01a446654936922fae80990c3285">,
      #splice.entry<"/build/gawk-5.4.1/test/functab5.awk" file 644 mtime 1782131302 "a496fbe6eacd764f229a953206e55fc78ffd4e166ca4928311533cd26784e3ed">,
      #splice.entry<"/build/gawk-5.4.1/test/functab5.ok" file 644 mtime 1782131302 "6b813a02a53ef4ae06ae5219f27cd86b0db1fc57a2765722b5e61d78df7ba989">,
      #splice.entry<"/build/gawk-5.4.1/test/functab6.awk" file 644 mtime 1782131302 "e7429bf9c0ffa9da53689e15786a87f5b199f954bc2727453f78fcb34992fb61">,
      #splice.entry<"/build/gawk-5.4.1/test/functab6.ok" file 644 mtime 1782131302 "3e6d8cd65234b9355b01754dc14a60b21345a9d7e96d09920fb86e335b1a8742">,
      #splice.entry<"/build/gawk-5.4.1/test/funlen.awk" file 644 mtime 1782131302 "5ef12354cc5f7490ad11f43cb89017503fd4337c5733949c1da43247d34a0d40">,
      #splice.entry<"/build/gawk-5.4.1/test/funlen.in" file 644 mtime 1782131302 "3e471b16f664a7fb50495ad35194e9899ffeee48c97caa0106f600f39d42cab7">,
      #splice.entry<"/build/gawk-5.4.1/test/funlen.ok" file 644 mtime 1782131302 "c4cce85f1c08c47ddd70477094975de981a3ea8f14af86d76e719f117c653922">,
      #splice.entry<"/build/gawk-5.4.1/test/funsemnl.awk" file 644 mtime 1782131302 "a94d7c1e3862b80558c77f0b50dd0504a73ecfe44ffd9661125bc3e8656670c7">,
      #splice.entry<"/build/gawk-5.4.1/test/funsemnl.ok" file 644 mtime 1782131302 "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c">,
      #splice.entry<"/build/gawk-5.4.1/test/funsmnam.awk" file 644 mtime 1782131302 "47918fcbcd647f59e46d57e285e07e937560d9355e4f09da5e5ce57a1fdbbcc9">,
      #splice.entry<"/build/gawk-5.4.1/test/funsmnam.ok" file 644 mtime 1782131302 "444999144e472c3d7a64a7442ba91a4d15989f0913bff3e3722d98512d09772a">,
      #splice.entry<"/build/gawk-5.4.1/test/funstack.awk" file 644 mtime 1782131302 "3aa113ec2a9adf2d47fd49853d113415c2a058eb44d9cb3658472ce4a0ac68d5">,
      #splice.entry<"/build/gawk-5.4.1/test/funstack.in" file 644 mtime 1782131302 "6dbccc8b23dd0dd9be94ac1b93c41db0e190625272b8cee34d9a823728e0eeb2">,
      #splice.entry<"/build/gawk-5.4.1/test/funstack.ok" file 644 mtime 1782131302 "40f2d0cfd0eec0de5bb7c38286b0caa91e4e5d623d3ef2401f1eecf5c8702a60">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest.awk" file 644 mtime 1782131302 "02acfedab991a228e967b84c42681becd739771f9192868c0e326bb08ce7aaf5">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest.in" file 644 mtime 1782131302 "edeaaff3f1774ad2888673770c6d64097e391bc362d7d6fb34982ddf0efd18cb">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest.ok" file 644 mtime 1782131302 "b800a439e4a3c84f8b865f5a7d799584fe2645b6b4278f2eeab51031e8192a34">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest2.awk" file 644 mtime 1782131302 "b7a51b4798333e9497b52de4ab22b4e9c6c84165d3df1aa61b314b917e15f6a5">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest2.in" file 644 mtime 1782131302 "c4bf9f95dae48878cec50fdb961a4f525ff43dc9e23fc4c5f653e28e777f75a0">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest2.ok" file 644 mtime 1782131302 "f902e9f9a72fbd99ac1d3f61134d03d2518ca962cb691ec50fe2cba029508252">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest3.awk" file 644 mtime 1782131302 "b87897784d33c9c967de6bb3e53181f3c068061a40b6467c042e923e4d6e138f">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest3.in" file 644 mtime 1782131302 "c4bf9f95dae48878cec50fdb961a4f525ff43dc9e23fc4c5f653e28e777f75a0">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest3.ok" file 644 mtime 1782131302 "36e56b81852d925d0e8d3638817443d4934520949f52257948a9aab631a882f2">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest4.awk" file 644 mtime 1782131302 "2f39db3c220143d5558ad53464737396e9298471a0d3b798f2f4d260c7d1b3c4">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest4.in" file 644 mtime 1782131302 "4795a1c2517089e4df569afd77c04e949139cf299c87f012b894fccf91df4594">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest4.ok" file 644 mtime 1782131302 "f33ae3bc9a22cd7564990a794789954409977013966fb1a8f43c35776b833a95">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest5.awk" file 644 mtime 1782131302 "507e71c1a72655d253d124e380bda47b50cd9ea2f693a752652fec236e54cc5c">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest5.in" file 644 mtime 1782131302 "3eb4c5d914afc7e6d3438080e3a53bf9f13ccdfb6191e822105aca2f72196d71">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest5.ok" file 644 mtime 1782131302 "c202425532c1677a00b908bad38e1aafb6b298d81d35b312b958bc2f886dc97c">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest6.awk" file 644 mtime 1782131302 "0f83728355c6e50d22c0a602ef04bd6ad04bdac980f98d188e887e2fc9291a65">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest6.in" file 644 mtime 1782131302 "cef796521ccbff1b2c9f9341cbf4d4f73a5576f98a82fb9399d648dea6b1e922">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest6.ok" file 644 mtime 1782131302 "ffc3ca0f21edbb01a798b9aa746547ebecfce7369e8ee2a6da4260e4658d2065">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest7.awk" file 644 mtime 1782131302 "c23bb0a266797f98d762c75d7026cec578d805c5ac461f1991ad7c7370396501">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest7.in" file 644 mtime 1782131302 "498d33378661e22ab3440ab24bd8e62144bf5ffffdae177165a0d1f4638be2f0">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest7.ok" file 644 mtime 1782131302 "10c955d6bb464d44efdaada64cc5ab7112ba4e292aefe287c396e1c85744e50c">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest8.awk" file 644 mtime 1782131302 "053a7219b97ca56b81e45430a0488c40cf3906bfe0bc7bf718ab7094eb4d6cb9">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest8.in" file 644 mtime 1782131302 "1424d10d01e3b1adfa5baedc4b538573a0df4f7c28a171925b30c664a2da1898">,
      #splice.entry<"/build/gawk-5.4.1/test/fwtest8.ok" file 644 mtime 1782131302 "46ec4515f9735fff7ba2e9032eed838fcfd9157772c6560d66d591925e2ceb69">,
      #splice.entry<"/build/gawk-5.4.1/test/genpot.awk" file 644 mtime 1782131302 "696c75421d2b078b127030f242bbe66e6595384e51662c5a42a5867f6514029d">,
      #splice.entry<"/build/gawk-5.4.1/test/genpot.ok" file 644 mtime 1782131302 "2f694ace3587c0d9b46795e8105f2f0c6120f8acef3525f2b374ec839d9561a1">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub.awk" file 644 mtime 1782131302 "4397df8e89aa6bf53876a09c96f9f039c08a72b2e62a8d2b12ef5040dd98c533">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub.in" file 644 mtime 1782131302 "c6a34d9f04600b19ee2063d58bb860aeb05fe7e3b74b55c23c62ec56ba6056de">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub.ok" file 644 mtime 1782131302 "a8d00b9be112ababdcab08415c7f7bc9f05415dc84698b637d52f4e4c5a6a2c4">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub2.awk" file 644 mtime 1782131302 "7bcbee9df1e4091290c74dc529705d124bea9a5748d1e5ce638eff665a5ae683">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub2.ok" file 644 mtime 1782131302 "cdc698535938b55327e4c7f7848745f123cfd27890ae6d61a8487b9741d7cacb">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub3.awk" file 644 mtime 1782131302 "0fad5a5672ab55e2a85d79e674b5c64e120fbb5a383bf2776e2e641c91fce360">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub3.in" file 644 mtime 1782131302 "9ff482bbad59dc6d2dda31549c8431f4cfd280a2e6b52f4b0f761b5961593322">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub3.ok" file 644 mtime 1782131302 "303980bcb9e9e6cdec515230791af8b0ab1aaa244b58a8d99152673aa22197d0">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub4.awk" file 644 mtime 1782131302 "8a0e5563dad1151c6365ca12af295ee00984dcee719647b576d8611b78f1b913">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub4.ok" file 644 mtime 1782131302 "b1fd87101a95dea64c74dd2bdf570d7b86fda01acfd4e3ff9802f52835fc0170">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub5.awk" file 644 mtime 1783241692 "83371f48eb83d7f40e16088571608c077df2511ff85f0d2f3ccba0c69adc6a57">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub5.in" file 644 mtime 1783241692 "623b6b282adf9e09066d63a7de2b17210e06f6a3cf918fd460a48871d68db0ae">,
      #splice.entry<"/build/gawk-5.4.1/test/gensub5.ok" file 644 mtime 1783241692 "ec0e542b893392997aedc3f91eae574b80459c386a71e65283119cc96761ec6c">,
      #splice.entry<"/build/gawk-5.4.1/test/getfile.awk" file 644 mtime 1782131302 "48277ea4d0249b93443b30c79609e5ab039c0f4d9a8e0a476fa65b2b440da047">,
      #splice.entry<"/build/gawk-5.4.1/test/getfile.ok" file 644 mtime 1782131302 "9c7879e5ba4b70c57568bfdb68df009e7b156fea73a14cb2d53518b1bdd1fc47">,
      #splice.entry<"/build/gawk-5.4.1/test/getline.awk" file 644 mtime 1782131302 "84b766248b7bb76baf74eb977c32fec718f6818fe3f0789a24c6dfa38fe5c8bf">,
      #splice.entry<"/build/gawk-5.4.1/test/getline.in" file 644 mtime 1782131302 "706204f15ce1834ad298c8e8d270315652bbd6e40cec489f65802db2fdd03167">,
      #splice.entry<"/build/gawk-5.4.1/test/getline.ok" file 644 mtime 1782131302 "6bb4a18c014fe54ca7617ca6890cdc688b67c8a469cef9ee4d06738774fe757e">,
      #splice.entry<"/build/gawk-5.4.1/test/getline2.awk" file 644 mtime 1782131302 "cfdf614db4bf088ca37e9ba05fd81143a614ca661fa795e16df5b3e8e6b10150">,
      #splice.entry<"/build/gawk-5.4.1/test/getline2.ok" file 644 mtime 1782131302 "0b3bd05020f858a307bc82cced4e69f466333883e2b9412592d8b83f15213982">,
      #splice.entry<"/build/gawk-5.4.1/test/getline3.awk" file 644 mtime 1782131302 "7533a9e92d1d3eec1a9c0eb1940b4852f4cde151fed3c16e0e8e7400d22c4b2d">,
      #splice.entry<"/build/gawk-5.4.1/test/getline3.ok" file 644 mtime 1782131302 "54183f4323f377b737433a1e98229ead0fdc686f93bab057ecb612daa94002b5">,
      #splice.entry<"/build/gawk-5.4.1/test/getline4.awk" file 644 mtime 1782131302 "5702f17a5e92ee956013859ad70c40909ce01659ca563270b3eb909a03e5380f">,
      #splice.entry<"/build/gawk-5.4.1/test/getline4.in" file 644 mtime 1782131302 "3ad5fb330a1e0d2be0bf0400a5e008ec3630f7fe7f8272c29e0726bf7e7eef67">,
      #splice.entry<"/build/gawk-5.4.1/test/getline4.ok" file 644 mtime 1782131302 "3ad5fb330a1e0d2be0bf0400a5e008ec3630f7fe7f8272c29e0726bf7e7eef67">,
      #splice.entry<"/build/gawk-5.4.1/test/getline5.awk" file 644 mtime 1782131302 "8b192014b9e67fbefb9f30d104d584c4e39b3b4945d2348e86b99b64d7796df3">,
      #splice.entry<"/build/gawk-5.4.1/test/getline5.ok" file 644 mtime 1782131302 "53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnbuf.awk" file 644 mtime 1782131302 "ef2efaf93d0e2b79d7a6820f2b5cc5121f6cebe80eb37329a4b5c5dfbbacbf2b">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnbuf.in" file 644 mtime 1782131302 "4e08d0040a74452a61f8d7dee4a4c8c889c474716da52d23de53d7e211ca3fe0">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnbuf.ok" file 644 mtime 1782131302 "4e08d0040a74452a61f8d7dee4a4c8c889c474716da52d23de53d7e211ca3fe0">,
      #splice.entry<"/build/gawk-5.4.1/test/getlndir.awk" file 644 mtime 1782131302 "9a8aef9f31d1e0a3133744a4280f1c6ad8bc11ea5826241431a3cfe8f3b78281">,
      #splice.entry<"/build/gawk-5.4.1/test/getlndir.ok" file 644 mtime 1782131302 "7c9f60a8f7dc012582a223813d4cb112cf963cbf1112ebd52198435cfab5bf23">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnfa.awk" file 644 mtime 1782131302 "b3526fd7b7b9dbabb5b5ae05ea0ac0ad1a1e28e6e8c6e71a8f66d91b5a926cd6">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnfa.ok" file 644 mtime 1782131302 "9d7533923bb1a5c1d9bfa0abb90f8b35ba539410f5be3b8a6359053621dc8c9a">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnhd.awk" file 644 mtime 1782131302 "9a998628b027ae6bac2f6aecfbd634738ccde4df44e63a1e1c3e9ffff49b9bbc">,
      #splice.entry<"/build/gawk-5.4.1/test/getlnhd.ok" file 644 mtime 1782131302 "8a69454ad8e3ef5a5444b1feebb4dc2d2637a91792c52129e345958a756d7ee4">,
      #splice.entry<"/build/gawk-5.4.1/test/getnr2tb.awk" file 644 mtime 1782131302 "a8170d283f8dc7165d612b8dbfa41a048c1e304c5c8854cdf3d1d3c02f377f71">,
      #splice.entry<"/build/gawk-5.4.1/test/getnr2tb.in" file 644 mtime 1782131302 "dcf65cfff29e5a15d4abebc8841cb82a43e9ba53e02dc602e8c53d0dc6ad473f">,
      #splice.entry<"/build/gawk-5.4.1/test/getnr2tb.ok" file 644 mtime 1782131302 "b3547d0a9b6e026b0078dd6ae67d07bb9d20f6e895eda260e1eaed0dae2c61de">,
      #splice.entry<"/build/gawk-5.4.1/test/getnr2tm.awk" file 644 mtime 1782131302 "14e7c160ad3960b0decd2f0a72da716ea2fafb629be9679d75f22527f4497397">,
      #splice.entry<"/build/gawk-5.4.1/test/getnr2tm.in" file 644 mtime 1782131302 "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7">,
      #splice.entry<"/build/gawk-5.4.1/test/getnr2tm.ok" file 644 mtime 1782131302 "e04e070c2909a0d7f166f6de0d481fc3e71d88c4d6d523a55fb9ac97ce16ac45">,
      #splice.entry<"/build/gawk-5.4.1/test/gnuops2.awk" file 644 mtime 1782131302 "1cc80e1558539bb17cf2d34e7194d9aae8c50255564f8cb9a84fc77aece73a2b">,
      #splice.entry<"/build/gawk-5.4.1/test/gnuops2.ok" file 644 mtime 1782131302 "0e6f726486b5745d3def0fbf8d0011fd2cde8b996b07ba6c7f03958b035afacf">,
      #splice.entry<"/build/gawk-5.4.1/test/gnuops3.awk" file 644 mtime 1782131302 "4c8ba1e10cbe03b3531f4cf0ce4860bf87120e5547296d8d71fc0dce1bae8536">,
      #splice.entry<"/build/gawk-5.4.1/test/gnuops3.ok" file 644 mtime 1782131302 "e2d998f9b5ebb865b1fa5fb28058e78141e5b3df3ba94eaf6b33b5eb1d9f9c16">,
      #splice.entry<"/build/gawk-5.4.1/test/gnureops.awk" file 644 mtime 1782131302 "afd4726b60b7fc1cf4dfb30ef81b81cef632be052dcdfaa71e3b5b696daec3cd">,
      #splice.entry<"/build/gawk-5.4.1/test/gnureops.ok" file 644 mtime 1782131302 "736b9e25282074a1b401301dbbff7e8b1f5b7759304b02898a27328f556f6ab9">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-8bit.awk" file 644 mtime 1783329604 "ae7230f6ddb32a888b25b8ac08e9f7d92793010dc62fe53bd7c8760a6dde469c">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-8bit.ok" file 644 mtime 1783329604 "cb2de1b2f8553552ee62cc835c589875df046c617da05883165f1286cb38c529">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-8bit.ok2" file 644 mtime 1783615671 "f0234d1ba9a53235f780a61404e70bc1de4b44ce185e222cceead94cef0e21af">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-equiv.awk" file 644 mtime 1783241692 "0ce56d14ab13bfc9e68a99b006de14a92df0d88bc75afc63380545273254ab57">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-equiv.ok" file 644 mtime 1783241692 "70d9eaf00f2d1683b167f8fa03f52c947aa3db8028a306a0cb233c4dda073b5a">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-utf.awk" file 644 mtime 1783241692 "e3348579c4c85734a89457f4057d149e3fec139aaac568dc518c14bde41a69d8">,
      #splice.entry<"/build/gawk-5.4.1/test/greek-utf.ok" file 644 mtime 1783241692 "2c5cddfaa38e1df3ceea50855f7f96251a147dcb4752ee57f4b8cb555444ca0a">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubasgn.awk" file 644 mtime 1782131302 "f15e5ca05b7200a171e2521a9563ac375ca640bec5b41c2a239f8c536ad23d49">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubasgn.ok" file 644 mtime 1782131302 "9b62da6f3a7b2fec61feea29ad702ce87667d7a2f2b8c6496f5134da22343579">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubind.awk" file 644 mtime 1782131302 "6d903e4b7e83eeab162911ef428593a5bb331373cd627daf654478a31f97a69e">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubind.ok" file 644 mtime 1782131302 "1e7fe6baeb5a794fc771b45c43164f6b2b82ce704a5db011968e4a889c71bd83">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubnulli18n.awk" file 644 mtime 1782131302 "f210692cdb7dd7e48ebd4b1f8a7bbd2bf74e5a4ee9b099c8b3ff834f1a36e084">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubnulli18n.ok" file 644 mtime 1782131302 "c70d0cae69bd402e6920a38249091295c8d27f28524630b9aebb12a32a14e7a0">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtest.awk" file 644 mtime 1782131302 "f21bc352e6dd01028cb8e0a62040a352b13aefa5ccdb4b589122f79de8515026">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtest.ok" file 644 mtime 1782131302 "475c0f74a9a73433295c6d323294457a29c025d698a15c0ce79c8339e195eac1">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst2.awk" file 644 mtime 1782131302 "393b5a89fd0a06ef79f8a2428570a69cac23b978654d57f74095a79758e0e0be">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst2.ok" file 644 mtime 1782131302 "9098e58b29254e20d79797dadb9b0a8b862230b82b44a99442ada1b667bdef5a">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst3.awk" file 644 mtime 1782131302 "ca9f03a06c90471d95eb0e9a50c7ab4b6d0c1be6c4c92b79c572bf598942ede9">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst3.in" file 644 mtime 1782131302 "233212a2c0f90a0d0ab7e08eb412f5312b0185ccdb253705b1f4604b505c0f21">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst3.ok" file 644 mtime 1782131302 "d635fa4486a24c02197fb9fec4adbc5ec87e3a33b638925bb9dad6a119295868">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst4.awk" file 644 mtime 1782131302 "367b94b1121bf83992dde43ab98fa4b46d600ee1c0085f1bac78bf4f7fe4ab09">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst4.ok" file 644 mtime 1782131302 "9631950734a6b5e01341f3b083cee53b7164c62238282ff5cf3484fad94a890f">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst5.awk" file 644 mtime 1782131302 "553fb44a2146ff756ca3b417fba815b00c48be02b561ecc0a13f984e24a6a1f1">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst5.in" file 644 mtime 1782131302 "8f422864de55bb67fd5ed3ea365d840459603004aa728c09c0bc051075558f16">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst5.ok" file 644 mtime 1782131302 "e02c1520974d6a13979d1464be8c62be0a64a4314303a57648f2c82f6a4f97f6">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst6.awk" file 644 mtime 1782131302 "6399056b1ce6fc3bf6c2564aa0119c98a7f03600bc6f17c2727530bcce448f7e">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst6.ok" file 644 mtime 1782131302 "9489a31bee32cd5a521757b387f0e08fb6cbb521dad3832f35e4038cb26f0c19">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst7.awk" file 644 mtime 1782131302 "2148d78babc2e49efb36a26042896dff9a7643678ec4283124ab0131b896fbe7">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst7.in" file 644 mtime 1782131302 "58ef1c685d9d768da9906eff348156faf8bcf44ba1bce83c101faf615ec01a19">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst7.ok" file 644 mtime 1782131302 "f99eeb18a692f53658181d937e97642ee3daa05fa78da90b936e99fc71e5ba1c">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst8.awk" file 644 mtime 1782131302 "1ab797c8c98f4bd2615c7432bbb065f073ee1c337b980649df69ce9e64148685">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst8.in" file 644 mtime 1782131302 "3bb1f9cf34a71249108b34d9ce8ff9411fc645f0b4cbf539d80309604c4b8ce0">,
      #splice.entry<"/build/gawk-5.4.1/test/gsubtst8.ok" file 644 mtime 1782131302 "96b23399fc78b58d1347b9d779ff0a8c73c00ef6e048d12b5ddd76a413e3b1e6">,
      #splice.entry<"/build/gawk-5.4.1/test/gtlnbufv.awk" file 644 mtime 1782131302 "ef0d73d5dbd3dd3173774b5801ae35c52a3f922924e82245a3f052ce5519fc1a">,
      #splice.entry<"/build/gawk-5.4.1/test/hello.awk" file 644 mtime 1782131302 "53c3fb99f2918de10aa7842ef26db9b37ec7902cc093617586faea6af3350ae2">,
      #splice.entry<"/build/gawk-5.4.1/test/hex.awk" file 644 mtime 1782131302 "866809081e09ff7f33e1b4cfc0d8c9b3b93dd30d28c355f22df8e6466d55e21c">,
      #splice.entry<"/build/gawk-5.4.1/test/hex.ok" file 644 mtime 1782131302 "9d1b2c776bd227acef11a374b437e076504c6ba239e60c40a9be09e07760403e">,
      #splice.entry<"/build/gawk-5.4.1/test/hex2.awk" file 644 mtime 1782131302 "dccbd1fe4fdfb8ea076150207bcde68660c0754026660a8c16d190a2c4bf34b9">,
      #splice.entry<"/build/gawk-5.4.1/test/hex2.in" file 644 mtime 1782131302 "b67a4f8c0dfa247b0e304d428e3ceff4e75362ee438de0c86c3be90fa2f8ca91">,
      #splice.entry<"/build/gawk-5.4.1/test/hex2.ok" file 644 mtime 1782131302 "dfc76087174d832f34d0210d926f4c40a579e70e12286619f74d8796a467900e">,
      #splice.entry<"/build/gawk-5.4.1/test/hex3.awk" file 644 mtime 1782131302 "f62b16b3206b101e77d8f5ee76078b76d8eb9195d725933e02bb7a46186346c0">,
      #splice.entry<"/build/gawk-5.4.1/test/hex3.ok" file 644 mtime 1782131302 "aa16dc62964603368c83dc333c72917f78951f86060b28005d0dc0ce50dd0ec2">,
      #splice.entry<"/build/gawk-5.4.1/test/hexfloat.awk" file 644 mtime 1782131302 "026202585ccb5e5403be05ec8e118c9d884057d46127de7786fd35a14d90ab1e">,
      #splice.entry<"/build/gawk-5.4.1/test/hexfloat.ok" file 644 mtime 1782131302 "07caa39aa702da39eee11f84172ae7364a0a0ba77ab3cc5a2fdb555bce269365">,
      #splice.entry<"/build/gawk-5.4.1/test/hsprint.awk" file 644 mtime 1782131302 "3bf9c5303445dd8a15d46134dab72ee7aa6bf1beb0cd9bd33811ee302a817481">,
      #splice.entry<"/build/gawk-5.4.1/test/hsprint.ok" file 644 mtime 1782131302 "2af1269e1888da1014cd12ad4c87f73ff27d3e5b05bd35af8f6928b91a48e0db">,
      #splice.entry<"/build/gawk-5.4.1/test/icasefs.awk" file 644 mtime 1782131302 "320f2ee65f3cfb8c64a911328829710f82866c40ef2ca2777b59b9f93437f5b2">,
      #splice.entry<"/build/gawk-5.4.1/test/icasefs.ok" file 644 mtime 1782131302 "f3ad84ef33b9d88c5553e1b8390c6f782d5c52fd30dcc0bba333b9665a7291bf">,
      #splice.entry<"/build/gawk-5.4.1/test/icasers.awk" file 644 mtime 1782131302 "8542cf07415ec57ecdedf87d4ea089bb4c459f8716cc69cb2e3e28914d7d4d16">,
      #splice.entry<"/build/gawk-5.4.1/test/icasers.in" file 644 mtime 1782131302 "d13ede94b839a2e73a58906893c4ab8979bd1759bade5d9f358a08763fb5bbb6">,
      #splice.entry<"/build/gawk-5.4.1/test/icasers.ok" file 644 mtime 1782131302 "a88899b8de2f452f61acb0d36ad113b650c22006b220b1ff31a67d374935d304">,
      #splice.entry<"/build/gawk-5.4.1/test/id.awk" file 644 mtime 1782131302 "db716aba179cf3d076151a29ef0c9123793a9e53c56f717785a206a210db0fef">,
      #splice.entry<"/build/gawk-5.4.1/test/id.ok" file 644 mtime 1782131302 "97f54b93f4e78ee396aec3c569e1109db0d7478460b07c82b5a9de04aeb192b0">,
      #splice.entry<"/build/gawk-5.4.1/test/igncdym.awk" file 644 mtime 1782131302 "1197fbf71aec4589c79106486bda86675aee8fc96e54f9202aa5fd3c6ab9e1ce">,
      #splice.entry<"/build/gawk-5.4.1/test/igncdym.in" file 644 mtime 1782131302 "70bc30edd44afa014f2d7225e21a3fd11dc2284e554d4c2878855f629cffacae">,
      #splice.entry<"/build/gawk-5.4.1/test/igncdym.ok" file 644 mtime 1782131302 "09baaf94955ba99e8c6629e3f60c8a7202a8abc41ffa32a98db3bbf7430f7fbc">,
      #splice.entry<"/build/gawk-5.4.1/test/igncfs.awk" file 644 mtime 1782131302 "90fd163b44c096276ebaba5639cb2e5a79b1731f33a1296a0b63515e1f451019">,
      #splice.entry<"/build/gawk-5.4.1/test/igncfs.in" file 644 mtime 1782131302 "d956e27f1106b54a584138c0ed8d3a936acfd123231c4d82d06c38e68742f0ca">,
      #splice.entry<"/build/gawk-5.4.1/test/igncfs.ok" file 644 mtime 1782131302 "af5e8899085038f875af3df201eb91eb243d13cdcbbec285879d16b95e154f1d">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcas2.awk" file 644 mtime 1782131302 "e71b470a7cd9a8d7f692a53ae9fec694aa7bf2cb5934719c441e420286af2287">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcas2.ok" file 644 mtime 1782131302 "a12b7cb43c9d9134b5bb1b35e9096b66775d9e92e7611d1cc92b02edd6782a87">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcas4.awk" file 644 mtime 1782131302 "1698b842a039ee31a5e08466e1bb20950eb79be7bf6d61b7b5c011708673693d">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcas4.ok" file 644 mtime 1782131302 "82c1315e6c757f33c4a77ca58b2a184f5a88614470c05ec77f3d28918db6b8ae">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcase.awk" file 644 mtime 1782131302 "9f3fe357b7c74e0588542f239e3d1b2ba6e2154fe1df9682be21379cd9eb8719">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcase.in" file 644 mtime 1782131302 "59a88c6c1d85d8adb3e0c11d1cc7b4d40740842481f3ec6d35c5f22834d33f29">,
      #splice.entry<"/build/gawk-5.4.1/test/ignrcase.ok" file 644 mtime 1782131302 "b44f7d6b5283a44ee5f2bd98f84087a04810092122d75e8fbf8ad85f8f2981f1">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe.ok" file 644 mtime 1782131302 "d1b14c46bb30f7658537a12332c1da1aa57656ef0db62b16e8104e672a5cac6a">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe2.ok" file 644 mtime 1782131302 "1bfdd5095f3ebf2501130fdf82e64447569b823604dde50b848be1765f6d3425">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe3.ok" file 644 mtime 1782131302 "a8a35680b0636e4e0baeca83c5b4441f7389d37bc7167e3d35a63168a688d53b">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe4.ok" file 644 mtime 1782131302 "f4be29771b979226903c570aec0ee06aa7a213ba0f47483a0d494da8be04411a">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe5.ok" file 644 mtime 1782131302 "f4be29771b979226903c570aec0ee06aa7a213ba0f47483a0d494da8be04411a">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe6.ok" file 644 mtime 1782131302 "5939da4b8f4171a1d12bf793272df793531c374dd510532a25058028cdc6868d">,
      #splice.entry<"/build/gawk-5.4.1/test/incdupe7.ok" file 644 mtime 1782131302 "5939da4b8f4171a1d12bf793272df793531c374dd510532a25058028cdc6868d">,
      #splice.entry<"/build/gawk-5.4.1/test/inchello.awk" file 644 mtime 1782131302 "8abbf05e4e4605d16e4ffee2c34c25b1c8af35eb70ff8e4e16742f28f9374716">,
      #splice.entry<"/build/gawk-5.4.1/test/inclib.awk" file 644 mtime 1782131302 "4e9486557aab13be1166f17dbf775cee8de71b3211b401e6d52c86bd3ddce86c">,
      #splice.entry<"/build/gawk-5.4.1/test/include.awk" file 644 mtime 1782131302 "137530b2d138f187c935e64e4f79f8c25ef9385ab4c3c61a87bb37b18072dc04">,
      #splice.entry<"/build/gawk-5.4.1/test/include.ok" file 644 mtime 1782131302 "f9626a47feda6635e3b1574ca5ddb9e332a8b87f6277b1b9fcb9ff438c99e794">,
      #splice.entry<"/build/gawk-5.4.1/test/include2.ok" file 644 mtime 1782131302 "f9626a47feda6635e3b1574ca5ddb9e332a8b87f6277b1b9fcb9ff438c99e794">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin.awk" file 644 mtime 1782131302 "982d31bef2bb19a11000baff833ae038950130e1870653359debff5e3e66ea9f">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin.ok" file 644 mtime 1782131302 "618687e50c03fe555c97b8405876d5767e0c41df3bac4a68a121f923595a2744">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin2.awk" file 644 mtime 1782131302 "99239e6dce362b911baff77d3f3c8f47e4a7d53f9b4dcdeea21ef124e8c1ed0f">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin2.ok" file 644 mtime 1782131302 "90ca088f52fc722e46329c4339fc59a31a6fcb2a8af4ccaa51ef6f8039dd0ddc">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin3.awk" file 644 mtime 1782131302 "4d48dfca5f08bbeb2ca63edfe67e8c6410b74a17976a0c629be0652b648f1acf">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin3.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin4.awk" file 644 mtime 1782131302 "9f7cc9e8e47ec87f5271cbcb44828fc14f7a45cb851493a8829ef987225b7aab">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin4.ok" file 644 mtime 1782131302 "7d4859a1f2891f570454152f469ea4f027fbbb0c75e17a909a079295735d1434">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin5.awk" file 644 mtime 1782131302 "79392ad80c45ea00cfc3d0368c5642e56acddb65f95b23d2d8e5abdd7f5ae7c6">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin5.ok" file 644 mtime 1782131302 "4c243213450b82e2b2d3bf6541ce245e6ed81d5177e5e2661c256188d299b765">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin6.awk" file 644 mtime 1782131302 "45ff1dd9d3a06514198d77455a409b017862e002d17b58fbed6e809c36b3c6b2">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectbuiltin6.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall.awk" file 644 mtime 1782131302 "8e49b2ec3489b07db88d6c1aaa8f9ce802fc1464c055fb20d5a06f799498982b">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall.in" file 644 mtime 1782131302 "9f5e222bcadbf41e04c17f4542d0eb5ad4df05153e5fe48507897cedf48b2d59">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall.ok" file 644 mtime 1782131302 "66c254ff8d901ba4979caae734b5edf82b9c43c14dbb944489cf5b8e25163330">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall2.awk" file 644 mtime 1782131302 "028ab56e7c10c402fbc03b3cad4b2b9c3db61a5ed3cec6123403cbc5bb25d59b">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall2.ok" file 644 mtime 1782131302 "6752b9956b3ca42ab76dcab198b091dbb1849834a088ab70750f2c5fe5118f7b">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall3.awk" file 644 mtime 1782131302 "8052fd957049009531b33fed02212e36a41abb8109a881ed461f5796ddba536e">,
      #splice.entry<"/build/gawk-5.4.1/test/indirectcall3.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/inf-nan-torture.awk" file 644 mtime 1782131302 "2f7b88980e559e3f0acc8fb8f9447126cad86caf07a7c2fb677591eff222af69">,
      #splice.entry<"/build/gawk-5.4.1/test/inf-nan-torture.in" file 644 mtime 1782131302 "9fd8fa8aebebdab70b0bbfa7973010b52b7abc32b4ae6f2b742440adc60b76b3">,
      #splice.entry<"/build/gawk-5.4.1/test/inf-nan-torture.ok" file 644 mtime 1782131302 "e17a859f0fe032839aad602f4428b19fe3d3e004934531ed463c20770316cd3b">,
      #splice.entry<"/build/gawk-5.4.1/test/inftest.awk" file 644 mtime 1782131302 "95679fc71b9390e173c72b4f0d740603db1568b05b1145c3bdf35a185c531dce">,
      #splice.entry<"/build/gawk-5.4.1/test/inftest.ok" file 644 mtime 1782131302 "7db690d5a72356c238adb77b4d24d55cd2c307d94de9437f1df4eb12a5d3f99a">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace.1.in" file 644 mtime 1782131302 "159173591ad6b235638d6431c1dc609ba72b4eda0384a0cca5644e23da4fe53d">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace.2.in" file 644 mtime 1782131302 "b007dc6cc9df5c33cc506569f347d13762eb4bbc4b4cb7c7588704f2f2170640">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace.in" file 644 mtime 1782131302 "6aaceff98f99a8b73076aedf9a4e8a345e3e1ca2fbb006ae23743a32b8849426">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace1.1.ok" file 644 mtime 1782131302 "698364566456b513a77dfe31a8764ac16f239daaa079ce4a39c58b94154f32ff">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace1.2.ok" file 644 mtime 1782131302 "99304e0265ee46c1008018664cc53b6c9e33dd61842523906b6ca49569667ad6">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace1.ok" file 644 mtime 1783241692 "a4115d87e5e51d0dbc53ed620e86e3b483cdf02cd03c386a218927a3bc8a17b5">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2.1.bak.ok" file 644 mtime 1782131302 "159173591ad6b235638d6431c1dc609ba72b4eda0384a0cca5644e23da4fe53d">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2.1.ok" file 644 mtime 1782131302 "698364566456b513a77dfe31a8764ac16f239daaa079ce4a39c58b94154f32ff">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2.2.bak.ok" file 644 mtime 1782131302 "b007dc6cc9df5c33cc506569f347d13762eb4bbc4b4cb7c7588704f2f2170640">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2.2.ok" file 644 mtime 1782131302 "99304e0265ee46c1008018664cc53b6c9e33dd61842523906b6ca49569667ad6">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2.ok" file 644 mtime 1783241692 "a4115d87e5e51d0dbc53ed620e86e3b483cdf02cd03c386a218927a3bc8a17b5">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2bcomp.1.ok" file 644 mtime 1782131302 "698364566456b513a77dfe31a8764ac16f239daaa079ce4a39c58b94154f32ff">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2bcomp.1.orig.ok" file 644 mtime 1782131302 "159173591ad6b235638d6431c1dc609ba72b4eda0384a0cca5644e23da4fe53d">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2bcomp.2.ok" file 644 mtime 1782131302 "99304e0265ee46c1008018664cc53b6c9e33dd61842523906b6ca49569667ad6">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2bcomp.2.orig.ok" file 644 mtime 1782131302 "b007dc6cc9df5c33cc506569f347d13762eb4bbc4b4cb7c7588704f2f2170640">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace2bcomp.ok" file 644 mtime 1783241692 "a4115d87e5e51d0dbc53ed620e86e3b483cdf02cd03c386a218927a3bc8a17b5">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3.1.bak.ok" file 644 mtime 1782131302 "698364566456b513a77dfe31a8764ac16f239daaa079ce4a39c58b94154f32ff">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3.1.ok" file 644 mtime 1782131302 "159173591ad6b235638d6431c1dc609ba72b4eda0384a0cca5644e23da4fe53d">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3.2.bak.ok" file 644 mtime 1782131302 "99304e0265ee46c1008018664cc53b6c9e33dd61842523906b6ca49569667ad6">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3.2.ok" file 644 mtime 1782131302 "b007dc6cc9df5c33cc506569f347d13762eb4bbc4b4cb7c7588704f2f2170640">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3.ok" file 644 mtime 1783241692 "b715b2e899f7fa7aa220b20804d290237091c23d1926f882d83dbcdf9a0f6d54">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3bcomp.1.ok" file 644 mtime 1782131302 "159173591ad6b235638d6431c1dc609ba72b4eda0384a0cca5644e23da4fe53d">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3bcomp.1.orig.ok" file 644 mtime 1782131302 "698364566456b513a77dfe31a8764ac16f239daaa079ce4a39c58b94154f32ff">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3bcomp.2.ok" file 644 mtime 1782131302 "b007dc6cc9df5c33cc506569f347d13762eb4bbc4b4cb7c7588704f2f2170640">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3bcomp.2.orig.ok" file 644 mtime 1782131302 "99304e0265ee46c1008018664cc53b6c9e33dd61842523906b6ca49569667ad6">,
      #splice.entry<"/build/gawk-5.4.1/test/inplace3bcomp.ok" file 644 mtime 1783241692 "b715b2e899f7fa7aa220b20804d290237091c23d1926f882d83dbcdf9a0f6d54">,
      #splice.entry<"/build/gawk-5.4.1/test/inpref.awk" file 644 mtime 1782131302 "1b3ae45a6fb9597bc06972be8f2481164f4e8d4ace56003bbbfdcfdb5635db1d">,
      #splice.entry<"/build/gawk-5.4.1/test/inpref.in" file 644 mtime 1782131302 "c1533fea112d8648564d78e48e582cca307a06eaf17ddc6e0ab5f7a5996cb944">,
      #splice.entry<"/build/gawk-5.4.1/test/inpref.ok" file 644 mtime 1782131302 "cba5243834a58801d5f3460c1d21fe28c33b1e1c1bb8ce7513e1948eed3a19e4">,
      #splice.entry<"/build/gawk-5.4.1/test/inputred.awk" file 644 mtime 1782131302 "36992a94025b26831f78867d4da074fc82ff088fbbf950c525cd01533ec5c135">,
      #splice.entry<"/build/gawk-5.4.1/test/inputred.ok" file 644 mtime 1782131302 "079bc56fcd388d2d6fbe2eeb28c059a12b268933d0c60f2bb465fca7b9a8be3e">,
      #splice.entry<"/build/gawk-5.4.1/test/intarray.awk" file 644 mtime 1782131302 "146807e1ae60bee4974c7294ee43bb699196ec3c522ca4b7f667357539720c3e">,
      #splice.entry<"/build/gawk-5.4.1/test/intarray.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/intest.awk" file 644 mtime 1782131302 "63520d475f5b90b89476a87a45f46c258012b9dabd5ed7ad87ffcd2f9633ea00">,
      #splice.entry<"/build/gawk-5.4.1/test/intest.ok" file 644 mtime 1782131302 "a79122992d53d358e6bbbbb98883d64fa0c15df3bcb08ff7b65a0580870af424">,
      #splice.entry<"/build/gawk-5.4.1/test/intformat.awk" file 644 mtime 1782131302 "d448208109e628d67f6ba3b67f19c9eeccb6c1a265685f7766afc9488a25ee51">,
      #splice.entry<"/build/gawk-5.4.1/test/intformat.ok" file 644 mtime 1782131302 "111cd89781b647aa38e99b4e4aab64228bddce52d991fa6e3e5672a9921b1ace">,
      #splice.entry<"/build/gawk-5.4.1/test/intprec.awk" file 644 mtime 1782131302 "ec42e0351810eb09213f91f07e3a8f6998d82652eaf286e40857289899504af4">,
      #splice.entry<"/build/gawk-5.4.1/test/intprec.ok" file 644 mtime 1782131302 "466372e612a5c0d7d4ad3834e7decf15384b155fc8e3cd2315877b690c7e0076">,
      #splice.entry<"/build/gawk-5.4.1/test/iobug1.awk" file 644 mtime 1782131302 "7bb870b4f2a200457dbf5558d5c071f7896dd2fbc00c9c56b33aea862b1b6d8a">,
      #splice.entry<"/build/gawk-5.4.1/test/iobug1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/iolint.awk" file 644 mtime 1782131302 "05321dbbf4a6dcff23294d484e8d267387b682552e8012cbb143e0a242db6ff7">,
      #splice.entry<"/build/gawk-5.4.1/test/iolint.ok" file 644 mtime 1782131302 "cf47f8ab08b7c235c4ea1e1e2cd712a945df3b276483b72d246f1766c1007a8b">,
      #splice.entry<"/build/gawk-5.4.1/test/isarrayunset.awk" file 644 mtime 1782131302 "03cd9c9461b7a376ca14b998cace933886d2681bcc5ed176d5ceb72118cd1f56">,
      #splice.entry<"/build/gawk-5.4.1/test/isarrayunset.ok" file 644 mtime 1782131302 "9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa">,
      #splice.entry<"/build/gawk-5.4.1/test/jarebug.awk" file 644 mtime 1782131302 "7163e800c17412eca60eafc984a05eb3bee9be986d23bedc3b9f0bc28b184605">,
      #splice.entry<"/build/gawk-5.4.1/test/jarebug.in" file 644 mtime 1782131302 "d2b51ba566be85a2f5e5b4871c986533a9460c6fbd90d2a5f3476eec1d3d2651">,
      #splice.entry<"/build/gawk-5.4.1/test/jarebug.ok" file 644 mtime 1782131302 "d2b51ba566be85a2f5e5b4871c986533a9460c6fbd90d2a5f3476eec1d3d2651">,
      #splice.entry<"/build/gawk-5.4.1/test/jarebug.sh" file 755 mtime 1782131302 "c361e464cacbc5723189308973f6ea57eedcc471875ab4d178fc1d3f8a0fdad7">,
      #splice.entry<"/build/gawk-5.4.1/test/lc_num1.awk" file 644 mtime 1782131302 "f402135eb0b8f0f1fab73fcf71118cd57923c95795425690aabbac9ca1d064bb">,
      #splice.entry<"/build/gawk-5.4.1/test/lc_num1.ok" file 644 mtime 1782131302 "5d35676e1e5d1cd29606544bf0cab913cc0a6aca31f18853d046523c5a6a8480">,
      #splice.entry<"/build/gawk-5.4.1/test/leaddig.awk" file 644 mtime 1782131302 "90e952eb10cfb3a61678c107e3a632ab3248fc31e95d5afabaf6cd2bbf765634">,
      #splice.entry<"/build/gawk-5.4.1/test/leaddig.ok" file 644 mtime 1782131302 "126e7f8248f55b1c979525712161e763a5fe0a488fca8b077fef8d9153bddba8">,
      #splice.entry<"/build/gawk-5.4.1/test/leadnl.awk" file 644 mtime 1782131302 "06cc73d33ca0fbdfbd1675b584ff681b9b7c8faf797c536679aefce4783cb61a">,
      #splice.entry<"/build/gawk-5.4.1/test/leadnl.in" file 644 mtime 1782131302 "ee3c008d541ba7c302ddcb8ffee43cdae06b5e1e720e73e0ccc1d2203bb82775">,
      #splice.entry<"/build/gawk-5.4.1/test/leadnl.ok" file 644 mtime 1782131302 "f9d221532f54b94207ae43cc05e919624112fac5fe8fa6ecb964796b95bfabe4">,
      #splice.entry<"/build/gawk-5.4.1/test/lib" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/test/lib/awkpath.awk" file 644 mtime 1782131302 "9dacbacf97e73e0e33f75aa161b519268cecb1354513472059f25a1e9e413845">,
      #splice.entry<"/build/gawk-5.4.1/test/lint.awk" file 644 mtime 1782131302 "3850ee0ee29d4f8304d8f63465506d373b1ad331cfa61f303a5af49e9a8ea850">,
      #splice.entry<"/build/gawk-5.4.1/test/lint.ok" file 644 mtime 1782131302 "a35956fa6084d58ca8181fb38f7baf455d5aaa79665fac2a9c9fa80edc178092">,
      #splice.entry<"/build/gawk-5.4.1/test/lintexp.awk" file 644 mtime 1782131302 "e8d25e006ec3399db72460d87b1d899351c3b3def30fdeb537dd57bf8dcf620a">,
      #splice.entry<"/build/gawk-5.4.1/test/lintexp.ok" file 644 mtime 1782131302 "c15eb5c5da255c0e4e7d76493b359d29f1ce2d2de3821050b59d7cda04017a51">,
      #splice.entry<"/build/gawk-5.4.1/test/lintindex.awk" file 644 mtime 1782131302 "c79cfbd4703898829e869055631cf43dd8c574b532a57f37d9364277f76ceb0c">,
      #splice.entry<"/build/gawk-5.4.1/test/lintindex.ok" file 644 mtime 1782131302 "1a3fe71f708720e984e16033e4c2ecc10a5b5d4a2dc05d70309807ab03339043">,
      #splice.entry<"/build/gawk-5.4.1/test/lintint.awk" file 644 mtime 1782131302 "ff96768814c412eca7a87b33a7003c638733d814bc7de4121ddfaf99dfecf431">,
      #splice.entry<"/build/gawk-5.4.1/test/lintint.ok" file 644 mtime 1782131302 "44c2a656f066292ee6eba44aec47ee4f172f91d00c4b931dd156165978959293">,
      #splice.entry<"/build/gawk-5.4.1/test/lintlength.awk" file 644 mtime 1782131302 "8074da88290d9b769d0535d347514c674294362b0473fc4fdad363f1c7b134c1">,
      #splice.entry<"/build/gawk-5.4.1/test/lintlength.ok" file 644 mtime 1782131302 "8acc9e9de8784a9404a1ab29f455ffd78abfcd912b72b777a72cf3fd8f95202e">,
      #splice.entry<"/build/gawk-5.4.1/test/lintold.awk" file 644 mtime 1783615620 "48253c996f73e01f25e6fb0a707c3d6b83510a710746cfb91a0cf20635f1f0ea">,
      #splice.entry<"/build/gawk-5.4.1/test/lintold.in" file 644 mtime 1783615620 "01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b">,
      #splice.entry<"/build/gawk-5.4.1/test/lintold.ok" file 644 mtime 1783615620 "0717521d12ad6e7c6fff5dca0736c3c39314f3bc9d4a7c39ed9da252040ed4f3">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus.awk" file 644 mtime 1782131302 "a819d4affeca958204f42cbb32502b54b76493c9641d6420349e7d82b8387013">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus.ok" file 644 mtime 1782131302 "e0f7ec882bfc7dbfedf298e461ecf8071693f8181a67217c88d3e07a16b71270">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus2.awk" file 644 mtime 1782131302 "b82b7e8d591b5e0ad295feeedf3987216d0c9e83f9154be82cdda0fe1c0cc868">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus2.ok" file 644 mtime 1782131302 "b82b7e8d591b5e0ad295feeedf3987216d0c9e83f9154be82cdda0fe1c0cc868">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus3.awk" file 644 mtime 1782131302 "f310d5bec5a529a27821fafeaea44097649a07491ba9f75096e49ad4382a8646">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus3.in" file 644 mtime 1782131302 "4b67fc13da04bfa13eae1b2069e788a2f02dc98052e2a84994e37406a7b8cf45">,
      #splice.entry<"/build/gawk-5.4.1/test/lintplus3.ok" file 644 mtime 1782131302 "7c83e1c7e2d3ee9b48bb2761a4b4628df80d223316f8ff69deeb7e2aa2910bb5">,
      #splice.entry<"/build/gawk-5.4.1/test/lintset.awk" file 644 mtime 1782131302 "8123575f6829b180eaf446803caa93ef73f6b5653505775a0ecc6788ae89092f">,
      #splice.entry<"/build/gawk-5.4.1/test/lintset.ok" file 644 mtime 1782131302 "0ecab35e92be7d283d48cfbe75d368fa5e6b9d5ab5976095ce61a5eb93087113">,
      #splice.entry<"/build/gawk-5.4.1/test/lintsubarray.awk" file 644 mtime 1782131302 "3b0bc1c08d21a65f9abe46193302bf13331006c4d1ffc66f9c5986beca9f1093">,
      #splice.entry<"/build/gawk-5.4.1/test/lintsubarray.ok" file 644 mtime 1782131302 "beb4699960f6cd6e61ebf838ed6277006a7788c3387d65de5291e45e83555547">,
      #splice.entry<"/build/gawk-5.4.1/test/linttypeof.awk" file 644 mtime 1782131302 "768df7d4d3032512d3e44ffe12afe5142effdf10d1b4ac7e7d0755e2e0fcc090">,
      #splice.entry<"/build/gawk-5.4.1/test/linttypeof.ok" file 644 mtime 1782131302 "85482b27cc2b212539ee5e288a1592aa80d563dff11baf449763c9633b373d90">,
      #splice.entry<"/build/gawk-5.4.1/test/lintwarn.awk" file 644 mtime 1782131302 "24fec6bd70ad8b0ac55cdd75de722984df1f9dc416bb0a5fd5306018862e167e">,
      #splice.entry<"/build/gawk-5.4.1/test/lintwarn.ok" file 644 mtime 1782131302 "e4c775095c6b788b8ac18bd320e0407e32cfaec4e5cb58e63c59fa57a3b1dfaa">,
      #splice.entry<"/build/gawk-5.4.1/test/litoct.awk" file 644 mtime 1782131302 "ed48cf8c29fb7a0f42a06b90ee71c18289370f45b18f182108280eeba3a27e57">,
      #splice.entry<"/build/gawk-5.4.1/test/litoct.in" file 644 mtime 1782131302 "a63d8014dba891345b30174df2b2a57efbb65b4f9f09b98f245d1b3192277ece">,
      #splice.entry<"/build/gawk-5.4.1/test/litoct.ok" file 644 mtime 1782131302 "a3010e49f491e79357181823002f73df0158eff1921ac1e64726a5e9ecabcbb1">,
      #splice.entry<"/build/gawk-5.4.1/test/localenl.ok" file 644 mtime 1782131302 "d39f3aec3388a73c73245775bba3fc06e7f784c3fc77ae6f7fee627ba2ec7db0">,
      #splice.entry<"/build/gawk-5.4.1/test/localenl.sh" file 755 mtime 1782131302 "0da71849b952a97644894a1ff2ab2b4c37b0a2f1d8136d51a02bbd216768b8c8">,
      #splice.entry<"/build/gawk-5.4.1/test/longsub.awk" file 644 mtime 1782131302 "e0fa6c761416d0e7b51ed098604256a84396e61b654d9e322ff17261eee405bf">,
      #splice.entry<"/build/gawk-5.4.1/test/longsub.in" file 644 mtime 1782131302 "f005d6779d2de1b0a331be9c83097a85c6ba300a19bad06958f9d8fe42d771dd">,
      #splice.entry<"/build/gawk-5.4.1/test/longsub.ok" file 644 mtime 1782131302 "eda836f0256bf087824f63b7a57d9cd50c4a605a48f9b361e3b6fcc2e4bd49ac">,
      #splice.entry<"/build/gawk-5.4.1/test/longwrds.awk" file 644 mtime 1782131302 "e18114ded8978bbb58f18e83704056076750bacd5863d33030e963093b7fd98e">,
      #splice.entry<"/build/gawk-5.4.1/test/longwrds.in" file 644 mtime 1782131302 "5e820760bef1500e80f8f4a4d4d9c0c2e7f10af58b729f9c97ccc6edceb91836">,
      #splice.entry<"/build/gawk-5.4.1/test/longwrds.ok" file 644 mtime 1782131302 "2ddf41e000074878c10983751b57ccea141520f6499430a5932344194696c7f5">,
      #splice.entry<"/build/gawk-5.4.1/test/makepmafile.c" file 644 mtime 1783241692 "6af9724dff7f6f838c18ed6ca690f46679a73092fb9f02bd0a24a1f48f8f146d">,
      #splice.entry<"/build/gawk-5.4.1/test/manglprm.awk" file 644 mtime 1782131302 "8a6fa1c870b45c152c66e81c1c4b350b28374d6fe15959210d0a1303a3adce46">,
      #splice.entry<"/build/gawk-5.4.1/test/manglprm.in" file 644 mtime 1782131302 "41920b348e0c6ff2ef9b7e3ee9308726aa5250fa717883e073ff6a936a9325a4">,
      #splice.entry<"/build/gawk-5.4.1/test/manglprm.ok" file 644 mtime 1782131302 "1453c6f321502bc34dd28a8dc2c4b37999f37fab7bc96f81657bdb253955087d">,
      #splice.entry<"/build/gawk-5.4.1/test/manyfiles.awk" file 644 mtime 1782131302 "d82a3b22eb973e2e18daa5635320fa2924e9288b6431efbef7a4d120f1426a5d">,
      #splice.entry<"/build/gawk-5.4.1/test/manyfiles.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/match1.awk" file 644 mtime 1782131302 "c4a3a5acf74e96494623765f06dafef7121916c95e25b823b2cf442f91a96411">,
      #splice.entry<"/build/gawk-5.4.1/test/match1.ok" file 644 mtime 1782131302 "fac781d73e9167fa80253af97a3a4a9d6146dd733c0fd2000e899a0c1dd66bf5">,
      #splice.entry<"/build/gawk-5.4.1/test/match2.awk" file 644 mtime 1782131302 "b25442ec2b1f7824daa0d0eadeea095dc4831d99f0749a889b478299a1824bbf">,
      #splice.entry<"/build/gawk-5.4.1/test/match2.ok" file 644 mtime 1782131302 "944df305ec410ce1228f4204ae25a825a039c22773d851274bb269cf3f79db4b">,
      #splice.entry<"/build/gawk-5.4.1/test/match3.awk" file 644 mtime 1782131302 "e8a01ea66621744515b39904dba69efe40e52017f0357656398ce301d6164ed3">,
      #splice.entry<"/build/gawk-5.4.1/test/match3.in" file 644 mtime 1782131302 "a909b4531f7cb8ff41f4579351b6b4c2f34381f88773153286f36d08f0d4b70e">,
      #splice.entry<"/build/gawk-5.4.1/test/match3.ok" file 644 mtime 1782131302 "feebd1e8e65cc0167231e4baf2edf43a25d164ba47f15f46789ad6a478229c57">,
      #splice.entry<"/build/gawk-5.4.1/test/match4.awk" file 644 mtime 1782131302 "7a54e9742367adb712bc4321e8588ad219f1adec7c2f483ccde938c56c87292d">,
      #splice.entry<"/build/gawk-5.4.1/test/match4.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/match5.awk" file 644 mtime 1782131302 "c65f2b19d8bc28f395cea608852d778f433c266aec8b71043399d4335c78667d">,
      #splice.entry<"/build/gawk-5.4.1/test/match5.in" file 644 mtime 1782131302 "b3ec24310faa52a521c07180553f8b00855d6306b8ca4ad43c0c6bd6ac8dd177">,
      #splice.entry<"/build/gawk-5.4.1/test/match5.ok" file 644 mtime 1782131302 "72472377d73ae2604b71fa9ee710ad96d89308565eef48f76bc78f1571e38ff3">,
      #splice.entry<"/build/gawk-5.4.1/test/matchbadarg1.awk" file 644 mtime 1782131302 "737c95ffa47564fa02d0427d472b1f5a3b530d8c595c80be79a7fa00f94653cd">,
      #splice.entry<"/build/gawk-5.4.1/test/matchbadarg1.in" file 644 mtime 1782131302 "75a11da44c802486bc6f65640aa48a730f0f684c5c07a42ba3cd1735eb3fb070">,
      #splice.entry<"/build/gawk-5.4.1/test/matchbadarg1.ok" file 644 mtime 1782131302 "7bbbde621500b160a26e6f14a554c4747f1b72644ce1594fb3d0b52ac75519f4">,
      #splice.entry<"/build/gawk-5.4.1/test/matchbadarg2.awk" file 644 mtime 1782131302 "737c95ffa47564fa02d0427d472b1f5a3b530d8c595c80be79a7fa00f94653cd">,
      #splice.entry<"/build/gawk-5.4.1/test/matchbadarg2.in" file 644 mtime 1782131302 "65438b806ad94fbfa9a6133466f4eed543dbc6a3fb07954966719f162079dd2f">,
      #splice.entry<"/build/gawk-5.4.1/test/matchbadarg2.ok" file 644 mtime 1782131302 "039afa07d008680e97ae5e75744cec0703ea688b4f2ecbd11d69c0d1d2c43799">,
      #splice.entry<"/build/gawk-5.4.1/test/matchuninitialized.awk" file 644 mtime 1782131302 "544a204cd58dff6174dfcda9502b495e2a57e96cc83afe5f0f1d71271791e02f">,
      #splice.entry<"/build/gawk-5.4.1/test/matchuninitialized.ok" file 644 mtime 1782131302 "f4a9e6112857118eb2bc7f5da02575697e41d3d8085febbd8ab816160da575ad">,
      #splice.entry<"/build/gawk-5.4.1/test/math.awk" file 644 mtime 1782131302 "4ceff81715182d651cade461d092ef97646059e802c292059971aebd174aae06">,
      #splice.entry<"/build/gawk-5.4.1/test/math.ok" file 644 mtime 1782131302 "67185113dbe4c6a4291f433663de2ae8c6beff3cba77c84c4c75c20b0b4b8299">,
      #splice.entry<"/build/gawk-5.4.1/test/mbfw1.awk" file 644 mtime 1782131302 "d2d04ab4df6252816a357bb124c3463dee4f7c28c8227e239c4febf8e74bcd1b">,
      #splice.entry<"/build/gawk-5.4.1/test/mbfw1.in" file 644 mtime 1782131302 "2d4e1a3be39e736f2b8b024db0ec51566db3455b90920d58f5ebb4c813250dfc">,
      #splice.entry<"/build/gawk-5.4.1/test/mbfw1.ok" file 644 mtime 1782131302 "10d956f300201113cbcb54bb362cd81e69f2e0fffa12ff337a0b4fd9ec4d607a">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf1.awk" file 644 mtime 1782131302 "6f04876ecd93399f6bf9921dee8f6b6f9d5dff4bfffa2df721e916373f7e84ce">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf1.in" file 644 mtime 1782131302 "793f71dc46b7db6998ad2f95493cdb9f2394ccd13fe59d281e5391456eaa6d45">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf1.ok" file 644 mtime 1782131302 "e1cdcc061f8a1c26c805afbb341911c809d35f8e6cd746caefcd2320e8178c53">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf2.awk" file 644 mtime 1782131302 "74b0caa94e97d68c2ea685326f1d8e3387bf1cec221043f15cdf0f3b3a72a562">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf2.ok" file 644 mtime 1782131302 "f2c7d522ec2c8f6b74a46a6b60af0e857b7f20ccc216a8d073071e734841356c">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf3.awk" file 644 mtime 1782131302 "9d4e78cd7b420005d9b5718ea0d5fba9900fee987296b0e8c6866e6219229cd0">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf3.in" file 644 mtime 1782131302 "08d4569c0f810f63f241e9fc7d837b94fec9e730babc29bac99838b122dfbcb9">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf3.ok" file 644 mtime 1782131302 "7b68556a4f18403a986354068562d2c06d5bb3d4d445e7167a6757425a0136f8">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf4.awk" file 644 mtime 1782131302 "d28ee496f8030e23dc38094a3f911e4822a12aed59fadb1cb61a65340f6692d6">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf4.in" file 644 mtime 1782131302 "2fd80950710a0cd91a4f36a7314462be0f6a379a20c84ed11bb253bfd0fe0753">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf4.ok" file 644 mtime 1782131302 "be0f85b8c12fe2f01f3f3a46ba4eef5a03059f192092ccf3cf95438fa449c90a">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf5.awk" file 644 mtime 1782131302 "af36e93c21f2e7a5a22a046317853081a76a3e10cd36c7768b41bd84e4b5ce0e">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf5.in" file 644 mtime 1782131302 "5bfe26c361cd2fb1fb0753e78015a21c35f34f97b5d89ee5fccf01f29e607dea">,
      #splice.entry<"/build/gawk-5.4.1/test/mbprintf5.ok" file 644 mtime 1782131302 "148d630703d579a47654ef213b10913d62aa590fff436dc9039c746711d3df9c">,
      #splice.entry<"/build/gawk-5.4.1/test/mbstr1.awk" file 644 mtime 1782131302 "9f88cc7e0f394d5e913b324a0b279d72392fa33403a2d3e656e66053367aec40">,
      #splice.entry<"/build/gawk-5.4.1/test/mbstr1.ok" file 644 mtime 1782131302 "24d5e3691d58327ec3b721d8ec366f064369b4c6d16b0cb2c5f80d5fd3c8997a">,
      #splice.entry<"/build/gawk-5.4.1/test/mbstr2.awk" file 644 mtime 1782131302 "1a38f01533453748b3f51b75876d4a2c94a636fa823e6b4cc084dee3fea09aed">,
      #splice.entry<"/build/gawk-5.4.1/test/mbstr2.in" file 644 mtime 1782131302 "3fdbc2ab707688ea0fbb34402ce7be70f251db8934355b7b1fcba234b272f30a">,
      #splice.entry<"/build/gawk-5.4.1/test/mbstr2.ok" file 644 mtime 1782131302 "6a87400140b3414712d08f037c303ed92aca93d8957bd2fabe8ce940acea5eab">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim1.awk" file 644 mtime 1783249699 "9c4c9405cbc99a69d2a49dfd95d05e49a952e3690d23251975c1f278afca9d7d">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim1.ok" file 644 mtime 1783249699 "a7185be8fbef0eb43354423259ea3e2b816b142ca57af8de588dc9db9b510f50">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim2.awk" file 644 mtime 1782131302 "1ea6571edc2547001df906436e282b83412e1d1b99607f93912b423463d2b629">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim2.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim3.awk" file 644 mtime 1782131302 "b0de11d94f1276653648f02ec0f940468ed85cae072f1954a166461f15718d40">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim3.ok" file 644 mtime 1782131302 "6a933cf22888ad6df1a13ad51c4d399625c2d6b1bf26ce2dd6d8311549a7c559">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim4.awk" file 644 mtime 1782131302 "25f0726a299644fc29b5811375ee39f6d9ddbdbb156fa806260174a91d5ad7b7">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim4.in" file 644 mtime 1782131302 "4e525e819f5f74e993b7bc440422c1f4663c395dd84f284eeed4eb59be6abf7e">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim4.ok" file 644 mtime 1782131302 "2c5bb41a195ab1fa4e72bae8bdb8341616e60c13198db63fe1c5a3d5fd1a6dd1">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim5.awk" file 644 mtime 1782131302 "4518428cb8f69285b91e54ee3126eae4dc8e15fb29d244769edf57dedd12eb86">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim5.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim6.awk" file 644 mtime 1782131302 "54e1f7c0f1c59320966dc5374e7ce891e034eda31b32badf7af589d6f88e9be6">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim6.ok" file 644 mtime 1782131302 "c99ac0a021d4d017104e9ea03daaabb33866eea648c1999f1f4fa97317aa40cb">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim7.awk" file 644 mtime 1782131302 "24fd6f4a86c44ef3a2fb0e249c1e6521a8c82031e2345455b9fb45a2cc94c2f4">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim7.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim8.awk" file 644 mtime 1782131302 "6fed8f97a6e1395a377ffae9ded78b4acda718522c294f1f9dff0bf30a790f40">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim8.in" file 644 mtime 1782131302 "0127688cf08cc4ee8d35db31c56266225d184bc557eeb3dcf99c60f519368ff2">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim8.ok" file 644 mtime 1782131302 "d5de46afe51d7aef42b3b3c6714fb3826cb53fcf6ec8892c0e6e773c769da9cf">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim9.awk" file 644 mtime 1783249699 "75e76944cc8a2789e8221d5cc82337f4de78bf75e400727b104528edd2d42d51">,
      #splice.entry<"/build/gawk-5.4.1/test/mdim9.ok" file 644 mtime 1783249699 "b20675ff2fb95cb15a2bce8b1f9e2c14deb7f1d2731999b39399904d9e292335">,
      #splice.entry<"/build/gawk-5.4.1/test/membug1.awk" file 644 mtime 1782131302 "a243f846baaf54dcec0770d2dece61286ffc56b78812249b7aa4151bda47834e">,
      #splice.entry<"/build/gawk-5.4.1/test/membug1.in" file 644 mtime 1782131302 "63b14c5c06d5125e576f5dd9e64c62ca520e59b52a92c2afc9f5390e6bb25d80">,
      #splice.entry<"/build/gawk-5.4.1/test/membug1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak.awk" file 644 mtime 1782131302 "77e00abfc55a05aa0e9756677308b285827f31b1f5d1e05801591e97ce1ac194">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak.ok" file 644 mtime 1782131302 "5372588733824ecf5744e694f5d12b57d33e19ff1fd8b88a7e723e7426eea890">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak2.awk" file 644 mtime 1782131302 "0d706f104c613b3af2cad564faf3a708250a03d3e67f6902f21f18b0f6bdbd77">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak3.awk" file 644 mtime 1782131302 "488138d2faf380a64bfa41b842746852b2fe01c15f976c572d7d3344291aca14">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak3.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak4.awk" file 644 mtime 1783241692 "f7d2a30d32b44d745decabae4bd15180aacbe5303f2c94cfb9064bc0fbc3d23a">,
      #splice.entry<"/build/gawk-5.4.1/test/memleak4.ok" file 644 mtime 1783241692 "e32e29f08455ebd96916ae0074aafe4c159790d3f204da542fd1fa2fd5e6055a">,
      #splice.entry<"/build/gawk-5.4.1/test/messages.awk" file 644 mtime 1782131302 "93d4257bd288f55ba7bd3c0def3167e428d3506087fdc8a65ccd979dd6e3c55f">,
      #splice.entry<"/build/gawk-5.4.1/test/minusstr.awk" file 644 mtime 1782131302 "660d0265c923700fac87c04256e93f11d2aaa2ed05a15d2772663c0ae169a890">,
      #splice.entry<"/build/gawk-5.4.1/test/minusstr.ok" file 644 mtime 1782131302 "d7b906a85360766ca93a7f2a3391ddc205bb248d2ec6e045769e67889fc1ebd5">,
      #splice.entry<"/build/gawk-5.4.1/test/mixed1.ok" file 644 mtime 1782131302 "d15cdb2689a0de2de87eacdd3a569ab0d2e3e11d479db52e356d69af14e7c7bf">,
      #splice.entry<"/build/gawk-5.4.1/test/mktime.awk" file 644 mtime 1782131302 "539555191a0dceb440ff86aba25f20d68d1c27aa918628229c539fd2f7725a9e">,
      #splice.entry<"/build/gawk-5.4.1/test/mktime.in" file 644 mtime 1782131302 "98e99ee7ce6c0668c62772d5a0afa04d19ca25887e277c92b1e42df69d8efa12">,
      #splice.entry<"/build/gawk-5.4.1/test/mktime.ok" file 644 mtime 1782131302 "e4de5fe75724ed9b7c4a9b455a1fd384b202875ca22de0faff0371362250133f">,
      #splice.entry<"/build/gawk-5.4.1/test/mmap8k.awk" file 644 mtime 1782131302 "ea23a50753e4c2494dfeb63b3278930b2c1c9bff51b8b58b96818845d87ca757">,
      #splice.entry<"/build/gawk-5.4.1/test/mmap8k.in" file 644 mtime 1782131302 "66482b33b7ea7abf6d047c3edce3d1943fdaec9a096ddd5757de0daad1972fe9">,
      #splice.entry<"/build/gawk-5.4.1/test/mmap8k.ok" file 644 mtime 1782131302 "66482b33b7ea7abf6d047c3edce3d1943fdaec9a096ddd5757de0daad1972fe9">,
      #splice.entry<"/build/gawk-5.4.1/test/modifiers.ok" file 644 mtime 1782131302 "4675fb456702bfc93701a67f3b3b5da2ee111070319b6d75e0a4a219705a2465">,
      #splice.entry<"/build/gawk-5.4.1/test/modifiers.sh" file 755 mtime 1782131302 "50fa1d30871927f81610b93855e9aa442d6f7a69d1680d96714dd3401aac2910">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfranswer42.awk" file 644 mtime 1782131302 "1e95b694fd2a4457ed9017665f99e1b852c4c10dfef143656f78c0e4ccd1a055">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfranswer42.ok" file 644 mtime 1782131302 "084c799cd551dd1d8d5c5f9a5d593b2e931f5e36122ee5c793c1d08a19839cc0">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrbigint.awk" file 644 mtime 1782131302 "d6474312efc258bc5aab11cadd3ecc7ea827e4f429784d0375696771d6786e93">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrbigint.ok" file 644 mtime 1782131302 "9af83f750a7dd1bd42d2746e1584804829a57817c0616e710ae09ce94fd6e2cf">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrbigint2.awk" file 644 mtime 1782131302 "6d5cb224895b3651f72572cd277768828552e2e9b5e7c8aa2cf3247dcb688388">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrbigint2.in" file 644 mtime 1782131302 "03ccb5fed4e91b4059eb9fe0e017e12acc609feeb6275ccb16f51d67f033682b">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrbigint2.ok" file 644 mtime 1782131302 "79ff740fab9e0b91b020cd3a5a696eb5e0923704f5ba7a06202e3dd550cbd621">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrcase.awk" file 644 mtime 1782131302 "7b018e04142e31c31528753551362b91a2e7e8cf584dc307f189ea8120672ab9">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrcase.in" file 644 mtime 1782131302 "06f961b802bc46ee168555f066d28f4f0e9afdf3f88174c1ee6f9de004fc30a0">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrcase.ok" file 644 mtime 1782131302 "190f80cab994d6b40822b7c34f08a706ac60adc769dbb3b1be999d75490b2d16">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrcase2.awk" file 644 mtime 1782131302 "6bde374d5dc45753bad22c36402ebdc12473d4d2d3c4ab040634d8bed2a13f38">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrcase2.in" file 644 mtime 1782131302 "2db799cf0c2c63fb374581297f7b7162b73c76a36055ad05350d6623a0eaa2da">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrcase2.ok" file 644 mtime 1782131302 "2db799cf0c2c63fb374581297f7b7162b73c76a36055ad05350d6623a0eaa2da">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrexprange.awk" file 644 mtime 1782131302 "2d6f8b261231b70cc6f264fce20b59bd0b9aea734203bb1b661f3fcc800d4286">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrexprange.ok" file 644 mtime 1782131302 "d30f915d2c8650e222ded625367ce10b5bce6dee41fb57ee68d8285e4b019b24">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrfield.awk" file 644 mtime 1782131302 "63ee53154896f1a25e26a3a2d149fa2ad1a929a7821fa7327138edcbf6065e82">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrfield.in" file 644 mtime 1782131302 "6ea11cf0f967c453ba6eca2e035633cbecbdd3a7ad7d227fc5ef8901ea81a3de">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrfield.ok" file 644 mtime 1782131302 "fd41210958b007cb1259f71cee513904b952074645e2d6e1c5626712e5e88725">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrieee.awk" file 644 mtime 1782131302 "957ed242102b979bc494b58cb7bdc2aad0e4c07b78b688b7db8b7a10b52a5f04">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrieee.ok" file 644 mtime 1782131302 "c4d618dbe46bb433299a68dd4cc3e36711c07ed27ca0d0a90292ea37fd274bf2">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrmemok1.awk" file 644 mtime 1782131302 "3b5082428bbca1992018cbec209f9f87302d6e2b63f2aa85094dda436ce98bc4">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrmemok1.ok" file 644 mtime 1782131302 "49470d72165df2650cca108116e08c272ec2ebce9fa0e01ceb311dfec8d6adf1">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnegzero.awk" file 644 mtime 1782131302 "18cc890da5fc32421b33329c601b52c31f987a19213523880b90c7c5504c8e63">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnegzero.ok" file 644 mtime 1782131302 "684b727b9cc4bd2b0a9ace5708d3f24cecdf212027e3ff293444ef93e3af4274">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnegzero2.awk" file 644 mtime 1782131302 "683b45ac3bfac1ce927ce74b8d5b2acda21c68f5ad80fbf9a53dbcb1db9bdef4">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnegzero2.ok" file 644 mtime 1782131302 "2420fd8d23b2007e2da5146d3a4c93ed0a801fa2f4af29d53d56c163ab0e2486">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnonum.awk" file 644 mtime 1782131302 "cb265d339957e8173f6bfdae4083bab1b76f42d6ce5b8c1c32406f5fb9e82b32">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnonum.in" file 644 mtime 1782131302 "40a76573afa7e2d0eda1d4420bcbcecc761b1e0c8a28055af4d3fe06ce0ce6d6">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnonum.ok" file 644 mtime 1782131302 "734a56c92f4db79b1da2fbce50174a5d6c3400053add8b0c0df304a2d3e2e16b">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnr.awk" file 644 mtime 1782131302 "bfd9abd804fd3db325f473c97a58c46b99b0e892b764b5195d2ebadc4f401c0a">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnr.in" file 644 mtime 1782131302 "ec1f9796b88620f692b2dbdfc17c114a1c06d78d527471486d49787f89a3cff1">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrnr.ok" file 644 mtime 1782131302 "cb5e6c3ec4a2b714341f7aa36bf8dad389e1dccad79e3b97fd801a8070491d66">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrrem.awk" file 644 mtime 1782131302 "59f848628ab1527d332d05f339bdc5c4df83573c7f0a79c54834f655ee62ae50">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrrem.ok" file 644 mtime 1782131302 "bc4f5b7dcfa62279e6fb7b306cf06ea27908200b4cec19e87d5a5b439025a515">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrrnd.awk" file 644 mtime 1782131302 "61d2e49994acf38b35452056ea2e7d0eccd8e0f61b9d8c3144fa3a0a9bcc6d05">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrrnd.ok" file 644 mtime 1782131302 "716b6fb0afe50a3b61a84b7784b304a02570426cf0b1d79470d879bad5849b6b">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrrndeval.awk" file 644 mtime 1782131302 "1f6990252468b0d542260946cf69bce599cffbba73e7ab1a4a3dfa87feb17a29">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrrndeval.ok" file 644 mtime 1782131302 "cb7ca2d0aa5f6ead50b3f44c432cf6127656b7531a957048c7f51142e6c2355e">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrsort.awk" file 644 mtime 1782131302 "c9491c9eb7618eaa55d54f76cafb51d69724706826576fcd3c99e08d7250658e">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrsort.ok" file 644 mtime 1782131302 "f26794f9d7d7e6f4b250118ef61b99d781bdbee95f7694e600552e54ceb14445">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrsqrt.awk" file 644 mtime 1782131302 "a06b1b92b061652145a3072a4e254d1d31b40b17a20c38be1cfd7d3a454c1c69">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrsqrt.ok" file 644 mtime 1782131302 "e2be134d2646722f60ddb2c1d203cc24551685c21c4ae775ade73f07a9d3a648">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrstrtonum.awk" file 644 mtime 1782131302 "4ae18e7d43371835d33313dd433424680b8e9d7499004c1dff38bf9ad21a7e41">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfrstrtonum.ok" file 644 mtime 1782131302 "cfbb0b2ac804980a5859eb68448265e2a705929a3ac2ca27d57b56001b7fbf8b">,
      #splice.entry<"/build/gawk-5.4.1/test/mpfruplus.ok" file 644 mtime 1782131302 "3b916844f0b00b46cf50fdb2e1cec237bc8963e5e6abb992a81307b1f30bb5fd">,
      #splice.entry<"/build/gawk-5.4.1/test/mpgforcenum.awk" file 644 mtime 1782131302 "a474e6fb4e0cfcd2b927dda9440b729073fc3526a64e66162b30aea43241743f">,
      #splice.entry<"/build/gawk-5.4.1/test/mpgforcenum.ok" file 644 mtime 1782131302 "0c68feae3aa59d3d3d7ebe892e077d98f82108b7c38af3d2c6d50b44572f4c77">,
      #splice.entry<"/build/gawk-5.4.1/test/mtchi18n.awk" file 644 mtime 1782131302 "a6ac94b87f37b30d528bbaf479e1d641ea850c9e46251297e14ff5df6c58fe0c">,
      #splice.entry<"/build/gawk-5.4.1/test/mtchi18n.in" file 644 mtime 1782131302 "75a11da44c802486bc6f65640aa48a730f0f684c5c07a42ba3cd1735eb3fb070">,
      #splice.entry<"/build/gawk-5.4.1/test/mtchi18n.ok" file 644 mtime 1782131302 "ad0fadf63cc7cd779ce475e345bf4063565b63a3c2efef1eebc89790aaa6acba">,
      #splice.entry<"/build/gawk-5.4.1/test/mtchi18n2.awk" file 755 mtime 1782131302 "eac2c5067e0cb3cecbcdd896ed3d5a00b88dc412e7a46968abb1f6af2349903a">,
      #splice.entry<"/build/gawk-5.4.1/test/mtchi18n2.ok" file 755 mtime 1782131302 "8fe6ef930626d379007500211ddaeea64a3bdb68b59dccc92a7ec595f0c50000">,
      #splice.entry<"/build/gawk-5.4.1/test/muldimposix.awk" file 644 mtime 1782131302 "57047727e0b3311ccef1e7b22e256b99a5c267ebe27f658663e3c1ac1591ace3">,
      #splice.entry<"/build/gawk-5.4.1/test/muldimposix.ok" file 644 mtime 1782131302 "6806013237dcded31acecac038cfe3b85ff2daf765f9092937f6c94c2c565e11">,
      #splice.entry<"/build/gawk-5.4.1/test/nasty.awk" file 644 mtime 1782131302 "6e8cf540e50730617be9770e9399fdc7855f20e4b69dc614426a579e643be532">,
      #splice.entry<"/build/gawk-5.4.1/test/nasty.ok" file 644 mtime 1782131302 "cfe955120872cdaab617da56c0d51b08f5b3ea5ded370b7a009d1324697f6c34">,
      #splice.entry<"/build/gawk-5.4.1/test/nasty2.awk" file 644 mtime 1782131302 "733658c9303e6dede85864fdedfee28cacf8e55a1b9252adb7233851d00d9c64">,
      #splice.entry<"/build/gawk-5.4.1/test/nasty2.ok" file 644 mtime 1782131302 "28b160b637f766b8bef2cde4b1d6d084b5597bde66707f29f7e3156ffe441c55">,
      #splice.entry<"/build/gawk-5.4.1/test/nastyparm.awk" file 644 mtime 1782131302 "979b0f5b78fb117f1009b1e50fe1304c179e33976210caeeaaa2fb9fc5880ccc">,
      #splice.entry<"/build/gawk-5.4.1/test/nastyparm.ok" file 644 mtime 1782131302 "208a07c23383eecb96eed0160e2f888d7af4a20480d3855c3c222d908d2a7140">,
      #splice.entry<"/build/gawk-5.4.1/test/negexp.awk" file 644 mtime 1782131302 "72f2b8369781441805db7ad750bb46a466b1632328370b663fddf9f71b3457f8">,
      #splice.entry<"/build/gawk-5.4.1/test/negexp.ok" file 644 mtime 1782131302 "a37f9fe7bd3fa9d73c6b5c339b56943e53f5e080499527175cf537b71a836c01">,
      #splice.entry<"/build/gawk-5.4.1/test/negrange.awk" file 644 mtime 1782131302 "c9aa7294225fbacb8b94a70f85636882f760280cd58a963c430d85ec5843c6ad">,
      #splice.entry<"/build/gawk-5.4.1/test/negrange.ok" file 644 mtime 1782131302 "b5932ebe5fe20e5274fde780cb4950e6bd2f17d86ff1fb7532550238321ae4e5">,
      #splice.entry<"/build/gawk-5.4.1/test/negtime.awk" file 644 mtime 1782131302 "a859cd173e6e8863239f45fc8babb16e40e978c082251a9b6f4021240f8f2bb9">,
      #splice.entry<"/build/gawk-5.4.1/test/negtime.ok" file 644 mtime 1782131302 "3893a2ef88dee02a5463fc757e33fd2e3507871ca49816b1ed239f9fd9043c5b">,
      #splice.entry<"/build/gawk-5.4.1/test/nested.awk" file 644 mtime 1782131302 "ffd1011cf70f2ffa2a8a8eb10181f24b2e5f9075ba1c05559839ac3756a0619b">,
      #splice.entry<"/build/gawk-5.4.1/test/nested.in" file 644 mtime 1782131302 "87a1422dae2f03bdff40431e7ba4e35c5bbc0aad2287c254e3920b357b928b14">,
      #splice.entry<"/build/gawk-5.4.1/test/nested.ok" file 644 mtime 1782131302 "7da0810372718aaba44c608981aa81247cee8c3fc0ece1f7f7dd0e3152b41715">,
      #splice.entry<"/build/gawk-5.4.1/test/next.ok" file 644 mtime 1782131302 "14a63a3f6b7d76ac57db51cfe5bc61e22b2245b1f3cd8f8872b7bbc1ba949b21">,
      #splice.entry<"/build/gawk-5.4.1/test/next.sh" file 755 mtime 1782131302 "8ec946a6f44fe202bc637443c17e7d9be0293691fff4539d971eb8c5b31a1bbd">,
      #splice.entry<"/build/gawk-5.4.1/test/nfldstr.awk" file 644 mtime 1782131302 "e76f0405d5db4d974fa9196f55ab34299886008215723d6efd45654247dc586c">,
      #splice.entry<"/build/gawk-5.4.1/test/nfldstr.in" file 644 mtime 1782131302 "01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b">,
      #splice.entry<"/build/gawk-5.4.1/test/nfldstr.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nfloop.awk" file 644 mtime 1782131302 "89259ecd595dce16cd5dabc5ff48cfd46138706b1ef95833ede0ae3eb833c1df">,
      #splice.entry<"/build/gawk-5.4.1/test/nfloop.ok" file 644 mtime 1782131302 "6ad43448c08fd3657ba7110d86ed4f2d59a151070b27cd8d84520eeb13b19d72">,
      #splice.entry<"/build/gawk-5.4.1/test/nfneg.awk" file 644 mtime 1782131302 "04798abc80088893aad80470a92cbd39fb12901d3b32911017b3c1e122bfb9b5">,
      #splice.entry<"/build/gawk-5.4.1/test/nfneg.ok" file 644 mtime 1782131302 "d4c2bd1895bf16e15536d3822bb98034dfc9f040aaaa42548ed470813a9c2c30">,
      #splice.entry<"/build/gawk-5.4.1/test/nfset.awk" file 644 mtime 1782131302 "e04114801883466a99653572018417e4fba62f7736abcd761da9a6beb2e25d0e">,
      #splice.entry<"/build/gawk-5.4.1/test/nfset.in" file 644 mtime 1782131302 "9967af34763dd28381edc02a7d6694c12beb19e717bcaeb99d4bad18ae160c29">,
      #splice.entry<"/build/gawk-5.4.1/test/nfset.ok" file 644 mtime 1782131302 "8523315ee3664b774cf645ab5ba1bc06de03995df3dfdfbd92f5363d36236d44">,
      #splice.entry<"/build/gawk-5.4.1/test/nlfldsep.awk" file 644 mtime 1782131302 "2aa85e493a1f05e198fafa2cb0b3173e7312d78ca92d37bcda14ecb189ebca84">,
      #splice.entry<"/build/gawk-5.4.1/test/nlfldsep.in" file 644 mtime 1782131302 "ea54581fe0948ca6a23d757c197b650bb3c8f81179d4e30164c0c885aa23d0e5">,
      #splice.entry<"/build/gawk-5.4.1/test/nlfldsep.ok" file 644 mtime 1782131302 "ce29b719cfee35794882995405adb072c80fec0451f2dbadc8938e9ab519546f">,
      #splice.entry<"/build/gawk-5.4.1/test/nlinstr.awk" file 644 mtime 1782131302 "ea7441ecca16ce02c9cb5b2f0452e2016f0f46794562d1e1b9337a972323815e">,
      #splice.entry<"/build/gawk-5.4.1/test/nlinstr.in" file 644 mtime 1782131302 "f20ad74d1a40bc4f0d6efd110d54c42e3b4d68179511f421a18d53994c1b0c77">,
      #splice.entry<"/build/gawk-5.4.1/test/nlinstr.ok" file 644 mtime 1782131302 "dc51b8c96c2d745df3bd5590d990230a482fd247123599548e0632fdbf97fc22">,
      #splice.entry<"/build/gawk-5.4.1/test/nlstrina.awk" file 644 mtime 1782131302 "a0fab1ef89156bce8f190b1c685edb5171be2bbd9bafc1df0049877d844e4b63">,
      #splice.entry<"/build/gawk-5.4.1/test/nlstrina.ok" file 644 mtime 1782131302 "c6e0003fba5c29e81bc3579c8105314057651c647b625888348358ebec8ce507">,
      #splice.entry<"/build/gawk-5.4.1/test/nlstringtest-nogettext.ok" file 644 mtime 1782131302 "7fd05b71a8bff818d7b1d28ec6dfedc680512d1eeb609d5880fd1b5c970e05b0">,
      #splice.entry<"/build/gawk-5.4.1/test/nlstringtest.awk" file 644 mtime 1782131302 "daa51f9c61cc8668691938a90e62118f6dfbed2e12962e3b45ac221668d80895">,
      #splice.entry<"/build/gawk-5.4.1/test/nlstringtest.ok" file 644 mtime 1782131302 "848346b1030cd4a72e49a0f1270a5f2daa6e50b92389cf057cdcbfc6be9b1ae3">,
      #splice.entry<"/build/gawk-5.4.1/test/nlstringtest.po" file 644 mtime 1782131302 "879fd9a665362487acc1ab87581c1cf4a68eeef078d6b83041bd18b4e734dfd4">,
      #splice.entry<"/build/gawk-5.4.1/test/noeffect.awk" file 644 mtime 1782131302 "d227fb33c0168ab1b89aaeeeea51100ffb1f3b40e96b17897048272e5bd5905a">,
      #splice.entry<"/build/gawk-5.4.1/test/noeffect.ok" file 644 mtime 1782131302 "a11cdf6a519c5998933aad60d4c62a9871fccfddb28c5293162901a7e1670171">,
      #splice.entry<"/build/gawk-5.4.1/test/nofile.ok" file 644 mtime 1782131302 "ada2e564417d9a62082ef02e2796c10bca2168f0ec4600da78a76e373c7ec2a4">,
      #splice.entry<"/build/gawk-5.4.1/test/nofmtch.awk" file 644 mtime 1782131302 "99d6fadede472b1d7221a6199fd2698bc5ebc75676fa7daed0951827620c8971">,
      #splice.entry<"/build/gawk-5.4.1/test/nofmtch.ok" file 644 mtime 1782131302 "841b7547b8b57e4213efd98e0a924c064790e3409197dd2f81dadeeb60b00d90">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop1.awk" file 644 mtime 1782131302 "b6a5412e3ff21ffe13575d262a8d65c7e3f850188fbe70552748c92245df5073">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop1.in" file 644 mtime 1782131302 "1b321d6f8f0d9cf60435d9112bac1c380f3de3b01ec191f6074a932711008ba1">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop2.awk" file 644 mtime 1782131302 "b6a5412e3ff21ffe13575d262a8d65c7e3f850188fbe70552748c92245df5073">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop2.in" file 644 mtime 1782131302 "0b6297986fcfb9286954b9a095f3291ec941c9b3ea7ca03f15b7dfc5bfc8b8d4">,
      #splice.entry<"/build/gawk-5.4.1/test/noloop2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nondec.awk" file 644 mtime 1782131302 "eca7a76016a4b1e304fb28e0e6fb15e6586f941f8e14628fefe412c9977033fa">,
      #splice.entry<"/build/gawk-5.4.1/test/nondec.ok" file 644 mtime 1782131302 "f88a040b3b55521fd563adee24d3b9b6ead53f17840bbe42d3ee41cadebf4cec">,
      #splice.entry<"/build/gawk-5.4.1/test/nondec2.awk" file 644 mtime 1782131302 "095a7b0c99bab0a4cbc2735920f5ff5063c1c3d85efe73c00c3b8d0110fc082b">,
      #splice.entry<"/build/gawk-5.4.1/test/nondec2.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/nonfatal1.awk" file 644 mtime 1782131302 "9efa4c5de061a5a78cf721d832b87bedbafc4e928fc4c9532897e9dfeb81b288">,
      #splice.entry<"/build/gawk-5.4.1/test/nonfatal1.ok" file 644 mtime 1782131302 "0be0c6f2102d9e9cee9504364d241d9eb22e0c9b0aab606e6959b67ea899d5a2">,
      #splice.entry<"/build/gawk-5.4.1/test/nonfatal2.awk" file 644 mtime 1782131302 "a99ce1a1399b640a5c1d4653d38e3064b1470b59a354760222dca5a6b0d6a625">,
      #splice.entry<"/build/gawk-5.4.1/test/nonfatal2.ok" file 644 mtime 1782131302 "7833838098dff21a62433384c486ade9ca1da78ee9f7995fa051640e4a6db5e4">,
      #splice.entry<"/build/gawk-5.4.1/test/nonfatal3.awk" file 644 mtime 1782131302 "4282b44ace8586b3350fa5a972a5a62938343ce37d5833a2c82032b967a13ff8">,
      #splice.entry<"/build/gawk-5.4.1/test/nonfatal3.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/nonl.awk" file 644 mtime 1782131302 "5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9">,
      #splice.entry<"/build/gawk-5.4.1/test/nonl.in" file 644 mtime 1782131302 "ef875a1705a5fdac206be996f4dc1f726ea6b68861eb741c37def7277f179e37">,
      #splice.entry<"/build/gawk-5.4.1/test/nonl.ok" file 644 mtime 1782131302 "f3634ac34659fbd745cf58f384fc39779e70d23f4728b1e2e2076db4419682c3">,
      #splice.entry<"/build/gawk-5.4.1/test/noparms.awk" file 644 mtime 1782131302 "d0853780d43aa463d839b51b159da0d9e8b15d0540167a5662eb53588d506e5f">,
      #splice.entry<"/build/gawk-5.4.1/test/noparms.ok" file 644 mtime 1782131302 "df014f05b28f7ac28fd600611987a5fa9f19a6be8cb24c6e61bd3570d7dab3c9">,
      #splice.entry<"/build/gawk-5.4.1/test/nors.in" file 644 mtime 1782131302 "f527687229a42ecd273f976a7c0b7ddde0050230e3729c77a41c1d59c54eabb3">,
      #splice.entry<"/build/gawk-5.4.1/test/nors.ok" file 644 mtime 1782131302 "f49cc1b27596d5fb6b2558671421a2dc462e1c84be7db8d81c1b94597ab48538">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1.awk" file 644 mtime 1782131302 "5a6eb6c4a2ea8a1da702ed6198f28648435b33df4a4121aec71ad99ff99ef275">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1a.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1b.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk1c.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk2.awk" file 644 mtime 1782131302 "4fd50d90e833764ecf98390564c2e910867bacd015765f98a34a32a7ea56f4dc">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk2a.ok" file 644 mtime 1782131302 "8ecc5f94c57b05d6c5e0ee316bee4875427e1845bbeef3ead59df29c72aab36e">,
      #splice.entry<"/build/gawk-5.4.1/test/nsawk2b.ok" file 644 mtime 1782131302 "8ecc5f94c57b05d6c5e0ee316bee4875427e1845bbeef3ead59df29c72aab36e">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad.awk" file 644 mtime 1782131302 "9e032825d660ae56aeb8c5fb4c1c163f1ac2d7a9cd1a2a0c67e552ac0ddb6e2b">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad.ok" file 644 mtime 1782131302 "890f9f6550e60f953efff6cd88d1a95ed38101919d1da0c428b1a04a0f89e428">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad2.awk" file 644 mtime 1782131302 "bd4da2143160efd454b1e161109939a0964b0961ae7b6134bab749ab16283db9">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad2.ok" file 644 mtime 1782131302 "82d7b346da15b4ce30d05e7a0246b00ea5b59493fbb3de60878d96d85d428422">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad3.awk" file 644 mtime 1782131302 "b4dba51b9c7286db1cba57828e7a8d2c6ff293187b60a07f84c2d0de0a8d8b3f">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad3.ok" file 644 mtime 1782131302 "c20e07f33c4925d2ab9a15ec33c13b431fb8c37353960f6499fc334bcd749699">,
      #splice.entry<"/build/gawk-5.4.1/test/nsbad_cmd.ok" file 644 mtime 1782131302 "03c94585685bd6f6514ac369edb0803e6ba7b5f0dc674bbf3353972d9e681be0">,
      #splice.entry<"/build/gawk-5.4.1/test/nsforloop.awk" file 644 mtime 1782131302 "2d3e8bdfffa623413195d8a713051508e6750d2b31180a3f16b96f8f1db8efc5">,
      #splice.entry<"/build/gawk-5.4.1/test/nsforloop.ok" file 644 mtime 1782131302 "208a55044684810cff3b5028867ec5f04abe0372cd2653f18ab12402f9eb52e0">,
      #splice.entry<"/build/gawk-5.4.1/test/nsfuncrecurse.awk" file 644 mtime 1782131302 "dad1c6ac1af99baba5e93b72388f9dbde7700f5de1d435f6c39f1d5633973526">,
      #splice.entry<"/build/gawk-5.4.1/test/nsfuncrecurse.ok" file 644 mtime 1782131302 "81934c163b34796c1dfc10e21345068d0bde46daa0028150e535f9cafeb63451">,
      #splice.entry<"/build/gawk-5.4.1/test/nsidentifier.awk" file 644 mtime 1782131302 "d5c65621a7e92c4a8aa4260a3defd17253d67e29f85206b6c40eac5746b596d5">,
      #splice.entry<"/build/gawk-5.4.1/test/nsidentifier.ok" file 644 mtime 1782131302 "f0cae6770fba53242b29c58975876b0d98fa4cc07874a9ad8d8ac1f0da392204">,
      #splice.entry<"/build/gawk-5.4.1/test/nsindirect1.awk" file 644 mtime 1782131302 "3542a7da728a93c5560fe3e76669733a0247f2ea5f1f99e72ec308ea932bfd2f">,
      #splice.entry<"/build/gawk-5.4.1/test/nsindirect1.ok" file 644 mtime 1782131302 "a81d16bf65c69e7cf8201620aa9e30b54b2e6eac7558bb47e42cb4585208ea91">,
      #splice.entry<"/build/gawk-5.4.1/test/nsindirect2.awk" file 644 mtime 1782131302 "215696cda2c4f02696df0cac42775388a7b863b163af312e4b396f14fb301939">,
      #splice.entry<"/build/gawk-5.4.1/test/nsindirect2.ok" file 644 mtime 1782131302 "b44546574cc3908d51d582a531910902c596cd7d92bccba398850786505f9038">,
      #splice.entry<"/build/gawk-5.4.1/test/nsprof1.awk" file 644 mtime 1782131302 "be014e6407b650730710610a79403116a41992a390f335ad6eb6ca5b6c3773b8">,
      #splice.entry<"/build/gawk-5.4.1/test/nsprof1.ok" file 644 mtime 1782131302 "cfce408503f9885e1e78f0ac248f2f48155227f5ed84abf4140d818107c43634">,
      #splice.entry<"/build/gawk-5.4.1/test/nsprof2.awk" file 644 mtime 1782131302 "cada4259deee421e715c85df809ec4f92288a541ee414c74f42b7c0e15331162">,
      #splice.entry<"/build/gawk-5.4.1/test/nsprof2.ok" file 644 mtime 1782131302 "ef764870fa44e8a6435c38b5029daa4c2dd758f6855959f34b7c5f29eaafdb11">,
      #splice.entry<"/build/gawk-5.4.1/test/nsprof3.awk" file 644 mtime 1782131302 "323eca460ecff80fc8954a27ebff3fd971a217c9243721df2c2face35b181475">,
      #splice.entry<"/build/gawk-5.4.1/test/nsprof3.ok" file 644 mtime 1782131302 "52ac20fec9b17fd7336bff05f71dabe2c79996d51fa418e9b4659faf08f864d7">,
      #splice.entry<"/build/gawk-5.4.1/test/nulinsrc.awk" file 644 mtime 1782131302 "62c9c3641d0b91aef515aaf0d5f7239e170316ab690b624dd718128c82cdd0c2">,
      #splice.entry<"/build/gawk-5.4.1/test/nulinsrc.ok" file 644 mtime 1782131302 "704c04818580cb38509be82f07ede117d69c8977e4970fc0cec3eb3bbe259bbc">,
      #splice.entry<"/build/gawk-5.4.1/test/nulrsend.awk" file 644 mtime 1782131302 "0e29eb859139ce1f081dba3db86492680576a2114d7c0cd8eaa91557f6f721ad">,
      #splice.entry<"/build/gawk-5.4.1/test/nulrsend.in" file 644 mtime 1782131302 "757a26ddeca2c653399e8c3ba7779c9820952767501cb05fe4f35820d371771e">,
      #splice.entry<"/build/gawk-5.4.1/test/nulrsend.ok" file 644 mtime 1782131302 "a6e2b7a040683432de03a18fd8a1939a2fdf82585b364bfc874bdd4095c4cae1">,
      #splice.entry<"/build/gawk-5.4.1/test/numindex.awk" file 644 mtime 1782131302 "998657daebd6e2ccb8a2fc77b510271ebdb613c19075a1a5d74d3cd5f9a6ecb1">,
      #splice.entry<"/build/gawk-5.4.1/test/numindex.in" file 644 mtime 1782131302 "e10358c182b207729cd704d7f4ef0339eeb6abb429e31c51ea877dcecedbf666">,
      #splice.entry<"/build/gawk-5.4.1/test/numindex.ok" file 644 mtime 1782131302 "5c37b570ed5ce819878bbd1f86dc1e066d4e46bf66acc51c459c6ccaccdbb432">,
      #splice.entry<"/build/gawk-5.4.1/test/numrange-mpfr.ok" file 644 mtime 1782131302 "b49b74ff6aa74bacff8da41b9683c33f3233f1d60209fb5ae6abf801db2b4c91">,
      #splice.entry<"/build/gawk-5.4.1/test/numrange.awk" file 644 mtime 1782131302 "b5e9a950987326c4ae3f358d5fc5d382a5a267f906e88fe1c12917f763d0ffbc">,
      #splice.entry<"/build/gawk-5.4.1/test/numrange.ok" file 644 mtime 1782131302 "936ca79b76f796eddb79dfbfb2db5a8de04d2afa655296422f80f35fd10ff45c">,
      #splice.entry<"/build/gawk-5.4.1/test/numstr1.awk" file 644 mtime 1782131302 "39222cbe9a537571ffe2fc78d1aef30b204879c36738c593d840bf46a5f769c3">,
      #splice.entry<"/build/gawk-5.4.1/test/numstr1.ok" file 644 mtime 1782131302 "006c8b7e03dd214c3f0d523fd7fae18d30f0dde0cfb32fbee8723acf5081cdeb">,
      #splice.entry<"/build/gawk-5.4.1/test/numsubstr.awk" file 644 mtime 1782131302 "b43ae74bb152a49530c45fd81510e38737f5b7f2816e0dc4245d9c935cfda3f1">,
      #splice.entry<"/build/gawk-5.4.1/test/numsubstr.in" file 644 mtime 1782131302 "2e4cddf1083a5e1959ce42a2c7902aaf5a487eb3a3a3d900bb241fda50d713ac">,
      #splice.entry<"/build/gawk-5.4.1/test/numsubstr.ok" file 644 mtime 1782131302 "06e5eae6256165bd5f1ef7e00cd69aca9839726c0bc184c43a4fc4c6f747182a">,
      #splice.entry<"/build/gawk-5.4.1/test/octdec.awk" file 644 mtime 1782131302 "41f567d76951bab1bf142bb2bd3a86219e4b15b1388155eef7ca58263eb48feb">,
      #splice.entry<"/build/gawk-5.4.1/test/octdec.ok" file 644 mtime 1782131302 "0ce1413f618ab46599687110d492fbabca574725126d81cae93ea305e8ca1b81">,
      #splice.entry<"/build/gawk-5.4.1/test/octsub.awk" file 644 mtime 1782131302 "0bfa073b256d96bdae49365ea918d34c06883767e672c9b058a40bf243a0425d">,
      #splice.entry<"/build/gawk-5.4.1/test/octsub.ok" file 644 mtime 1782131302 "8d38ad526db6ecf0f2283785c7558ecc465cef7413b518fb22a2e15c334d609f">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmt.awk" file 644 mtime 1782131302 "6488a58a22767d18a03e08e3b9cf84f909fd7a0dfcb8bdd4019b08d808849176">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmt.in" file 644 mtime 1782131302 "d357569885919f24f27d11a36029eef70c5f2a64f731d1cc6c7473f8b931a3f5">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmt.ok" file 644 mtime 1782131302 "f8b727e487334989e20a0b0e2a20bfc337718c59316945bfb82788797109205b">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmta.awk" file 644 mtime 1782131302 "1995ada315414f804fb7e9baf657ca64e0ac28785206d5b2286126268acf83a0">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmta.ok" file 644 mtime 1782131302 "c13b2cd30b0ec6821fb27fe55e3a38dd04067ccaffa235f8295343de4c451a4a">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtbig.awk" file 644 mtime 1782131302 "d8a76b385fa5beafef01b80efc16afcebcbf18849babe61c94cb6b2f88b1eedc">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtbig.in" file 644 mtime 1782131302 "ba4971f7af1ee974620f33700b2d2c917d347cd2824893d9f77943106755eef0">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtbig.ok" file 644 mtime 1782131302 "59b41fef0cab67db755d648cc20638c88cc75c3023832d62fd502dd65d937408">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtfidl.awk" file 644 mtime 1782131302 "afcddde22f5e507668ae63ad84aefa576ffdf88d046131d89c0ddc54da2658c9">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtfidl.in" file 644 mtime 1782131302 "bf794518e35d7f1ce3a50b3058c4191bb9401e568fc645d77e10b0f404cf1f22">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtfidl.ok" file 644 mtime 1782131302 "bf794518e35d7f1ce3a50b3058c4191bb9401e568fc645d77e10b0f404cf1f22">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmts.awk" file 644 mtime 1782131302 "d14cbb8435a37b055b374e3b6061ca7f92e829892319c93b6b70b3b54df5da3c">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmts.in" file 644 mtime 1782131302 "f94090d3f3687edbe431969e3f15affe5548130db2d1b1d2ebd31a17c859d518">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmts.ok" file 644 mtime 1783249447 "083540d82cd70639186c04b1df82c22d66ba93fdd8aa5101365edd4466ecdcb2">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtstrnum.awk" file 644 mtime 1782131302 "cd4932c7eb6d68541ac6b00e283229d8a7bc27574c815f1d287e581c6245f84c">,
      #splice.entry<"/build/gawk-5.4.1/test/ofmtstrnum.ok" file 644 mtime 1782131302 "fd04e5d83d2f2a54c79a4760a01f4fb0760bf58a6c22c47a244b60efe9314bf6">,
      #splice.entry<"/build/gawk-5.4.1/test/ofs1.awk" file 644 mtime 1782131302 "2a059ffd7341498ec632ad58d62a6f78edc2c69d4c38b8ba25538ac0826a5233">,
      #splice.entry<"/build/gawk-5.4.1/test/ofs1.in" file 644 mtime 1782131302 "42bee1c8bd952e59b2815ba57a50cfc37fe9b50624259ce2a10d2c1b603499de">,
      #splice.entry<"/build/gawk-5.4.1/test/ofs1.ok" file 644 mtime 1782131302 "176b8085c5f974733eb709a70cbaad6acb1cad317940205d6fd20cd31895e24b">,
      #splice.entry<"/build/gawk-5.4.1/test/onlynl.awk" file 644 mtime 1782131302 "4bfc68c8669d26d18366be4a49e79d826dcc4f3f0a7aa56ba135b78d1f7c7c7b">,
      #splice.entry<"/build/gawk-5.4.1/test/onlynl.in" file 644 mtime 1782131302 "545c38b0922de19734fbffde62792c37c2aef6a3216cfa472449173165220f7d">,
      #splice.entry<"/build/gawk-5.4.1/test/onlynl.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/opasnidx.awk" file 644 mtime 1782131302 "cf6025b40492fd7b7dc3b74aaf4637800b35dbc712d38c0ccfc35cfbd222dd47">,
      #splice.entry<"/build/gawk-5.4.1/test/opasnidx.ok" file 644 mtime 1782131302 "337b794ce718a09a620090d53541c3b4640a64133bbee2188444810cd3169f81">,
      #splice.entry<"/build/gawk-5.4.1/test/opasnslf.awk" file 644 mtime 1782131302 "6cc997e1bcca0c5ac6bf9bf96233e37e1d97f7bf271932ff9507b4ec3ea045e2">,
      #splice.entry<"/build/gawk-5.4.1/test/opasnslf.ok" file 644 mtime 1782131302 "b11ddc0345623e8be95c2a7e38a9c7e134e1920a9edc5955466c5f834f7fe272">,
      #splice.entry<"/build/gawk-5.4.1/test/ordchr.awk" file 644 mtime 1782131302 "95bf2587eee9baa941fa68f86b8f3671cb74939d60b20a9c9441dbb3e2b9cb35">,
      #splice.entry<"/build/gawk-5.4.1/test/ordchr.ok" file 644 mtime 1782131302 "0a0afcbd76854ed8fa9dc7bb7acde92079dec28d46429239ab357ec573f4344c">,
      #splice.entry<"/build/gawk-5.4.1/test/ordchr2.ok" file 644 mtime 1782131302 "c865f6c5ab8d1b0bcd383a5e1e3879d22681c96bf462c269b7581d523fbe70ab">,
      #splice.entry<"/build/gawk-5.4.1/test/out1.ok" file 644 mtime 1782131302 "6604c5df6cd9090121d4ddba622f6b90cdbf3f7a1ab2ae9d3e35e5cb5dbb81b7">,
      #splice.entry<"/build/gawk-5.4.1/test/out2.ok" file 644 mtime 1782131302 "67a13558d97bed971156749cf7239e89bc85320a926b20888bb581d06f49291c">,
      #splice.entry<"/build/gawk-5.4.1/test/out3.ok" file 644 mtime 1782131302 "753cccef8324e648a49fe3448a4dbbce436f23b2db77b931876aedad5e54cd69">,
      #splice.entry<"/build/gawk-5.4.1/test/paramasfunc1.awk" file 644 mtime 1782131302 "45e5c4afc9c89f883d39ef052cadbd0cf40d6c56fea0dd16f3aa967a7dc0a113">,
      #splice.entry<"/build/gawk-5.4.1/test/paramasfunc1.ok" file 644 mtime 1782131302 "4da4514256f62e7676d5c2b462f37d51169a52fb788b09342a19ab0e1c0ae9c9">,
      #splice.entry<"/build/gawk-5.4.1/test/paramasfunc2.awk" file 644 mtime 1782131302 "ce3f8a1aa598c114c54af7a3a70c140181e6471300f7133454d6c7bb9977a20c">,
      #splice.entry<"/build/gawk-5.4.1/test/paramasfunc2.ok" file 644 mtime 1782131302 "b08379ddedb3d73959f34472abb6854286365f27020e0f47fe0cb559531172ba">,
      #splice.entry<"/build/gawk-5.4.1/test/paramdup.awk" file 644 mtime 1782131302 "baa46ea4f7d72ad9ec0944172baf642aec486d0ab33d4f886fed8ef93883126f">,
      #splice.entry<"/build/gawk-5.4.1/test/paramdup.ok" file 644 mtime 1782131302 "46fd498147eb595e2e23378b1b3600478d3b78cb1405fcc8211bd7df0cbd82e7">,
      #splice.entry<"/build/gawk-5.4.1/test/paramres.awk" file 644 mtime 1782131302 "44f07d9fc51b2e14990ff08e98c7f80713aed80c19725b4d2f06c7a0583e3a95">,
      #splice.entry<"/build/gawk-5.4.1/test/paramres.ok" file 644 mtime 1782131302 "74e66331cc2d44e04875ba96b231b23d86188f4541a99c07175a244885ae0fb1">,
      #splice.entry<"/build/gawk-5.4.1/test/paramtyp.awk" file 644 mtime 1782131302 "40daabb2c2075496c66c861444b699e99b0521b3c8668636599d8c3c312d7b1f">,
      #splice.entry<"/build/gawk-5.4.1/test/paramtyp.ok" file 644 mtime 1782131302 "7e5212c0f7e558ae1541b4b597a2a5d46e5a4140aa7e6c21cb43aabf27890c09">,
      #splice.entry<"/build/gawk-5.4.1/test/paramuninitglobal.awk" file 644 mtime 1782131302 "0104c6793f62a130df95a5e94f24b867132b2d3ae6677196cefced12ed88eb5c">,
      #splice.entry<"/build/gawk-5.4.1/test/paramuninitglobal.ok" file 644 mtime 1782131302 "6aad786f0734758f02e2791b29f310365d98d4f5234532b63043daeadde84860">,
      #splice.entry<"/build/gawk-5.4.1/test/parse1.awk" file 644 mtime 1782131302 "0ad0e00cbef73697e7cb5dcc9bb222a9d2fd13779b45333fe612d3d620251641">,
      #splice.entry<"/build/gawk-5.4.1/test/parse1.in" file 644 mtime 1782131302 "c569c30b90e29e148da9fd0c20a58fef51dbb1a95fec17dd77395ed675aa8d11">,
      #splice.entry<"/build/gawk-5.4.1/test/parse1.ok" file 644 mtime 1782131302 "2bf2ab4d72613f5994a6b8bd12fc99b6f26f41f572e9a7fc2c9564ae8f6e456e">,
      #splice.entry<"/build/gawk-5.4.1/test/parsefld.awk" file 644 mtime 1782131302 "f236ee14a4fcddd0b8efa6a25e4a1b26df4ad7e10e0eeb63b529e4a293c0e9c2">,
      #splice.entry<"/build/gawk-5.4.1/test/parsefld.in" file 644 mtime 1782131302 "83147372b31735878beba3926601373b33976d2e9775bdb9229cea0cf6fdff0b">,
      #splice.entry<"/build/gawk-5.4.1/test/parsefld.ok" file 644 mtime 1782131302 "49a5846198dc502ea3311dc29162c5dc78b27f0f56a7380b3c62899407045917">,
      #splice.entry<"/build/gawk-5.4.1/test/parseme.awk" file 644 mtime 1782131302 "7be1aa98356ef32a4984fef344e3ddbbb331fc63dabbcd0c4d8dc0d3246160cb">,
      #splice.entry<"/build/gawk-5.4.1/test/parseme.ok" file 644 mtime 1782131302 "0552af67947eb6d55cce89b412bf318b8cc54af850f01dd7d22ffeae90dfa7c8">,
      #splice.entry<"/build/gawk-5.4.1/test/patsplit.awk" file 644 mtime 1782131302 "d46b05db68fe61c6b7fd270138162b51c5624a7ad273cc9054265bcd99f14d9e">,
      #splice.entry<"/build/gawk-5.4.1/test/patsplit.ok" file 644 mtime 1782131302 "fee86b355e68dffaa943d12c8840956346d0a67f467772d53a9e0cafa8df04f0">,
      #splice.entry<"/build/gawk-5.4.1/test/pcntplus.awk" file 644 mtime 1782131302 "98c5508120651ab5ab40a16400c164945c0fe94cb7fcfebe71789f452cd08850">,
      #splice.entry<"/build/gawk-5.4.1/test/pcntplus.ok" file 644 mtime 1782131302 "f4a84f58ce333f9308eed8e41b5abf7877f90ea049e34103187bdef85fca4a6f">,
      #splice.entry<"/build/gawk-5.4.1/test/pid.awk" file 644 mtime 1782131302 "e16346deac647b5f5c030751a5f6e53dee362db225a8fc86364451ce9cd7cbac">,
      #splice.entry<"/build/gawk-5.4.1/test/pid.ok" file 644 mtime 1782131302 "2d8abe775f8f1ac00c1a8b7ef48004fbe8acb688d6c48df5ce2816cd43c10b0a">,
      #splice.entry<"/build/gawk-5.4.1/test/pid.sh" file 755 mtime 1782131302 "28ef54930e970546812c66d87fc7bbfb3aa969c06c2bade864207de5f8dcaea9">,
      #splice.entry<"/build/gawk-5.4.1/test/pipeio1.awk" file 644 mtime 1782131302 "2ef52fab72b52175cd76ced2a7e7ac7a0f3856c53241bf57bbf0aa855ef2f0ba">,
      #splice.entry<"/build/gawk-5.4.1/test/pipeio1.ok" file 644 mtime 1782131302 "97976f3673f0901d7d9fd158a9f96275b1814546f91b4b68b6d2931df54b5d5b">,
      #splice.entry<"/build/gawk-5.4.1/test/pipeio2.awk" file 644 mtime 1782131302 "1e44e10809f843a2b18545f014a3932b0714b120f5a95dca50cba2f00a1ab976">,
      #splice.entry<"/build/gawk-5.4.1/test/pipeio2.in" file 644 mtime 1782131302 "f2ab5873acbd99b98e467dc7ffe40033e7fb815829b8311bdc57a02abc8d89b5">,
      #splice.entry<"/build/gawk-5.4.1/test/pipeio2.ok" file 644 mtime 1782131302 "fffd39ac6e39740b9e4b8875c56950a467734ec76b961bd4712750f141457ca8">,
      #splice.entry<"/build/gawk-5.4.1/test/pma.ok" file 644 mtime 1782131302 "a6e2b7a040683432de03a18fd8a1939a2fdf82585b364bfc874bdd4095c4cae1">,
      #splice.entry<"/build/gawk-5.4.1/test/posix-inf.awk" file 644 mtime 1783328483 "3541305e29bfa50b7ed0348554470d8c049bf817683c672720fd1e437127968a">,
      #splice.entry<"/build/gawk-5.4.1/test/posix-inf.ok" file 644 mtime 1783328483 "ce7a8e705396f51d4f60979f11ec2620e2e00ccee852338f495df658127c01c6">,
      #splice.entry<"/build/gawk-5.4.1/test/posix-inf.ok2" file 644 mtime 1783329604 "144edfd587e4c8f6dba13693702c5962233da805f91990b210098afe2fdee8ce">,
      #splice.entry<"/build/gawk-5.4.1/test/posix.awk" file 644 mtime 1782131302 "e87eb0a71edeb09b249077d8d70d2134655fac28de84545b94be78d87e4d340d">,
      #splice.entry<"/build/gawk-5.4.1/test/posix.in" file 644 mtime 1782131302 "0ae2dd739e9068c531c18d71ee06ce52fe9b8aff4577d31b5e0ec1113a073497">,
      #splice.entry<"/build/gawk-5.4.1/test/posix.ok" file 644 mtime 1782322910 "6f825ea2b63b3283eaa13633ef70eda0de05e3de1dfc8de6c61c12f6dd435c4b">,
      #splice.entry<"/build/gawk-5.4.1/test/posix2008sub.awk" file 644 mtime 1782131302 "bcd130109e657b2e72a29799814ac23031242a2be9ed504837653d9fab5675c6">,
      #splice.entry<"/build/gawk-5.4.1/test/posix2008sub.ok" file 644 mtime 1782131302 "6571d217e7edf2502b0a7e3c85c43d0bc170fafcaa8c76834764a4d4c7ab81d7">,
      #splice.entry<"/build/gawk-5.4.1/test/posix_compare.awk" file 644 mtime 1782131302 "554f4c37786a1529ce2b4bcaf2721f313f621a6fc3bdf36b730f499b17f979a9">,
      #splice.entry<"/build/gawk-5.4.1/test/posix_compare.ok" file 644 mtime 1782131302 "eed214df1831ed5208491c58d6ded34791ad05b32357010e1190019cf55ab2e0">,
      #splice.entry<"/build/gawk-5.4.1/test/poundbang.awk" file 644 mtime 1782131302 "5df4fbac2aefaae92a92f651754a8b780b3ca3ece8b7c10d3ea237ae98d926d9">,
      #splice.entry<"/build/gawk-5.4.1/test/prdupval.awk" file 644 mtime 1782131302 "160696f280ff576aed0a02334287096fa89f63ed014e0c3e12f76c2b640ebb1c">,
      #splice.entry<"/build/gawk-5.4.1/test/prdupval.in" file 644 mtime 1782131302 "2c8b08da5ce60398e1f19af0e5dccc744df274b826abe585eaba68c525434806">,
      #splice.entry<"/build/gawk-5.4.1/test/prdupval.ok" file 644 mtime 1782131302 "0da6bba2bcbe147926d31670b89700b9b87207d12fe0457fc0b06a3f0c18c169">,
      #splice.entry<"/build/gawk-5.4.1/test/prec.awk" file 644 mtime 1782131302 "e3900335523b271d422d0e3c61f29cd1fe91823c6ac8533b5eb99bc4ba78bd9e">,
      #splice.entry<"/build/gawk-5.4.1/test/prec.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/printf-corners-mpfr.ok" file 644 mtime 1782131302 "e8636a26faa334f0ef2b44ffad30526067533a7b78517438bc932322c967f06f">,
      #splice.entry<"/build/gawk-5.4.1/test/printf-corners.awk" file 644 mtime 1782131302 "951f1df096552958af62514e6905f56ac33d1daefc7ae19a9aab3ca1a05236ee">,
      #splice.entry<"/build/gawk-5.4.1/test/printf-corners.ok" file 644 mtime 1782131302 "e8636a26faa334f0ef2b44ffad30526067533a7b78517438bc932322c967f06f">,
      #splice.entry<"/build/gawk-5.4.1/test/printf0.awk" file 644 mtime 1782131302 "f140001d235ac3e8e851972357af6fca1d9efe8ec58e62715fe8cbb0d3492c7f">,
      #splice.entry<"/build/gawk-5.4.1/test/printf0.ok" file 644 mtime 1782131302 "7058299627365fc7a3dd7840fd3d56f29306cd30c0f2c13cb500fe79617290ff">,
      #splice.entry<"/build/gawk-5.4.1/test/printf1.awk" file 644 mtime 1782131302 "23a7ff180f8ae38b5bc35cf09bdf57c423915d1b34c1ae654c3a83b2717dca89">,
      #splice.entry<"/build/gawk-5.4.1/test/printf1.ok" file 644 mtime 1782131302 "eb0a7809a932b6ecd69382b778ff2d73c4cde3161ffd7912b564537d044a01a6">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad1.awk" file 644 mtime 1782131302 "1e98fcca4e12d242ac8c8e3a6ac5ebc7c3ae7891d55cc0734b269af7d206d379">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad1.ok" file 644 mtime 1782131302 "42bc425befcd6faa7c2e9f584f181796150330dc97eba14e51573e0b5098fff1">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad2.awk" file 644 mtime 1782131302 "6a69b1568391fa66253ff3b9e68607ba417ebb6d5b4ea6ab751888e726f22fc1">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad2.in" file 644 mtime 1782131302 "c1ebcf03b20d449cd3be1c25ff27850368332ccfe8f6d7cbc4eec89f0aa22f30">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad2.ok" file 644 mtime 1782131302 "c1dffa91043eb6942f0f92f0428f05104254c50142d09f4a3de943213cb2f45a">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad3.awk" file 644 mtime 1782131302 "eb142daf50dfeef3d4bbb8c082c45b7972b72e4c1a94c717b76f4f2235196d50">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad3.ok" file 644 mtime 1782131302 "b51eb834a583fd593ee0b1a143e072ed3c10521ce19ffafdb43d27afcae3fbf4">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad4.awk" file 644 mtime 1782131302 "534cfc06b9febd47836fff3b6be566fdf90c30207427dab7338d8fbee60f8d94">,
      #splice.entry<"/build/gawk-5.4.1/test/printfbad4.ok" file 644 mtime 1782131302 "e9ccd56b6cdb8afb51b1e2db1dedf8acafa8e6783cf378268cf8ecf3929fd668">,
      #splice.entry<"/build/gawk-5.4.1/test/printfchar.awk" file 644 mtime 1782131302 "310c0ce0f9eb96181bb251300e183460c30a4f112fda0a96b12f1b19ba63e9b0">,
      #splice.entry<"/build/gawk-5.4.1/test/printfchar.ok" file 644 mtime 1782131302 "06e9d52c1720fca412803e3b07c4b228ff113e303f4c7ab94665319d832bbfb7">,
      #splice.entry<"/build/gawk-5.4.1/test/printfloat.awk" file 644 mtime 1782131302 "91541b8122801d6b1daa44e52c2f623ba843de50d3684934886f6c0a33d9dddc">,
      #splice.entry<"/build/gawk-5.4.1/test/printhuge.awk" file 644 mtime 1782131302 "93f074125e20ce4efabae2768d16b377a0a52d3e23a6c6cb5dada48d7274603e">,
      #splice.entry<"/build/gawk-5.4.1/test/printhuge.ok" file 644 mtime 1782131302 "e4688624e5f1ad0629505e6768e3bb36244f2f3e33e751215afa820334a76ed3">,
      #splice.entry<"/build/gawk-5.4.1/test/printlang.awk" file 644 mtime 1782131302 "092a87f9c978620a319b3c7032e367ddc0db8506e8fd37c487a866d9b864f745">,
      #splice.entry<"/build/gawk-5.4.1/test/prmarscl.awk" file 644 mtime 1782131302 "509fc52698ecf59cb7b7417378e972743b6f001abdc50bc9b5d680641d8b354d">,
      #splice.entry<"/build/gawk-5.4.1/test/prmarscl.ok" file 644 mtime 1782131302 "84661477ccfb68a2bbbb90b17307156ec6c2ab5cea6bfa682f21b19f1a323e4b">,
      #splice.entry<"/build/gawk-5.4.1/test/prmreuse.awk" file 644 mtime 1782131302 "e32523d7da2e97e150cce082f06ab96e5253dbcd68756d5af72b97ec086e0ee6">,
      #splice.entry<"/build/gawk-5.4.1/test/prmreuse.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/procinfs.awk" file 644 mtime 1782131302 "b3be202f56b2aa37453b5d92f73205b737f78bcbad4e391d7e047a282c60de59">,
      #splice.entry<"/build/gawk-5.4.1/test/procinfs.ok" file 644 mtime 1782131302 "b067e653a8049b3f2b66e8330a8a615c09500d53745d7e53ee89dabeaba8d6b4">,
      #splice.entry<"/build/gawk-5.4.1/test/profile0.awk" file 644 mtime 1782131302 "e8b15aee478dd982b0a685320de80daf35e505bb68f92b0487e92bbfdcdd8653">,
      #splice.entry<"/build/gawk-5.4.1/test/profile0.in" file 644 mtime 1782131302 "9060554863a62b9db5f726216876654e561896071d2e6480f2048b70e0fdadb9">,
      #splice.entry<"/build/gawk-5.4.1/test/profile0.ok" file 644 mtime 1782131302 "419667df91b4aa4d9ef6164e40c21ee4facbbc457a508412c25bc9c34fc647e1">,
      #splice.entry<"/build/gawk-5.4.1/test/profile10.awk" file 644 mtime 1782131302 "9e5f142cfe4d11b147ab403335ac266850d09f6555e22b6c519f645dca82bebc">,
      #splice.entry<"/build/gawk-5.4.1/test/profile10.ok" file 644 mtime 1782131302 "7326e07cd118c31f0f9f4a04248af732b39da6f7335c89cdefc3c174e7731cbd">,
      #splice.entry<"/build/gawk-5.4.1/test/profile11.awk" file 644 mtime 1782131302 "2b13de56aa2fe71e161a753f4917217f58fd70e8159a9bb37a6cf5eff79d0e23">,
      #splice.entry<"/build/gawk-5.4.1/test/profile11.ok" file 644 mtime 1782131302 "1ffae8a99821c63bf420090b82d12cad0904b67b0dea831c41705c05586ebb9f">,
      #splice.entry<"/build/gawk-5.4.1/test/profile12.awk" file 644 mtime 1782131302 "f993e6b5bd9c97870c4ee1e943cb67bbbbf7f6e12e1e45ad97dc6122d83a7e66">,
      #splice.entry<"/build/gawk-5.4.1/test/profile12.in" file 644 mtime 1782131302 "d57532e60e6f606f4f7529d722c7e9ea16e1763620b5e81fbb6a562a1effbfc6">,
      #splice.entry<"/build/gawk-5.4.1/test/profile12.ok" file 644 mtime 1782131302 "ec1f9796b88620f692b2dbdfc17c114a1c06d78d527471486d49787f89a3cff1">,
      #splice.entry<"/build/gawk-5.4.1/test/profile13.awk" file 644 mtime 1782131302 "e130d63b0bb1de30336aa5121a9d62ecc27a416b55516effeb65be264f395b1c">,
      #splice.entry<"/build/gawk-5.4.1/test/profile13.ok" file 644 mtime 1782131302 "610abd70b211e2a4a7981cd9af18bd8dae81bbba0623224b9e8569d6dd5e2fc7">,
      #splice.entry<"/build/gawk-5.4.1/test/profile14.awk" file 644 mtime 1782131302 "de92912ee1a337c597995ddfbd2cdb1e4126c4370cf1d63c33fb98763a65f1e8">,
      #splice.entry<"/build/gawk-5.4.1/test/profile14.ok" file 644 mtime 1782131302 "71118634ae4d2be41f9d6d45bf99f39888fcb0ddf0c8f3b92dfe8ac54d3ce686">,
      #splice.entry<"/build/gawk-5.4.1/test/profile15.awk" file 644 mtime 1782131302 "c621da4d9c195448329c270cf9796b0056729ff6d0340814a621d0adac041d89">,
      #splice.entry<"/build/gawk-5.4.1/test/profile15.ok" file 644 mtime 1782131302 "4e1adc98c16f6487adac3000b07fb1c3fc3f4651974df8625e9c63dd11210019">,
      #splice.entry<"/build/gawk-5.4.1/test/profile16.awk" file 644 mtime 1782131302 "04cb987dbe4ebf6eecfb147c5a6758e542a6c1793f95e440c81f3e2c8948d509">,
      #splice.entry<"/build/gawk-5.4.1/test/profile16.ok" file 644 mtime 1782131302 "04cb987dbe4ebf6eecfb147c5a6758e542a6c1793f95e440c81f3e2c8948d509">,
      #splice.entry<"/build/gawk-5.4.1/test/profile17.awk" file 644 mtime 1782131302 "b0cb0d05113ed781e9ad341ac91aba789abfdae87e188cf79dc14f05618fa7e2">,
      #splice.entry<"/build/gawk-5.4.1/test/profile17.ok" file 644 mtime 1782131302 "6c3c728bdbe46c8739e0bfbcc5150ec0131ac352bdf1f0a7763f714a625bb735">,
      #splice.entry<"/build/gawk-5.4.1/test/profile2.ok" file 644 mtime 1782131302 "161bb6edf9c9ee59909e1eea5155338c36f68cb383aeafc2fe0d950371453191">,
      #splice.entry<"/build/gawk-5.4.1/test/profile3.awk" file 644 mtime 1782131302 "a31eb1b048b5cb7598e0b9132d59be08874d70089203191a5bea386c6cf51423">,
      #splice.entry<"/build/gawk-5.4.1/test/profile3.ok" file 644 mtime 1782131302 "0171de23ee5db2d8a3d2b003bd701d7ea530e29925e38b58f7e21abac792844a">,
      #splice.entry<"/build/gawk-5.4.1/test/profile4.awk" file 644 mtime 1782131302 "230931bd08f8558bfb9533f13365eb12562eb482e1e3cb65f324c4a2dedfa2db">,
      #splice.entry<"/build/gawk-5.4.1/test/profile4.ok" file 644 mtime 1782131302 "230931bd08f8558bfb9533f13365eb12562eb482e1e3cb65f324c4a2dedfa2db">,
      #splice.entry<"/build/gawk-5.4.1/test/profile5.awk" file 644 mtime 1782131302 "f165ecda9f19c7f3156712134db288260e856522e8339f9a35ecae07f034f676">,
      #splice.entry<"/build/gawk-5.4.1/test/profile5.ok" file 644 mtime 1782131302 "70e86cbec29f5a360e538f8892f046fe2ba6cec0f89929c818b3eb97a3fb98c6">,
      #splice.entry<"/build/gawk-5.4.1/test/profile6.awk" file 644 mtime 1782131302 "e6a020b05a9c915f829479619965b7c8670c978616b054ed643eef259d544da5">,
      #splice.entry<"/build/gawk-5.4.1/test/profile6.ok" file 644 mtime 1782131302 "e5fb23df7b4ef8638401a56781646452d34b169ac53c2bada98a9a3df9e799a4">,
      #splice.entry<"/build/gawk-5.4.1/test/profile7.awk" file 644 mtime 1782131302 "b6f4653a3b3290f55ba7f57a9b06a055f6a84ae6c8092209bc2ea0127e3b9f8c">,
      #splice.entry<"/build/gawk-5.4.1/test/profile7.ok" file 644 mtime 1782131302 "91ef947faa07079c8dcee06efef4d692c3da625e8e7c4a00fe824591be5b5482">,
      #splice.entry<"/build/gawk-5.4.1/test/profile8.awk" file 644 mtime 1782131302 "efc27c5b990e79b4e01eaa8bd0bd4bcb85efa6d60bfd51ed27cb99929f764eae">,
      #splice.entry<"/build/gawk-5.4.1/test/profile8.ok" file 644 mtime 1782131302 "48be7432b50e67c9d067e4f91a68ed6ec45404dc81ef24dbaaadc75f4790237c">,
      #splice.entry<"/build/gawk-5.4.1/test/profile9.awk" file 644 mtime 1782131302 "6ca80b82dd5accf3af7a437995747697f21cb927f9ba59848fd4648b4421dab1">,
      #splice.entry<"/build/gawk-5.4.1/test/profile9.ok" file 644 mtime 1782131302 "6eaf50f268cdc42b8e9a5362e0db54519e60a8b22970996127c1dd5a238bed14">,
      #splice.entry<"/build/gawk-5.4.1/test/prt1eval.awk" file 644 mtime 1782131302 "6d2242fd34acf9096221aefa8d8ea0ed375fa2bb8c3d1bd6f03f6bc1bed28f4a">,
      #splice.entry<"/build/gawk-5.4.1/test/prt1eval.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/prtoeval.awk" file 644 mtime 1782131302 "bc31805bd1b22752eacf266e60dfdec899360dddcf5dfbbc1cf70c93384f291d">,
      #splice.entry<"/build/gawk-5.4.1/test/prtoeval.ok" file 644 mtime 1782131302 "a2dff4df763f572a9c684b94425c6340c86716c1e1bb95d814d5578973db0e5f">,
      #splice.entry<"/build/gawk-5.4.1/test/pty1.awk" file 644 mtime 1782131302 "0bfc36d020ba5e52c5ea97661c6060562843af23578f49ce857f3037eea92c39">,
      #splice.entry<"/build/gawk-5.4.1/test/pty1.ok" file 644 mtime 1782131302 "6618b0ca3aa54b2143d92c05b46229459f1732697997f44ee1d74618db44a104">,
      #splice.entry<"/build/gawk-5.4.1/test/pty2.awk" file 644 mtime 1782131302 "64b53ccc1ccba5a7fed4bd0f7d9dfe0288de5a3daba63892005757994e1a735f">,
      #splice.entry<"/build/gawk-5.4.1/test/pty2.ok" file 644 mtime 1782131302 "5b805503cf8afac60d792be2285608fcca8b4bfd1dd5b377a6a905e6a81c6d7d">,
      #splice.entry<"/build/gawk-5.4.1/test/rand-mpfr.ok" file 644 mtime 1782131302 "56b4dd496df165453c98fc39f542f6967ddaf50d38e143f6faaf8e2be7a041d1">,
      #splice.entry<"/build/gawk-5.4.1/test/rand.awk" file 644 mtime 1782131302 "82d564055d7d545bdaee89624b158c7016b7dcde3d0748d9ae4c00b010661a39">,
      #splice.entry<"/build/gawk-5.4.1/test/rand.ok" file 644 mtime 1782131302 "a7f5dd9c9bc3cacd7b002b768507f244dd9dde1077cd15ce52bea07523ab22a3">,
      #splice.entry<"/build/gawk-5.4.1/test/randtest.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/randtest.sh" file 755 mtime 1783249447 "07641216bf4e1c85e0b76cdf3b6e0a8c945dbdc3e896ed1ee8c460443e0c196f">,
      #splice.entry<"/build/gawk-5.4.1/test/range1.awk" file 644 mtime 1782131302 "0d4325ee11349e968c7e14eb65f0dd4e48ab8042e40dc66eeecb862942da213a">,
      #splice.entry<"/build/gawk-5.4.1/test/range1.in" file 644 mtime 1782131302 "4b68b18d7029aadceed4a7aedd18fe7672d51cdfac3176d4cdb4d39552696fe8">,
      #splice.entry<"/build/gawk-5.4.1/test/range1.ok" file 644 mtime 1782131302 "aec070645fe53ee3b3763059376134f058cc337247c978add178b6ccdfb0019f">,
      #splice.entry<"/build/gawk-5.4.1/test/range2.awk" file 644 mtime 1782131302 "ccfdd026a8edd97743ced3638d4344851e89efa7ce0ae9c602c8649313bb8488">,
      #splice.entry<"/build/gawk-5.4.1/test/range2.ok" file 644 mtime 1782131302 "9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa">,
      #splice.entry<"/build/gawk-5.4.1/test/re_test.awk" file 644 mtime 1782131302 "974b36ff58abeebdb319d65b670539aa779f0713cf877c544b7f8ad6f5d46b1d">,
      #splice.entry<"/build/gawk-5.4.1/test/re_test.ok" file 644 mtime 1782131302 "a249578809a9e66093aee263a430126447114871eb828e68860a44d697a73ddd">,
      #splice.entry<"/build/gawk-5.4.1/test/readall.ok" file 644 mtime 1782131302 "d395e5d175731d2839015630d2167632b6c0bb17e8dd28d8d40fa3a1b31ca930">,
      #splice.entry<"/build/gawk-5.4.1/test/readall1.awk" file 644 mtime 1782131302 "f942c6abd25e3469cb6329ba044fd8137617072e35bc9e3d650f7859aafb43b6">,
      #splice.entry<"/build/gawk-5.4.1/test/readall2.awk" file 644 mtime 1782131302 "30fbf831d37694bbdd7f499ad976a4041bceb14af2b4d8863ad80b0f74609666">,
      #splice.entry<"/build/gawk-5.4.1/test/readbuf.awk" file 644 mtime 1782131302 "abf25cfdb4f82fe57917bffae1f9effdf3bc41830524d2ecb87773b62df5ae90">,
      #splice.entry<"/build/gawk-5.4.1/test/readbuf.ok" file 644 mtime 1782131302 "49fa8087478ac4b6c45fc0d64d1a3b3bf612a4e897d555cf53f703714a7b844f">,
      #splice.entry<"/build/gawk-5.4.1/test/readdir.awk" file 644 mtime 1782131302 "f54e2c7fb4218933caab0f9eed2f1d88d8f74b7323a3022bd9f823dec9524981">,
      #splice.entry<"/build/gawk-5.4.1/test/readdir0.awk" file 644 mtime 1782131302 "2be85fe6f49cd51f4f5e7f5e67942f8499ad55d4267c2ce1d660a47cc083cb70">,
      #splice.entry<"/build/gawk-5.4.1/test/readdir_retest.awk" file 644 mtime 1782131302 "9457d908356d3bfb36c68184a52da1f013af315f64ec95d34cd1038a38085d51">,
      #splice.entry<"/build/gawk-5.4.1/test/readfile2.awk" file 644 mtime 1782131302 "620fa3f706e5bbdb8b9f18956ef45711c9a137ca93d6d2e42be6c117771e673d">,
      #splice.entry<"/build/gawk-5.4.1/test/readfile2.ok" file 644 mtime 1782131302 "22d6a68b9cedaf67552e05d4f52ff03f5d7e4d15c59d6b2ca1947c8b3b643b24">,
      #splice.entry<"/build/gawk-5.4.1/test/rebrackloc.awk" file 644 mtime 1782131302 "ad1930b7bcfc44942fe9902459f7000393fe7f949b444289d3def8ba59d55d29">,
      #splice.entry<"/build/gawk-5.4.1/test/rebrackloc.in" file 644 mtime 1782131302 "5c1ea6f2876fb9424cfb5b87e07d96e62b80237e1c27c9a75b0c50b6327caa1b">,
      #splice.entry<"/build/gawk-5.4.1/test/rebrackloc.ok" file 644 mtime 1782131302 "769abc2b4bcaf0ee6c4b96a2ad505a12d3e098ecae6a99003c8355eefc9b7411">,
      #splice.entry<"/build/gawk-5.4.1/test/rebt8b1.awk" file 644 mtime 1782131302 "84f6179627490e646753f6a9b9f53ec8c857be45b3207b0e19b22e8f74281cde">,
      #splice.entry<"/build/gawk-5.4.1/test/rebt8b1.ok" file 644 mtime 1782131302 "4d056b3781048d36fcf6690949779307b474a921813f883942e172a5bb079201">,
      #splice.entry<"/build/gawk-5.4.1/test/rebt8b2.awk" file 644 mtime 1782131302 "ab7325f387b6b84f99106c578e352559bef95c3dfa74ecec46d3fcd631703bda">,
      #splice.entry<"/build/gawk-5.4.1/test/rebt8b2.ok" file 644 mtime 1782131302 "be732f599fa1d5b037391e5941508b0a7c53290f7e5f808a3b5a01a11ba190d3">,
      #splice.entry<"/build/gawk-5.4.1/test/rebuf.awk" file 644 mtime 1782131302 "dc468fd5e417510af581a3ec8a02451c38ca96700358cdb18163f96ffb535d5b">,
      #splice.entry<"/build/gawk-5.4.1/test/rebuf.in" file 644 mtime 1782131302 "cfde5f9a60abe33024d9856782dd92e7a3b04eef50144408b96885e441d35e62">,
      #splice.entry<"/build/gawk-5.4.1/test/rebuf.ok" file 644 mtime 1782131302 "1fc4995083a3bc976ef5f3f9f09eeba1c0f201a69f11346787ee4bee7b2d9977">,
      #splice.entry<"/build/gawk-5.4.1/test/rebuild.awk" file 644 mtime 1782131302 "6c857d461d63b70a6f1c22ef94cdfe051bd61c3f7c9d0e47eafc796ff88ed348">,
      #splice.entry<"/build/gawk-5.4.1/test/rebuild.in" file 644 mtime 1782131302 "b42bdd8cf0ec3b85ee92faa07a9bac8ba906cbc8d042d4f5d643b4e17b536bc9">,
      #splice.entry<"/build/gawk-5.4.1/test/rebuild.ok" file 644 mtime 1782131302 "44b3dfa6c4d7aaaac74ad4cb613e3eacd3826f9784b70247fc8a35360f0fda4f">,
      #splice.entry<"/build/gawk-5.4.1/test/redfilnm.awk" file 644 mtime 1782131302 "c4eb6bb3fa51ae7efe8120499866232da35a884c3d78058853e465a39971a90f">,
      #splice.entry<"/build/gawk-5.4.1/test/redfilnm.in" file 644 mtime 1782131302 "853ff93762a06ddbf722c4ebe9ddd66d8f63ddaea97f521c3ecc20da7c976020">,
      #splice.entry<"/build/gawk-5.4.1/test/redfilnm.ok" file 644 mtime 1782131302 "e7d3f9c86bf1ea06e654eb46fea712628b9465ffa63d190aac1e2e4fd7742eed">,
      #splice.entry<"/build/gawk-5.4.1/test/reg" dir 755 mtime 1783240706>,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete" dir 755 mtime 1782131302>,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete/exp.awk" file 644 mtime 1782131302 "cc5807b13757e34a786cfc02c0c4648bc35a216c1ff673936a1389d53701b542">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete/exp.good" file 644 mtime 1782131302 "fcb6fe9f2527a4f1930dff202ee98f31201b11b90a90170a8cccbd4e71324f7e">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete/exp.in" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete/log.awk" file 644 mtime 1782131302 "3415c41c30c12d47a43128df7b54eaf1ef60463ac0b254692421e79eed05348d">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete/log.good" file 644 mtime 1782131302 "29cbfb09768020bc6c0cd45ad2ac5d7ef7d8a9984480c11c5069d3c786393b57">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/Obsolete/log.in" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/exp-eq.awk" file 644 mtime 1782131302 "30f5eb97f0e24a2a3c4e380d1a1486eb8c671ce1ea64b1b6b538d16de7c49ccf">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/exp-eq.good" file 644 mtime 1782131302 "d25f723defcb74b828cba023c3d31f487f01d1fb1fd4501e5fe243f4e0bca972">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/exp-eq.in" file 644 mtime 1782131302 "14c5e74c4b96ccef41cd94db73a9ec3348038ac094feca4fd897cecffa07cdae">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/func.awk" file 644 mtime 1782131302 "f7528e36066e7272555679254053e816d7967e67baa39bea71445b2d71d5f4b6">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/func.good" file 644 mtime 1782131302 "e26b9dbd0c4cc0b4f34c8ad0717d2ba287c6e9deb9057c58dd8263af01d59172">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/func.in" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/func2.awk" file 644 mtime 1782131302 "bd1238ef40d592569de54c4ce5b340213f2daf16faf43a7271ccf44857c32b3e">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/func2.good" file 644 mtime 1782131302 "c736897ae44dcefa7eb6251575ddc2404d599a84c5658c6a486b36f627542a3a">,
      #splice.entry<"/build/gawk-5.4.1/test/reg/func2.in" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/regeq.awk" file 644 mtime 1782131302 "9ee7ae85b0f17cb153b361649e85611dd2bf187e910c942ac83b0471b61c1582">,
      #splice.entry<"/build/gawk-5.4.1/test/regeq.in" file 644 mtime 1782131302 "776a68b09a467b57a53ef8f1503701ea8f2f8b5a2b4694539a6db3adff6ac2e4">,
      #splice.entry<"/build/gawk-5.4.1/test/regeq.ok" file 644 mtime 1782131302 "2b4debfa02d0b86cd102682784dc522991ecb4a5f61f14b9cf435a1ab45e4a3a">,
      #splice.entry<"/build/gawk-5.4.1/test/regex3minus.awk" file 644 mtime 1782131302 "82ab22c67e80dc11527fca6e65330e1c106c11fe4c5b82efe76312d4c6a6fddf">,
      #splice.entry<"/build/gawk-5.4.1/test/regex3minus.ok" file 644 mtime 1782131302 "7712e63cb01eab463afb3762b911e68d449f313ac9842c6a39b993140735a9c7">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbad.awk" file 644 mtime 1782131302 "9a8fafde386e84644f3509fb79a3be222a448ef294b3114e6571b422ed32311f">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbad.ok" file 644 mtime 1782131302 "7f074b387c61f79236c4064c9a3f75a15d85596457ab4c428e1cfae00f9050cd">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack.awk" file 644 mtime 1782131302 "c69d0dadacd7f46b57fbe8d68df7a542937b243483b4f89fdb61d6c6111211fe">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack.in" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack2.awk" file 644 mtime 1782131302 "1d88560c7aa6b013f8105bed3f9634572ef6b7e9f939cdf3f6be92e4833c9890">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack2.in" file 644 mtime 1782131302 "406a036df08d3db196d6bd311b42838fc7efbde4f136c93d8e3eeba84602eae0">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack2.ok" file 644 mtime 1782131302 "fc3eb9bce194fb349df7f7d4f601e9bf230bda4445039b0685e77ec31f50fa49">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack3.awk" file 644 mtime 1783249447 "91aa8d482be094cb851e7a143e6f52f3111d337753a31f2ab62d5052ec045da5">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpbrack3.ok" file 644 mtime 1783249447 "40d3f08df962ecc666f7df69a9b3aaab9a615a9b52807f958c0f734d2e7f33f9">,
      #splice.entry<"/build/gawk-5.4.1/test/regexprange.awk" file 644 mtime 1782131302 "a3dcfe4b3b9ab269a52f432e85116a4b5c478059f46c7a6c60d8f9755b808064">,
      #splice.entry<"/build/gawk-5.4.1/test/regexprange.ok" file 644 mtime 1782131302 "a711783ddf66dc9f13d401146754ef7835369d21b73f5d5376a48709ae12aa42">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpuparrow.awk" file 644 mtime 1782131302 "70061081d3802f5a8791f743b2f25f5b4ede042be0a5af57ba6e2515228a6a25">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpuparrow.in" file 644 mtime 1782131302 "c96d722217495819e4396dbc451dfbae368023197600c80723827ab3ba41454f">,
      #splice.entry<"/build/gawk-5.4.1/test/regexpuparrow.ok" file 644 mtime 1782131302 "30f97acce19a6db3ba24aec8249febdd55ca8e8658d07d6f92222249b504a5e3">,
      #splice.entry<"/build/gawk-5.4.1/test/regexsub.awk" file 644 mtime 1782131302 "a855fbef05b5a0e70ccc0fe55d37057738ef07b3569ed200cd165c0183f9285f">,
      #splice.entry<"/build/gawk-5.4.1/test/regexsub.ok" file 644 mtime 1782131302 "01eb8f3f772432b2ee8fd240974f92a4c4f8fd04cb48011e8f9029ff9a0ccb86">,
      #splice.entry<"/build/gawk-5.4.1/test/reginttrad.awk" file 644 mtime 1782131302 "3f92d13a5f50ee2ba4a7021228fed1ab4154014c0c09297ecf8fa561f0f10baa">,
      #splice.entry<"/build/gawk-5.4.1/test/reginttrad.ok" file 644 mtime 1782131302 "b258406cd1af4f2834d9f1efd055244ee19c68ae0b17447f137b9a89df8e9997">,
      #splice.entry<"/build/gawk-5.4.1/test/regnul1.awk" file 644 mtime 1782131302 "7e6e60f2e602746aded928e671959d55a802561abb117c7e9f9677a3436c9ab1">,
      #splice.entry<"/build/gawk-5.4.1/test/regnul1.ok" file 644 mtime 1782131302 "c7ffab7f0d7d69de6cf93ade107d1fc640492b658f7ef2e8f251fd0eefff6a48">,
      #splice.entry<"/build/gawk-5.4.1/test/regnul2.awk" file 644 mtime 1782131302 "a2ee92e0b68e5aa52ca626a04de9570fde1a227b80c2abbe4a274b1f7a997c8d">,
      #splice.entry<"/build/gawk-5.4.1/test/regnul2.ok" file 644 mtime 1782131302 "861a724d26220e090fad2d3648d5a2e97c75a73731543ba181804819734a9737">,
      #splice.entry<"/build/gawk-5.4.1/test/regrange.awk" file 644 mtime 1782131302 "2a3cbb50140519fbf18d688cf25e5837d595fd757f6766dfdbd30731fbe078ee">,
      #splice.entry<"/build/gawk-5.4.1/test/regrange.ok" file 644 mtime 1782131302 "7ab10030410b5f7176a3a45ebea43bd158da3462d25810b2f7af679a8495797f">,
      #splice.entry<"/build/gawk-5.4.1/test/regtest.sh" file 755 mtime 1782131302 "1dd7e158f09a8b34724767ab2f2f7f435868fbd7c1b01c788682dfba04f38e71">,
      #splice.entry<"/build/gawk-5.4.1/test/regx8bit.awk" file 644 mtime 1782131302 "46b7c9436a1a3e115888552e5f2f7ce6b3fbefe9358494475677c348308d7c1f">,
      #splice.entry<"/build/gawk-5.4.1/test/regx8bit.ok" file 644 mtime 1782131302 "27f800b10e9fd8cfd67a0b32f5225eb7daab804754419cc1064de15b1fb47ef5">,
      #splice.entry<"/build/gawk-5.4.1/test/reindops.awk" file 644 mtime 1782131302 "f312366f3034455296ceb7b4167f84875a81e6e352ee10f47576acda1213d96f">,
      #splice.entry<"/build/gawk-5.4.1/test/reindops.in" file 644 mtime 1782131302 "c8cd83888962eca1a6f4f8c70715f90f910acaa0af6530a71fb6f1609f6db45a">,
      #splice.entry<"/build/gawk-5.4.1/test/reindops.ok" file 644 mtime 1782131302 "3235316e7293f78e0181b04ddc1ae16e3b6756c49d5d45ef1071e2f5a940f160">,
      #splice.entry<"/build/gawk-5.4.1/test/reint.awk" file 644 mtime 1782131302 "ac336b1e59276e604b0da6cbe7d537800b966f8c406c3d400c06657541a57b05">,
      #splice.entry<"/build/gawk-5.4.1/test/reint.in" file 644 mtime 1782131302 "0d8253d55440260a371ae5a7ba2c463a548328239c898b192fbfa61c282d499d">,
      #splice.entry<"/build/gawk-5.4.1/test/reint.ok" file 644 mtime 1782131302 "1a252402972f6057fa53cc172b52b9ffca698e18311facd0f3b06ecaaef79e17">,
      #splice.entry<"/build/gawk-5.4.1/test/reint2.awk" file 644 mtime 1782131302 "eee5d28708dcbffcf940b7f2732cb44d61605b58879a7b2b4327f665e7efa86c">,
      #splice.entry<"/build/gawk-5.4.1/test/reint2.in" file 644 mtime 1782131302 "1def07dbe06eeb097aafec8a40329937cd20c93a83634b8221ea2b41a894310c">,
      #splice.entry<"/build/gawk-5.4.1/test/reint2.ok" file 644 mtime 1782131302 "1def07dbe06eeb097aafec8a40329937cd20c93a83634b8221ea2b41a894310c">,
      #splice.entry<"/build/gawk-5.4.1/test/reparse.awk" file 644 mtime 1782131302 "acc6007206f396b7fad544b5f53058f37ffa3970966713e6dbc15172f72b923d">,
      #splice.entry<"/build/gawk-5.4.1/test/reparse.in" file 644 mtime 1782131302 "61c703aeb0efeedfdc802f8a75e9a9d8ce0b763fb096010a13ecee81593ffe3c">,
      #splice.entry<"/build/gawk-5.4.1/test/reparse.ok" file 644 mtime 1782131302 "63a198f1bca35c57a81abf36fb15b14ad7670c25dcbe85fb9ef2c2db65cf75dd">,
      #splice.entry<"/build/gawk-5.4.1/test/resplit.awk" file 644 mtime 1782131302 "3793f1c4bf30ab0f15e258be62f0162f20a034f8e7d8e2053a51610051462bdf">,
      #splice.entry<"/build/gawk-5.4.1/test/resplit.in" file 644 mtime 1782131302 "5cf014276bd80cba736ddaf883cc2eb504859683e315439765524a0b190aee3a">,
      #splice.entry<"/build/gawk-5.4.1/test/resplit.ok" file 644 mtime 1782131302 "0263829989b6fd954f72baaf2fc64bc2e2f01d692d4de72986ea808f6e99813f">,
      #splice.entry<"/build/gawk-5.4.1/test/revout.awk" file 644 mtime 1782131302 "fc70b93c6a3de55e4028eb89c172edfbe432b850a12a7b2cf1820b828272a446">,
      #splice.entry<"/build/gawk-5.4.1/test/revout.ok" file 644 mtime 1782131302 "6824f1b3d5edcacf75240c22d35bbe71c2ce93169a89af5b5856655c6d0cac4e">,
      #splice.entry<"/build/gawk-5.4.1/test/revtwoway.awk" file 644 mtime 1782131302 "96dc3b0c00f581acc05ad63b389cbdeac5b9d3677de628e2250ccb8ee8eae303">,
      #splice.entry<"/build/gawk-5.4.1/test/revtwoway.ok" file 644 mtime 1782131302 "28e8ecb9e89a49fea457a208a0ba7ac2b50f4f523157b1b6f4a6b8496f2c37eb">,
      #splice.entry<"/build/gawk-5.4.1/test/rri1.awk" file 644 mtime 1782131302 "38f6dbe13a43f877bc65f97835015370a827903bb11d368ba294697d62e53793">,
      #splice.entry<"/build/gawk-5.4.1/test/rri1.in" file 644 mtime 1782131302 "f1def8bcda5b17a1b39174859f18e8a565e158e01bfb82d7cadac3d276b29428">,
      #splice.entry<"/build/gawk-5.4.1/test/rri1.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/rs.awk" file 644 mtime 1782131302 "fda0d106d084495add2211a0b2185a3771910bae928e2d2c90ec3ae80de3964f">,
      #splice.entry<"/build/gawk-5.4.1/test/rs.in" file 644 mtime 1782131302 "268637b9f39bce3a5c82365efcb518030783ef9eac38e6ae0758f3b536064a15">,
      #splice.entry<"/build/gawk-5.4.1/test/rs.ok" file 644 mtime 1782131302 "9606a733bb8c4698ac73883ab81cfaa83fda02a9f06f9a0038e5a270bdec3916">,
      #splice.entry<"/build/gawk-5.4.1/test/rscompat.awk" file 644 mtime 1782131302 "bb71ad991e77426c8e58ec61d20e89402d0f43e7f7360dfa113d7634815e06bf">,
      #splice.entry<"/build/gawk-5.4.1/test/rscompat.in" file 644 mtime 1782131302 "646c807b8e19a74ceee8410eec9cea67a84b3d91468fbd4ffc3af824957f5865">,
      #splice.entry<"/build/gawk-5.4.1/test/rscompat.ok" file 644 mtime 1782131302 "6f663f991e151ea36a44b9fec93e82ef4303612b1db6801f8733e391154d3e77">,
      #splice.entry<"/build/gawk-5.4.1/test/rsgetline.awk" file 644 mtime 1782131302 "babf2a3a0c7470c570fda2cd0f623da99a4be2cd5ff3dfcb04168eea54da5e68">,
      #splice.entry<"/build/gawk-5.4.1/test/rsgetline.in" file 644 mtime 1782131302 "b59e0e2bea083927aa2636fe26d63578bc2a87fdc8262231a3cb6d419293abd6">,
      #splice.entry<"/build/gawk-5.4.1/test/rsgetline.ok" file 644 mtime 1782131302 "1e5355673a10cd73f831d20999da597b1002d62d8a6cc1fe118c2fcdcd5a9ba1">,
      #splice.entry<"/build/gawk-5.4.1/test/rsglstdin.ok" file 644 mtime 1782131302 "1e5355673a10cd73f831d20999da597b1002d62d8a6cc1fe118c2fcdcd5a9ba1">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnul1nl.awk" file 644 mtime 1782131302 "f9aee5397853861709076e50ead50f6cf73ede34c0c8f94814362aeed041216a">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnul1nl.in" file 644 mtime 1782131302 "af1da5fa1644c15b261693575dc7996d1497512d586f3e14169dcd43c8ef0cd0">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnul1nl.ok" file 644 mtime 1782131302 "79e48afc760dcd7e24ecba6325293bd004ffdbbafe3392077e762940e0dc83fb">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnulbig.ok" file 644 mtime 1782131302 "15c0c6ba5feba0e74c30a2979025e0d2b576087cc6813c38a019a5c095660b2d">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnulbig2.ok" file 644 mtime 1782131302 "53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnullre.awk" file 644 mtime 1782131302 "fab5f16a42df7d9fdd1474b44dfdf3bbd628e539fe8ddca52eef9bdc767ffbe4">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnullre.in" file 644 mtime 1782131302 "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnullre.ok" file 644 mtime 1782131302 "65be8b13c1d2c2528d10ff80a4247b5b8293b31e484b89c2a6e0a33f183eec56">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnulw.awk" file 644 mtime 1782131302 "da1bcdfb2ae253856a83742368868d375e1915986bd7df42246096c79b59b415">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnulw.in" file 644 mtime 1782131302 "58fa314cf0dd555a857a7e93d8ca81bde58e7117c33f24f0470ab5bd1910166f">,
      #splice.entry<"/build/gawk-5.4.1/test/rsnulw.ok" file 644 mtime 1782131302 "3d5544a4358623a1b343aeb98c6d0590d5adfeb877b67b19a92d26e78e91985a">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart1.awk" file 644 mtime 1782131302 "70339e508b4aea5ff689debad26e6e4d5c2cb839d789b909c7c429aa3936790d">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart1.in" file 644 mtime 1782131302 "04631fa8cc3f77c6213ccc2c6e6acfcc01f17cf2c24ab6f12db88e19fd027ab7">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart1.ok" file 644 mtime 1782131302 "53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart2.awk" file 644 mtime 1782131302 "52bec55b4c68a6f45d037d9d0eaf91b8036aea085bf22f77e67b45e8930eb197">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart2.in" file 644 mtime 1782131302 "04631fa8cc3f77c6213ccc2c6e6acfcc01f17cf2c24ab6f12db88e19fd027ab7">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart2.ok" file 644 mtime 1782131302 "53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3">,
      #splice.entry<"/build/gawk-5.4.1/test/rsstart3.ok" file 644 mtime 1782131302 "53c234e5e8472b6ac51c1ae1cab3fe06fad053beb8ebfd8977b010655bfdd3c3">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest1.awk" file 644 mtime 1782131302 "4cfec938f9f01bf93ca399640a1af8657da17783ff3155e19f321a6e49a9a371">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest1.ok" file 644 mtime 1782131302 "9422b95a5e9325e99b4848aa8d911c6ddf0745dea8d00a54dc8915fa23de5d2f">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest2.awk" file 644 mtime 1782131302 "147b90420a8892b5178ab9ba6201d29c6450bca5510ac038236b314e9195a2f2">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest2.ok" file 644 mtime 1782131302 "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest3.awk" file 644 mtime 1782131302 "1ea5ad8b814093faedd1f95f4dcf5878de6d8c8b5d6912b3a1a71611b77e2c6f">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest3.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest4.awk" file 644 mtime 1782131302 "9c86cdc5b43b269c28ace7207e3e0b675c56a9d02d49b2b51979ccab2c4f19e3">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest4.ok" file 644 mtime 1782131302 "15315e7fa93bb1997d2da613dfd2413c28acbe06e1b9407025630d2d907fee07">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest5.awk" file 644 mtime 1782131302 "407a2c5fa00854228ef20ffb9dadf36f83124c2adeac43d45cf04f12ebdcb019">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest5.ok" file 644 mtime 1782131302 "59d81eef547417230c13841115b42613bdde5ff9e54be59c2664c924f123629b">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest6.awk" file 644 mtime 1782131302 "1d541415036bcff335b07550e3de41e70b81381c655e96c7f5b7918f8ae65d39">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest6.in" file 644 mtime 1782131302 "e12e115acf4552b2568b55e93cbd39394c4ef81c82447fafc997882a02d23677">,
      #splice.entry<"/build/gawk-5.4.1/test/rstest6.ok" file 644 mtime 1782131302 "7b7632005be0f36c5d1663a6c5ec4d13315589d65e1ef8687fb4b9866f9bc4b0">,
      #splice.entry<"/build/gawk-5.4.1/test/rswhite.awk" file 644 mtime 1782131302 "09da3020b36aeb55828e26a79819f8201ba27c35dfa34fa4a4a685582e74c5b6">,
      #splice.entry<"/build/gawk-5.4.1/test/rswhite.in" file 644 mtime 1782131302 "d38e7c5460cbb65b23af00dd79ec36d2c9f1c78cedb745ea2782fdcb605e2b4c">,
      #splice.entry<"/build/gawk-5.4.1/test/rswhite.ok" file 644 mtime 1782131302 "99231b7da4c2599e6aadd1d0a95b624aaf769cc7cb1fad36fc37f9b89dcf2950">,
      #splice.entry<"/build/gawk-5.4.1/test/rtlen.ok" file 644 mtime 1782131302 "31a2a0c58bd118b3e33568eda8060cc59dd559571a6864514c6e55d916d4fcf6">,
      #splice.entry<"/build/gawk-5.4.1/test/rtlen.sh" file 755 mtime 1782131302 "a3e38617575f05e07867ce45531af0edc27c61f7f29f09c44d29123db892426e">,
      #splice.entry<"/build/gawk-5.4.1/test/rtlen01.ok" file 644 mtime 1782131302 "b78a1987bcbdc0903ba6ba29ee3e1f4e7cc1ca868a60889beb141e26e06cb005">,
      #splice.entry<"/build/gawk-5.4.1/test/rtlen01.sh" file 755 mtime 1782131302 "e9da739dc2d5387c3b237f07b4151a59d24c98baa390b46b7b9c611fe44a283c">,
      #splice.entry<"/build/gawk-5.4.1/test/rtlenmb.ok" file 644 mtime 1782131302 "31a2a0c58bd118b3e33568eda8060cc59dd559571a6864514c6e55d916d4fcf6">,
      #splice.entry<"/build/gawk-5.4.1/test/rwarray.awk" file 644 mtime 1782131302 "e73397022cc538cc20e84042659d7059bcc9709091198bdac9f8ec2662e3068b">,
      #splice.entry<"/build/gawk-5.4.1/test/rwarray.in" file 644 mtime 1782131302 "0b0d55908b5a8f84e8f35b49c11ac06fa287bb351fb372615585058e85e88a4c">,
      #splice.entry<"/build/gawk-5.4.1/test/rwarray.ok" file 644 mtime 1782131302 "37cc37f48a221a415b26932e3601ea8f5e80fced11a4a542ef9876c76b168a1f">,
      #splice.entry<"/build/gawk-5.4.1/test/sandbox1.awk" file 644 mtime 1782131302 "b3ff3659d75ffc6d1a5dd130d606b440be9c99bcc92592f7feccafe0635a00d2">,
      #splice.entry<"/build/gawk-5.4.1/test/sandbox1.ok" file 644 mtime 1783615620 "29e9a3ffdc1e594701c5eb305abb4eaad1ff6dcc4ce6fe135638c2ce2f93c4da">,
      #splice.entry<"/build/gawk-5.4.1/test/scalar.awk" file 644 mtime 1782131302 "7c2c3ebdcd37d1245e8cc5f860f1d5005c33f7740bea359aebf2ebe6e9578935">,
      #splice.entry<"/build/gawk-5.4.1/test/scalar.ok" file 644 mtime 1782131302 "e90c148f7aefffeaf6a29a22c65580fdf672f0c7b18e04123ba55ff23b0dc8de">,
      #splice.entry<"/build/gawk-5.4.1/test/sclforin.awk" file 644 mtime 1782131302 "5bf1324788a850647370f044750dd4074a4501dfebed98d0cf817b7b1d801e7e">,
      #splice.entry<"/build/gawk-5.4.1/test/sclforin.ok" file 644 mtime 1782131302 "b72b10094a4b398ea0a4278545d1db2ccfc110246f992f7c7d6134ac5060e792">,
      #splice.entry<"/build/gawk-5.4.1/test/sclifin.awk" file 644 mtime 1782131302 "08abfec3425ae8767a216b4dc1b46f5633fd2815bad8a1e60e8966c35f730fdf">,
      #splice.entry<"/build/gawk-5.4.1/test/sclifin.ok" file 644 mtime 1782131302 "2d97c045714e10ae34759d1eaf84f4019fe78f3778cf1c17e4186ec08ec97b80">,
      #splice.entry<"/build/gawk-5.4.1/test/setrec0.awk" file 644 mtime 1782131302 "209632e2639e26fa9acc80f9fd9743f94f59cf6ff2ab4128128cb361275447b9">,
      #splice.entry<"/build/gawk-5.4.1/test/setrec0.in" file 644 mtime 1782131302 "5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03">,
      #splice.entry<"/build/gawk-5.4.1/test/setrec0.ok" file 644 mtime 1782131302 "5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03">,
      #splice.entry<"/build/gawk-5.4.1/test/setrec1.awk" file 644 mtime 1782131302 "c340a92583d197913f713e08a166d02987b6a4e37b122061e53dd2f79e751e1e">,
      #splice.entry<"/build/gawk-5.4.1/test/setrec1.ok" file 644 mtime 1782131302 "f57ad676105a9856365a987a3b16a78ad43c009d4621f33e9bcc9cd50a13b01c">,
      #splice.entry<"/build/gawk-5.4.1/test/shadow.awk" file 644 mtime 1782131302 "ab338637965ad11e7e8c104d97d8fad79db1ec6844c458b8753cc31a63d36422">,
      #splice.entry<"/build/gawk-5.4.1/test/shadow.ok" file 644 mtime 1782131302 "6696742db52948d84607d4387c1bfa6241cb1c1b11cca4727972bd151133cf48">,
      #splice.entry<"/build/gawk-5.4.1/test/shadowbuiltin.awk" file 644 mtime 1782131302 "34fdd64e6a18e7e1628005b5dadec3c48463d0c1847287cc9e51fc74f9b6a4bc">,
      #splice.entry<"/build/gawk-5.4.1/test/shadowbuiltin.ok" file 644 mtime 1782131302 "2acb8b48ee300b54e32f5ed676635c90463360f4476ca4615a0c2f6d0c56f36a">,
      #splice.entry<"/build/gawk-5.4.1/test/shortest-match.awk" file 644 mtime 1782131302 "69e704e266811fe226f3215db10646d7bab9f424cbe80665a301da3e6e400250">,
      #splice.entry<"/build/gawk-5.4.1/test/shortest-match.ok" file 644 mtime 1782131302 "58a4d5eecf7a263450a39ee2cf8c6c7b371c958865163b20bbdb4cf5cd5870b1">,
      #splice.entry<"/build/gawk-5.4.1/test/sigpipe1.awk" file 644 mtime 1782131302 "266ef0f261a7dd8ef324e873cc69aa5176c5921bb5ba301a92bb158e05e6277b">,
      #splice.entry<"/build/gawk-5.4.1/test/sigpipe1.ok" file 644 mtime 1782131302 "af5ff022420e00b4b2519140047f75d468fa8824ebcffa1b9dd72eef3b178f35">,
      #splice.entry<"/build/gawk-5.4.1/test/sort1.awk" file 644 mtime 1782131302 "260d85c84b4aef9464445789bd1d470a703b67bddd44353cbe4a91af974480b6">,
      #splice.entry<"/build/gawk-5.4.1/test/sort1.ok" file 644 mtime 1782131302 "7feee7a74e4e9dccb9a3df0560e829d52328a9e4226cf459b5de63220de5895d">,
      #splice.entry<"/build/gawk-5.4.1/test/sortempty.awk" file 644 mtime 1782131302 "3a55f28513fde5769f0d34cb06ec2f974748f40672e591b50b5797714efe6c09">,
      #splice.entry<"/build/gawk-5.4.1/test/sortempty.ok" file 644 mtime 1782131302 "9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa">,
      #splice.entry<"/build/gawk-5.4.1/test/sortfor.awk" file 644 mtime 1782131302 "82c8a2581233ec4b9ee21674160363858b6b8242dc339257e853b3b305b6cdc7">,
      #splice.entry<"/build/gawk-5.4.1/test/sortfor.in" file 644 mtime 1782131302 "75a8cb43272d19d8dd644a0516b9d626156404377737904500acae0720ddb420">,
      #splice.entry<"/build/gawk-5.4.1/test/sortfor.ok" file 644 mtime 1782131302 "5c3a738a9bc35cdca37bdbbb582ac586ea3cde4b2f81a4eacc6be98b9c57796a">,
      #splice.entry<"/build/gawk-5.4.1/test/sortfor2.awk" file 644 mtime 1782131302 "48b35371b4d5947c0e0fa724680b05b61889d0a9d6d1c5bff4c0f5d4b5a69b3c">,
      #splice.entry<"/build/gawk-5.4.1/test/sortfor2.in" file 644 mtime 1782131302 "de86bc28aa9ae1e4846caa6e1dbefd0133a3b2a78d4ee24c9d0a76cf9b6071b9">,
      #splice.entry<"/build/gawk-5.4.1/test/sortfor2.ok" file 644 mtime 1782131302 "de86bc28aa9ae1e4846caa6e1dbefd0133a3b2a78d4ee24c9d0a76cf9b6071b9">,
      #splice.entry<"/build/gawk-5.4.1/test/sortglos.awk" file 644 mtime 1782131302 "38dd9c9362b43eccc5acc17576010bf8f7da15d307e3d4f95d86d1cc37dda97f">,
      #splice.entry<"/build/gawk-5.4.1/test/sortglos.in" file 644 mtime 1782131302 "76d767ea69bce4383145fa46a2d62a07947f6c50bcbed0333fee339a02c69a89">,
      #splice.entry<"/build/gawk-5.4.1/test/sortglos.ok" file 644 mtime 1782131302 "cdb386d893566f3f2f8dbe103867ca265fb3ebb6b7dfd34b55d14a759ada65d2">,
      #splice.entry<"/build/gawk-5.4.1/test/sortu.awk" file 644 mtime 1782131302 "aa2f5f4c48872fc6d0c572d313dd3787d8bd487659b3e3c6d2d18ded1a5e67d6">,
      #splice.entry<"/build/gawk-5.4.1/test/sortu.ok" file 644 mtime 1782131302 "2c3d609a2f1ce4dfbba5ecfe55611dd7aa1faf8e8abc6b0bc904701be03687c8">,
      #splice.entry<"/build/gawk-5.4.1/test/sourcesplit.ok" file 644 mtime 1782131302 "dfef969892f3498d0add512cd4d6de67e38ae716155793742d906c855830e422">,
      #splice.entry<"/build/gawk-5.4.1/test/space.ok" file 644 mtime 1782131302 "4ad24ae8c1fee912523babbb80ddfe76472523a7aec192a24419a7af73f3e672">,
      #splice.entry<"/build/gawk-5.4.1/test/spacere.awk" file 644 mtime 1782131302 "c9131ab47b01f7a879dbd3c735952588b5bc7d515241f1da6b56d870bdfd0faa">,
      #splice.entry<"/build/gawk-5.4.1/test/spacere.ok" file 644 mtime 1782131302 "4fd0adeeeb51fac7b81cdcc03b5590cc6fc97c0b399f77e39f9dfdab6eb6079c">,
      #splice.entry<"/build/gawk-5.4.1/test/split_after_fpat.awk" file 644 mtime 1782131302 "22abeed9845d3cee55eab32114a010f2b53d795aaa450c4a94e1252627f2f8d9">,
      #splice.entry<"/build/gawk-5.4.1/test/split_after_fpat.in" file 644 mtime 1782131302 "837fa831a68a7f8706a9d5608a3ad8712e5d4bd07f921004bc24854f5253e4aa">,
      #splice.entry<"/build/gawk-5.4.1/test/split_after_fpat.ok" file 644 mtime 1782131302 "0bf261cdad2963e9488952c98f3f9fbc5d2ea8c9e57d30cc8b45f78c7fc7effb">,
      #splice.entry<"/build/gawk-5.4.1/test/splitany.awk" file 644 mtime 1783241692 "922ea3f515cc3db7b5286553500023ca48298e5a65b33b2f2a44b77ce04a2102">,
      #splice.entry<"/build/gawk-5.4.1/test/splitany.in" file 644 mtime 1783241692 "c23ea2f0622809c82d36af45ab49af99d00c6fc4897823043c85a09b2960b72b">,
      #splice.entry<"/build/gawk-5.4.1/test/splitany.ok" file 644 mtime 1783241692 "287b9d97d3936f9e3d5bb677de45fa8e0c1f24649d8b971a6195572306c2f257">,
      #splice.entry<"/build/gawk-5.4.1/test/splitarg4.awk" file 644 mtime 1782131302 "8489c57474e2b45b3ca839c0c0d4635262e2eeefee603cc062b95e503be9036f">,
      #splice.entry<"/build/gawk-5.4.1/test/splitarg4.in" file 644 mtime 1782131302 "f56203b9044a7cd82bcc1c816aa86aa75949ae4e573f744fbdd6f55f2914887f">,
      #splice.entry<"/build/gawk-5.4.1/test/splitarg4.ok" file 644 mtime 1782131302 "0c012bcf941f5e8a50a6c4120524633f2a35f5cf25dbaff5db5297fd18287b24">,
      #splice.entry<"/build/gawk-5.4.1/test/splitargv.awk" file 644 mtime 1782131302 "ec1f2cc7b5ad2106ddddff340e5c87330bdc92e52ead465c5e67138ff6b97967">,
      #splice.entry<"/build/gawk-5.4.1/test/splitargv.in" file 644 mtime 1782131302 "ec1f2cc7b5ad2106ddddff340e5c87330bdc92e52ead465c5e67138ff6b97967">,
      #splice.entry<"/build/gawk-5.4.1/test/splitargv.ok" file 644 mtime 1782131302 "ec1f2cc7b5ad2106ddddff340e5c87330bdc92e52ead465c5e67138ff6b97967">,
      #splice.entry<"/build/gawk-5.4.1/test/splitarr.awk" file 644 mtime 1782131302 "201ea9b81b09ee063a5a5e30b9d6a471cb61cab0fc616dacebc7d74f38727ed8">,
      #splice.entry<"/build/gawk-5.4.1/test/splitarr.ok" file 644 mtime 1782131302 "55c42eac67d4451fd2bd0cedc3d915e09240874dc3915f486e710c9134247173">,
      #splice.entry<"/build/gawk-5.4.1/test/splitdef.awk" file 644 mtime 1782131302 "6a1ee44d3756cec11a177a609cae4bf25e73c119656a70e23b4a0e5fe6196439">,
      #splice.entry<"/build/gawk-5.4.1/test/splitdef.ok" file 644 mtime 1782131302 "c3920c984492725fae083e059d9cc41f00f68e0b0c25f00eeb42e453194977ee">,
      #splice.entry<"/build/gawk-5.4.1/test/splitvar.awk" file 644 mtime 1782131302 "c708332bf81f7388f3c180c451cfe532273f6bae6aee62ac3c58eba3325d1200">,
      #splice.entry<"/build/gawk-5.4.1/test/splitvar.in" file 644 mtime 1782131302 "5be1c400ec342672e31fa50dc8baf614f1c0f556bc13dcc0af77d89296330735">,
      #splice.entry<"/build/gawk-5.4.1/test/splitvar.ok" file 644 mtime 1782131302 "7de1555df0c2700329e815b93b32c571c3ea54dc967b89e81ab73b9972b72d1d">,
      #splice.entry<"/build/gawk-5.4.1/test/splitwht.awk" file 644 mtime 1782131302 "33deeba8af91db47826cc05f177776e38b5061020529249cd751c7ae6886c033">,
      #splice.entry<"/build/gawk-5.4.1/test/splitwht.ok" file 644 mtime 1782131302 "ab2fafd33682c9e5457b36098c493a9f06572e6bd9b562f2513943b7869560a1">,
      #splice.entry<"/build/gawk-5.4.1/test/splitwht2.awk" file 644 mtime 1783241692 "21efde45621af6898d299a6c72febf996b2f5bf5f2138703b1b470ff464a2841">,
      #splice.entry<"/build/gawk-5.4.1/test/splitwht2.ok" file 644 mtime 1782131302 "13ed278efcb02abbe6e86efa322fa2efb910c794420c67cd13435ba6065bd715">,
      #splice.entry<"/build/gawk-5.4.1/test/sprintfc.awk" file 644 mtime 1782131302 "0b71ddfdac0b3f0b210d6415706f38ef9b05734172ab26380450494b81b04f00">,
      #splice.entry<"/build/gawk-5.4.1/test/sprintfc.in" file 644 mtime 1782131302 "73eae764f26bda7dfdc033c28297e60f713bde0a1b55f6e9a824072a2eb8f232">,
      #splice.entry<"/build/gawk-5.4.1/test/sprintfc.ok" file 644 mtime 1782131302 "bd1e8e378af596715236a813625040b59e3787448eff9728c00ab88f5aa9bcab">,
      #splice.entry<"/build/gawk-5.4.1/test/status-close.awk" file 644 mtime 1782131302 "6ea9ef4bdb54c581bfdde1ae49884711937d31abf3a0385709fef644782d4754">,
      #splice.entry<"/build/gawk-5.4.1/test/status-close.ok" file 644 mtime 1782131302 "ea2b2e489922c22eca6b3da55fd2a9a4d5dfacebf180ab7b87fb11408f37e1a2">,
      #splice.entry<"/build/gawk-5.4.1/test/strcat1.awk" file 644 mtime 1782131302 "13b95462b64370865a523a1824d99171f7c73170ebafd01d0c7cda8bce6244ba">,
      #splice.entry<"/build/gawk-5.4.1/test/strcat1.ok" file 644 mtime 1782131302 "2841b77424db9ef9af60490780058253d9478443e314310540623fee07f19ec6">,
      #splice.entry<"/build/gawk-5.4.1/test/strfieldnum.awk" file 644 mtime 1782131302 "928228521e029140ced78591aae40c880b8916fc7215729abb73a35c73090b52">,
      #splice.entry<"/build/gawk-5.4.1/test/strfieldnum.in" file 644 mtime 1782131302 "1a25953465ab671d54b30108a9951b5500fa40994098ef9463853004da7933e1">,
      #splice.entry<"/build/gawk-5.4.1/test/strfieldnum.ok" file 644 mtime 1782131302 "0263829989b6fd954f72baaf2fc64bc2e2f01d692d4de72986ea808f6e99813f">,
      #splice.entry<"/build/gawk-5.4.1/test/strftfld.awk" file 644 mtime 1782131302 "c1d037425a8c384fb4c6c2f37bc9505224b7e33b0c469a0633fd4bc4899c5590">,
      #splice.entry<"/build/gawk-5.4.1/test/strftfld.in" file 644 mtime 1782131302 "08519132ecdf5b90ff4f108db3a65f04b0f55af93a237eb00001db389498d3a7">,
      #splice.entry<"/build/gawk-5.4.1/test/strftfld.ok" file 644 mtime 1782131302 "4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865">,
      #splice.entry<"/build/gawk-5.4.1/test/strftime.awk" file 644 mtime 1782131302 "0b9a26837db13e3f27691d8367ee99d3ef211c5c36153a7026423e50e457a8d5">,
      #splice.entry<"/build/gawk-5.4.1/test/strftlng.awk" file 644 mtime 1782131302 "650daec0c30d8156906ad50e79673de4c0f7861586839aade8e80de92b5b67a2">,
      #splice.entry<"/build/gawk-5.4.1/test/strftlng.ok" file 644 mtime 1782131302 "acdb54cd9c8539d4042671f2e33c19a2d0c2ae5f71018b8e06036e6e2c33df42">,
      #splice.entry<"/build/gawk-5.4.1/test/strnum1.awk" file 644 mtime 1782131302 "5bb3a34fa41c1be85df0394f9cfcfb7be7a3de893b15a3e3676bbb98e45e72e7">,
      #splice.entry<"/build/gawk-5.4.1/test/strnum1.ok" file 644 mtime 1782131302 "39dde6bc20f0c862fa42bf54b1538b612e4bbdbdc017723be9c1a9457796b03d">,
      #splice.entry<"/build/gawk-5.4.1/test/strnum2.awk" file 644 mtime 1782131302 "ab09df48148d5970e1886f7d61d1e05d845b70f42110128540924b7904c6d2cb">,
      #splice.entry<"/build/gawk-5.4.1/test/strnum2.ok" file 644 mtime 1782131302 "5461d61881dbd9c12b9ca8ff03b69f569631c5da24674cd91fecf05ec65ece07">,
      #splice.entry<"/build/gawk-5.4.1/test/strsubscript.awk" file 644 mtime 1782131302 "aa06fcf9c2226fd78041744e57ffc788501801d3455a62debeeec7d04c36810a">,
      #splice.entry<"/build/gawk-5.4.1/test/strsubscript.ok" file 644 mtime 1782131302 "917df3320d778ddbaa5c5c7742bc4046bf803c36ed2b050f30844ed206783469">,
      #splice.entry<"/build/gawk-5.4.1/test/strtod.awk" file 644 mtime 1782131302 "6e4eb50c0326e2a6044fcb7229a140b90695cf5d9b5c7ce2859817be760ce0b3">,
      #splice.entry<"/build/gawk-5.4.1/test/strtod.in" file 644 mtime 1782131302 "0e29300477d73e793b5872d058c0849d0b0b5ff4743c9f5f9f9f20a85ee87a49">,
      #splice.entry<"/build/gawk-5.4.1/test/strtod.ok" file 644 mtime 1782131302 "e22d47959113db99b622e8fe1229a0f26c0684e54afcc4be6d701cb41468a7f0">,
      #splice.entry<"/build/gawk-5.4.1/test/strtonum.awk" file 644 mtime 1782131302 "8a2c8854a12140ec1f55cb7b6a410fd69e541733057794eb2b5b97770f8d6b4a">,
      #splice.entry<"/build/gawk-5.4.1/test/strtonum.ok" file 644 mtime 1782131302 "7b13d8dad09e480b6ed09890ba2bcf7539bc26a14a53eb8b9c3efde1b0f7397d">,
      #splice.entry<"/build/gawk-5.4.1/test/strtonum1.awk" file 644 mtime 1782131302 "4ae18e7d43371835d33313dd433424680b8e9d7499004c1dff38bf9ad21a7e41">,
      #splice.entry<"/build/gawk-5.4.1/test/strtonum1.ok" file 644 mtime 1782131302 "cfbb0b2ac804980a5859eb68448265e2a705929a3ac2ca27d57b56001b7fbf8b">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid1.awk" file 644 mtime 1782131302 "c7b02f81adf00fc31a348fe43f8df6cb69f8c340d598e52f92241aa75515df33">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid1.ok" file 644 mtime 1782131302 "29e05ee313594dc4806022f4669d6eeb5b548bafabea4b69b5ce1c10f2bd3811">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid2.awk" file 644 mtime 1782131302 "57360bbbcc1fa92f6c569efe6d09d45d91aaa84bacb2be53825911e0fdb5355a">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid3.awk" file 644 mtime 1782131302 "d8c6a8f407b717378164e9418cb2d2eef775b1f088e9285ca83d924c94bdb468">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid3.ok" file 644 mtime 1782131302 "084b3ad224ba559616ee3cf4f6ecdea2dbf4384a7185ac1816a432e666b963d0">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid4.awk" file 644 mtime 1782131302 "8735e6bf257f6056a8caa1ec103281d4868ead83d2397002b55a13c36128b166">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid4.ok" file 644 mtime 1782131302 "7d2c58f348978221cff37768790494bfff43d409af95132090abf8bbdfb75661">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid5.awk" file 644 mtime 1782131302 "6af2d74068451ecc73ccf76d45fb82f4fc68c421db2eb3908b6432cca170ed42">,
      #splice.entry<"/build/gawk-5.4.1/test/stupid5.ok" file 644 mtime 1782131302 "7d2c58f348978221cff37768790494bfff43d409af95132090abf8bbdfb75661">,
      #splice.entry<"/build/gawk-5.4.1/test/subamp.awk" file 644 mtime 1782131302 "f3cbfc7fec5f7864865cf383c1aa5e4f28cc109f4bd9bfb182e4a8e95fd19bae">,
      #splice.entry<"/build/gawk-5.4.1/test/subamp.in" file 644 mtime 1782131302 "17e682f060b5f8e47ea04c5c4855908b0a5ad612022260fe50e11ecb0cc0ab76">,
      #splice.entry<"/build/gawk-5.4.1/test/subamp.ok" file 644 mtime 1782131302 "17e682f060b5f8e47ea04c5c4855908b0a5ad612022260fe50e11ecb0cc0ab76">,
      #splice.entry<"/build/gawk-5.4.1/test/subback.awk" file 644 mtime 1782131302 "a55f49bf5defb6def1a74fcdd5ffa2d82e799d10fe556e44e59dc1e1d8ba5042">,
      #splice.entry<"/build/gawk-5.4.1/test/subback.in" file 644 mtime 1782131302 "c0cde77fa8fef97d476c10aad3d2d54fcc2f336140d073651c2dcccf1e379fd6">,
      #splice.entry<"/build/gawk-5.4.1/test/subback.ok" file 644 mtime 1782131302 "069d4dffe3a16aaf8623f14d82244b40adf44efb2686ee68397c4e308759a296">,
      #splice.entry<"/build/gawk-5.4.1/test/subi18n.awk" file 644 mtime 1782131302 "a08305f2d70f0b70440cdc2b0659038de584f26c39f48e67d08bbb8d447d7dcd">,
      #splice.entry<"/build/gawk-5.4.1/test/subi18n.ok" file 644 mtime 1782131302 "74c001a5b38b542f9ea60b8af1cad5e56a7835698963798dd7a36a39ffdecf7b">,
      #splice.entry<"/build/gawk-5.4.1/test/subsepnm.awk" file 644 mtime 1782131302 "49460451de265450c19b5d0bc5fa65c0f8c0c71c2aa230054badcdd3963a54f0">,
      #splice.entry<"/build/gawk-5.4.1/test/subsepnm.ok" file 644 mtime 1782131302 "eea8254c7500ba3de996aa8ad6af399183f04e17d4a8102fde539dbc93a90012">,
      #splice.entry<"/build/gawk-5.4.1/test/subslash.awk" file 644 mtime 1782131302 "bb84a7b5f5bebd2dc6a91d2a906f6f0520824c9b22879c1eb1ab0ab2cd57741b">,
      #splice.entry<"/build/gawk-5.4.1/test/subslash.ok" file 644 mtime 1782131302 "e480798f5b53751d7af515d2244360589a94e5a920b6120b8db416f5592d0297">,
      #splice.entry<"/build/gawk-5.4.1/test/substr.awk" file 644 mtime 1782131302 "50449cab77b27bd94515948821b900d0121b3c9502acd40566e82818ce212216">,
      #splice.entry<"/build/gawk-5.4.1/test/substr.ok" file 644 mtime 1782131302 "6235dd87d1c19d7fb602e166917a2226e88b28413ca1dcb8898c492b1146e32d">,
      #splice.entry<"/build/gawk-5.4.1/test/swaplns.awk" file 644 mtime 1782131302 "5885321b816213f8c22362cd12b3d947db0f2e1fbf4c2c67f66d6191ded65991">,
      #splice.entry<"/build/gawk-5.4.1/test/swaplns.in" file 644 mtime 1782131302 "98036ba21db5f4cc74efe5f31dc74657513b4c415c31761e9de106e4fbeee938">,
      #splice.entry<"/build/gawk-5.4.1/test/swaplns.ok" file 644 mtime 1782131302 "540cb7d0d419527b869f5a93c26e2e0b77f84ff6b934535cb7c5efe23d0a017d">,
      #splice.entry<"/build/gawk-5.4.1/test/switch2.awk" file 644 mtime 1782131302 "464450cbbcf57a824c0415d8bdc9360d83c398be77bce13e7783d6c9f0d9cb7e">,
      #splice.entry<"/build/gawk-5.4.1/test/switch2.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab1.awk" file 644 mtime 1782131302 "e22d9dd10fd00efbe2b1352a67264f7d012c078472e807191d60c09fcf1c48e6">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab1.ok" file 644 mtime 1782131302 "164a30538916ec3c1b8f4ad43f1a3068cc89f96435523a6eff81bd9c384f600c">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab10.awk" file 644 mtime 1782131302 "39f069bd2d5cf75c7589ccf3adacbf07d90c4ebca28d90daee42639b2bbee958">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab10.ok" file 644 mtime 1782131302 "ec0e95ce2008a468b8d3bb1dafe92798bee73c4b6fe2e185c37c46fc5d1906df">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab11.awk" file 644 mtime 1782131302 "886780032b7fc0ae66d7d863a348ced47f01a73751a3140bcbcefa3e02295952">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab11.ok" file 644 mtime 1782131302 "c0a20247658bb3d1208dfa95970f0f4759afe1a008a2c6fc44d6045ebebd0a7d">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab12.awk" file 644 mtime 1782131302 "1628c97f1e565a25d2d8cbe2e197f8728fdc2525888a1cd27925c540dc22f136">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab12.ok" file 644 mtime 1782131302 "938ad89011971a68ad7a702eee778fe56fc893ce7c5ebffd8db69e4b1df737c3">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab2.awk" file 644 mtime 1782131302 "5e50a036e90cb47b8872755e6c4cf0d3eea997d0f5ae7705c4c1ea452abb1408">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab2.ok" file 644 mtime 1782131302 "319be896dc3fbceb5f88531d8b0ef14e59b4adc672fceacd75fa719c17859a78">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab3.awk" file 644 mtime 1782131302 "b24997d8285ad4171037ba4cce5df88fd6d99c9b5fdd4c22a430e66a9260d6ef">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab3.ok" file 644 mtime 1782131302 "bda510b6562931882043eb756820fffb0f5f1674f74b3b124b0c2139ca0c4db8">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab4.awk" file 644 mtime 1782131302 "0dbdffaa656a1e65973ff0266b33d7a718a5ed0699cf1a034d14fcb9c39a72fb">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab4.in" file 644 mtime 1782131302 "6bdf6e37dc327165fa4db779b911b98b6eba38852a9cd4a97cdd6be810a88357">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab4.ok" file 644 mtime 1782131302 "a6e2b7a040683432de03a18fd8a1939a2fdf82585b364bfc874bdd4095c4cae1">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab5.awk" file 644 mtime 1782131302 "ce974bbd62d366a072d4a4d18e2178159c6603e314835825de6b227e249cccd2">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab5.in" file 644 mtime 1782131302 "6bdf6e37dc327165fa4db779b911b98b6eba38852a9cd4a97cdd6be810a88357">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab5.ok" file 644 mtime 1782131302 "a6e2b7a040683432de03a18fd8a1939a2fdf82585b364bfc874bdd4095c4cae1">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab6.awk" file 644 mtime 1782131302 "46f05b101f5b67349942c99ee7ed1b222c191e589be887205e413995d9a54061">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab6.ok" file 644 mtime 1782131302 "1934362f47a6f21e5a68fcf0fceac630e2b3cd2b6c81f3a367e48e2bef1a5045">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab7.awk" file 644 mtime 1782131302 "425c95783061dfc4dc3073df4dc241d65ba1d4c439c061b63244eb15ebf8f4f5">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab7.in" file 644 mtime 1782131302 "4071216acca26bb147d1df860d13be5d805a200f7af8a0fd0ec5411365e8af17">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab7.ok" file 644 mtime 1782131302 "5506b3a8ff13f2f8aa37e0b36da2d6150bc0f77603b405f000b6c533c12f07de">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab8.awk" file 644 mtime 1782131302 "bafc7ebac1b91ada2a1d75d706ba81a92a91d9b6593e55a79cd3ae98c6d8c324">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab8.in" file 644 mtime 1782131302 "f2ca1bb6c7e907d06dafe4687e579fce76b37e4e93b7605022da52e6ccc26fd2">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab8.ok" file 644 mtime 1782131302 "46d811f8bb8d78dc9c920516b76a1b358e9d4795dfe1f6c040e4560526fa6662">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab9.awk" file 644 mtime 1782131302 "d662ab433f47283b522a5c2d72a7c222ec2d8e9ee7401d9e7fbe922951b7f50b">,
      #splice.entry<"/build/gawk-5.4.1/test/symtab9.ok" file 644 mtime 1782131302 "a32653aa1028639edddc02f30fb002a9420a9d007a01a7378013ef21fa8d1e5e">,
      #splice.entry<"/build/gawk-5.4.1/test/synerr1.awk" file 644 mtime 1782131302 "9edd8505323e37f72e8757f8145f078ec88ee6b2013c5a986dc790fff546f050">,
      #splice.entry<"/build/gawk-5.4.1/test/synerr1.ok" file 644 mtime 1782131302 "6c54aed6ce34a6f87050185a1cfadc484c7a11c093ff848eb6276d6e74cb591f">,
      #splice.entry<"/build/gawk-5.4.1/test/synerr2.awk" file 644 mtime 1782131302 "141655fcce66bea35614dcf6cbe247cdaa3969fc93742de5c9bb1e0ddc6c2226">,
      #splice.entry<"/build/gawk-5.4.1/test/synerr2.ok" file 644 mtime 1782131302 "ba3deeec6dbd6c294084b92cda7771aec6d17749db14ec3b8f5c4fd9b8fd2dcb">,
      #splice.entry<"/build/gawk-5.4.1/test/synerr3.awk" file 644 mtime 1782131302 "32cfbf531a8535ae9aa04b9465586d4ea49c61a7ab57e54ecbbf69b013208a13">,
      #splice.entry<"/build/gawk-5.4.1/test/synerr3.ok" file 644 mtime 1782131302 "e4cbe88a7b981ea226e7987f1190db2a56207ed97b4b649db90b480d83b6b7e2">,
      #splice.entry<"/build/gawk-5.4.1/test/tailrecurse.awk" file 644 mtime 1782131302 "8c8ad1b4936dc882f06b677ec9b456deebbc2e31fd60a5d43e67cc9f1ea5ae68">,
      #splice.entry<"/build/gawk-5.4.1/test/tailrecurse.ok" file 644 mtime 1782131302 "67e4f9beb048b5a022fdb8290f51ae12a163eca1af581508fc9375fc53d2d1fd">,
      #splice.entry<"/build/gawk-5.4.1/test/testext-mpfr.ok" file 644 mtime 1782131302 "b5cacee0d6fdc146e6e54ab4a2d66f165ab0d013d81e31fd35b269710f94a0d8">,
      #splice.entry<"/build/gawk-5.4.1/test/testext.ok" file 644 mtime 1782131302 "eb63d60c42d79f879c991606eff40aadfa2675377c3a88134feaee1add58717a">,
      #splice.entry<"/build/gawk-5.4.1/test/time.awk" file 644 mtime 1782131302 "f6d264c6c40c98d7f08fc17b687bbae5bb71d8c2c84fdb32d5ce82dfc11980d3">,
      #splice.entry<"/build/gawk-5.4.1/test/time.ok" file 644 mtime 1782131302 "0230f447a409cf10d711e04e5a976970468c0d3036b33b292c77cd5fef89e56e">,
      #splice.entry<"/build/gawk-5.4.1/test/timeout.awk" file 644 mtime 1782131302 "5095f6c14eb8005438d229986437c1b66b8e35c61a1376d557142803dec10475">,
      #splice.entry<"/build/gawk-5.4.1/test/timeout.ok" file 644 mtime 1782131302 "5b9ef77539a8501a1fbaa7ab41ae49ff261dc882ee03fe5ed2a86aaa6b8262eb">,
      #splice.entry<"/build/gawk-5.4.1/test/tradanch.awk" file 644 mtime 1782131302 "83992878410d208246f77ccfef671155bdc930d37e31325a1dac26ae1ac79d76">,
      #splice.entry<"/build/gawk-5.4.1/test/tradanch.in" file 644 mtime 1782131302 "97ffecbe0b2c169a439966b235ffb084e921892ce86c6ed9c1a7e2fce334b9a8">,
      #splice.entry<"/build/gawk-5.4.1/test/tradanch.ok" file 644 mtime 1782131302 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/test/trailbs.awk" file 644 mtime 1782131302 "e01fb556b7efebb6fda6bc58b0642df1a3960b9eab8348b2d5ca086ded9f29ef">,
      #splice.entry<"/build/gawk-5.4.1/test/trailbs.in" file 644 mtime 1782131302 "fd83b3852015fcb2f4baef0ec448acd8ac9ffda006cbb8c0e89ea34539c09aed">,
      #splice.entry<"/build/gawk-5.4.1/test/trailbs.ok" file 644 mtime 1782131302 "8432cc756ce8625f53923470b61218dc0dd5474a5b8b383e6715c9ebaf1647fa">,
      #splice.entry<"/build/gawk-5.4.1/test/tweakfld.awk" file 644 mtime 1782131302 "66c58b17583d8c6313fab273cc6a34595060e35584538d1ad853080c3aec25b5">,
      #splice.entry<"/build/gawk-5.4.1/test/tweakfld.in" file 644 mtime 1782131302 "5b110967a96324bee8f6470655cd900925b7d06d7ab03b8185a2dcfa35166b60">,
      #splice.entry<"/build/gawk-5.4.1/test/tweakfld.ok" file 644 mtime 1782131302 "1186befeb23b442264e288cef0d2c14462c9256ebd06589f86d11a58de84c7ee">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex1.awk" file 644 mtime 1782131302 "d35b4076d93353c0d822a5a0b1d5ce8e9c612bd0c995129380f0dbd33191eacc">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex1.ok" file 644 mtime 1782131302 "6616cf2d8025dbc18dab40152b73d94bbb852dd7b0d2dd025c1a8ddcbb508b36">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex2.awk" file 644 mtime 1782131302 "fe6c240b85da7f85b346d35bc556a71417f00efc7bbe4c1524341fdefa0e5456">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex2.ok" file 644 mtime 1782131302 "664e5342de30ecab1d6fd3ebbbd21f935031a5206582dfc85c44f207220c2781">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex3.awk" file 644 mtime 1782131302 "3bc9fc2851ef85c0f4bce088a0cbee6d35ab4ffc01d56f52f5cb431ac9997c9e">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex3.ok" file 644 mtime 1782131302 "ae226346f5e16555d242097b5b884c6f0a3e62a9ce9fbf9a404f6b0d476fef4f">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex4.awk" file 644 mtime 1782131302 "043c66481cf0385b5390473b1f89566919ebf51a0d3d727c30f4cb7c252cc0c9">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex4.ok" file 644 mtime 1782131302 "d2bb0d30f3fe872e917345681a2839711aaccc38f8b1836deec491504110f388">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex5.awk" file 644 mtime 1782131302 "46d333c2a4af5c262494dfb84ae650c8ce5bbd745b65e9d6d7452a3c0c089780">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex5.in" file 644 mtime 1782131302 "7390429e6947130654bf08fd246b10083cc2763af59dc9353949d7bf07b554f9">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex5.ok" file 644 mtime 1782131302 "08471bb50f18ca79f66d452898411793e341f5fa07f5b96f720483309bf40803">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex6.awk" file 644 mtime 1782131302 "8574af727ed852f702dcc524cb00aa5bd29e14b86b16e0b282ca9534fa943234">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex6.in" file 644 mtime 1782131302 "7390429e6947130654bf08fd246b10083cc2763af59dc9353949d7bf07b554f9">,
      #splice.entry<"/build/gawk-5.4.1/test/typedregex6.ok" file 644 mtime 1782131302 "8afce97d8a1cd8d569c19f8f6d76dc0262a04077ea675c4a3382d632973ad112">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof1.awk" file 644 mtime 1782131302 "b64aee498cefa8e1252001cf49dcff808fc6b4589fed66254bd829a9c2f36151">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof1.ok" file 644 mtime 1782131302 "1aca17c0df4df8c598a79e370939af3b081172609f748611aa66067630032a6c">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof2.awk" file 644 mtime 1782131302 "624ab9e3c837e7e4773b3b5678e53ac9ed9634129a3cbd2d374bffefb47e23f9">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof2.ok" file 644 mtime 1782131302 "8ca07558cf98bfa044a0770453802dd7b5e81d862abbd13f50367ca1e6b0347c">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof3.awk" file 644 mtime 1782131302 "18aad461dd8eae2b10909e4f851cb669b8976c184e10754121a671f1fd1ca607">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof3.ok" file 644 mtime 1782131302 "285024fa6461995c23a23ac677d3d81208bb5530003c41b51f79cd354cdaaa00">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof4.awk" file 644 mtime 1782131302 "70ea2e9a8001384c2cf0d1eb02d20726cbfe9632bf5d83bfca871392297f1499">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof4.ok" file 644 mtime 1782131302 "3795f3477e788690366ba81e5e3a3d8bccf820b5f2e26c6ee87d5e2f4cb7e3ca">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof5.awk" file 644 mtime 1782131302 "49f76a7756f777f7944aa34af457c76597ddaf7e1f3dc24c4b6f4cfb8c87c867">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof5.in" file 644 mtime 1782131302 "f2ca1bb6c7e907d06dafe4687e579fce76b37e4e93b7605022da52e6ccc26fd2">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof5.ok" file 644 mtime 1782131302 "6c30667c3a26580770dff17878cef5dcdc1fd726d764b7ca631ae8ad9aeb3452">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof6.awk" file 644 mtime 1782131302 "33a76c3bf6e1135fc4eac5aa0925129b23ad83b084966485988332fc45c5339e">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof6.ok" file 644 mtime 1782131302 "6d6f1adcd1e1ef897b5c352f40eea7233da6c10069009bf14cb6abb527efc599">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof7.awk" file 644 mtime 1782131302 "986b14e4a593b9511f855495393a34f1647a15d0e992ab03f974c8d8d2068317">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof7.ok" file 644 mtime 1783249699 "08466f8ee2a29e88e51484e558406b7208285b1d2cb7592bc8d0b7a5efed31a9">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof8.awk" file 644 mtime 1782131302 "3da09cc28cabb2fb64e579878181bb71ba11274151717c7a6ebc2cde2fb78740">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof8.ok" file 644 mtime 1783249699 "43cafa8450227ecc30304228df7b843d9a9af13970c7053677858d8ec036019b">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof9.awk" file 644 mtime 1782131302 "9dbe0d5c5919e1c6d1eb9531989c4d1f125a4d7ce063b1a14ddfe2fd7030082f">,
      #splice.entry<"/build/gawk-5.4.1/test/typeof9.ok" file 644 mtime 1782131302 "5ceab9d6ab9a619700ac3086a4a6ca765b1f996c5495b0684be07a16844efa55">,
      #splice.entry<"/build/gawk-5.4.1/test/unicode1.awk" file 644 mtime 1782131302 "2cc87a98ce175b2436aa2baffcef2dacc25416716fd75f1e5d21ad96db455bd6">,
      #splice.entry<"/build/gawk-5.4.1/test/unicode1.ok" file 644 mtime 1782131302 "ecc9f05dba46dc5cb9021d05ca45849132fa81dca4aebd89ae1ea3d0c1c707ec">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit2.awk" file 644 mtime 1782131302 "fbb70a950b9d03b9533972d54b4762ece6b2dcf71ccaa91a6876aafacc135d58">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit2.ok" file 644 mtime 1782131302 "b64305805fde96f08c139efa0fc6f3b218c1505ae452dfb1ab8a7bf98ec0cc80">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit3.awk" file 644 mtime 1782131302 "7605e5e32d65b1e59aa474d529c0f915ccef6ec6fb8e8b5ec966437c3cb1834c">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit3.ok" file 644 mtime 1782131302 "ba08f3a34217926bae084f090d3c62141849bbb2c86ca2e93d18f7d19e847f32">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit4.awk" file 644 mtime 1782131302 "e10581069f3d54d91cdb73cc30f5551ba3d904bd5f81e1dc6cdda1a844ad6ab3">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit4.ok" file 644 mtime 1782131302 "7d52907f1f2b9716a1755869bd49688f55452b949b149a9aa10006df2a1291fb">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit5.awk" file 644 mtime 1782131302 "bd3fda3f42ee555f26faac48bb66a123a4fb2aeeb81cc8bb985161505a136aad">,
      #splice.entry<"/build/gawk-5.4.1/test/uninit5.ok" file 644 mtime 1782131302 "370e00d6d9509a46b67326df736ac2f7b523157f892236d9cd1c710cbae3416e">,
      #splice.entry<"/build/gawk-5.4.1/test/uninitialized.awk" file 644 mtime 1782131302 "71882a371b2f099a7928163fe011d69dfd5a2ad6f5622ebbc7b0e7cea3ada04d">,
      #splice.entry<"/build/gawk-5.4.1/test/uninitialized.ok" file 644 mtime 1782131302 "0d8b25de29fd398ac4c7954110a64cf70c8f06f8b7d9bbaf82d3ed528989789e">,
      #splice.entry<"/build/gawk-5.4.1/test/unterm.awk" file 644 mtime 1782131302 "24c33e2f2bfc0bb2532a7a9b8b7e9996dd59a58923ddacb0558da95ef634c84a">,
      #splice.entry<"/build/gawk-5.4.1/test/unterm.ok" file 644 mtime 1782131302 "d86b3ec06a308910899b1b236b079e9c403c63181d0905b60e9ecebe4a80ad38">,
      #splice.entry<"/build/gawk-5.4.1/test/uparrfs.awk" file 644 mtime 1782131302 "5de6ce3f45f7746096a4ba157a6f68d773d4da799fe28319e50b34adddf61159">,
      #splice.entry<"/build/gawk-5.4.1/test/uparrfs.in" file 644 mtime 1782131302 "ce95084f62cf889e24c9ab685934fcc0a9706f886a172805e290c16c4acf38a9">,
      #splice.entry<"/build/gawk-5.4.1/test/uparrfs.ok" file 644 mtime 1782131302 "aebdddd79b4866f10f2b5d33556fa050e7b88495a5060021ae02705996a0d168">,
      #splice.entry<"/build/gawk-5.4.1/test/uplus.awk" file 644 mtime 1782131302 "6d965f4cc17ea4c79b44e3db38646b03c7470e7467578a7200e8e6017f6e8c5b">,
      #splice.entry<"/build/gawk-5.4.1/test/uplus.ok" file 644 mtime 1782131302 "3b916844f0b00b46cf50fdb2e1cec237bc8963e5e6abb992a81307b1f30bb5fd">,
      #splice.entry<"/build/gawk-5.4.1/test/uplus2.awk" file 644 mtime 1783241692 "33b586ccc2d359128c3f670798c8edad39c34377888517cc02837e2c7bd8a111">,
      #splice.entry<"/build/gawk-5.4.1/test/uplus2.ok" file 644 mtime 1783241692 "bfde8a91c78e9f9f2c9947fc81a1f1fea18b0b23788c2913cbeed0564d6c7ddc">,
      #splice.entry<"/build/gawk-5.4.1/test/valgrind.awk" file 644 mtime 1782131302 "c9b5d060ef24859b6c4e49f08322eb72c7ceaa365c688ba80d8c4101b42e2eba">,
      #splice.entry<"/build/gawk-5.4.1/test/watchpoint1.awk" file 644 mtime 1782131302 "96f89f03195b2b989d2fc1f905e271066c23b89b0c665addb62fb4b9445132be">,
      #splice.entry<"/build/gawk-5.4.1/test/watchpoint1.in" file 644 mtime 1782131302 "86bf80d92e9fe3ed3eb517d3deb6a651b3878d2c126397076b343e4a7c24ce80">,
      #splice.entry<"/build/gawk-5.4.1/test/watchpoint1.ok" file 644 mtime 1782131302 "3dc184fbbfb97e19fb48b9f2cbef18594079741456375fa2aaf1a3b07ea3f75b">,
      #splice.entry<"/build/gawk-5.4.1/test/watchpoint1.script" file 644 mtime 1782131302 "3752ce79951d14a228587f75f187f8bbbbd2845860f67a4b821a4f727ead89d5">,
      #splice.entry<"/build/gawk-5.4.1/test/wideidx.awk" file 644 mtime 1782131302 "4f299b59fbebdbc15bd48db2799d7801c70ac0cb481987409033246119fc8f76">,
      #splice.entry<"/build/gawk-5.4.1/test/wideidx.in" file 644 mtime 1782131302 "d78931fcf2660108eec0d6674ecb4e02401b5256a6b5ee82527766ef6d198c67">,
      #splice.entry<"/build/gawk-5.4.1/test/wideidx.ok" file 644 mtime 1782131302 "452e39c241ac7c3d1fe29b5529a5e2ea849dff1f35727ab388946535f4f2f0f8">,
      #splice.entry<"/build/gawk-5.4.1/test/wideidx2.awk" file 644 mtime 1782131302 "b07aa214b11939e39a5269c9afc70c45f206d55f7a63f2628f545317e5d11c1c">,
      #splice.entry<"/build/gawk-5.4.1/test/wideidx2.ok" file 644 mtime 1782131302 "35495adf95aca1bd4a0b998736950543cb7f06e7b45a67e9451d43370d92eb76">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub.awk" file 644 mtime 1782131302 "86f902957d508f5938604ef04371f6a4e277849314bc1abf86cb3657e224bc66">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub.ok" file 644 mtime 1782131302 "74c001a5b38b542f9ea60b8af1cad5e56a7835698963798dd7a36a39ffdecf7b">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub2.awk" file 644 mtime 1782131302 "0e59d4883d85aff6f366e7c66c9522b3450637f06a0ad4cb4be5fa765fc23f16">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub2.ok" file 644 mtime 1782131302 "35495adf95aca1bd4a0b998736950543cb7f06e7b45a67e9451d43370d92eb76">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub3.awk" file 644 mtime 1782131302 "0f35b9a2eb178b3443f80a061835a6f3e41e3da23ceddf9cc515365cf04ded8c">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub3.in" file 644 mtime 1782131302 "4b67510ff53287e48bd4938291e403a3f7fac4e84c2611dfc88efd8c2a8b6eac">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub3.ok" file 644 mtime 1782131302 "b2b4bfa3722fc10d0527351e10733c37d02e5c97f30fa0b2c011b3676ba9cfcd">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub4.awk" file 644 mtime 1782131302 "793012749ad944e5a4d261796e229180ac0c5930e82a9b1aa6ee2ea8574ff692">,
      #splice.entry<"/build/gawk-5.4.1/test/widesub4.ok" file 644 mtime 1782131302 "109c73d9672e4430e597a769dbdf921bf7a39657f74de1f95ea277bdd2eae7fe">,
      #splice.entry<"/build/gawk-5.4.1/test/wjposer1.awk" file 644 mtime 1782131302 "2e0d3024427956fdef7dd622d9453c7ece2c52266443929efafc539c057d5201">,
      #splice.entry<"/build/gawk-5.4.1/test/wjposer1.in" file 644 mtime 1782131302 "374ae5783d6e4292ea8c854bce8b7ed858579a357e4dec4f94065cd5b933bd51">,
      #splice.entry<"/build/gawk-5.4.1/test/wjposer1.ok" file 644 mtime 1782131302 "80d90c5077ce52d7608163bab67a6b1cf12a1e87a07d21e9d1c35f5cb3d9f10a">,
      #splice.entry<"/build/gawk-5.4.1/test/xref.awk" file 644 mtime 1782131302 "9ae714e19c8e6b783cbd2fcad89c5c3581cb662f1e88e8651948642f093bedda">,
      #splice.entry<"/build/gawk-5.4.1/test/xref.original" file 644 mtime 1782131302 "cc104d3661ccf478cd66083ea912cb155800b663537a671d7d45962857006b05">,
      #splice.entry<"/build/gawk-5.4.1/test/zero2.awk" file 644 mtime 1782131302 "00c9297dee05164010723fd7d4d5ffcfac0e69b50268f4066c0da5e136b5e519">,
      #splice.entry<"/build/gawk-5.4.1/test/zero2.ok" file 644 mtime 1782131302 "f456c1ffc6a33cd5dae1ca90cf499aadeabb167b9e687175a8fc62476833374c">,
      #splice.entry<"/build/gawk-5.4.1/test/zeroe0.awk" file 644 mtime 1782131302 "04e5d8731c6b23974675e8effa6a95386e4d79a0f0dc73d3a4395023d89cf87b">,
      #splice.entry<"/build/gawk-5.4.1/test/zeroe0.ok" file 644 mtime 1782131302 "b2e5457b029a261911668aae9d9671612f6d13002d03cdabdf91141a8379f748">,
      #splice.entry<"/build/gawk-5.4.1/test/zeroflag.awk" file 644 mtime 1782131302 "51badedb8812019b1cc24483e909d80e250a4e17237f17bd52d6b012fbe309ca">,
      #splice.entry<"/build/gawk-5.4.1/test/zeroflag.ok" file 644 mtime 1782131302 "895c15fbbd1d510b35ab959c2ecac8fd25f2c0b592620cbf985e5556a528ac9e">,
      #splice.entry<"/build/gawk-5.4.1/version.c" file 644 mtime 1782131302 "6a7cf7af2e18ba2bb63cbff34174673eaf1546ad9077574362c4c22859f13b4f">,
      #splice.entry<"/build/gawk-5.4.1/vms" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/vms/ChangeLog" file 644 mtime 1783615671 "973c50628ee48de988e50f53e85133ad525064e864688c6d5ed2d1f8ccae98ae">,
      #splice.entry<"/build/gawk-5.4.1/vms/ChangeLog.0" file 644 mtime 1782131302 "0962c65e43bfd0bd1a167664c4fb0c6da489884733d51b65abbaa20845f4b2c3">,
      #splice.entry<"/build/gawk-5.4.1/vms/ChangeLog.1" file 644 mtime 1782131302 "cc4405d242ea2f4e480912d539ae0436980fb7e744a2b947d8fdaf3b94359088">,
      #splice.entry<"/build/gawk-5.4.1/vms/backup_gawk_src.com" file 644 mtime 1782131302 "50ef449ee62f7d9722fdf5906621b0adba80276bd2a6bbe70c279cc3e0b62208">,
      #splice.entry<"/build/gawk-5.4.1/vms/build_gawk_pcsi_desc.com" file 644 mtime 1782131302 "17c88cf0c818e0964a57af1c3e297ce3f861bcc84b7fb15b5a6a61634c370c26">,
      #splice.entry<"/build/gawk-5.4.1/vms/build_gawk_pcsi_text.com" file 644 mtime 1782131302 "149e254b860f915829f59f15e829a358b8d1b6763afabf82cb44d9c638acda93">,
      #splice.entry<"/build/gawk-5.4.1/vms/build_gawk_release_notes.com" file 644 mtime 1782131302 "b0652ceebbd687842dd40e40236c22ee639bc3f53bfe65a476ccb52071527a8d">,
      #splice.entry<"/build/gawk-5.4.1/vms/compare_gawk_source.com" file 644 mtime 1782131302 "0e2eea777d9a46f8e58262531c1717b83b153dbe8116dde50d2625f6482f6915">,
      #splice.entry<"/build/gawk-5.4.1/vms/config_h.com" file 644 mtime 1783329604 "f87053d14c845157000dc7f02e000dbcd03820f3c04a847e6e438deef5785f1c">,
      #splice.entry<"/build/gawk-5.4.1/vms/config_vms.h" file 755 mtime 1782131302 "ea59d01574ac4bd95efcd40346aaca08fbccb8dc70c9eb0231bd12d8636eb319">,
      #splice.entry<"/build/gawk-5.4.1/vms/descrip.mms" file 644 mtime 1782131302 "8e8af6127658363a35912af945a746c4e433437fbcc12bf84cf2e116ff2de412">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk.cld" file 644 mtime 1782131302 "224b895b1d76b541cd1e5a63b7fdf65a46edf523ba201a8a0a6363c470682e58">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk.hlp" file 644 mtime 1782131302 "dcd9fd7c33dfa41fa9f9db33cbe7f2d4fd8f119dea992a40bd4d1f0ea7199acb">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk_alias_setup.com" file 644 mtime 1782131302 "432f4526ab42989282c4394c8fd2152bf9f2f16cc9cee14e6bc1f2e8e63d9434">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk_build_steps.txt" file 644 mtime 1782131302 "fdcc4de0501fe9d12451d7258bd5c897ea949793155f1ca427f85e1c78630cc9">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk_ident.com" file 644 mtime 1782131302 "75aecdeab3682be8c5a7bdef2bc0e19709bf6bc3ac53b7939d3440683cdad4d4">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk_plugin.opt" file 644 mtime 1782131302 "046eaaa6f3df8f0356ca0d8e795f3ebea079e7caf49496de8069fc080690d0f9">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk_release_note_start.txt" file 644 mtime 1782131302 "e2dcf3fd46631f31a19e27445acb268e6df31186f166a458a33a551872cf1387">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawk_verb.com" file 644 mtime 1782131302 "317048afaa7b0c5564b6b59840ae822cab713bf3e91f9a41a250109583a22891">,
      #splice.entry<"/build/gawk-5.4.1/vms/gawkmisc.vms" file 644 mtime 1783241692 "19a8804850e787004df23b95a6eb6a50600b491276e044fbb4e5a8efca1484da">,
      #splice.entry<"/build/gawk-5.4.1/vms/generate_config_vms_h_gawk.com" file 755 mtime 1783329604 "d48578369410d33a035394ae9f8f68aff259397c73fb17d9800fb545b9e43987">,
      #splice.entry<"/build/gawk-5.4.1/vms/gnv_gawk_startup.com" file 644 mtime 1782131302 "d5310f78d9b8ddbe5858db5836d52c55a3fd1d56c0ae0b3ee355a8bc2744c9c8">,
      #splice.entry<"/build/gawk-5.4.1/vms/inttypes.h" file 755 mtime 1782131302 "46bea43db9b887aacfcb45cb672a7e37683fe019962cf0864f5e94c6d471af47">,
      #splice.entry<"/build/gawk-5.4.1/vms/make_pcsi_gawk_kit_name.com" file 644 mtime 1782131302 "511969641584b3599846217bbdc2c2a0bef7d079959659d48d7c0370a3e71a89">,
      #splice.entry<"/build/gawk-5.4.1/vms/math.h" file 755 mtime 1782131302 "2288a4c915ffeb9e09732e89b12debcd588582face32a4fcc814a3f236b58caf">,
      #splice.entry<"/build/gawk-5.4.1/vms/pcsi_gawk_file_list.txt" file 644 mtime 1782131302 "68d0d1843c58d4501486ead251ae8db665c952b20c8f70f4623bedd8a0a739f1">,
      #splice.entry<"/build/gawk-5.4.1/vms/pcsi_product_gawk.com" file 644 mtime 1782131302 "86eae42eb3a5457af8239a9ff58b6322bdb085d1cbdf01bad1ddd3dc3a493eaf">,
      #splice.entry<"/build/gawk-5.4.1/vms/posix-cc.sh" file 755 mtime 1782131302 "c6ce8cdfe9e63d8adc531a4dff77557203b90055848172e82c7b6c5775ac1d97">,
      #splice.entry<"/build/gawk-5.4.1/vms/redirect.h" file 644 mtime 1783241692 "8c07eb6c0f181ce61fe668ee3c0dca3f8ec22e944fa11de2c9e3c6019927dcee">,
      #splice.entry<"/build/gawk-5.4.1/vms/remove_old_gawk.com" file 644 mtime 1782131302 "3800e725f8a9e464f91a371d70128373eeb03dd1641679c7c73cb19c0b6ba4b0">,
      #splice.entry<"/build/gawk-5.4.1/vms/stage_gawk_install.com" file 644 mtime 1782131302 "0e3ab127e0bcdc58b54100f6364d7bf7db485308a5897b0aefc97e824291e31e">,
      #splice.entry<"/build/gawk-5.4.1/vms/stdint.h" file 755 mtime 1782131302 "1235f7ee4bce6feba69f43ec77d484cedd6acce9e974d7e5ed6e20c6d9861565">,
      #splice.entry<"/build/gawk-5.4.1/vms/stdio.h" file 755 mtime 1782131302 "a5321079f15c19506b0eabfa6030a6fa566d09c2b0bed6c10d1f358215ba2b07">,
      #splice.entry<"/build/gawk-5.4.1/vms/unixlib.h" file 644 mtime 1782131302 "4f4dd249e69a87b63240602c653128f9c296d9563993e8526824fb78fc34331f">,
      #splice.entry<"/build/gawk-5.4.1/vms/varargs.h" file 644 mtime 1782131302 "f1b274844e34c5d6cd79676d67fa077bc06043c6d7b3875ac0bb594c2b2e7744">,
      #splice.entry<"/build/gawk-5.4.1/vms/vax" dir 755 mtime 1783615671>,
      #splice.entry<"/build/gawk-5.4.1/vms/vax/ChangeLog" file 644 mtime 1783615671 "ce3d6052fdc5856290822418d4efaf3626e8e8d961f4ad72d79da555705ce9d7">,
      #splice.entry<"/build/gawk-5.4.1/vms/vax/gawk_plugin_xfer.mar_exact" file 644 mtime 1782131302 "daa7aa5af7bcae270e9cd47358817f41ce83ad9534acf43062ced4274e306947">,
      #splice.entry<"/build/gawk-5.4.1/vms/vax/gawk_plugin_xfer.opt" file 644 mtime 1782131302 "eba281a5020b84836117011a31cf2a7bb5a72678586a83488b8e629ef3a1ff3a">,
      #splice.entry<"/build/gawk-5.4.1/vms/vax/macro32_exactcase.com" file 644 mtime 1782131302 "27df8fc72428c3e5dca788f0e7778bb195bd34bc403d0743fc539ae03ee5832c">,
      #splice.entry<"/build/gawk-5.4.1/vms/vax/macro32_exactcase.patch" file 644 mtime 1782131302 "406d6462b0eaaf447b97ad9854f8d703ebc093e40066a8bec40ff8290e42b22f">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms.h" file 644 mtime 1782131302 "7211b31350f544c89cf2bd23f5f25885a3c3b85d629a09631528d0d58dee9cc3">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_args.c" file 644 mtime 1783329604 "4c3ce0aa9e60fc808077e0d3c00a837420d49d4c690d6aaf3795343c06934672">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_cli.c" file 644 mtime 1783329604 "2ca4fc4d308ee9df3073f3d5bd387f80f9423b3a73072244cb0507d01d349bb0">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_crtl_init.c" file 644 mtime 1782131302 "7e2a70f6c231a6fde37210d7849b857c1156fa08b97310d45c241ec185c348cb">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_fwrite.c" file 644 mtime 1783329604 "d09be336c348f48e7842741f8f84fbba38fd7e12fdccc62717cdd6e2e33b2946">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_gawk.c" file 644 mtime 1783329604 "fc8628af4742c51d8ce4d7348e174b94b8e9d366ecc0d8192f78b490b3679edb">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_misc.c" file 644 mtime 1783329604 "490c9c819c9a6e7e4d2bf14d0b8c39d81f1647f7579ab6ec4aefb314ef918c84">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_popen.c" file 644 mtime 1783329604 "3d97fbb034f5142dba53aa61363c604b8298c9a80a3506baf865c1248a4ef6f7">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_printf.c" file 755 mtime 1783241692 "7b72267db93726faae147c072202dced3cbd3a5263c527dacf9b33d79aa0139a">,
      #splice.entry<"/build/gawk-5.4.1/vms/vms_sort.com" file 755 mtime 1782131302 "e0c25d562fe9b3087eceae034ce5e8e50fa51bffd7115f61b55cbab3d50df06a">,
      #splice.entry<"/build/gawk-5.4.1/vms/vmsbuild.com" file 644 mtime 1782131302 "a163e5b3e8b873ecc76a21b70694b73802c76f6f01afccca5ee128d32a53d1b0">,
      #splice.entry<"/build/gawk-5.4.1/vms/vmstest.com" file 644 mtime 1782131302 "66864ff9729e31117a9f14395a813aa20ec8500577644cb5f4c5e10554cc2676">
  ]
  %cat_patch_8932 = splice.copy "cat|patch" at 8932(%tar_xz_1467_0#4) -> <"/build/gawk-5.4.1/ChangeLog.orig" file 644 mtime 1783615671 "1adcf94e0bcefde5b926c17a6c0bbe87cac2169379fd4ab37c400df81560c6db">
  %cat_patch_8932_1:3 = splice.exec "cat|patch" at 8932(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467_0#4, %tar_xz_1467_0#40) -> [
      #splice.entry<"/build/gawk-5.4.1/ChangeLog" file 644 mtime 1795046400 "3d8638a29c260b13c39f8d8f60f540d9673653e46fd7bf9d03a8f9cd57d8ee35">,
      #splice.entry<"/build/gawk-5.4.1/ChangeLog.orig" file 644 mtime 1783615671 "1adcf94e0bcefde5b926c17a6c0bbe87cac2169379fd4ab37c400df81560c6db">,
      #splice.entry<"/build/gawk-5.4.1/awk.h" file 644 mtime 1795046400 "b0a1e2c1464117886ac506900dc3c76d38307da5d34498e3b52bcd0e2fa720c2">
  ]
  %glue_9037 = splice.literal "glue" at 9037 -> [
      #splice.entry<"/build/ar5k_9Qu" dir 700 mtime 1795046400>
  ]
  %mkdir_10150 = splice.literal "mkdir" at 10150 folded -> [
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98" dir 755 mtime 1795046400>
  ]
  %xz_tar_10162:24 = splice.exec "xz|tar" at 10162(%sandbox_720#0, %tar_xz_1467#0, %mkdir_10150) -> [
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2" dir 755 mtime 1586789293>,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/ABOUT-NLS" file 644 mtime 1586789273 "fbe8681a07eab3934d302edb4db8fbcea014b460232e3638e7f4cdb7da53e5aa">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/config.rpath" file 755 mtime 1586789293 "9153320951eac143ec6e2715fe660f0eb842a5a058bcbfef98870d114ed6f07a">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4" dir 755 mtime 1586789293>,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/gettext.m4" file 644 mtime 1586789277 "6b8ca63d019cf362cfeb9d4b52e7d431b4feb14d5f3f03f97bef824319c0375b">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/host-cpu-c-abi.m4" file 644 mtime 1586789277 "e57eed3ec16c8f4c3555469e1defe954a55ddcb45d3de4022f811f2cd3428f8a">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/iconv.m4" file 644 mtime 1586789277 "45d19e622dd2710126b3bd1376597a461309f26409be3bc0a640d5aabfc7edb8">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/intlmacosx.m4" file 644 mtime 1586789277 "fa6e64ba32baf3288d18c332fc4cc3746fc52de51a908d6fe8ed65a50445815f">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/lib-ld.m4" file 644 mtime 1586789277 "55d2a7427d8486e457b4a03c577299bf18116d98b9c8e58a1879f75ec10a0388">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/lib-link.m4" file 644 mtime 1586789277 "e9fd2728210c10668902329281cfa8430285180e964acc103f8c1a9a0e2c5f4f">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/lib-prefix.m4" file 644 mtime 1586789277 "7acf0b725120cdbe81415333685d196baea274c18aa8ad0380616498a1fe1fb6">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/nls.m4" file 644 mtime 1586789277 "f20554b3126292f1b1282ad31f219f52abe520e7ac53782944f54cc901e5c7d7">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/po.m4" file 644 mtime 1586789277 "2b0014754884aa7aaa581a9dd848ca83e3420781ad76ed2bef8a733e811ea112">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/m4/progtest.m4" file 644 mtime 1586789277 "9a3f23956f09b5555d37c657513316001f7d6de4bad0af531384fdf533f327e0">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po" dir 755 mtime 1586789293>,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/Makefile.in.in" file 644 mtime 1586789277 "b9146b0739ad3c5c319a4b072a02a8cdfd31f107376857cfb299fb2ea319784b">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/Makevars.template" file 644 mtime 1586789277 "d374f67b9c269f97539789e4dc464753cf263064eccb971a70e1e92d3955f4c2">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/Rules-quot" file 644 mtime 1586789277 "8ced8cd2b86458be88c38322db49df53f41f87200a79233ce34499cb031db0cd">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/boldquot.sed" file 644 mtime 1586789277 "33234736a58f1610c73e1c8c08faf1b2ef1397d878dd7d2cbd888ca0f2da4ffc">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/en@boldquot.header" file 644 mtime 1586789277 "99ad82767e9b1b4dd1e413664e06c686c8ab70eaadb129ac08a8b8b76f9173d2">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/en@quot.header" file 644 mtime 1586789277 "6f4df89908e6e413db10738ff01e0c7046922c2a4aa4f9e64d376235745a4af5">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/insert-header.sin" file 644 mtime 1586789277 "87041830aa4c5e87cedd35a2a95cf94c4e889604580481430b214422a5e8dc98">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/quot.sed" file 644 mtime 1586789277 "d19ab2cc69000c1206f1b8460952857f05d154158da8b89273ac2900a5c80ec0">,
      #splice.entry<"/build/gawk-5.4.1/tmpwrk98/gettext-0.20.2/po/remove-potcdate.sin" file 644 mtime 1586789277 "d582513385c800f75224f4041fbff207053d4229be6038c6810af382420ac362">
  ]
  %cp_11610 = splice.copy "cp" at 11610(%tar_xz_1467_0#157) -> <"/build/gawk-5.4.1/build-aux/config.rpath~" file 755 mtime 1782830234 "fc70d6138bc62e8ea8080602b607f38d56c4def03ec4d523d516b338cff41df9">
  %cp_11714 = splice.copy "cp" at 11714(%xz_tar_10162#2) -> <"/build/gawk-5.4.1/build-aux/config.rpath" file 755 mtime 1795046400 "9153320951eac143ec6e2715fe660f0eb842a5a058bcbfef98870d114ed6f07a">
  %cp_11991 = splice.copy "cp" at 11991(%xz_tar_10162#5) -> <"/build/gawk-5.4.1/m4/host-cpu-c-abi.m4" file 644 mtime 1795046400 "e57eed3ec16c8f4c3555469e1defe954a55ddcb45d3de4022f811f2cd3428f8a">
  %cp_12203 = splice.copy "cp" at 12203(%xz_tar_10162#6) -> <"/build/gawk-5.4.1/m4/iconv.m4" file 644 mtime 1795046400 "45d19e622dd2710126b3bd1376597a461309f26409be3bc0a640d5aabfc7edb8">
  %cp_12424 = splice.copy "cp" at 12424(%xz_tar_10162#7) -> <"/build/gawk-5.4.1/m4/intlmacosx.m4" file 644 mtime 1795046400 "fa6e64ba32baf3288d18c332fc4cc3746fc52de51a908d6fe8ed65a50445815f">
  %cp_12636 = splice.copy "cp" at 12636(%xz_tar_10162#8) -> <"/build/gawk-5.4.1/m4/lib-ld.m4" file 644 mtime 1795046400 "55d2a7427d8486e457b4a03c577299bf18116d98b9c8e58a1879f75ec10a0388">
  %cp_12848 = splice.copy "cp" at 12848(%xz_tar_10162#9) -> <"/build/gawk-5.4.1/m4/lib-link.m4" file 644 mtime 1795046400 "e9fd2728210c10668902329281cfa8430285180e964acc103f8c1a9a0e2c5f4f">
  %cp_13060 = splice.copy "cp" at 13060(%xz_tar_10162#10) -> <"/build/gawk-5.4.1/m4/lib-prefix.m4" file 644 mtime 1795046400 "7acf0b725120cdbe81415333685d196baea274c18aa8ad0380616498a1fe1fb6">
  %cp_13272 = splice.copy "cp" at 13272(%xz_tar_10162#11) -> <"/build/gawk-5.4.1/m4/nls.m4" file 644 mtime 1795046400 "f20554b3126292f1b1282ad31f219f52abe520e7ac53782944f54cc901e5c7d7">
  %cp_13560 = splice.copy "cp" at 13560(%xz_tar_10162#13) -> <"/build/gawk-5.4.1/m4/progtest.m4" file 644 mtime 1795046400 "9a3f23956f09b5555d37c657513316001f7d6de4bad0af531384fdf533f327e0">
  %cp_13785 = splice.copy "cp" at 13785(%xz_tar_10162#16) -> <"/build/gawk-5.4.1/po/Makevars.template" file 644 mtime 1795046400 "d374f67b9c269f97539789e4dc464753cf263064eccb971a70e1e92d3955f4c2">
  %aclocal_14331 = splice.literal "aclocal" at 14331 folded -> [
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache" dir 755 mtime 1795046402>
  ]
  %aclocal_14331_2:5 = splice.exec "aclocal" at 14331(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467_0#38, %tar_xz_1467_0#172, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#411, %tar_xz_1467_0#412, %tar_xz_1467_0#413, %tar_xz_1467_0#414, %tar_xz_1467_0#415, %cp_11991, %cp_12203, %tar_xz_1467_0#418, %tar_xz_1467_0#419, %tar_xz_1467_0#420, %cp_12424, %tar_xz_1467_0#422, %tar_xz_1467_0#423, %tar_xz_1467_0#424, %tar_xz_1467_0#425, %tar_xz_1467_0#426, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#431, %tar_xz_1467_0#432, %tar_xz_1467_0#433, %tar_xz_1467_0#434, %tar_xz_1467_0#435, %tar_xz_1467_0#436, %tar_xz_1467_0#437, %tar_xz_1467_0#438, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %tar_xz_1467_0#444, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#447, %tar_xz_1467_0#448, %tar_xz_1467_0#449, %tar_xz_1467_0#450, %tar_xz_1467_0#451, %tar_xz_1467_0#452, %tar_xz_1467_0#453, %tar_xz_1467_0#454, %tar_xz_1467_0#455, %tar_xz_1467_0#456, %tar_xz_1467_0#457) -> [
      #splice.entry<"/build/gawk-5.4.1/aclocal.m4" file 644 mtime 1795046402 "114acd0eccbecbcf257116f8572a73bd0bc650f41718c316fdd0332956c223aa">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache" dir 755 mtime 1795046402>,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/output.0" file 644 mtime 1795046402 "b6b7f7a24075b170ee34e0faff62cea93e64310a1289362a66f5eda8f0a4b37e">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/requests" file 644 mtime 1795046402 "d4fcd7c0c523255f04dc6afd0345bf82ec46f1227ed1739f56f6da189ec1828e">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/traces.0" file 644 mtime 1795046402 "d3f0530f0858849e3c4c1a073cc63a84d0e216bc35e5493220a83080f0ee3d7e">
  ]
  %autom4te_15108:3 = splice.exec "autom4te" at 15108(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %aclocal_14331_2#0, %aclocal_14331, %aclocal_14331_2#3, %tar_xz_1467_0#172, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#434, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#449, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/output.1" file 644 mtime 1795046403 "b6b7f7a24075b170ee34e0faff62cea93e64310a1289362a66f5eda8f0a4b37e">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/requests" file 644 mtime 1795046403 "568b4cbd0e0161d3ab47ffd1b31a2e34787c654a6b8a4df824052bb4344134ce">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/traces.1" file 644 mtime 1795046403 "d9a98fe5a806db05d8151cd9281756f9f3e284db8be677cec4886d9d9c5f06b3">
  ]
  %mkdir_16450 = splice.literal "mkdir" at 16450 folded -> [
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491" dir 755 mtime 1795046403>
  ]
  %xz_tar_16462:24 = splice.exec "xz|tar" at 16462(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_16450) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2" dir 755 mtime 1586789293>,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/ABOUT-NLS" file 644 mtime 1586789273 "fbe8681a07eab3934d302edb4db8fbcea014b460232e3638e7f4cdb7da53e5aa">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/config.rpath" file 755 mtime 1586789293 "9153320951eac143ec6e2715fe660f0eb842a5a058bcbfef98870d114ed6f07a">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4" dir 755 mtime 1586789293>,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/gettext.m4" file 644 mtime 1586789277 "6b8ca63d019cf362cfeb9d4b52e7d431b4feb14d5f3f03f97bef824319c0375b">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/host-cpu-c-abi.m4" file 644 mtime 1586789277 "e57eed3ec16c8f4c3555469e1defe954a55ddcb45d3de4022f811f2cd3428f8a">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/iconv.m4" file 644 mtime 1586789277 "45d19e622dd2710126b3bd1376597a461309f26409be3bc0a640d5aabfc7edb8">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/intlmacosx.m4" file 644 mtime 1586789277 "fa6e64ba32baf3288d18c332fc4cc3746fc52de51a908d6fe8ed65a50445815f">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/lib-ld.m4" file 644 mtime 1586789277 "55d2a7427d8486e457b4a03c577299bf18116d98b9c8e58a1879f75ec10a0388">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/lib-link.m4" file 644 mtime 1586789277 "e9fd2728210c10668902329281cfa8430285180e964acc103f8c1a9a0e2c5f4f">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/lib-prefix.m4" file 644 mtime 1586789277 "7acf0b725120cdbe81415333685d196baea274c18aa8ad0380616498a1fe1fb6">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/nls.m4" file 644 mtime 1586789277 "f20554b3126292f1b1282ad31f219f52abe520e7ac53782944f54cc901e5c7d7">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/po.m4" file 644 mtime 1586789277 "2b0014754884aa7aaa581a9dd848ca83e3420781ad76ed2bef8a733e811ea112">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/m4/progtest.m4" file 644 mtime 1586789277 "9a3f23956f09b5555d37c657513316001f7d6de4bad0af531384fdf533f327e0">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po" dir 755 mtime 1586789293>,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/Makefile.in.in" file 644 mtime 1586789277 "b9146b0739ad3c5c319a4b072a02a8cdfd31f107376857cfb299fb2ea319784b">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/Makevars.template" file 644 mtime 1586789277 "d374f67b9c269f97539789e4dc464753cf263064eccb971a70e1e92d3955f4c2">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/Rules-quot" file 644 mtime 1586789277 "8ced8cd2b86458be88c38322db49df53f41f87200a79233ce34499cb031db0cd">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/boldquot.sed" file 644 mtime 1586789277 "33234736a58f1610c73e1c8c08faf1b2ef1397d878dd7d2cbd888ca0f2da4ffc">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/en@boldquot.header" file 644 mtime 1586789277 "99ad82767e9b1b4dd1e413664e06c686c8ab70eaadb129ac08a8b8b76f9173d2">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/en@quot.header" file 644 mtime 1586789277 "6f4df89908e6e413db10738ff01e0c7046922c2a4aa4f9e64d376235745a4af5">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/insert-header.sin" file 644 mtime 1586789277 "87041830aa4c5e87cedd35a2a95cf94c4e889604580481430b214422a5e8dc98">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/quot.sed" file 644 mtime 1586789277 "d19ab2cc69000c1206f1b8460952857f05d154158da8b89273ac2900a5c80ec0">,
      #splice.entry<"/build/gawk-5.4.1/extension/tmpwrk491/gettext-0.20.2/po/remove-potcdate.sin" file 644 mtime 1586789277 "d582513385c800f75224f4041fbff207053d4229be6038c6810af382420ac362">
  ]
  %cp_18702 = splice.copy "cp" at 18702(%xz_tar_16462#16) -> <"/build/gawk-5.4.1/extension/po/Makevars.template" file 644 mtime 1795046403 "d374f67b9c269f97539789e4dc464753cf263064eccb971a70e1e92d3955f4c2">
  %aclocal_19246 = splice.literal "aclocal" at 19246 folded -> [
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache" dir 755 mtime 1795046405>
  ]
  %aclocal_19246_3:5 = splice.exec "aclocal" at 19246(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467#8, %tar_xz_1467_0#336, %tar_xz_1467_0#339, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#411, %tar_xz_1467_0#412, %tar_xz_1467_0#413, %tar_xz_1467_0#414, %tar_xz_1467_0#415, %cp_11991, %cp_12203, %tar_xz_1467_0#418, %tar_xz_1467_0#419, %tar_xz_1467_0#420, %cp_12424, %tar_xz_1467_0#422, %tar_xz_1467_0#423, %tar_xz_1467_0#424, %tar_xz_1467_0#425, %tar_xz_1467_0#426, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#431, %tar_xz_1467_0#432, %tar_xz_1467_0#433, %tar_xz_1467_0#434, %tar_xz_1467_0#435, %tar_xz_1467_0#436, %tar_xz_1467_0#437, %tar_xz_1467_0#438, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %tar_xz_1467_0#444, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#447, %tar_xz_1467_0#448, %tar_xz_1467_0#449, %tar_xz_1467_0#450, %tar_xz_1467_0#451, %tar_xz_1467_0#452, %tar_xz_1467_0#453, %tar_xz_1467_0#454, %tar_xz_1467_0#455, %tar_xz_1467_0#456, %tar_xz_1467_0#457) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/aclocal.m4" file 644 mtime 1795046405 "489544529a9aa047aea9b70195562a86fbc9a66317cfc440232a59f7afcb0747">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache" dir 755 mtime 1795046405>,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/output.0" file 644 mtime 1795046405 "b7a34319f1f3b62a76cda14cc80272e6557e9f6591805ae0a74e0e92af480785">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/requests" file 644 mtime 1795046405 "e43c1e3e17a83c9e3c3c8560b6d1eed7be641887aa970e596312ed1874245ec3">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/traces.0" file 644 mtime 1795046405 "9c70a6c665f30814d2d78bbee624780db629a6b1b66d7fc38114f433ef589b55">
  ]
  %autom4te_20012:3 = splice.exec "autom4te" at 20012(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467#8, %aclocal_19246_3#0, %aclocal_19246, %aclocal_19246_3#3, %tar_xz_1467_0#339, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#431, %tar_xz_1467_0#435, %tar_xz_1467_0#436, %tar_xz_1467_0#437, %tar_xz_1467_0#438, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/output.1" file 644 mtime 1795046406 "b7a34319f1f3b62a76cda14cc80272e6557e9f6591805ae0a74e0e92af480785">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/requests" file 644 mtime 1795046406 "3189fb77cd6017d7dbeacf7826bd306a7a38563d34baa20e1f8fb6ca01168633">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/traces.1" file 644 mtime 1795046405 "309f14af86f880312be16b48991f242c009c41f7718805a444ea7344b47387b9">
  ]
  %cp_21444 = splice.exec "cp" at 21444(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#5, %tar_xz_1467#8) -> [
      #splice.entry<"/build/gawk-5.4.1/build-aux/ltmain.sh" file 444 mtime 1795046406 "1473fd999be7bb9a36d9d6eeac9fbfe4ed63902fc8c0a64c722559da4a46da95">
  ]
  %cp_21891 = splice.exec "cp" at 21891(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %tar_xz_1467#11) -> [
      #splice.entry<"/build/gawk-5.4.1/m4/libtool.m4" file 444 mtime 1795046406 "3ab7a300db14a3aa7d1986dcec78ec21fbaaea614ca7d82c2f39a73ba0552c4a">
  ]
  %cp_22189 = splice.exec "cp" at 22189(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %tar_xz_1467#11) -> [
      #splice.entry<"/build/gawk-5.4.1/m4/ltoptions.m4" file 444 mtime 1795046406 "2b725d300784a63d5e71aaeac011e11b5b22f6f6017c29967085447632a7e0ae">
  ]
  %cp_22514 = splice.exec "cp" at 22514(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %tar_xz_1467#11) -> [
      #splice.entry<"/build/gawk-5.4.1/m4/ltsugar.m4" file 444 mtime 1795046406 "8a19df00dbbbb911d0e633d88e53c1bdce4b722469d43a105ed2d77e8a7b4dd8">
  ]
  %cp_22845 = splice.exec "cp" at 22845(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %tar_xz_1467#11) -> [
      #splice.entry<"/build/gawk-5.4.1/m4/ltversion.m4" file 444 mtime 1795046406 "0275a2fb0b5f0cf402a9e03bfa99722da9f603ca03d81ba911ae7573558577dc">
  ]
  %cp_23184 = splice.exec "cp" at 23184(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %tar_xz_1467#11) -> [
      #splice.entry<"/build/gawk-5.4.1/m4/lt~obsolete.m4" file 444 mtime 1795046406 "e35bdbd17dcd0216a2b8a6148ffb5edb941e27f8f90eba8ba7c520043821af4e">
  ]
  %aclocal_23618 = splice.copy "aclocal" at 23618(%aclocal_19246_3#0) -> <"/build/gawk-5.4.1/extension/aclocal.m4" file 644 mtime 1795046407 "489544529a9aa047aea9b70195562a86fbc9a66317cfc440232a59f7afcb0747">
  %aclocal_23618_4:4 = splice.exec "aclocal" at 23618(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467#8, %aclocal_19246_3#0, %aclocal_19246, %aclocal_19246_3#2, %autom4te_20012#1, %aclocal_19246_3#4, %tar_xz_1467_0#339, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#411, %tar_xz_1467_0#412, %tar_xz_1467_0#413, %tar_xz_1467_0#414, %tar_xz_1467_0#415, %cp_11991, %cp_12203, %tar_xz_1467_0#418, %tar_xz_1467_0#419, %tar_xz_1467_0#420, %cp_12424, %tar_xz_1467_0#422, %tar_xz_1467_0#423, %tar_xz_1467_0#424, %tar_xz_1467_0#425, %tar_xz_1467_0#426, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %cp_21891, %tar_xz_1467_0#432, %tar_xz_1467_0#433, %tar_xz_1467_0#434, %cp_22189, %cp_22514, %cp_22845, %cp_23184, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %tar_xz_1467_0#444, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#447, %tar_xz_1467_0#448, %tar_xz_1467_0#449, %tar_xz_1467_0#450, %tar_xz_1467_0#451, %tar_xz_1467_0#452, %tar_xz_1467_0#453, %tar_xz_1467_0#454, %tar_xz_1467_0#455, %tar_xz_1467_0#456, %tar_xz_1467_0#457) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/aclocal.m4" file 644 mtime 1795046407 "489544529a9aa047aea9b70195562a86fbc9a66317cfc440232a59f7afcb0747">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/output.0" file 644 mtime 1795046406 "abd26b1035cbb08cc14baf4b46e9c6abc21356dcf8ad720d397a11355d06daed">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/requests" file 644 mtime 1795046407 "5f4735eb7b20816cad2939e8739f37cc7d52a30bcbd15ce5760eda3346c3d634">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/traces.0" file 644 mtime 1795046406 "76454d7b290a9c93231e1fce0e56a3e59608ceeceecc54fbf74d18ae804904e8">
  ]
  %autom4te_24370 = splice.copy "autom4te" at 24370(%tar_xz_1467_0#338) -> <"/build/gawk-5.4.1/extension/configure~" file 755 mtime 1783615727 "52d694871263d8d24924b7663d12950b0f7d6ba692ca79f86e3d24b031f660ac">
  %autom4te_24370_5:5 = splice.exec "autom4te" at 24370(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467#8, %aclocal_23618, %aclocal_19246, %aclocal_23618_4#2, %tar_xz_1467_0#338, %tar_xz_1467_0#339, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %cp_21891, %cp_22189, %cp_22514, %cp_22845, %cp_23184, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/output.2" file 644 mtime 1795046407 "f14a1176c51b41c5565f3b45e7f63b800c625a5b9cf3f71141a0417edcc15de5">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/requests" file 644 mtime 1795046407 "3effd599762cdb7e6217b227e6230bd1efe8c5cb00a0feba1b99fb838294982e">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/traces.2" file 644 mtime 1795046407 "309f14af86f880312be16b48991f242c009c41f7718805a444ea7344b47387b9">,
      #splice.entry<"/build/gawk-5.4.1/extension/configure" file 755 mtime 1795046407 "6e265a7b88145312d4b2bf58f06306acaad153b9e9cc731b3d2e738af370016f">,
      #splice.entry<"/build/gawk-5.4.1/extension/configure~" file 755 mtime 1783615727 "52d694871263d8d24924b7663d12950b0f7d6ba692ca79f86e3d24b031f660ac">
  ]
  %autoheader_24625 = splice.copy "autoheader" at 24625(%autom4te_24370_5#1) -> <"/build/gawk-5.4.1/extension/autom4te.cache/requests" file 644 mtime 1795046408 "3effd599762cdb7e6217b227e6230bd1efe8c5cb00a0feba1b99fb838294982e">
  %autoheader_24625_6 = splice.copy "autoheader" at 24625(%autom4te_20012#2) -> <"/build/gawk-5.4.1/extension/autom4te.cache/traces.1" file 644 mtime 1795046407 "309f14af86f880312be16b48991f242c009c41f7718805a444ea7344b47387b9">
  %autoheader_24625_7 = splice.copy "autoheader" at 24625(%tar_xz_1467_0#337) -> <"/build/gawk-5.4.1/extension/configh.in~" file 644 mtime 1783615732 "5c5b1466b6da98ac95a0c065d326e465a697ff4ab610a66507d56829d275f47f">
  %autoheader_24625_8:5 = splice.exec "autoheader" at 24625(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467#8, %aclocal_23618, %aclocal_19246, %autom4te_20012#0, %autom4te_24370_5#1, %autom4te_20012#2, %tar_xz_1467_0#337, %tar_xz_1467_0#339, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %cp_21891, %cp_22189, %cp_22514, %cp_22845, %cp_23184, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/output.1" file 644 mtime 1795046408 "abd26b1035cbb08cc14baf4b46e9c6abc21356dcf8ad720d397a11355d06daed">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/requests" file 644 mtime 1795046408 "3effd599762cdb7e6217b227e6230bd1efe8c5cb00a0feba1b99fb838294982e">,
      #splice.entry<"/build/gawk-5.4.1/extension/autom4te.cache/traces.1" file 644 mtime 1795046407 "309f14af86f880312be16b48991f242c009c41f7718805a444ea7344b47387b9">,
      #splice.entry<"/build/gawk-5.4.1/extension/configh.in" file 644 mtime 1795046408 "76b1e642c72106ac9b7640b935789af09395fa548a37db7f33beeb6c633b5bb4">,
      #splice.entry<"/build/gawk-5.4.1/extension/configh.in~" file 644 mtime 1783615732 "5c5b1466b6da98ac95a0c065d326e465a697ff4ab610a66507d56829d275f47f">
  ]
  %automake_24905 = splice.copy "automake" at 24905(%tar_xz_1467_0#160) -> <"/build/gawk-5.4.1/build-aux/install-sh" file 555 mtime 1795046408 "776876b3909b096439109a4c7642eb0f9100f6ba3fb42fa93d05351e50a0a7ef">
  %automake_24905_9:9 = splice.exec "automake" at 24905(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467#5, %tar_xz_1467_0#153, %tar_xz_1467_0#154, %tar_xz_1467_0#156, %cp_11714, %cp_11610, %tar_xz_1467_0#158, %tar_xz_1467_0#160, %cp_21444, %tar_xz_1467_0#163, %tar_xz_1467_0#164, %tar_xz_1467#8, %tar_xz_1467_0#324, %tar_xz_1467_0#325, %tar_xz_1467_0#326, %tar_xz_1467_0#327, %tar_xz_1467_0#328, %tar_xz_1467_0#329, %tar_xz_1467_0#330, %tar_xz_1467_0#331, %tar_xz_1467_0#332, %tar_xz_1467_0#333, %tar_xz_1467_0#334, %tar_xz_1467_0#335, %aclocal_23618, %aclocal_19246, %autoheader_24625_8#0, %autoheader_24625, %autoheader_24625_6, %autoheader_24625_8#3, %autoheader_24625_7, %autom4te_24370_5#3, %tar_xz_1467_0#339, %autom4te_24370, %tar_xz_1467_0#340, %tar_xz_1467_0#341, %tar_xz_1467_0#342, %tar_xz_1467_0#343, %tar_xz_1467_0#344, %tar_xz_1467_0#345, %tar_xz_1467_0#346, %tar_xz_1467_0#347, %tar_xz_1467_0#348, %tar_xz_1467_0#349, %tar_xz_1467_0#350, %tar_xz_1467_0#351, %tar_xz_1467_0#352, %tar_xz_1467_0#353, %tar_xz_1467_0#354, %tar_xz_1467_0#355, %tar_xz_1467_0#356, %tar_xz_1467#9, %tar_xz_1467_0#370, %tar_xz_1467_0#371, %tar_xz_1467_0#372, %tar_xz_1467_0#373, %tar_xz_1467_0#374, %tar_xz_1467_0#375, %tar_xz_1467_0#376, %tar_xz_1467_0#377, %tar_xz_1467_0#378, %tar_xz_1467_0#379, %tar_xz_1467_0#380, %tar_xz_1467_0#381, %tar_xz_1467_0#382, %tar_xz_1467_0#383, %tar_xz_1467_0#384, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#409, %tar_xz_1467_0#410, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %cp_21891, %cp_22189, %cp_22514, %cp_22845, %cp_23184, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/build-aux/ar-lib" file 555 mtime 1795046408 "8e211dd0df621bf4985c1d3466548564a835e379acfc12dc0c1009ced4f90417">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/compile" file 555 mtime 1795046408 "92ed7feeda61ad958dc3c4cc4efd724e1414482f1cad60b74b09e0633a93dfd6">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.guess" file 555 mtime 1795046408 "641cae3c0c74c49354d3ede009f3febd80febe1501a77c1d9fac8d42cc45b6cb">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.sub" file 555 mtime 1795046408 "fe3a2f32fbaff57848732549f48d983fd6526024ec2f0f5a9dc75c2f4359a3a6">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/depcomp" file 555 mtime 1795046408 "ac3ae010382a83144ff6ec1a4c368a3f16a14ea2b12751aa73ddfb548d931574">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/install-sh" file 555 mtime 1795046408 "776876b3909b096439109a4c7642eb0f9100f6ba3fb42fa93d05351e50a0a7ef">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/missing" file 555 mtime 1795046408 "4f17c4a66ec5b8000d44573a576f6b5d9c0c84848e8fd1286f84a52f439db4e9">,
      #splice.entry<"/build/gawk-5.4.1/extension/INSTALL" file 444 mtime 1795046408 "8269293b2738175f54354957d64f691ea9a55ffacb9d8912c79060a9b9bf769b">,
      #splice.entry<"/build/gawk-5.4.1/extension/Makefile.in" file 644 mtime 1795046408 "5dee15676a7cc0cacba5f6d5dde36c2ec3cd17a5900355516d5496aad6f774e3">
  ]
  %autom4te_25318 = splice.copy "autom4te" at 25318(%tar_xz_1467_0#171) -> <"/build/gawk-5.4.1/configure~" file 755 mtime 1783615715 "d04365f773b20e2e0ceaf6c2b5c696a1858730c18ccad3602a1afdbc1b408af6">
  %autom4te_25318_10:5 = splice.exec "autom4te" at 25318(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %aclocal_14331_2#0, %aclocal_14331, %autom4te_15108#1, %tar_xz_1467_0#171, %tar_xz_1467_0#172, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#434, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#449, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/output.2" file 644 mtime 1795046408 "ea5d9bd2ee87562bb116c6a560ef7409d7379ebda9783337b2c6376d8180fbec">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/requests" file 644 mtime 1795046408 "c5cda5730090a1b5ce31a26493e838531609e6bf4651e2ea17380e9d0f8937a3">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/traces.2" file 644 mtime 1795046408 "d9a98fe5a806db05d8151cd9281756f9f3e284db8be677cec4886d9d9c5f06b3">,
      #splice.entry<"/build/gawk-5.4.1/configure" file 755 mtime 1795046408 "c35d7fe2c9f68e3bbbfa493ee9b9c89e480edd49048158b3805f6d2f520e83c2">,
      #splice.entry<"/build/gawk-5.4.1/configure~" file 755 mtime 1783615715 "d04365f773b20e2e0ceaf6c2b5c696a1858730c18ccad3602a1afdbc1b408af6">
  ]
  %autoheader_25580 = splice.copy "autoheader" at 25580(%autom4te_15108#0) -> <"/build/gawk-5.4.1/autom4te.cache/output.1" file 644 mtime 1795046408 "b6b7f7a24075b170ee34e0faff62cea93e64310a1289362a66f5eda8f0a4b37e">
  %autoheader_25580_11 = splice.copy "autoheader" at 25580(%autom4te_15108#2) -> <"/build/gawk-5.4.1/autom4te.cache/traces.1" file 644 mtime 1795046408 "d9a98fe5a806db05d8151cd9281756f9f3e284db8be677cec4886d9d9c5f06b3">
  %autoheader_25580_12 = splice.copy "autoheader" at 25580(%tar_xz_1467_0#170) -> <"/build/gawk-5.4.1/configh.in~" file 644 mtime 1783615722 "ad0eefb133a3ee539d77a0ddfba71291fb66b0115644cbc4e21a11798a69cb9d">
  %autoheader_25580_13:4 = splice.exec "autoheader" at 25580(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %aclocal_14331_2#0, %aclocal_14331, %autom4te_15108#0, %autom4te_15108#2, %tar_xz_1467_0#170, %tar_xz_1467_0#172, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#434, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#449, %tar_xz_1467_0#452) -> [
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/output.1" file 644 mtime 1795046408 "b6b7f7a24075b170ee34e0faff62cea93e64310a1289362a66f5eda8f0a4b37e">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/traces.1" file 644 mtime 1795046408 "d9a98fe5a806db05d8151cd9281756f9f3e284db8be677cec4886d9d9c5f06b3">,
      #splice.entry<"/build/gawk-5.4.1/configh.in" file 644 mtime 1795046408 "f7746aad35b54bf1f8cd7aa6cf4cc2aa1b5329bf37f346bb48d11ac72e60993d">,
      #splice.entry<"/build/gawk-5.4.1/configh.in~" file 644 mtime 1783615722 "ad0eefb133a3ee539d77a0ddfba71291fb66b0115644cbc4e21a11798a69cb9d">
  ]
  %automake_25858 = splice.copy "automake" at 25858(%automake_24905_9#0) -> <"/build/gawk-5.4.1/build-aux/ar-lib" file 555 mtime 1795046409 "8e211dd0df621bf4985c1d3466548564a835e379acfc12dc0c1009ced4f90417">
  %automake_25858_14 = splice.copy "automake" at 25858(%automake_24905_9#1) -> <"/build/gawk-5.4.1/build-aux/compile" file 555 mtime 1795046409 "92ed7feeda61ad958dc3c4cc4efd724e1414482f1cad60b74b09e0633a93dfd6">
  %automake_25858_15 = splice.copy "automake" at 25858(%automake_24905_9#2) -> <"/build/gawk-5.4.1/build-aux/config.guess" file 555 mtime 1795046409 "641cae3c0c74c49354d3ede009f3febd80febe1501a77c1d9fac8d42cc45b6cb">
  %automake_25858_16 = splice.copy "automake" at 25858(%automake_24905_9#3) -> <"/build/gawk-5.4.1/build-aux/config.sub" file 555 mtime 1795046409 "fe3a2f32fbaff57848732549f48d983fd6526024ec2f0f5a9dc75c2f4359a3a6">
  %automake_25858_17 = splice.copy "automake" at 25858(%tar_xz_1467_0#160) -> <"/build/gawk-5.4.1/build-aux/install-sh" file 555 mtime 1795046409 "776876b3909b096439109a4c7642eb0f9100f6ba3fb42fa93d05351e50a0a7ef">
  %automake_25858_18 = splice.copy "automake" at 25858(%automake_24905_9#6) -> <"/build/gawk-5.4.1/build-aux/missing" file 555 mtime 1795046409 "4f17c4a66ec5b8000d44573a576f6b5d9c0c84848e8fd1286f84a52f439db4e9">
  %automake_25858_19:17 = splice.exec "automake" at 25858(%sandbox_720#0, %glue_9037, %tar_xz_1467#0, %tar_xz_1467_0#1, %tar_xz_1467_0#2, %tar_xz_1467_0#3, %cat_patch_8932_1#0, %tar_xz_1467_0#5, %tar_xz_1467_0#6, %cat_patch_8932, %tar_xz_1467_0#7, %tar_xz_1467_0#8, %tar_xz_1467_0#9, %tar_xz_1467_0#10, %tar_xz_1467_0#11, %tar_xz_1467_0#12, %tar_xz_1467_0#13, %tar_xz_1467_0#14, %tar_xz_1467#1, %tar_xz_1467_0#37, %aclocal_14331_2#0, %tar_xz_1467_0#39, %aclocal_14331, %autoheader_25580, %autom4te_25318_10#1, %autoheader_25580_11, %cat_patch_8932_1#2, %tar_xz_1467_0#41, %tar_xz_1467_0#42, %tar_xz_1467#2, %tar_xz_1467_0#44, %tar_xz_1467_0#45, %tar_xz_1467_0#46, %tar_xz_1467_0#47, %tar_xz_1467_0#48, %tar_xz_1467#3, %tar_xz_1467_0#150, %tar_xz_1467_0#151, %tar_xz_1467#5, %tar_xz_1467_0#153, %automake_24905_9#0, %automake_24905_9#1, %automake_24905_9#2, %cp_11714, %cp_11610, %automake_24905_9#3, %automake_24905_9#4, %automake_24905, %cp_21444, %automake_24905_9#6, %tar_xz_1467_0#163, %tar_xz_1467_0#164, %tar_xz_1467_0#165, %tar_xz_1467_0#166, %tar_xz_1467_0#167, %tar_xz_1467_0#168, %tar_xz_1467_0#169, %autoheader_25580_13#2, %autoheader_25580_12, %autom4te_25318_10#3, %tar_xz_1467_0#172, %autom4te_25318, %tar_xz_1467_0#173, %tar_xz_1467_0#174, %tar_xz_1467#6, %tar_xz_1467_0#176, %tar_xz_1467_0#177, %tar_xz_1467_0#178, %tar_xz_1467_0#179, %tar_xz_1467_0#180, %tar_xz_1467_0#181, %tar_xz_1467_0#182, %tar_xz_1467_0#183, %tar_xz_1467_0#184, %tar_xz_1467_0#185, %tar_xz_1467_0#186, %tar_xz_1467_0#187, %tar_xz_1467_0#188, %tar_xz_1467_0#189, %tar_xz_1467_0#190, %tar_xz_1467_0#191, %tar_xz_1467_0#192, %tar_xz_1467_0#193, %tar_xz_1467_0#194, %tar_xz_1467_0#195, %tar_xz_1467_0#196, %tar_xz_1467_0#197, %tar_xz_1467_0#198, %tar_xz_1467_0#199, %tar_xz_1467_0#200, %tar_xz_1467_0#201, %tar_xz_1467_0#202, %tar_xz_1467_0#203, %tar_xz_1467_0#204, %tar_xz_1467_0#205, %tar_xz_1467_0#206, %tar_xz_1467_0#207, %tar_xz_1467_0#208, %tar_xz_1467_0#209, %tar_xz_1467_0#210, %tar_xz_1467_0#211, %tar_xz_1467_0#212, %tar_xz_1467_0#213, %tar_xz_1467_0#214, %tar_xz_1467_0#215, %tar_xz_1467_0#216, %tar_xz_1467_0#217, %tar_xz_1467_0#218, %tar_xz_1467_0#219, %tar_xz_1467_0#220, %tar_xz_1467_0#221, %tar_xz_1467_0#222, %tar_xz_1467_0#223, %tar_xz_1467_0#224, %tar_xz_1467_0#225, %tar_xz_1467_0#226, %tar_xz_1467_0#227, %tar_xz_1467_0#228, %tar_xz_1467_0#229, %tar_xz_1467_0#230, %tar_xz_1467_0#231, %tar_xz_1467_0#232, %tar_xz_1467_0#233, %tar_xz_1467_0#234, %tar_xz_1467_0#235, %tar_xz_1467_0#236, %tar_xz_1467_0#237, %tar_xz_1467_0#238, %tar_xz_1467_0#239, %tar_xz_1467_0#240, %tar_xz_1467_0#241, %tar_xz_1467_0#242, %tar_xz_1467_0#243, %tar_xz_1467_0#244, %tar_xz_1467#7, %tar_xz_1467_0#298, %tar_xz_1467_0#299, %tar_xz_1467_0#300, %tar_xz_1467_0#301, %tar_xz_1467_0#302, %tar_xz_1467_0#303, %tar_xz_1467_0#304, %tar_xz_1467_0#305, %tar_xz_1467_0#306, %tar_xz_1467_0#307, %tar_xz_1467_0#308, %tar_xz_1467_0#309, %tar_xz_1467_0#310, %tar_xz_1467_0#311, %tar_xz_1467_0#312, %tar_xz_1467_0#313, %tar_xz_1467_0#314, %tar_xz_1467_0#315, %tar_xz_1467_0#316, %tar_xz_1467_0#317, %tar_xz_1467_0#318, %tar_xz_1467_0#319, %tar_xz_1467_0#320, %tar_xz_1467_0#321, %tar_xz_1467_0#322, %tar_xz_1467#8, %tar_xz_1467#10, %tar_xz_1467_0#386, %tar_xz_1467_0#387, %tar_xz_1467_0#388, %tar_xz_1467_0#389, %tar_xz_1467_0#390, %tar_xz_1467_0#391, %tar_xz_1467_0#392, %tar_xz_1467_0#393, %tar_xz_1467_0#394, %tar_xz_1467_0#395, %tar_xz_1467_0#396, %tar_xz_1467_0#397, %tar_xz_1467_0#398, %tar_xz_1467_0#399, %tar_xz_1467_0#400, %tar_xz_1467_0#401, %tar_xz_1467#11, %tar_xz_1467_0#406, %tar_xz_1467_0#407, %tar_xz_1467_0#408, %tar_xz_1467_0#409, %tar_xz_1467_0#413, %cp_11991, %cp_12203, %cp_12424, %tar_xz_1467_0#427, %cp_12636, %cp_12848, %cp_13060, %tar_xz_1467_0#434, %tar_xz_1467_0#439, %cp_13272, %tar_xz_1467_0#441, %tar_xz_1467_0#442, %tar_xz_1467_0#443, %cp_13560, %tar_xz_1467_0#446, %tar_xz_1467_0#449, %tar_xz_1467_0#452, %tar_xz_1467_0#458, %tar_xz_1467#12, %tar_xz_1467_0#476, %tar_xz_1467_0#477, %tar_xz_1467_0#478, %tar_xz_1467_0#479, %tar_xz_1467#13, %tar_xz_1467#14, %tar_xz_1467#15, %tar_xz_1467_0#576, %tar_xz_1467_0#577, %tar_xz_1467_0#578, %tar_xz_1467_0#579, %tar_xz_1467_0#580, %tar_xz_1467#16, %tar_xz_1467_0#582, %tar_xz_1467_0#583, %tar_xz_1467_0#584, %tar_xz_1467_0#585, %tar_xz_1467_0#586, %tar_xz_1467_0#587, %tar_xz_1467_0#588, %tar_xz_1467_0#589, %tar_xz_1467_0#590, %tar_xz_1467_0#591, %tar_xz_1467_0#592, %tar_xz_1467_0#593, %tar_xz_1467_0#594, %tar_xz_1467_0#595, %tar_xz_1467_0#596, %tar_xz_1467_0#597, %tar_xz_1467_0#598, %tar_xz_1467_0#599, %tar_xz_1467_0#600, %tar_xz_1467_0#601, %tar_xz_1467_0#602, %tar_xz_1467_0#603, %tar_xz_1467#17, %tar_xz_1467_0#612, %tar_xz_1467_0#613, %tar_xz_1467_0#614, %tar_xz_1467_0#615, %tar_xz_1467_0#616, %tar_xz_1467_0#617, %tar_xz_1467_0#618, %tar_xz_1467_0#619, %tar_xz_1467_0#620, %tar_xz_1467_0#621, %tar_xz_1467_0#622, %tar_xz_1467_0#623, %tar_xz_1467_0#624, %tar_xz_1467_0#625, %tar_xz_1467_0#626, %tar_xz_1467#18, %tar_xz_1467_0#628, %tar_xz_1467_0#629, %tar_xz_1467_0#630, %tar_xz_1467_0#631, %tar_xz_1467_0#632, %tar_xz_1467_0#633, %tar_xz_1467_0#634, %tar_xz_1467_0#635, %tar_xz_1467_0#636, %tar_xz_1467_0#637, %tar_xz_1467_0#638, %tar_xz_1467_0#639, %tar_xz_1467_0#640, %tar_xz_1467_0#641, %tar_xz_1467_0#642, %tar_xz_1467_0#643, %tar_xz_1467_0#644, %tar_xz_1467_0#645, %tar_xz_1467_0#646, %tar_xz_1467_0#647, %tar_xz_1467_0#648, %tar_xz_1467_0#649, %tar_xz_1467_0#650, %tar_xz_1467_0#651, %tar_xz_1467_0#652, %tar_xz_1467_0#653, %tar_xz_1467_0#654, %tar_xz_1467_0#655, %tar_xz_1467_0#656, %tar_xz_1467_0#657, %tar_xz_1467_0#658, %tar_xz_1467_0#659, %tar_xz_1467_0#660, %tar_xz_1467_0#661, %tar_xz_1467_0#662, %tar_xz_1467_0#663, %tar_xz_1467_0#664, %tar_xz_1467_0#665, %tar_xz_1467_0#666, %tar_xz_1467_0#667, %tar_xz_1467_0#668, %tar_xz_1467_0#669, %tar_xz_1467_0#670, %tar_xz_1467_0#671, %tar_xz_1467_0#672, %tar_xz_1467_0#673, %tar_xz_1467_0#674, %tar_xz_1467_0#675, %tar_xz_1467_0#676, %tar_xz_1467_0#677, %tar_xz_1467_0#678, %tar_xz_1467_0#679, %tar_xz_1467_0#680, %tar_xz_1467_0#681, %tar_xz_1467_0#682, %tar_xz_1467_0#683, %tar_xz_1467_0#684, %tar_xz_1467_0#685, %tar_xz_1467#19, %tar_xz_1467_0#687, %tar_xz_1467_0#688, %tar_xz_1467_0#689, %tar_xz_1467_0#690, %tar_xz_1467_0#691, %tar_xz_1467_0#692, %tar_xz_1467_0#693, %tar_xz_1467_0#694, %tar_xz_1467_0#695, %tar_xz_1467_0#696, %tar_xz_1467_0#697, %tar_xz_1467_0#698, %tar_xz_1467_0#699, %tar_xz_1467_0#700, %tar_xz_1467_0#701, %tar_xz_1467_0#702, %tar_xz_1467_0#703, %tar_xz_1467_0#704, %tar_xz_1467_0#705, %tar_xz_1467_0#706, %tar_xz_1467_0#707, %tar_xz_1467_0#708, %tar_xz_1467_0#709, %tar_xz_1467_0#710, %tar_xz_1467_0#711, %tar_xz_1467_0#712, %tar_xz_1467#20, %tar_xz_1467_0#714, %tar_xz_1467_0#715, %tar_xz_1467_0#716, %tar_xz_1467_0#717, %tar_xz_1467_0#718, %tar_xz_1467_0#719, %tar_xz_1467_0#720, %tar_xz_1467_0#721, %tar_xz_1467_0#722, %tar_xz_1467_0#723, %tar_xz_1467_0#724, %tar_xz_1467_0#725, %tar_xz_1467_0#726, %tar_xz_1467_0#727, %tar_xz_1467_0#728, %tar_xz_1467_0#729, %tar_xz_1467_0#730, %tar_xz_1467#21, %tar_xz_1467_0#732, %tar_xz_1467_0#733, %tar_xz_1467_0#734, %tar_xz_1467_0#735, %tar_xz_1467_0#736, %tar_xz_1467_0#737, %tar_xz_1467_0#738, %tar_xz_1467_0#739, %tar_xz_1467_0#740, %tar_xz_1467_0#741, %tar_xz_1467_0#742, %tar_xz_1467_0#743, %tar_xz_1467_0#744, %tar_xz_1467_0#745, %tar_xz_1467_0#746, %tar_xz_1467_0#747, %tar_xz_1467_0#748, %tar_xz_1467_0#749, %tar_xz_1467_0#750, %tar_xz_1467_0#751, %tar_xz_1467_0#752, %tar_xz_1467_0#753, %tar_xz_1467_0#754, %tar_xz_1467_0#755, %tar_xz_1467_0#756, %tar_xz_1467_0#757, %tar_xz_1467_0#758, %tar_xz_1467_0#759, %tar_xz_1467_0#760, %tar_xz_1467_0#761, %tar_xz_1467_0#762, %tar_xz_1467_0#763, %tar_xz_1467_0#764, %tar_xz_1467_0#765, %tar_xz_1467_0#766, %tar_xz_1467_0#767, %tar_xz_1467_0#768, %tar_xz_1467#22, %tar_xz_1467_0#770, %tar_xz_1467_0#771, %tar_xz_1467_0#772, %tar_xz_1467_0#773, %tar_xz_1467_0#774, %tar_xz_1467_0#775, %tar_xz_1467_0#776, %tar_xz_1467_0#777, %tar_xz_1467_0#778, %tar_xz_1467_0#779, %tar_xz_1467_0#780, %tar_xz_1467_0#781, %tar_xz_1467_0#782, %tar_xz_1467_0#783, %tar_xz_1467_0#784, %tar_xz_1467_0#785, %tar_xz_1467_0#786, %tar_xz_1467_0#787, %tar_xz_1467_0#788, %tar_xz_1467_0#789, %tar_xz_1467_0#790, %tar_xz_1467_0#791, %tar_xz_1467_0#792, %tar_xz_1467_0#793, %tar_xz_1467_0#794, %tar_xz_1467_0#795, %tar_xz_1467_0#796, %tar_xz_1467_0#797, %tar_xz_1467_0#798, %tar_xz_1467_0#799, %tar_xz_1467_0#800, %tar_xz_1467_0#801, %tar_xz_1467_0#802, %tar_xz_1467_0#803, %tar_xz_1467_0#804, %tar_xz_1467_0#805, %tar_xz_1467_0#806, %tar_xz_1467_0#807, %tar_xz_1467_0#808, %tar_xz_1467_0#809, %tar_xz_1467_0#810, %tar_xz_1467_0#811, %tar_xz_1467_0#812, %tar_xz_1467_0#813, %tar_xz_1467_0#814, %tar_xz_1467_0#815, %tar_xz_1467_0#816, %tar_xz_1467_0#817, %tar_xz_1467_0#818, %tar_xz_1467_0#819, %tar_xz_1467_0#820, %tar_xz_1467_0#821, %tar_xz_1467_0#822, %tar_xz_1467_0#823, %tar_xz_1467_0#824, %tar_xz_1467_0#825, %tar_xz_1467_0#826, %tar_xz_1467_0#827, %tar_xz_1467_0#828, %tar_xz_1467_0#829, %tar_xz_1467_0#830, %tar_xz_1467_0#831, %tar_xz_1467_0#832, %tar_xz_1467_0#833, %tar_xz_1467_0#834, %tar_xz_1467_0#835, %tar_xz_1467_0#836, %tar_xz_1467_0#837, %tar_xz_1467_0#838, %tar_xz_1467_0#839, %tar_xz_1467_0#840, %tar_xz_1467_0#841, %tar_xz_1467_0#842, %tar_xz_1467_0#843, %tar_xz_1467_0#844, %tar_xz_1467_0#845, %tar_xz_1467_0#846, %tar_xz_1467_0#847, %tar_xz_1467_0#848, %tar_xz_1467_0#849, %tar_xz_1467_0#850, %tar_xz_1467_0#851, %tar_xz_1467_0#852, %tar_xz_1467_0#853, %tar_xz_1467_0#854, %tar_xz_1467#23, %tar_xz_1467_0#856, %tar_xz_1467_0#857, %tar_xz_1467_0#858, %tar_xz_1467_0#859, %tar_xz_1467_0#860, %tar_xz_1467_0#861, %tar_xz_1467_0#862, %tar_xz_1467_0#863, %tar_xz_1467_0#864, %tar_xz_1467_0#865, %tar_xz_1467_0#866, %tar_xz_1467_0#867, %tar_xz_1467_0#868, %tar_xz_1467_0#869, %tar_xz_1467_0#870, %tar_xz_1467_0#871, %tar_xz_1467_0#872, %tar_xz_1467_0#873, %tar_xz_1467_0#874, %tar_xz_1467_0#875, %tar_xz_1467_0#876, %tar_xz_1467_0#877, %tar_xz_1467_0#878, %tar_xz_1467_0#879, %tar_xz_1467_0#880, %tar_xz_1467_0#881, %tar_xz_1467_0#882, %tar_xz_1467_0#883, %tar_xz_1467_0#884, %tar_xz_1467#24, %tar_xz_1467_0#886, %tar_xz_1467_0#887, %tar_xz_1467_0#888, %tar_xz_1467_0#889, %tar_xz_1467_0#890, %tar_xz_1467_0#891, %tar_xz_1467_0#892, %tar_xz_1467_0#893, %tar_xz_1467_0#894, %tar_xz_1467_0#895, %tar_xz_1467_0#896, %tar_xz_1467_0#897, %tar_xz_1467_0#898, %tar_xz_1467_0#899, %tar_xz_1467_0#900, %tar_xz_1467#25, %tar_xz_1467_0#902, %tar_xz_1467_0#903, %tar_xz_1467_0#904, %tar_xz_1467#26, %tar_xz_1467_0#906, %tar_xz_1467_0#907, %tar_xz_1467_0#908, %tar_xz_1467_0#909, %tar_xz_1467_0#910, %tar_xz_1467_0#911, %tar_xz_1467_0#912, %tar_xz_1467_0#913, %tar_xz_1467_0#914, %tar_xz_1467_0#915, %tar_xz_1467_0#916, %tar_xz_1467_0#917, %tar_xz_1467_0#918, %tar_xz_1467_0#919, %tar_xz_1467_0#920, %tar_xz_1467_0#921, %tar_xz_1467_0#922, %tar_xz_1467_0#923, %tar_xz_1467_0#924, %tar_xz_1467_0#925, %tar_xz_1467_0#926, %tar_xz_1467_0#927, %tar_xz_1467_0#928, %tar_xz_1467_0#929, %tar_xz_1467_0#930, %tar_xz_1467_0#931, %tar_xz_1467_0#932, %tar_xz_1467_0#933, %tar_xz_1467_0#934, %tar_xz_1467_0#935, %tar_xz_1467_0#936, %tar_xz_1467_0#937, %tar_xz_1467_0#938, %tar_xz_1467_0#939, %tar_xz_1467_0#940, %tar_xz_1467#27, %tar_xz_1467_0#942, %tar_xz_1467_0#943, %tar_xz_1467_0#944, %tar_xz_1467_0#945, %tar_xz_1467_0#946, %tar_xz_1467_0#947, %tar_xz_1467_0#948, %tar_xz_1467_0#949, %tar_xz_1467_0#950, %tar_xz_1467_0#951, %tar_xz_1467_0#952, %tar_xz_1467#28, %tar_xz_1467_0#954, %tar_xz_1467_0#955, %tar_xz_1467_0#956, %tar_xz_1467_0#957, %tar_xz_1467_0#958, %tar_xz_1467_0#959, %tar_xz_1467_0#960, %tar_xz_1467_0#961, %tar_xz_1467_0#962, %tar_xz_1467_0#963, %tar_xz_1467_0#964, %tar_xz_1467_0#965, %tar_xz_1467_0#966, %tar_xz_1467_0#967, %tar_xz_1467_0#968, %tar_xz_1467#29, %tar_xz_1467_0#970, %tar_xz_1467_0#971, %tar_xz_1467_0#972, %tar_xz_1467_0#973, %tar_xz_1467_0#974, %tar_xz_1467_0#975, %tar_xz_1467_0#976, %tar_xz_1467_0#977, %tar_xz_1467_0#978, %tar_xz_1467_0#979, %tar_xz_1467_0#980, %tar_xz_1467_0#981, %tar_xz_1467_0#982, %tar_xz_1467_0#983, %tar_xz_1467_0#984, %tar_xz_1467_0#985, %tar_xz_1467_0#986, %tar_xz_1467_0#987, %tar_xz_1467_0#988, %tar_xz_1467_0#989, %tar_xz_1467_0#990, %tar_xz_1467_0#991, %tar_xz_1467_0#992, %tar_xz_1467_0#993, %tar_xz_1467#30, %tar_xz_1467_0#995, %tar_xz_1467_0#996, %tar_xz_1467_0#997, %tar_xz_1467_0#998, %tar_xz_1467_0#999, %tar_xz_1467_0#1000, %tar_xz_1467_0#1001, %tar_xz_1467_0#1002, %tar_xz_1467_0#1003, %tar_xz_1467_0#1004, %tar_xz_1467_0#1005, %tar_xz_1467_0#1006, %tar_xz_1467_0#1007, %tar_xz_1467#31, %tar_xz_1467_0#1009, %tar_xz_1467_0#1010, %tar_xz_1467_0#1011, %tar_xz_1467_0#1012, %tar_xz_1467_0#1013, %tar_xz_1467_0#1014, %tar_xz_1467_0#1015, %tar_xz_1467_0#1016, %tar_xz_1467_0#1017, %tar_xz_1467_0#1018, %tar_xz_1467_0#1019, %tar_xz_1467_0#1020, %tar_xz_1467_0#1021, %tar_xz_1467_0#1022, %tar_xz_1467_0#1023, %tar_xz_1467_0#1024, %tar_xz_1467_0#1025, %tar_xz_1467_0#1026, %tar_xz_1467_0#1027, %tar_xz_1467_0#1028, %tar_xz_1467_0#1029, %tar_xz_1467_0#1030, %tar_xz_1467_0#1031, %tar_xz_1467_0#1032, %tar_xz_1467_0#1033, %tar_xz_1467_0#1034, %tar_xz_1467_0#1035, %tar_xz_1467_0#1036, %tar_xz_1467_0#1037, %tar_xz_1467_0#1038, %tar_xz_1467#32, %tar_xz_1467_0#1040, %tar_xz_1467#33, %tar_xz_1467_0#1042, %tar_xz_1467#34, %tar_xz_1467_0#1044, %tar_xz_1467_0#1045, %tar_xz_1467_0#1046, %tar_xz_1467_0#1047, %tar_xz_1467_0#1048, %tar_xz_1467_0#1049, %tar_xz_1467_0#1050, %tar_xz_1467_0#1051, %tar_xz_1467_0#1052, %tar_xz_1467_0#1053, %tar_xz_1467_0#1054, %tar_xz_1467_0#1055, %tar_xz_1467_0#1056, %tar_xz_1467_0#1057, %tar_xz_1467_0#1058, %tar_xz_1467_0#1059, %tar_xz_1467_0#1060, %tar_xz_1467_0#1061, %tar_xz_1467_0#1062, %tar_xz_1467_0#1063, %tar_xz_1467_0#1064, %tar_xz_1467_0#1065, %tar_xz_1467_0#1066, %tar_xz_1467_0#1067, %tar_xz_1467_0#1068, %tar_xz_1467_0#1069, %tar_xz_1467_0#1070, %tar_xz_1467_0#1071, %tar_xz_1467_0#1072, %tar_xz_1467_0#1073, %tar_xz_1467_0#1074, %tar_xz_1467_0#1075, %tar_xz_1467#35, %tar_xz_1467_0#1079, %tar_xz_1467_0#1080, %tar_xz_1467_0#1081, %tar_xz_1467_0#1082, %tar_xz_1467_0#1083, %tar_xz_1467_0#1084, %tar_xz_1467_0#1085, %tar_xz_1467_0#1086, %tar_xz_1467_0#1087, %tar_xz_1467_0#1088, %tar_xz_1467_0#1089, %tar_xz_1467_0#1090, %tar_xz_1467_0#1091, %tar_xz_1467_0#1092, %tar_xz_1467_0#1093, %tar_xz_1467_0#1094, %tar_xz_1467_0#1095, %tar_xz_1467_0#1096, %tar_xz_1467_0#1097, %tar_xz_1467_0#1098, %tar_xz_1467_0#1099, %tar_xz_1467_0#1100, %tar_xz_1467_0#1101, %tar_xz_1467_0#1102, %tar_xz_1467_0#1103, %tar_xz_1467_0#1104, %tar_xz_1467_0#1105, %tar_xz_1467_0#1106, %tar_xz_1467_0#1107, %tar_xz_1467_0#1108, %tar_xz_1467_0#1109, %tar_xz_1467_0#1110, %tar_xz_1467_0#1111, %tar_xz_1467_0#1112, %tar_xz_1467_0#1113, %tar_xz_1467_0#1114, %tar_xz_1467_0#1115, %tar_xz_1467_0#1116, %tar_xz_1467_0#1117, %tar_xz_1467_0#1118, %tar_xz_1467_0#1119, %tar_xz_1467_0#1120, %tar_xz_1467_0#1121, %tar_xz_1467_0#1122, %tar_xz_1467_0#1123, %tar_xz_1467_0#1124, %tar_xz_1467_0#1125, %tar_xz_1467_0#1126, %tar_xz_1467_0#1127, %tar_xz_1467_0#1128, %tar_xz_1467_0#1129, %tar_xz_1467_0#1130, %tar_xz_1467_0#1131, %tar_xz_1467_0#1132, %tar_xz_1467_0#1133, %tar_xz_1467_0#1134, %tar_xz_1467_0#1135, %tar_xz_1467_0#1136, %tar_xz_1467_0#1137, %tar_xz_1467_0#1138, %tar_xz_1467_0#1139, %tar_xz_1467_0#1140, %tar_xz_1467_0#1141, %tar_xz_1467_0#1142, %tar_xz_1467_0#1143, %tar_xz_1467_0#1144, %tar_xz_1467_0#1145, %tar_xz_1467_0#1146, %tar_xz_1467_0#1147, %tar_xz_1467_0#1148, %tar_xz_1467_0#1149, %tar_xz_1467_0#1150, %tar_xz_1467_0#1151, %tar_xz_1467_0#1152, %tar_xz_1467_0#1153, %tar_xz_1467_0#1154, %tar_xz_1467_0#1155, %tar_xz_1467_0#1156, %tar_xz_1467_0#1157, %tar_xz_1467_0#1158, %tar_xz_1467_0#1159, %tar_xz_1467_0#1160, %tar_xz_1467_0#1161, %tar_xz_1467_0#1162, %tar_xz_1467_0#1163, %tar_xz_1467_0#1164, %tar_xz_1467_0#1165, %tar_xz_1467_0#1166, %tar_xz_1467_0#1167, %tar_xz_1467_0#1168, %tar_xz_1467_0#1169, %tar_xz_1467_0#1170, %tar_xz_1467_0#1171, %tar_xz_1467_0#1172, %tar_xz_1467_0#1173, %tar_xz_1467_0#1174, %tar_xz_1467_0#1175, %tar_xz_1467_0#1176, %tar_xz_1467_0#1177, %tar_xz_1467_0#1178, %tar_xz_1467_0#1179, %tar_xz_1467_0#1180, %tar_xz_1467_0#1181, %tar_xz_1467_0#1182, %tar_xz_1467_0#1183, %tar_xz_1467_0#1184, %tar_xz_1467_0#1185, %tar_xz_1467_0#1186, %tar_xz_1467_0#1187, %tar_xz_1467_0#1188, %tar_xz_1467_0#1189, %tar_xz_1467_0#1190, %tar_xz_1467_0#1191, %tar_xz_1467_0#1192, %tar_xz_1467_0#1193, %tar_xz_1467_0#1194, %tar_xz_1467_0#1195, %tar_xz_1467_0#1196, %tar_xz_1467_0#1197, %tar_xz_1467_0#1198, %tar_xz_1467_0#1199, %tar_xz_1467_0#1200, %tar_xz_1467_0#1201, %tar_xz_1467_0#1202, %tar_xz_1467_0#1203, %tar_xz_1467_0#1204, %tar_xz_1467_0#1205, %tar_xz_1467_0#1206, %tar_xz_1467_0#1207, %tar_xz_1467_0#1208, %tar_xz_1467_0#1209, %tar_xz_1467_0#1210, %tar_xz_1467_0#1211, %tar_xz_1467_0#1212, %tar_xz_1467_0#1213, %tar_xz_1467_0#1214, %tar_xz_1467_0#1215, %tar_xz_1467_0#1216, %tar_xz_1467_0#1217, %tar_xz_1467_0#1218, %tar_xz_1467_0#1219, %tar_xz_1467_0#1220, %tar_xz_1467_0#1221, %tar_xz_1467_0#1222, %tar_xz_1467_0#1223, %tar_xz_1467_0#1224, %tar_xz_1467_0#1225, %tar_xz_1467_0#1226, %tar_xz_1467_0#1227, %tar_xz_1467_0#1228, %tar_xz_1467_0#1229, %tar_xz_1467_0#1230, %tar_xz_1467_0#1231, %tar_xz_1467_0#1232, %tar_xz_1467_0#1233, %tar_xz_1467_0#1234, %tar_xz_1467_0#1235, %tar_xz_1467_0#1236, %tar_xz_1467_0#1237, %tar_xz_1467_0#1238, %tar_xz_1467_0#1239, %tar_xz_1467_0#1240, %tar_xz_1467_0#1241, %tar_xz_1467_0#1242, %tar_xz_1467_0#1243, %tar_xz_1467_0#1244, %tar_xz_1467_0#1245, %tar_xz_1467_0#1246, %tar_xz_1467_0#1247, %tar_xz_1467_0#1248, %tar_xz_1467_0#1249, %tar_xz_1467_0#1250, %tar_xz_1467_0#1251, %tar_xz_1467_0#1252, %tar_xz_1467_0#1253, %tar_xz_1467_0#1254, %tar_xz_1467_0#1255, %tar_xz_1467_0#1256, %tar_xz_1467_0#1257, %tar_xz_1467_0#1258, %tar_xz_1467_0#1259, %tar_xz_1467_0#1260, %tar_xz_1467_0#1261, %tar_xz_1467_0#1262, %tar_xz_1467_0#1263, %tar_xz_1467_0#1264, %tar_xz_1467_0#1265, %tar_xz_1467_0#1266, %tar_xz_1467_0#1267, %tar_xz_1467_0#1268, %tar_xz_1467_0#1269, %tar_xz_1467_0#1270, %tar_xz_1467_0#1271, %tar_xz_1467_0#1272, %tar_xz_1467_0#1273, %tar_xz_1467_0#1274, %tar_xz_1467_0#1275, %tar_xz_1467_0#1276, %tar_xz_1467_0#1277, %tar_xz_1467_0#1278, %tar_xz_1467_0#1279, %tar_xz_1467_0#1280, %tar_xz_1467_0#1281, %tar_xz_1467_0#1282, %tar_xz_1467_0#1283, %tar_xz_1467_0#1284, %tar_xz_1467_0#1285, %tar_xz_1467#36, %tar_xz_1467_0#1287, %tar_xz_1467_0#1288, %tar_xz_1467_0#1289, %tar_xz_1467_0#1290, %tar_xz_1467_0#1291, %tar_xz_1467_0#1292, %tar_xz_1467#37, %tar_xz_1467_0#1294, %tar_xz_1467_0#1295, %tar_xz_1467_0#1296, %tar_xz_1467_0#1297, %tar_xz_1467_0#1298, %tar_xz_1467_0#1299, %tar_xz_1467_0#1300, %tar_xz_1467_0#1301, %tar_xz_1467_0#1302, %tar_xz_1467_0#1303, %tar_xz_1467_0#1304, %tar_xz_1467_0#1305, %tar_xz_1467_0#1306, %tar_xz_1467_0#1307, %tar_xz_1467_0#1308, %tar_xz_1467_0#1309, %tar_xz_1467_0#1310, %tar_xz_1467_0#1311, %tar_xz_1467_0#1312, %tar_xz_1467_0#1313, %tar_xz_1467_0#1314, %tar_xz_1467_0#1315, %tar_xz_1467_0#1316, %tar_xz_1467_0#1317, %tar_xz_1467_0#1318, %tar_xz_1467_0#1319, %tar_xz_1467_0#1320, %tar_xz_1467_0#1321, %tar_xz_1467_0#1322, %tar_xz_1467_0#1323, %tar_xz_1467_0#1324, %tar_xz_1467_0#1325, %tar_xz_1467_0#1326, %tar_xz_1467_0#1327, %tar_xz_1467_0#1328, %tar_xz_1467_0#1329, %tar_xz_1467_0#1330, %tar_xz_1467#38, %tar_xz_1467_0#1332, %tar_xz_1467_0#1333, %tar_xz_1467_0#1334, %tar_xz_1467_0#1335, %tar_xz_1467_0#1336, %tar_xz_1467_0#1337, %tar_xz_1467_0#1338, %tar_xz_1467#39, %tar_xz_1467_0#1340, %tar_xz_1467_0#1341, %tar_xz_1467_0#1342, %tar_xz_1467_0#1343, %tar_xz_1467_0#1344, %tar_xz_1467_0#1345, %tar_xz_1467_0#1346, %tar_xz_1467_0#1347, %tar_xz_1467_0#1348, %tar_xz_1467_0#1349, %tar_xz_1467_0#1350, %tar_xz_1467_0#1351, %tar_xz_1467_0#1352, %tar_xz_1467_0#1353, %tar_xz_1467_0#1354, %tar_xz_1467#40, %tar_xz_1467_0#1357, %tar_xz_1467_0#1358, %tar_xz_1467_0#1359, %tar_xz_1467_0#1360, %tar_xz_1467_0#1361, %tar_xz_1467_0#1362, %tar_xz_1467_0#1363, %tar_xz_1467_0#1364, %tar_xz_1467_0#1365, %tar_xz_1467_0#1366, %tar_xz_1467_0#1367, %tar_xz_1467_0#1368, %tar_xz_1467_0#1369, %tar_xz_1467_0#1370, %tar_xz_1467_0#1371, %tar_xz_1467_0#1372, %tar_xz_1467_0#1373, %tar_xz_1467_0#1374, %tar_xz_1467_0#1375, %tar_xz_1467_0#1376, %tar_xz_1467_0#1377, %tar_xz_1467_0#1378, %tar_xz_1467_0#1379, %tar_xz_1467_0#1380, %tar_xz_1467_0#1381, %tar_xz_1467_0#1382, %tar_xz_1467_0#1383, %tar_xz_1467_0#1384, %tar_xz_1467_0#1385, %tar_xz_1467_0#1386, %tar_xz_1467_0#1387, %tar_xz_1467_0#1388, %tar_xz_1467_0#1389, %tar_xz_1467_0#1390, %tar_xz_1467_0#1391, %tar_xz_1467_0#1392, %tar_xz_1467_0#1393, %tar_xz_1467_0#1394, %tar_xz_1467_0#1395, %tar_xz_1467_0#1396, %tar_xz_1467_0#1397, %tar_xz_1467_0#1398, %tar_xz_1467_0#1399, %tar_xz_1467_0#1400, %tar_xz_1467_0#1401, %tar_xz_1467_0#1402, %tar_xz_1467_0#1403, %tar_xz_1467_0#1404, %tar_xz_1467_0#1405, %tar_xz_1467_0#1406, %tar_xz_1467_0#1407, %tar_xz_1467_0#1408, %tar_xz_1467_0#1409, %tar_xz_1467_0#1410, %tar_xz_1467_0#1411, %tar_xz_1467_0#1412, %tar_xz_1467_0#1413, %tar_xz_1467_0#1414, %tar_xz_1467_0#1415, %tar_xz_1467_0#1416, %tar_xz_1467_0#1417, %tar_xz_1467_0#1418, %tar_xz_1467_0#1419, %tar_xz_1467_0#1420, %tar_xz_1467_0#1421, %tar_xz_1467_0#1422, %tar_xz_1467_0#1423, %tar_xz_1467_0#1424, %tar_xz_1467_0#1425, %tar_xz_1467_0#1426, %tar_xz_1467_0#1427, %tar_xz_1467_0#1428, %tar_xz_1467_0#1429, %tar_xz_1467_0#1430, %tar_xz_1467_0#1431, %tar_xz_1467_0#1432, %tar_xz_1467_0#1433, %tar_xz_1467_0#1434, %tar_xz_1467_0#1435, %tar_xz_1467_0#1436, %tar_xz_1467_0#1437, %tar_xz_1467_0#1438, %tar_xz_1467_0#1439, %tar_xz_1467_0#1440, %tar_xz_1467_0#1441, %tar_xz_1467_0#1442, %tar_xz_1467_0#1443, %tar_xz_1467_0#1444, %tar_xz_1467_0#1445, %tar_xz_1467_0#1446, %tar_xz_1467_0#1447, %tar_xz_1467_0#1448, %tar_xz_1467_0#1449, %tar_xz_1467_0#1450, %tar_xz_1467_0#1451, %tar_xz_1467_0#1452, %tar_xz_1467_0#1453, %tar_xz_1467_0#1454, %tar_xz_1467_0#1455, %tar_xz_1467#41, %tar_xz_1467_0#1457, %tar_xz_1467_0#1458, %tar_xz_1467_0#1459, %tar_xz_1467#42, %tar_xz_1467_0#1461, %tar_xz_1467_0#1462, %tar_xz_1467_0#1463, %tar_xz_1467_0#1464, %tar_xz_1467_0#1465, %tar_xz_1467_0#1466, %tar_xz_1467_0#1467, %tar_xz_1467#43, %tar_xz_1467_0#1469, %tar_xz_1467_0#1470, %tar_xz_1467_0#1471, %tar_xz_1467#44, %tar_xz_1467_0#1473, %tar_xz_1467#45, %tar_xz_1467_0#1475, %tar_xz_1467_0#1476, %tar_xz_1467_0#1477, %tar_xz_1467_0#1478, %tar_xz_1467_0#1479, %tar_xz_1467_0#1480, %tar_xz_1467_0#1481, %tar_xz_1467_0#1482, %tar_xz_1467_0#1483, %tar_xz_1467_0#1484, %tar_xz_1467_0#1485, %tar_xz_1467_0#1486, %tar_xz_1467_0#1487, %tar_xz_1467_0#1488, %tar_xz_1467_0#1489, %tar_xz_1467_0#1490, %tar_xz_1467_0#1491, %tar_xz_1467_0#1492, %tar_xz_1467_0#1493, %tar_xz_1467_0#1494, %tar_xz_1467_0#1495, %tar_xz_1467_0#1496, %tar_xz_1467_0#1497, %tar_xz_1467_0#1498, %tar_xz_1467_0#1499, %tar_xz_1467_0#1500, %tar_xz_1467_0#1501, %tar_xz_1467_0#1502, %tar_xz_1467_0#1503, %tar_xz_1467_0#1504, %tar_xz_1467_0#1505, %tar_xz_1467_0#1506, %tar_xz_1467_0#1507, %tar_xz_1467_0#1508, %tar_xz_1467_0#1509, %tar_xz_1467_0#1510, %tar_xz_1467_0#1511, %tar_xz_1467_0#1512, %tar_xz_1467_0#1513, %tar_xz_1467_0#1514, %tar_xz_1467_0#1515, %tar_xz_1467_0#1516, %tar_xz_1467_0#1517, %tar_xz_1467_0#1518, %tar_xz_1467_0#1519, %tar_xz_1467_0#1520, %tar_xz_1467_0#1521, %tar_xz_1467_0#1522, %tar_xz_1467_0#1523, %tar_xz_1467_0#1524, %tar_xz_1467_0#1525, %tar_xz_1467_0#1526, %tar_xz_1467_0#1527, %tar_xz_1467_0#1528, %tar_xz_1467_0#1529, %tar_xz_1467_0#1530, %tar_xz_1467_0#1531, %tar_xz_1467_0#1532, %tar_xz_1467_0#1533, %tar_xz_1467_0#1534, %tar_xz_1467_0#1535, %tar_xz_1467_0#1536, %tar_xz_1467_0#1537, %tar_xz_1467_0#1538, %tar_xz_1467_0#1539, %tar_xz_1467_0#1540, %tar_xz_1467_0#1541, %tar_xz_1467_0#1542, %tar_xz_1467_0#1543, %tar_xz_1467_0#1544, %tar_xz_1467_0#1545, %tar_xz_1467_0#1546, %tar_xz_1467_0#1547, %tar_xz_1467_0#1548, %tar_xz_1467_0#1549, %tar_xz_1467_0#1550, %tar_xz_1467_0#1551, %tar_xz_1467_0#1552, %tar_xz_1467_0#1553, %tar_xz_1467_0#1554, %tar_xz_1467_0#1555, %tar_xz_1467_0#1556, %tar_xz_1467_0#1557, %tar_xz_1467_0#1558, %tar_xz_1467_0#1559, %tar_xz_1467_0#1560, %tar_xz_1467_0#1561, %tar_xz_1467#46, %tar_xz_1467_0#1563, %tar_xz_1467_0#1564, %tar_xz_1467_0#1565, %tar_xz_1467_0#1566, %tar_xz_1467_0#1567, %tar_xz_1467_0#1568, %tar_xz_1467_0#1569, %tar_xz_1467_0#1570, %tar_xz_1467_0#1571, %tar_xz_1467_0#1572, %tar_xz_1467_0#1573, %tar_xz_1467_0#1574, %tar_xz_1467_0#1575, %tar_xz_1467_0#1576, %tar_xz_1467_0#1577, %tar_xz_1467_0#1578, %tar_xz_1467_0#1579, %tar_xz_1467_0#1580, %tar_xz_1467_0#1581, %tar_xz_1467_0#1582, %tar_xz_1467_0#1583, %tar_xz_1467_0#1584, %tar_xz_1467_0#1585, %tar_xz_1467_0#1586, %tar_xz_1467_0#1587, %tar_xz_1467_0#1588, %tar_xz_1467#47, %tar_xz_1467_0#1590, %tar_xz_1467_0#1591, %tar_xz_1467#48, %tar_xz_1467_0#1593, %tar_xz_1467_0#1594, %tar_xz_1467_0#1595, %tar_xz_1467_0#1596, %tar_xz_1467_0#1597, %tar_xz_1467_0#1598, %tar_xz_1467_0#1599, %tar_xz_1467_0#1600, %tar_xz_1467_0#1601, %tar_xz_1467_0#1602, %tar_xz_1467_0#1603, %tar_xz_1467_0#1604, %tar_xz_1467_0#1605, %tar_xz_1467_0#1606, %tar_xz_1467_0#1607, %tar_xz_1467_0#1608, %tar_xz_1467_0#1609, %tar_xz_1467_0#1610, %tar_xz_1467#49, %tar_xz_1467#50, %tar_xz_1467#51, %tar_xz_1467_0#1614, %tar_xz_1467_0#1615, %tar_xz_1467_0#1616, %tar_xz_1467_0#1617, %tar_xz_1467_0#1618, %tar_xz_1467_0#1619, %tar_xz_1467_0#1620, %tar_xz_1467_0#1621, %tar_xz_1467_0#1622, %tar_xz_1467_0#1623, %tar_xz_1467_0#1624, %tar_xz_1467_0#1625, %tar_xz_1467_0#1626, %tar_xz_1467_0#1627, %tar_xz_1467_0#1628, %tar_xz_1467_0#1629, %tar_xz_1467_0#1630, %tar_xz_1467_0#1631, %tar_xz_1467_0#1632, %tar_xz_1467_0#1633, %tar_xz_1467_0#1634, %tar_xz_1467_0#1635, %tar_xz_1467_0#1636, %tar_xz_1467_0#1637, %tar_xz_1467_0#1638, %tar_xz_1467_0#1639, %tar_xz_1467_0#1640, %tar_xz_1467_0#1641, %tar_xz_1467_0#1642, %tar_xz_1467_0#1643, %tar_xz_1467_0#1644, %tar_xz_1467_0#1645, %tar_xz_1467_0#1646, %tar_xz_1467_0#1647, %tar_xz_1467_0#1648, %tar_xz_1467_0#1649, %tar_xz_1467_0#1650, %tar_xz_1467_0#1651, %tar_xz_1467_0#1652, %tar_xz_1467_0#1653, %tar_xz_1467_0#1654, %tar_xz_1467_0#1655, %tar_xz_1467_0#1656, %tar_xz_1467_0#1657, %tar_xz_1467_0#1658, %tar_xz_1467_0#1659, %tar_xz_1467_0#1660, %tar_xz_1467_0#1661, %tar_xz_1467_0#1662, %tar_xz_1467_0#1663, %tar_xz_1467_0#1664, %tar_xz_1467_0#1665, %tar_xz_1467_0#1666, %tar_xz_1467_0#1667, %tar_xz_1467_0#1668, %tar_xz_1467_0#1669, %tar_xz_1467_0#1670, %tar_xz_1467_0#1671, %tar_xz_1467_0#1672, %tar_xz_1467_0#1673, %tar_xz_1467_0#1674, %tar_xz_1467_0#1675, %tar_xz_1467_0#1676, %tar_xz_1467_0#1677, %tar_xz_1467_0#1678, %tar_xz_1467_0#1679, %tar_xz_1467_0#1680, %tar_xz_1467#52, %tar_xz_1467_0#1682, %tar_xz_1467_0#1683, %tar_xz_1467_0#1684, %tar_xz_1467_0#1685, %tar_xz_1467_0#1686, %tar_xz_1467_0#1687, %tar_xz_1467_0#1688, %tar_xz_1467_0#1689, %tar_xz_1467_0#1690, %tar_xz_1467_0#1691, %tar_xz_1467_0#1692, %tar_xz_1467_0#1693, %tar_xz_1467_0#1694, %tar_xz_1467_0#1695, %tar_xz_1467_0#1696, %tar_xz_1467_0#1697, %tar_xz_1467_0#1698, %tar_xz_1467_0#1699, %tar_xz_1467_0#1700, %tar_xz_1467_0#1701, %tar_xz_1467_0#1702, %tar_xz_1467_0#1703, %tar_xz_1467_0#1704, %tar_xz_1467_0#1705, %tar_xz_1467_0#1706, %tar_xz_1467_0#1707, %tar_xz_1467_0#1708, %tar_xz_1467_0#1709, %tar_xz_1467_0#1710, %tar_xz_1467_0#1711, %tar_xz_1467_0#1712, %tar_xz_1467_0#1713, %tar_xz_1467_0#1714, %tar_xz_1467_0#1715, %tar_xz_1467_0#1716, %tar_xz_1467_0#1717, %tar_xz_1467_0#1718, %tar_xz_1467_0#1719, %tar_xz_1467_0#1720, %tar_xz_1467_0#1721, %tar_xz_1467_0#1722, %tar_xz_1467_0#1723, %tar_xz_1467_0#1724, %tar_xz_1467_0#1725, %tar_xz_1467_0#1726, %tar_xz_1467_0#1727, %tar_xz_1467_0#1728, %tar_xz_1467_0#1729, %tar_xz_1467_0#1730, %tar_xz_1467_0#1731, %tar_xz_1467_0#1732, %tar_xz_1467_0#1733, %tar_xz_1467_0#1734, %tar_xz_1467_0#1735, %tar_xz_1467_0#1736, %tar_xz_1467_0#1737, %tar_xz_1467_0#1738, %tar_xz_1467_0#1739, %tar_xz_1467_0#1740, %tar_xz_1467_0#1741, %tar_xz_1467_0#1742, %tar_xz_1467_0#1743, %tar_xz_1467_0#1744, %tar_xz_1467_0#1745, %tar_xz_1467_0#1746, %tar_xz_1467_0#1747, %tar_xz_1467_0#1748, %tar_xz_1467_0#1749, %tar_xz_1467_0#1750, %tar_xz_1467_0#1751, %tar_xz_1467_0#1752, %tar_xz_1467_0#1753, %tar_xz_1467_0#1754, %tar_xz_1467_0#1755, %tar_xz_1467_0#1756, %tar_xz_1467_0#1757, %tar_xz_1467_0#1758, %tar_xz_1467_0#1759, %tar_xz_1467_0#1760, %tar_xz_1467_0#1761, %tar_xz_1467_0#1762, %tar_xz_1467_0#1763, %tar_xz_1467_0#1764, %tar_xz_1467_0#1765, %tar_xz_1467#53, %tar_xz_1467_0#1767, %tar_xz_1467_0#1768, %tar_xz_1467_0#1769, %tar_xz_1467_0#1770, %tar_xz_1467_0#1771, %tar_xz_1467_0#1772, %tar_xz_1467_0#1773, %tar_xz_1467_0#1774, %tar_xz_1467_0#1775, %tar_xz_1467_0#1776, %tar_xz_1467_0#1777, %tar_xz_1467_0#1778, %tar_xz_1467_0#1779, %tar_xz_1467_0#1780, %tar_xz_1467_0#1781, %tar_xz_1467_0#1782, %tar_xz_1467_0#1783, %tar_xz_1467_0#1784, %tar_xz_1467_0#1785, %tar_xz_1467_0#1786, %tar_xz_1467_0#1787, %tar_xz_1467_0#1788, %tar_xz_1467_0#1789, %tar_xz_1467_0#1790, %tar_xz_1467_0#1791, %tar_xz_1467_0#1792, %tar_xz_1467_0#1793, %tar_xz_1467_0#1794, %tar_xz_1467_0#1795, %tar_xz_1467_0#1796, %tar_xz_1467_0#1797, %tar_xz_1467_0#1798, %tar_xz_1467_0#1799, %tar_xz_1467_0#1800, %tar_xz_1467_0#1801, %tar_xz_1467_0#1802, %tar_xz_1467_0#1803, %tar_xz_1467_0#1804, %tar_xz_1467_0#1805, %tar_xz_1467_0#1806, %tar_xz_1467_0#1807, %tar_xz_1467_0#1808, %tar_xz_1467_0#1809, %tar_xz_1467_0#1810, %tar_xz_1467_0#1811, %tar_xz_1467_0#1812, %tar_xz_1467_0#1813, %tar_xz_1467_0#1814, %tar_xz_1467#54, %tar_xz_1467_0#1816, %tar_xz_1467_0#1817, %tar_xz_1467_0#1818, %tar_xz_1467_0#1819, %tar_xz_1467_0#1820, %tar_xz_1467_0#1821, %tar_xz_1467_0#1822, %tar_xz_1467_0#1823, %tar_xz_1467_0#1824, %tar_xz_1467_0#1825, %tar_xz_1467_0#1826, %tar_xz_1467_0#1827, %tar_xz_1467_0#1828, %tar_xz_1467_0#1829, %tar_xz_1467_0#1830, %tar_xz_1467_0#1831, %tar_xz_1467_0#1832, %tar_xz_1467_0#1833, %tar_xz_1467_0#1834, %tar_xz_1467_0#1835, %tar_xz_1467_0#1836, %tar_xz_1467_0#1837, %tar_xz_1467_0#1838, %tar_xz_1467_0#1839, %tar_xz_1467_0#1840, %tar_xz_1467_0#1841, %tar_xz_1467_0#1842, %tar_xz_1467_0#1843, %tar_xz_1467_0#1844, %tar_xz_1467_0#1845, %tar_xz_1467_0#1846, %tar_xz_1467_0#1847, %tar_xz_1467_0#1848, %tar_xz_1467_0#1849, %tar_xz_1467#55, %tar_xz_1467_0#1867, %tar_xz_1467_0#1868, %tar_xz_1467_0#1869, %tar_xz_1467_0#1870, %tar_xz_1467_0#1871, %tar_xz_1467_0#1872, %tar_xz_1467_0#1873, %tar_xz_1467_0#1874, %tar_xz_1467#56, %tar_xz_1467#57, %tar_xz_1467_0#1877, %tar_xz_1467_0#1878, %tar_xz_1467_0#1879, %tar_xz_1467_0#1880, %tar_xz_1467_0#1881, %tar_xz_1467_0#1882, %tar_xz_1467_0#1883, %tar_xz_1467_0#1884, %tar_xz_1467_0#1885, %tar_xz_1467_0#1886, %tar_xz_1467_0#1887, %tar_xz_1467_0#1888, %tar_xz_1467_0#1889, %tar_xz_1467_0#1890, %tar_xz_1467_0#1891, %tar_xz_1467_0#1892, %tar_xz_1467_0#1893, %tar_xz_1467_0#1894, %tar_xz_1467_0#1895, %tar_xz_1467_0#1896, %tar_xz_1467_0#1897, %tar_xz_1467_0#1898, %tar_xz_1467_0#1899, %tar_xz_1467_0#1900, %tar_xz_1467_0#1901, %tar_xz_1467_0#1902, %tar_xz_1467_0#1903, %tar_xz_1467_0#1904, %tar_xz_1467_0#1905, %tar_xz_1467_0#1906, %tar_xz_1467_0#1907, %tar_xz_1467_0#1908, %tar_xz_1467_0#1909, %tar_xz_1467_0#1910, %tar_xz_1467_0#1911, %tar_xz_1467_0#1912, %tar_xz_1467_0#1913, %tar_xz_1467_0#1914, %tar_xz_1467_0#1915, %tar_xz_1467_0#1916, %tar_xz_1467_0#1917, %tar_xz_1467_0#1918, %tar_xz_1467_0#1919, %tar_xz_1467_0#1920, %tar_xz_1467#58, %tar_xz_1467_0#1922, %tar_xz_1467_0#1923, %tar_xz_1467_0#1924, %tar_xz_1467_0#1925, %tar_xz_1467_0#1926, %tar_xz_1467_0#1927, %tar_xz_1467_0#1928, %tar_xz_1467_0#1929, %tar_xz_1467_0#1930, %tar_xz_1467_0#1931, %tar_xz_1467_0#1932, %tar_xz_1467_0#1933, %tar_xz_1467_0#1934, %tar_xz_1467_0#1935, %tar_xz_1467_0#1936, %tar_xz_1467_0#1937, %tar_xz_1467_0#1938, %tar_xz_1467_0#1939, %tar_xz_1467_0#1940, %tar_xz_1467_0#1941, %tar_xz_1467_0#1942, %tar_xz_1467_0#1943, %tar_xz_1467_0#1944, %tar_xz_1467_0#1945, %tar_xz_1467_0#1946, %tar_xz_1467_0#1947, %tar_xz_1467_0#1948, %tar_xz_1467_0#1949, %tar_xz_1467_0#1950, %tar_xz_1467_0#1951, %tar_xz_1467_0#1952, %tar_xz_1467_0#1953, %tar_xz_1467_0#1954, %tar_xz_1467#59, %tar_xz_1467_0#1956, %tar_xz_1467_0#1957, %tar_xz_1467_0#1958, %tar_xz_1467_0#1959, %tar_xz_1467_0#1960, %tar_xz_1467_0#1961, %tar_xz_1467_0#1962, %tar_xz_1467_0#1963, %tar_xz_1467_0#1964, %tar_xz_1467_0#1965, %tar_xz_1467_0#1966, %tar_xz_1467_0#1967, %tar_xz_1467_0#1968, %tar_xz_1467_0#1969, %tar_xz_1467_0#1970, %tar_xz_1467_0#1971, %tar_xz_1467_0#1972, %tar_xz_1467_0#1973, %tar_xz_1467_0#1974, %tar_xz_1467_0#1975, %tar_xz_1467_0#1976, %tar_xz_1467_0#1977, %tar_xz_1467_0#1978, %tar_xz_1467_0#1979, %tar_xz_1467_0#1980, %tar_xz_1467_0#1981, %tar_xz_1467_0#1982, %tar_xz_1467_0#1983, %tar_xz_1467_0#1984, %tar_xz_1467_0#1985, %tar_xz_1467_0#1986, %tar_xz_1467_0#1987, %tar_xz_1467_0#1988, %tar_xz_1467_0#1989, %tar_xz_1467_0#1990, %tar_xz_1467_0#1991, %tar_xz_1467_0#1992, %tar_xz_1467_0#1993, %tar_xz_1467_0#1994, %tar_xz_1467_0#1995, %tar_xz_1467_0#1996, %tar_xz_1467_0#1997, %tar_xz_1467_0#1998, %tar_xz_1467_0#1999, %tar_xz_1467_0#2000, %tar_xz_1467_0#2001, %tar_xz_1467_0#2002, %tar_xz_1467_0#2003, %tar_xz_1467_0#2004, %tar_xz_1467_0#2005, %tar_xz_1467_0#2006, %tar_xz_1467_0#2007, %tar_xz_1467_0#2008, %tar_xz_1467_0#2009, %tar_xz_1467_0#2010, %tar_xz_1467_0#2011, %tar_xz_1467_0#2012, %tar_xz_1467_0#2013, %tar_xz_1467_0#2014, %tar_xz_1467_0#2015, %tar_xz_1467_0#2016, %tar_xz_1467_0#2017, %tar_xz_1467_0#2018, %tar_xz_1467_0#2019, %tar_xz_1467_0#2020, %tar_xz_1467_0#2021, %tar_xz_1467_0#2022, %tar_xz_1467_0#2023, %tar_xz_1467_0#2024, %tar_xz_1467_0#2025, %tar_xz_1467_0#2026, %tar_xz_1467_0#2027, %tar_xz_1467_0#2028, %tar_xz_1467_0#2029, %tar_xz_1467_0#2030, %tar_xz_1467_0#2031, %tar_xz_1467_0#2032, %tar_xz_1467_0#2033, %tar_xz_1467_0#2034, %tar_xz_1467_0#2035, %tar_xz_1467_0#2036, %tar_xz_1467_0#2037, %tar_xz_1467_0#2038, %tar_xz_1467_0#2039, %tar_xz_1467_0#2040, %tar_xz_1467_0#2041, %tar_xz_1467_0#2042, %tar_xz_1467_0#2043, %tar_xz_1467_0#2044, %tar_xz_1467_0#2045, %tar_xz_1467_0#2046, %tar_xz_1467_0#2047, %tar_xz_1467_0#2048, %tar_xz_1467_0#2049, %tar_xz_1467_0#2050, %tar_xz_1467_0#2051, %tar_xz_1467_0#2052, %tar_xz_1467_0#2053, %tar_xz_1467_0#2054, %tar_xz_1467_0#2055, %tar_xz_1467_0#2056, %tar_xz_1467_0#2057, %tar_xz_1467_0#2058, %tar_xz_1467_0#2059, %tar_xz_1467_0#2060, %tar_xz_1467_0#2061, %tar_xz_1467_0#2062, %tar_xz_1467_0#2063, %tar_xz_1467_0#2064, %tar_xz_1467_0#2065, %tar_xz_1467_0#2066, %tar_xz_1467_0#2067, %tar_xz_1467_0#2068, %tar_xz_1467#60, %tar_xz_1467_0#2070, %tar_xz_1467_0#2071, %tar_xz_1467_0#2072, %tar_xz_1467_0#2073, %tar_xz_1467_0#2074, %tar_xz_1467_0#2075, %tar_xz_1467_0#2076, %tar_xz_1467_0#2077, %tar_xz_1467_0#2078, %tar_xz_1467_0#2079, %tar_xz_1467_0#2080, %tar_xz_1467_0#2081, %tar_xz_1467_0#2082, %tar_xz_1467_0#2083, %tar_xz_1467_0#2084, %tar_xz_1467_0#2085, %tar_xz_1467_0#2086, %tar_xz_1467_0#2087, %tar_xz_1467_0#2088, %tar_xz_1467_0#2089, %tar_xz_1467_0#2090, %tar_xz_1467_0#2091, %tar_xz_1467_0#2092, %tar_xz_1467_0#2093, %tar_xz_1467#61, %tar_xz_1467_0#2095, %tar_xz_1467_0#2096, %tar_xz_1467_0#2097, %tar_xz_1467_0#2098, %tar_xz_1467_0#2099, %tar_xz_1467_0#2100, %tar_xz_1467_0#2101, %tar_xz_1467_0#2102, %tar_xz_1467_0#2103, %tar_xz_1467_0#2104, %tar_xz_1467_0#2105, %tar_xz_1467_0#2106, %tar_xz_1467_0#2107, %tar_xz_1467_0#2108, %tar_xz_1467_0#2109, %tar_xz_1467_0#2110, %tar_xz_1467_0#2111, %tar_xz_1467_0#2112, %tar_xz_1467_0#2113, %tar_xz_1467_0#2114, %tar_xz_1467_0#2115, %tar_xz_1467_0#2116, %tar_xz_1467_0#2117, %tar_xz_1467_0#2118, %tar_xz_1467_0#2119, %tar_xz_1467_0#2120, %tar_xz_1467_0#2121, %tar_xz_1467_0#2122, %tar_xz_1467_0#2123, %tar_xz_1467_0#2124, %tar_xz_1467_0#2125, %tar_xz_1467_0#2126, %tar_xz_1467_0#2127, %tar_xz_1467_0#2128, %tar_xz_1467_0#2129, %tar_xz_1467_0#2130, %tar_xz_1467_0#2131, %tar_xz_1467_0#2132, %tar_xz_1467_0#2133, %tar_xz_1467_0#2134, %tar_xz_1467_0#2135, %tar_xz_1467_0#2136, %tar_xz_1467_0#2137, %tar_xz_1467_0#2138, %tar_xz_1467#62, %tar_xz_1467_0#2140, %tar_xz_1467_0#2141, %tar_xz_1467_0#2142, %tar_xz_1467_0#2143, %tar_xz_1467_0#2144, %tar_xz_1467_0#2145, %tar_xz_1467_0#2146, %tar_xz_1467_0#2147, %tar_xz_1467_0#2148, %tar_xz_1467_0#2149, %tar_xz_1467_0#2150, %tar_xz_1467_0#2151, %tar_xz_1467_0#2152, %tar_xz_1467_0#2153, %tar_xz_1467_0#2154, %tar_xz_1467_0#2155, %tar_xz_1467_0#2156, %tar_xz_1467_0#2157, %tar_xz_1467_0#2158, %tar_xz_1467_0#2159, %tar_xz_1467_0#2160, %tar_xz_1467_0#2161, %tar_xz_1467_0#2162, %tar_xz_1467_0#2163, %tar_xz_1467_0#2164, %tar_xz_1467_0#2165, %tar_xz_1467_0#2166, %tar_xz_1467_0#2167, %tar_xz_1467_0#2168, %tar_xz_1467_0#2169, %tar_xz_1467_0#2170, %tar_xz_1467_0#2171, %tar_xz_1467_0#2172, %tar_xz_1467_0#2173, %tar_xz_1467_0#2174, %tar_xz_1467_0#2175, %tar_xz_1467_0#2176, %tar_xz_1467_0#2177, %tar_xz_1467_0#2178, %tar_xz_1467_0#2179, %tar_xz_1467_0#2180, %tar_xz_1467_0#2181, %tar_xz_1467_0#2182, %tar_xz_1467_0#2183, %tar_xz_1467_0#2184, %tar_xz_1467_0#2185, %tar_xz_1467_0#2186, %tar_xz_1467_0#2187, %tar_xz_1467_0#2188, %tar_xz_1467_0#2189, %tar_xz_1467_0#2190, %tar_xz_1467_0#2191, %tar_xz_1467_0#2192, %tar_xz_1467_0#2193, %tar_xz_1467_0#2194, %tar_xz_1467_0#2195, %tar_xz_1467_0#2196, %tar_xz_1467_0#2197, %tar_xz_1467_0#2198, %tar_xz_1467_0#2199, %tar_xz_1467_0#2200, %tar_xz_1467_0#2201, %tar_xz_1467_0#2202, %tar_xz_1467_0#2203, %tar_xz_1467_0#2204, %tar_xz_1467_0#2205, %tar_xz_1467_0#2206, %tar_xz_1467_0#2207, %tar_xz_1467_0#2208, %tar_xz_1467_0#2209, %tar_xz_1467_0#2210, %tar_xz_1467_0#2211, %tar_xz_1467_0#2212, %tar_xz_1467_0#2213, %tar_xz_1467_0#2214, %tar_xz_1467_0#2215, %tar_xz_1467_0#2216, %tar_xz_1467_0#2217, %tar_xz_1467_0#2218, %tar_xz_1467_0#2219, %tar_xz_1467_0#2220, %tar_xz_1467_0#2221, %tar_xz_1467_0#2222, %tar_xz_1467_0#2223, %tar_xz_1467_0#2224, %tar_xz_1467_0#2225, %tar_xz_1467_0#2226, %tar_xz_1467_0#2227, %tar_xz_1467_0#2228, %tar_xz_1467_0#2229, %tar_xz_1467_0#2230, %tar_xz_1467#63) -> [
      #splice.entry<"/build/gawk-5.4.1/INSTALL" file 444 mtime 1795046409 "8269293b2738175f54354957d64f691ea9a55ffacb9d8912c79060a9b9bf769b">,
      #splice.entry<"/build/gawk-5.4.1/Makefile.in" file 644 mtime 1795046409 "5553f13d74f03ed0c169742dc1f62fd5687ea79754cb1a7d0d0d2956e562a03c">,
      #splice.entry<"/build/gawk-5.4.1/autom4te.cache/requests" file 644 mtime 1795046409 "c5cda5730090a1b5ce31a26493e838531609e6bf4651e2ea17380e9d0f8937a3">,
      #splice.entry<"/build/gawk-5.4.1/awklib/Makefile.in" file 644 mtime 1795046409 "0d84d707592d2b6cac1100b80b67caee7df6dd797ad455e3aac7065cda618f56">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/ar-lib" file 555 mtime 1795046409 "8e211dd0df621bf4985c1d3466548564a835e379acfc12dc0c1009ced4f90417">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/compile" file 555 mtime 1795046409 "92ed7feeda61ad958dc3c4cc4efd724e1414482f1cad60b74b09e0633a93dfd6">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.guess" file 555 mtime 1795046409 "641cae3c0c74c49354d3ede009f3febd80febe1501a77c1d9fac8d42cc45b6cb">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/config.sub" file 555 mtime 1795046409 "fe3a2f32fbaff57848732549f48d983fd6526024ec2f0f5a9dc75c2f4359a3a6">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/depcomp" file 555 mtime 1795046409 "ac3ae010382a83144ff6ec1a4c368a3f16a14ea2b12751aa73ddfb548d931574">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/install-sh" file 555 mtime 1795046409 "776876b3909b096439109a4c7642eb0f9100f6ba3fb42fa93d05351e50a0a7ef">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/missing" file 555 mtime 1795046409 "4f17c4a66ec5b8000d44573a576f6b5d9c0c84848e8fd1286f84a52f439db4e9">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/texinfo.tex" file 444 mtime 1795046409 "d01e8daf8bf49e2c8a280729ef86c35bb23b3d9bc6292f5776562a20b5961b85">,
      #splice.entry<"/build/gawk-5.4.1/build-aux/ylwrap" file 555 mtime 1795046409 "2429c34e7f0e95b15fa7ae944c42de4454447af7302586b123b7dff2d4e01cdc">,
      #splice.entry<"/build/gawk-5.4.1/doc/Makefile.in" file 644 mtime 1795046409 "f65f4e010afbbcbfab43e391af25c633c250628f203243a079fb5f0cb80d623f">,
      #splice.entry<"/build/gawk-5.4.1/extras/Makefile.in" file 644 mtime 1795046409 "172c88b37584fb9d577085586c45d5cb4369e30689abe9ded71b7c999a9e6893">,
      #splice.entry<"/build/gawk-5.4.1/support/Makefile.in" file 644 mtime 1795046409 "71d72f651f8605bca947ec110ecd3dbbc8803d21b997f582aa53768f3e17a8bd">,
      #splice.entry<"/build/gawk-5.4.1/test/Makefile.in" file 644 mtime 1795046409 "029a1032274b2dab45a1ea538e1afb1e54e1e0e0f56c4917a96e9d6b5e00df41">
  ]
  %find_sed_26594 = splice.exec "find|sed" at 26594(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#5, %cp_21444) -> [
      #splice.entry<"/build/gawk-5.4.1/build-aux/ltmain.sh" file 444 mtime 1795046409 "1ee2563006f895478c6421cc5ad0cae1adad870b044b1376ae22266108d770aa">
  ]
  %touch_26703 = splice.copy "touch" at 26703(%autom4te_24370_5#3) -> <"/build/gawk-5.4.1/extension/configure" file 755 mtime 1795046407 "6e265a7b88145312d4b2bf58f06306acaad153b9e9cc731b3d2e738af370016f">
  %find_basename_stat_mktemp__4_26776 = splice.exec "find|basename|stat|mktemp|+4" at 26776(%sandbox_720#0, %tar_xz_1467#0, %autom4te_25318_10#3) -> [
      #splice.entry<"/build/gawk-5.4.1/configure" file 755 mtime 1795046408 "f2d95095886a17fca69db7c38aa2f9f332ecf23ebb49cab37e7c93ca7ae3e292">
  ]
  %bash_26987:22 = splice.exec "bash" at 26987(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467_0#1, %tar_xz_1467_0#2, %tar_xz_1467_0#3, %cat_patch_8932_1#0, %tar_xz_1467_0#5, %tar_xz_1467_0#6, %cat_patch_8932, %automake_25858_19#0, %tar_xz_1467_0#8, %automake_25858_19#1, %tar_xz_1467_0#10, %tar_xz_1467_0#11, %tar_xz_1467_0#12, %tar_xz_1467_0#13, %tar_xz_1467_0#14, %tar_xz_1467#1, %tar_xz_1467_0#37, %aclocal_14331_2#0, %tar_xz_1467_0#39, %aclocal_14331, %cat_patch_8932_1#2, %tar_xz_1467_0#41, %tar_xz_1467_0#42, %tar_xz_1467#2, %automake_25858_19#3, %tar_xz_1467#5, %automake_25858, %automake_25858_14, %automake_25858_15, %cp_11714, %automake_25858_16, %automake_25858_17, %find_sed_26594, %automake_25858_18, %tar_xz_1467_0#165, %tar_xz_1467_0#166, %tar_xz_1467_0#167, %tar_xz_1467_0#168, %tar_xz_1467_0#169, %autoheader_25580_13#2, %autoheader_25580_12, %find_basename_stat_mktemp__4_26776, %tar_xz_1467_0#172, %autom4te_25318, %tar_xz_1467_0#173, %tar_xz_1467_0#174, %tar_xz_1467#6, %automake_25858_19#13, %tar_xz_1467_0#321, %tar_xz_1467_0#322, %tar_xz_1467#8, %tar_xz_1467_0#324, %tar_xz_1467_0#325, %tar_xz_1467_0#326, %tar_xz_1467_0#327, %tar_xz_1467_0#328, %tar_xz_1467_0#329, %automake_24905_9#7, %tar_xz_1467_0#331, %automake_24905_9#8, %tar_xz_1467_0#333, %tar_xz_1467_0#334, %tar_xz_1467_0#335, %aclocal_23618, %aclocal_19246, %autoheader_24625_8#3, %autoheader_24625_7, %touch_26703, %tar_xz_1467_0#339, %autom4te_24370, %tar_xz_1467_0#340, %tar_xz_1467_0#341, %tar_xz_1467_0#342, %tar_xz_1467_0#343, %tar_xz_1467_0#344, %tar_xz_1467_0#345, %tar_xz_1467_0#346, %tar_xz_1467_0#347, %tar_xz_1467_0#348, %tar_xz_1467_0#349, %tar_xz_1467_0#350, %tar_xz_1467_0#351, %tar_xz_1467_0#352, %tar_xz_1467_0#353, %tar_xz_1467_0#354, %tar_xz_1467_0#355, %tar_xz_1467_0#356, %tar_xz_1467#9, %tar_xz_1467_0#358, %tar_xz_1467_0#359, %tar_xz_1467_0#360, %cp_18702, %tar_xz_1467_0#361, %tar_xz_1467_0#362, %tar_xz_1467_0#363, %tar_xz_1467_0#364, %tar_xz_1467_0#365, %tar_xz_1467_0#366, %tar_xz_1467_0#367, %tar_xz_1467_0#368, %tar_xz_1467_0#369, %tar_xz_1467_0#370, %tar_xz_1467_0#371, %tar_xz_1467_0#372, %tar_xz_1467_0#373, %tar_xz_1467_0#374, %tar_xz_1467_0#375, %tar_xz_1467_0#376, %tar_xz_1467_0#377, %tar_xz_1467_0#378, %tar_xz_1467_0#379, %tar_xz_1467_0#380, %tar_xz_1467_0#381, %tar_xz_1467_0#382, %tar_xz_1467_0#383, %tar_xz_1467_0#384, %tar_xz_1467#10, %automake_25858_19#14, %tar_xz_1467_0#391, %tar_xz_1467_0#392, %tar_xz_1467_0#393, %tar_xz_1467_0#394, %tar_xz_1467_0#395, %tar_xz_1467_0#396, %tar_xz_1467_0#397, %tar_xz_1467_0#398, %tar_xz_1467_0#399, %tar_xz_1467_0#400, %tar_xz_1467_0#401, %tar_xz_1467#11, %tar_xz_1467_0#458, %tar_xz_1467#12, %tar_xz_1467_0#476, %tar_xz_1467_0#477, %tar_xz_1467_0#478, %tar_xz_1467_0#479, %tar_xz_1467#13, %tar_xz_1467#14, %tar_xz_1467_0#514, %tar_xz_1467_0#515, %tar_xz_1467_0#516, %tar_xz_1467_0#517, %tar_xz_1467_0#518, %tar_xz_1467_0#519, %cp_13785, %tar_xz_1467_0#520, %tar_xz_1467_0#521, %tar_xz_1467_0#522, %tar_xz_1467_0#523, %tar_xz_1467_0#524, %tar_xz_1467_0#525, %tar_xz_1467_0#526, %tar_xz_1467_0#527, %tar_xz_1467_0#528, %tar_xz_1467_0#529, %tar_xz_1467_0#530, %tar_xz_1467_0#531, %tar_xz_1467_0#532, %tar_xz_1467_0#533, %tar_xz_1467_0#534, %tar_xz_1467_0#535, %tar_xz_1467_0#536, %tar_xz_1467_0#537, %tar_xz_1467_0#538, %tar_xz_1467_0#539, %tar_xz_1467_0#540, %tar_xz_1467_0#541, %tar_xz_1467_0#542, %tar_xz_1467_0#543, %tar_xz_1467_0#544, %tar_xz_1467_0#545, %tar_xz_1467_0#546, %tar_xz_1467_0#547, %tar_xz_1467_0#548, %tar_xz_1467_0#549, %tar_xz_1467_0#550, %tar_xz_1467_0#551, %tar_xz_1467_0#552, %tar_xz_1467_0#553, %tar_xz_1467_0#554, %tar_xz_1467_0#555, %tar_xz_1467_0#556, %tar_xz_1467_0#557, %tar_xz_1467_0#558, %tar_xz_1467_0#559, %tar_xz_1467_0#560, %tar_xz_1467_0#561, %tar_xz_1467_0#562, %tar_xz_1467_0#563, %tar_xz_1467_0#564, %tar_xz_1467_0#565, %tar_xz_1467_0#566, %tar_xz_1467_0#567, %tar_xz_1467_0#568, %tar_xz_1467_0#569, %tar_xz_1467_0#570, %tar_xz_1467#15, %tar_xz_1467_0#576, %tar_xz_1467_0#577, %tar_xz_1467_0#578, %tar_xz_1467_0#579, %tar_xz_1467_0#580, %tar_xz_1467#16, %automake_25858_19#15, %tar_xz_1467_0#626, %tar_xz_1467#18, %automake_25858_19#16, %tar_xz_1467_0#2230, %tar_xz_1467#63) -> [
      #splice.entry<"/build/gawk-5.4.1/Makefile" file 644 mtime 1795046413 "6b6c85da134111fd6e1678a59f97bafea5397d7d86038f1c6721d3d204e41512">,
      #splice.entry<"/build/gawk-5.4.1/awklib/Makefile" file 644 mtime 1795046414 "f50810ed4a7226753bea27b5415e69da497094bb987ab762faf8165a7b4e07aa">,
      #splice.entry<"/build/gawk-5.4.1/config.h" file 644 mtime 1795046414 "5c0e5b02e809f1c4c58ca03598a101cf6a686cc38dc6c67e413d648d229a66e5">,
      #splice.entry<"/build/gawk-5.4.1/config.status" file 755 mtime 1795046413 "8aad1bc8148a0404e5a59f4f102dc2710c0e5f90aaae6d33470c50326c75bb4b">,
      #splice.entry<"/build/gawk-5.4.1/doc/Makefile" file 644 mtime 1795046414 "3a3d24f0e557effb3529ad35e6955e6feccfb0362cfbe440b07d10d434c72453">,
      #splice.entry<"/build/gawk-5.4.1/extension/Makefile" file 644 mtime 1795046417 "1b3cbfb97b629eefe60a54f2b6943deaece44b6dd81e77d2854343c14a13ef33">,
      #splice.entry<"/build/gawk-5.4.1/extension/config.h" file 644 mtime 1795046417 "43b5f0e12ebc77ae2f7b770bf313245e35f357c5488a392ed553fe4039f327ca">,
      #splice.entry<"/build/gawk-5.4.1/extension/config.log" file 644 mtime 1795046417 "f45001ac85cc201ea94e5b15e9bfdd44ed78d69dcc17321fbbf4121ff2a39453">,
      #splice.entry<"/build/gawk-5.4.1/extension/config.status" file 755 mtime 1795046417 "85d98275297de3bf9474af8840e2a9ecdabbb2df7e42912a8aa988772627486b">,
      #splice.entry<"/build/gawk-5.4.1/extension/libtool" file 755 mtime 1795046417 "3f8a174df8cff2ab87d53c61aad59bee67e69513977842a3b092924f35e16383">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/Makefile" file 644 mtime 1795046417 "0d8ae861a87ec88cc0cf9d3c9c7e74d936ddbd52097be13d1ef73dabfbc7386a">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/Makefile.in" file 644 mtime 1795046417 "61f9a60ddbf89b6e8113a4b216f144ee37f6cd2b4dfa41ef0146ee9978af8b9f">,
      #splice.entry<"/build/gawk-5.4.1/extension/po/POTFILES" file 644 mtime 1795046417 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/gawk-5.4.1/extension/stamp-h1" file 644 mtime 1795046417 "24fdde0aee1f49666fc7a5bd7f422dc0118e4db128bc1f606f7f047c9b245bb4">,
      #splice.entry<"/build/gawk-5.4.1/extras/Makefile" file 644 mtime 1795046414 "7ba41e815b8dc1e105f44d3b0c24f7606bc9e94859ef6beef76a77f50b9117ce">,
      #splice.entry<"/build/gawk-5.4.1/gawkbug" file 755 mtime 1795046414 "9deb450d06459e6117e96c7362e935e5f6153c5b7b0d3f5475c44bbc2d0a8328">,
      #splice.entry<"/build/gawk-5.4.1/po/Makefile" file 644 mtime 1795046414 "8db335245c3f7de5db8919e0379a4a376e5f54cdcfbefa729c5ec2d70fb1374a">,
      #splice.entry<"/build/gawk-5.4.1/po/Makefile.in" file 644 mtime 1795046414 "ae07bb74fa5f7b81541eab3a1f0d07cf5e279138b577a6d7b32252b4ec8fa367">,
      #splice.entry<"/build/gawk-5.4.1/po/POTFILES" file 644 mtime 1795046414 "81a5847d2661cd9b29b71e1b6588bd52230b99129f01ab35eb52ea7e3ce0b3b4">,
      #splice.entry<"/build/gawk-5.4.1/stamp-h1" file 644 mtime 1795046414 "24fdde0aee1f49666fc7a5bd7f422dc0118e4db128bc1f606f7f047c9b245bb4">,
      #splice.entry<"/build/gawk-5.4.1/support/Makefile" file 644 mtime 1795046413 "66a673f54ca7e60310620bcf8172a68e3b79c4578901cfe3c344c9ff70f78dc3">,
      #splice.entry<"/build/gawk-5.4.1/test/Makefile" file 644 mtime 1795046414 "d78871d0e9958e8259d379ee2467861e027b55abaf533fb77731aad29a7bd281">
  ]
  %gcc_108274 = splice.exec "gcc" at 108274 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#590, %tar_xz_1467_0#591, %tar_xz_1467_0#593, %tar_xz_1467_0#598, %tar_xz_1467_0#599, %tar_xz_1467_0#600, %tar_xz_1467_0#603, %tar_xz_1467_0#615, %tar_xz_1467_0#620, %tar_xz_1467_0#624, %tar_xz_1467_0#625) -> [
      #splice.entry<"/build/gawk-5.4.1/support/dfa.o" file 644 mtime 1795046418 "eb5cf52416d16478851e49434103cbd75b4db979bb347918d82794968a65322a">
  ]
  %gcc_108386 = splice.exec "gcc" at 108386 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#594, %tar_xz_1467_0#595, %tar_xz_1467_0#597, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/getopt.o" file 644 mtime 1795046418 "4e0c88ce58955f71066cc525c8e722b4903b6d42f988e4c8cb345be30a4fec78">
  ]
  %gcc_108514 = splice.exec "gcc" at 108514 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#595, %tar_xz_1467_0#596, %tar_xz_1467_0#597, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/getopt1.o" file 644 mtime 1795046418 "c177365825e695502fb463c53cf8d20ac40d104d2af5e5e306314e4ab77e755f">
  ]
  %gcc_108615 = splice.exec "gcc" at 108615 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#602, %tar_xz_1467_0#603, %tar_xz_1467_0#615, %tar_xz_1467_0#624) -> [
      #splice.entry<"/build/gawk-5.4.1/support/localeinfo.o" file 644 mtime 1795046418 "4bb3710fb991aa0bd77e5d7e4ce43c94448308a2b38bc85186e15f025fab8c7d">
  ]
  %gcc_108717 = splice.exec "gcc" at 108717 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#588, %tar_xz_1467_0#589, %tar_xz_1467_0#612, %tar_xz_1467_0#613, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/minrx.o" file 644 mtime 1795046419 "5252d4fb878ecf4a88791921c3959b93cecf92a2a56aa5ec2efcdc7400c6c6ca">
  ]
  %gcc_108830 = splice.exec "gcc" at 108830 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#615, %tar_xz_1467_0#616, %tar_xz_1467_0#617) -> [
      #splice.entry<"/build/gawk-5.4.1/support/random.o" file 644 mtime 1795046419 "76bbb0925035f25cf6826c96ca3ad64a08f628d9b22d101296ef1aa6c110df79">
  ]
  %gcc_108932 = splice.exec "gcc" at 108932 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#586, %tar_xz_1467_0#592, %tar_xz_1467_0#599, %tar_xz_1467_0#600, %tar_xz_1467_0#601, %tar_xz_1467_0#603, %tar_xz_1467#17, %tar_xz_1467_0#605, %tar_xz_1467_0#606, %tar_xz_1467_0#615, %tar_xz_1467_0#618, %tar_xz_1467_0#619, %tar_xz_1467_0#620, %tar_xz_1467_0#621, %tar_xz_1467_0#622, %tar_xz_1467_0#623, %tar_xz_1467_0#624) -> [
      #splice.entry<"/build/gawk-5.4.1/support/regex.o" file 644 mtime 1795046421 "b94f3b6c64c1a945009e96e284a777169e613ca752534374891f0e5e910fd99f">
  ]
  %gcc_109102 = splice.exec "gcc" at 109102 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#592, %tar_xz_1467_0#601, %tar_xz_1467#17, %tar_xz_1467_0#606, %tar_xz_1467_0#607, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_at_failure.o" file 644 mtime 1795046422 "c30179fae206b80b192e3ab2dddeeb9e1caf52f1cc3a6c2fdd3cace51653202c">
  ]
  %gcc_109202 = splice.exec "gcc" at 109202 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#592, %tar_xz_1467_0#599, %tar_xz_1467_0#600, %tar_xz_1467_0#601, %tar_xz_1467#17, %tar_xz_1467_0#606, %tar_xz_1467_0#608, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_emplace_enlarge.o" file 644 mtime 1795046422 "d71fbd4d1e515a42c687aeb9d5c35613ec77786f2afa70610b19d94be2261cba">
  ]
  %gcc_109303 = splice.exec "gcc" at 109303 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#592, %tar_xz_1467_0#601, %tar_xz_1467#17, %tar_xz_1467_0#606, %tar_xz_1467_0#609, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_finalize.o" file 644 mtime 1795046422 "7722217c1cacbb289fcdc112279d7e92c86e88d93bf6272f7eb0bea710c1b869">
  ]
  %gcc_109402 = splice.exec "gcc" at 109402 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#592, %tar_xz_1467_0#599, %tar_xz_1467_0#600, %tar_xz_1467_0#601, %tar_xz_1467#17, %tar_xz_1467_0#606, %tar_xz_1467_0#610, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_resize.o" file 644 mtime 1795046422 "13fc9943a95888d0465ee8b6a8967653734374de5d16ddf1997d423298ab0f18">
  ]
  %gcc_109502 = splice.exec "gcc" at 109502 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#592, %tar_xz_1467_0#601, %tar_xz_1467#17, %tar_xz_1467_0#606, %tar_xz_1467_0#611, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/malloc/dynarray_resize_clear.o" file 644 mtime 1795046422 "d2797f07cad72fabe43f1e1d0fed055faaf06c1499067ce652eb03de83895914">
  ]
  %gcc_109602 = splice.exec "gcc" at 109602 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#16, %tar_xz_1467_0#614, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/support/pma.o" file 644 mtime 1795046422 "cfc588b1e9dca10a5b8bf8a75c1f03d04768765c8bbfbd2da276566939e1e2c3">
  ]
  %ar_109725 = splice.exec "ar" at 109725 as "cc_library"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#16, %gcc_108274, %gcc_108386, %gcc_108514, %gcc_108615, %tar_xz_1467#17, %gcc_109102, %gcc_109202, %gcc_109303, %gcc_109402, %gcc_109502, %gcc_108717, %gcc_109602, %gcc_108830, %gcc_108932) -> [
      #splice.entry<"/build/gawk-5.4.1/support/libsupport.a" file 644 mtime 1795046422 "0bedf163653a35b89a4d16a0224b403372a55a16f6246e25171c7106ad41b046">
  ]
  %gcc_109805 = splice.exec "gcc" at 109805 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467_0#39, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/array.o" file 644 mtime 1795046422 "7bd863bed37fb823d7adca1ebab7921ccd27c2501495c81c8a6d1db9e7cbca9d">
  ]
  %gcc_109918 = splice.exec "gcc" at 109918 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %tar_xz_1467_0#41, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/awkgram.o" file 644 mtime 1795046424 "f7e9da3bd31b7340b01cf32d36e428c0cfb73be4fdb49ea0c1ac40c8aa515850">
  ]
  %gcc_110030 = splice.exec "gcc" at 110030 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %tar_xz_1467_0#165, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#617, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/builtin.o" file 644 mtime 1795046426 "9d2a2d000160ef8684d7e009877d69a61c22ecf88edb1c82318a68dbb260a89b">
  ]
  %gcc_110154 = splice.exec "gcc" at 110154 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %tar_xz_1467_0#166, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/cint_array.o" file 644 mtime 1795046427 "4a356cf9478e1ce48e12e9a45ea1b45cac38acf08ce8a3d39ebd65661d4ed478">
  ]
  %gcc_110256 = splice.exec "gcc" at 110256 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %tar_xz_1467_0#167, %tar_xz_1467_0#168, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/command.o" file 644 mtime 1795046427 "ca86fa83ea7f2eef558c0c2d921f667d4f9205d458367b4b05744e2b8d4492f1">
  ]
  %gcc_110367 = splice.exec "gcc" at 110367 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %tar_xz_1467_0#167, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#174, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/debug.o" file 644 mtime 1795046429 "201332c660f352ca992279c7a63ccc04595a163f42a7d49326cc44d64d66bcd1">
  ]
  %gcc_110487 = splice.exec "gcc" at 110487 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#321, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#400, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/eval.o" file 644 mtime 1795046431 "89a855889ab9068dedc3f11ffc159fc5c30174115fc9cedf1b399436b2310759">
  ]
  %gcc_110601 = splice.exec "gcc" at 110601 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#322, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/ext.o" file 644 mtime 1795046431 "c84d8dad9f9b9fb393d34c863ccec272e24ba6a2a8581a270f5815ac652a7155">
  ]
  %gcc_110703 = splice.exec "gcc" at 110703 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#391, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/field.o" file 644 mtime 1795046432 "bbe71ae361ece7e3fa50f7471b58239cfca8216589d6ad4c4248745f67bb211e">
  ]
  %gcc_110813 = splice.exec "gcc" at 110813 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#392, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/floatcomp.o" file 644 mtime 1795046432 "380d422a625b639129c5517e4e4b79c153f9552bc1ced7eceb7be886aee1a38f">
  ]
  %gcc_110913 = splice.exec "gcc" at 110913 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#394, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/gawkapi.o" file 644 mtime 1795046432 "c4902e802fadbb491ea6586894b28f3a4da82d37e8ad0114953c680c43d1e9ca">
  ]
  %gcc_111024 = splice.exec "gcc" at 111024 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#397, %tar_xz_1467_0#398, %tar_xz_1467#15, %tar_xz_1467_0#575, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/gawkmisc.o" file 644 mtime 1795046432 "2cfe3932671f08732a06dafb2c96fbcbda8143de96a35fe339d9d0ca77041e8b">
  ]
  %gcc_111135 = splice.exec "gcc" at 111135 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#399, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/int_array.o" file 644 mtime 1795046433 "519affd160e8cd46abe68957920449d70489ef4585c9247aef06806370e4ae0e">
  ]
  %gcc_111251 = splice.exec "gcc" at 111251 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#401, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/io.o" file 644 mtime 1795046434 "b06b36d504136b0e78bd7854ea843ee4e0210ac47bac684fb04bc62153542701">
  ]
  %gcc_111354 = splice.exec "gcc" at 111354 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#458, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#595, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/main.o" file 644 mtime 1795046434 "0b4d304606e685d21856b026986d41670d5767f5912b21c3499cafa294a153ae">
  ]
  %gcc_111466 = splice.exec "gcc" at 111466 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#476, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/mpfr.o" file 644 mtime 1795046434 "e2ecd12723510357b2e6eebe5ac8cb0f3ff9a79acc88ff444d47c6b39c0e63cb">
  ]
  %gcc_111567 = splice.exec "gcc" at 111567 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#477, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/msg.o" file 644 mtime 1795046434 "45fa03661af93afc99b0169f17126e22fc57a586e6cb63c5e54a7d153b251d78">
  ]
  %gcc_111679 = splice.exec "gcc" at 111679 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#478, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/node.o" file 644 mtime 1795046435 "0e30d1cf17dc3b89f87f82a929bb4d977ee84a37b38fa12fda479fe4e799bc46">
  ]
  %gcc_111789 = splice.exec "gcc" at 111789 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#576, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/printf.o" file 644 mtime 1795046435 "a15d8865838b5aa443270eade72026e8d9320989bdd6af54b1a29d3e0c276601">
  ]
  %gcc_111899 = splice.exec "gcc" at 111899 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#577, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/profile.o" file 644 mtime 1795046436 "e0acb8546ea8de147300d4c300ad4736fd22545bb718f97a5cfbf5689f7c64e6">
  ]
  %gcc_112010 = splice.exec "gcc" at 112010 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#578, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#603, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/re.o" file 644 mtime 1795046436 "3348f5dc367d1d9c4a3ab894bd3844232d2bc519debb00ab06b9fc891b424724">
  ]
  %gcc_112120 = splice.exec "gcc" at 112120 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#579, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/replace.o" file 644 mtime 1795046437 "6526557bb27179c6a0effbc5a6c2f54b4819b73c3add7d411fb00ffb79ca61c7">
  ]
  %gcc_112222 = splice.exec "gcc" at 112222 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#580, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620) -> [
      #splice.entry<"/build/gawk-5.4.1/str_array.o" file 644 mtime 1795046437 "fb18a1f741b7a762e053a4e5208e7eca31d7bc90d305973aeff96577c1960c4d">
  ]
  %gcc_112333 = splice.exec "gcc" at 112333 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %cat_patch_8932_1#2, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467_0#393, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467#16, %tar_xz_1467_0#591, %tar_xz_1467_0#598, %tar_xz_1467_0#613, %tar_xz_1467_0#615, %tar_xz_1467_0#620, %tar_xz_1467_0#626) -> [
      #splice.entry<"/build/gawk-5.4.1/symbol.o" file 644 mtime 1795046437 "d10a54c61cc15c704a253f6761b993ed7df86e4762d1ed899694c6a7e110dee6">
  ]
  %gcc_112444 = splice.exec "gcc" at 112444 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#615, %tar_xz_1467_0#2230) -> [
      #splice.entry<"/build/gawk-5.4.1/version.o" file 644 mtime 1795046437 "58b21d6f8be4a3e69fe5b6dd1a7db85577f30ae39878f23d7d897b2c5b5a02cc">
  ]
  %gcc_112594 = splice.exec "gcc" at 112594 as "cc_binary"(%sandbox_720#0, %tar_xz_1467#0, %gcc_109805, %gcc_109918, %gcc_110030, %gcc_110154, %gcc_110256, %gcc_110367, %gcc_110487, %gcc_110601, %gcc_110703, %gcc_110813, %gcc_110913, %gcc_111024, %gcc_111135, %gcc_111251, %gcc_111354, %gcc_111466, %gcc_111567, %gcc_111679, %gcc_111789, %gcc_111899, %gcc_112010, %gcc_112120, %gcc_112222, %tar_xz_1467#16, %ar_109725, %gcc_112333, %gcc_112444) -> [
      #splice.entry<"/build/gawk-5.4.1/gawk" file 755 mtime 1795046437 "e06af91d1f2467f1e6b0b17040f0a502459f11d847a4021e08b732d2659fc7d5">
  ]
  %mkdir_114089 = splice.literal "mkdir" at 114089 folded -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs" dir 755 mtime 1795046437>
  ]
  %gcc_115535 = splice.exec "gcc" at 115535 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#342, %tar_xz_1467_0#350, %tar_xz_1467_0#381, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/filefuncs.o" file 644 mtime 1795046438 "0daca4b1d40bff189eb7bfc4b2b75c6f69d305589631bf2a34520818cf281e4e">
  ]
  %glue_115638 = splice.literal "glue" at 115638 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/filefuncs.loT" file 644 mtime 1795046438 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_115638 = splice.exec "cat" at 115638(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_115638) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/filefuncs.loT" file 644 mtime 1795046438 "4ba01fd6bc5fb0197863318dec930ec21c349feeb2c1966e99060c98d51c3085">
  ]
  %mv_115650 = splice.copy "mv" at 115650(%cat_115638) -> <"/build/gawk-5.4.1/extension/filefuncs.lo" file 644 mtime 1795046438 "4ba01fd6bc5fb0197863318dec930ec21c349feeb2c1966e99060c98d51c3085">
  %gcc_116038 = splice.exec "gcc" at 116038 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %tar_xz_1467_0#380, %tar_xz_1467_0#381) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/stack.o" file 644 mtime 1795046438 "022e0550d22a0a3708a62396bf5bff045a643d86d8066708c45d3d31e715ece5">
  ]
  %glue_116132 = splice.literal "glue" at 116132 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/stack.loT" file 644 mtime 1795046438 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_116132 = splice.exec "cat" at 116132(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_116132) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/stack.loT" file 644 mtime 1795046438 "e16eec54cf6a9cc68f45cb23a814abc889fb04cbcf4022dcf0934bd985729cbb">
  ]
  %mv_116144 = splice.copy "mv" at 116144(%cat_116132) -> <"/build/gawk-5.4.1/extension/stack.lo" file 644 mtime 1795046438 "e16eec54cf6a9cc68f45cb23a814abc889fb04cbcf4022dcf0934bd985729cbb">
  %gcc_116521 = splice.exec "gcc" at 116521 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#348, %tar_xz_1467_0#349, %tar_xz_1467_0#350, %tar_xz_1467_0#479) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/gawkfts.o" file 644 mtime 1795046438 "02514d7f083985ec8536303234b87c53e2ac431e8638178b43bbb1526d729755">
  ]
  %glue_116624 = splice.literal "glue" at 116624 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/gawkfts.loT" file 644 mtime 1795046438 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_116624 = splice.exec "cat" at 116624(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_116624) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/gawkfts.loT" file 644 mtime 1795046438 "d70dd8e9386ad335fbae5f3e2e9ea975465cf9ddb295a15fa56bb2159f408b89">
  ]
  %mv_116636 = splice.copy "mv" at 116636(%cat_116624) -> <"/build/gawk-5.4.1/extension/gawkfts.lo" file 644 mtime 1795046438 "d70dd8e9386ad335fbae5f3e2e9ea975465cf9ddb295a15fa56bb2159f408b89">
  %bash_116655:4 = splice.exec "bash" at 116655(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_115535, %gcc_116521, %gcc_116038, %mv_115650, %mv_116636, %bash_26987#9, %mv_116144) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/filefuncs.la" link 0 mtime 1795046438 "../filefuncs.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/filefuncs.lai" file 644 mtime 1795046438 "e869e4f36f5c2046287da053ba4192d3a96a86f451f360e9c6e19e8fe774b2fa">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/filefuncs.so" file 755 mtime 1795046438 "bdb6bae4acd198fbc91128067df4ac6989a044b3c60036b6102de2a04d4d71c7">,
      #splice.entry<"/build/gawk-5.4.1/extension/filefuncs.la" file 644 mtime 1795046438 "2ec0b39e2cbb90d4304221bf77e71793d4b9b2e0a0eae72801a47c5f35d81df1">
  ]
  %gcc_117923 = splice.exec "gcc" at 117923 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#344, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fnmatch.o" file 644 mtime 1795046438 "b6f39a50f844311c0a1984ea8d36883366a625117015a8dc667b2032e20a874a">
  ]
  %glue_118028 = splice.literal "glue" at 118028 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/fnmatch.loT" file 644 mtime 1795046438 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_118028 = splice.exec "cat" at 118028(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_118028) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/fnmatch.loT" file 644 mtime 1795046438 "e8e535a04d505ba2d420560df16ad0b9011db58b24c237dde089bac12a59f17a">
  ]
  %mv_118040 = splice.copy "mv" at 118040(%cat_118028) -> <"/build/gawk-5.4.1/extension/fnmatch.lo" file 644 mtime 1795046438 "e8e535a04d505ba2d420560df16ad0b9011db58b24c237dde089bac12a59f17a">
  %bash_118059:4 = splice.exec "bash" at 118059(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_117923, %mv_118040, %bash_26987#9) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fnmatch.la" link 0 mtime 1795046438 "../fnmatch.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fnmatch.lai" file 644 mtime 1795046438 "f662a897e96833225c050ff929eb6327ecf53fccf80be1d2343e1c099d0069d9">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fnmatch.so" file 755 mtime 1795046438 "9d2efe22ac4f2e3fb78f9d0e79d7f341169a4bda42bccd75af1cae18ce4e0064">,
      #splice.entry<"/build/gawk-5.4.1/extension/fnmatch.la" file 644 mtime 1795046438 "00fef9f7cce20fd7534dcdb3cd9144f2775b2d85fd95a78911bb80543c5772e0">
  ]
  %gcc_119323 = splice.exec "gcc" at 119323 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#346, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fork.o" file 644 mtime 1795046439 "4edfe3d6ae9cd493457612a1b2b6aa269a7bbaa3444d3775101c874b8d870a52">
  ]
  %glue_119417 = splice.literal "glue" at 119417 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/fork.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_119417 = splice.exec "cat" at 119417(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_119417) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/fork.loT" file 644 mtime 1795046439 "fb89510ca76db60533c62aed61a794156900503f44cd9ae3ef1023ccab262b12">
  ]
  %mv_119429 = splice.copy "mv" at 119429(%cat_119417) -> <"/build/gawk-5.4.1/extension/fork.lo" file 644 mtime 1795046439 "fb89510ca76db60533c62aed61a794156900503f44cd9ae3ef1023ccab262b12">
  %bash_119448:4 = splice.exec "bash" at 119448(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_119323, %mv_119429, %bash_26987#9) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fork.la" link 0 mtime 1795046439 "../fork.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fork.lai" file 644 mtime 1795046439 "03ffa14df2ccfe0eeb1c52955531f80116c2073c44c62fcbcaeeafda1be8cc38">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/fork.so" file 755 mtime 1795046439 "3c195c9589f58de735f5a57cec3ff39f3e04713c274c9f7091bd495709e33634">,
      #splice.entry<"/build/gawk-5.4.1/extension/fork.la" file 644 mtime 1795046439 "d421c07f016a69a2ccbf6c3f6d1d865b5714b4d42705ce1cb3f54c6bda1a584a">
  ]
  %gcc_120712 = splice.exec "gcc" at 120712 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#352, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/inplace.o" file 644 mtime 1795046439 "10cb61b2464f7d1926d007235f86e54c32cc077505d26c16dead73f36bbfb46b">
  ]
  %glue_120816 = splice.literal "glue" at 120816 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/inplace.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_120816 = splice.exec "cat" at 120816(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_120816) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/inplace.loT" file 644 mtime 1795046439 "cd7d56d249a7684cd8b3e522ad13c91d32c14e5befe7b07eeae263e8af5c9eb1">
  ]
  %mv_120828 = splice.copy "mv" at 120828(%cat_120816) -> <"/build/gawk-5.4.1/extension/inplace.lo" file 644 mtime 1795046439 "cd7d56d249a7684cd8b3e522ad13c91d32c14e5befe7b07eeae263e8af5c9eb1">
  %bash_120847:4 = splice.exec "bash" at 120847(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_120712, %mv_120828, %bash_26987#9) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/inplace.la" link 0 mtime 1795046439 "../inplace.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/inplace.lai" file 644 mtime 1795046439 "c120fc1137c3ebb851d41726e49d32ef539134890b8b28203868dacd2bcb3872">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/inplace.so" file 755 mtime 1795046439 "319516596f8154293f846afaa3d9bad8296c58a0d0daf0db7de3e37d36fc783c">,
      #splice.entry<"/build/gawk-5.4.1/extension/inplace.la" file 644 mtime 1795046439 "ae9cb4f88a21594c3fab12ef14d6b7c2f961d052397e11af77dfe5d8957beb51">
  ]
  %gcc_122110 = splice.exec "gcc" at 122110 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#354, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/intdiv.o" file 644 mtime 1795046439 "09793fab0a8f9acfee7862c045fc5b275b56cb7585ae7ada5376a39c1f829710">
  ]
  %glue_122195 = splice.literal "glue" at 122195 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/intdiv.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_122195 = splice.exec "cat" at 122195(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_122195) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/intdiv.loT" file 644 mtime 1795046439 "6255cd46a701d5c04f6b95c272491b428ef7dfb54e0ab3698f1870dd93a2cbc3">
  ]
  %mv_122207 = splice.copy "mv" at 122207(%cat_122195) -> <"/build/gawk-5.4.1/extension/intdiv.lo" file 644 mtime 1795046439 "6255cd46a701d5c04f6b95c272491b428ef7dfb54e0ab3698f1870dd93a2cbc3">
  %bash_122226:4 = splice.exec "bash" at 122226(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_122110, %mv_122207, %bash_26987#9) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/intdiv.la" link 0 mtime 1795046439 "../intdiv.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/intdiv.lai" file 644 mtime 1795046439 "8f9b949d9eb1d6d6080e19667964989f9b445792b019c53a71f4dba34481887f">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/intdiv.so" file 755 mtime 1795046439 "2d01436c0481acd54ba7dcb728bce68972dc6eabb4a176fd21cfd052e1be754e">,
      #splice.entry<"/build/gawk-5.4.1/extension/intdiv.la" file 644 mtime 1795046439 "769b9c9ca91e71b0951ea3bed123c37afafd241e1afa156f426348840f1d47e4">
  ]
  %gcc_123502 = splice.exec "gcc" at 123502 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#356, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/ordchr.o" file 644 mtime 1795046439 "0dce437ca61c94f6e425683571be5c803afa80c2c2f80c718ced9e4f75ec3d27">
  ]
  %glue_123606 = splice.literal "glue" at 123606 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/ordchr.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_123606 = splice.exec "cat" at 123606(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_123606) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/ordchr.loT" file 644 mtime 1795046439 "3473bdae066efe0048d0a9a7b287f3f500a22a71d3bdcdbe2c5e99ab7773f781">
  ]
  %mv_123618 = splice.copy "mv" at 123618(%cat_123606) -> <"/build/gawk-5.4.1/extension/ordchr.lo" file 644 mtime 1795046439 "3473bdae066efe0048d0a9a7b287f3f500a22a71d3bdcdbe2c5e99ab7773f781">
  %bash_123637:4 = splice.exec "bash" at 123637(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_123502, %bash_26987#9, %mv_123618) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/ordchr.la" link 0 mtime 1795046439 "../ordchr.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/ordchr.lai" file 644 mtime 1795046439 "b47d98845938a11fb0c435849c8bab43695357a9d1211dcc533ca38b351fa883">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/ordchr.so" file 755 mtime 1795046439 "95fe74cc2cd669efabcf81449a88be164d31a30a3bb61aa7dcc7cbbdad67d4c7">,
      #splice.entry<"/build/gawk-5.4.1/extension/ordchr.la" file 644 mtime 1795046439 "dbabefeb189909c267b357db2eba2ad21bd400516fb401f77fd9b3a76a42d71d">
  ]
  %gcc_124898 = splice.exec "gcc" at 124898 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#348, %tar_xz_1467_0#371, %tar_xz_1467_0#395, %tar_xz_1467_0#398, %tar_xz_1467_0#479) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readdir.o" file 644 mtime 1795046439 "541f4541f512e2b372c813c4076d93e449308a08816990ba88197401e704938e">
  ]
  %glue_124993 = splice.literal "glue" at 124993 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/readdir.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_124993 = splice.exec "cat" at 124993(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_124993) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/readdir.loT" file 644 mtime 1795046439 "c34b4bc33d7b81b3bb4cf9084fb6384963c39ccd1bf5c28bbee040f188e01b10">
  ]
  %mv_125005 = splice.copy "mv" at 125005(%cat_124993) -> <"/build/gawk-5.4.1/extension/readdir.lo" file 644 mtime 1795046439 "c34b4bc33d7b81b3bb4cf9084fb6384963c39ccd1bf5c28bbee040f188e01b10">
  %bash_125024:4 = splice.exec "bash" at 125024(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_124898, %bash_26987#9, %mv_125005) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readdir.la" link 0 mtime 1795046439 "../readdir.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readdir.lai" file 644 mtime 1795046439 "fdf45b6aebe5fdc4b79ba1ad7ef83873c22384879d2f7e3c180c3e4c8a6c2bef">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readdir.so" file 755 mtime 1795046439 "002dfc0dfe28f7441834d1128e487c59550edefc212e174ab0cfb726d653ab70">,
      #splice.entry<"/build/gawk-5.4.1/extension/readdir.la" file 644 mtime 1795046439 "afef995f7b13850ef2272f2494b6ed4126977dce734fb2cb13bfbec1432b6d93">
  ]
  %gcc_126288 = splice.exec "gcc" at 126288 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#373, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readfile.o" file 644 mtime 1795046439 "4a91f8ca450b3e27676fecac3c73234a208952d01c6145414857439dec7e1dfe">
  ]
  %glue_126383 = splice.literal "glue" at 126383 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/readfile.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_126383 = splice.exec "cat" at 126383(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_126383) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/readfile.loT" file 644 mtime 1795046439 "295126c0f3adc9214bd60f4b2b1bc4c7c1b63d4948d04b1bb598b49062035af6">
  ]
  %mv_126395 = splice.copy "mv" at 126395(%cat_126383) -> <"/build/gawk-5.4.1/extension/readfile.lo" file 644 mtime 1795046439 "295126c0f3adc9214bd60f4b2b1bc4c7c1b63d4948d04b1bb598b49062035af6">
  %bash_126414:4 = splice.exec "bash" at 126414(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_126288, %bash_26987#9, %mv_126395) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readfile.la" link 0 mtime 1795046439 "../readfile.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readfile.lai" file 644 mtime 1795046439 "7019c412d4847c73a8975089a7a7858dcfe3c43b63838a7ff384b7e25b1eed06">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/readfile.so" file 755 mtime 1795046439 "2e37bd30a5efac63bb089cd7d683fd27a7f2ad983640562ecc24044d14506532">,
      #splice.entry<"/build/gawk-5.4.1/extension/readfile.la" file 644 mtime 1795046439 "ead09e0ed71b317c794635dbf42691431a9ea2e9b8dda45e2775f3eb771cce83">
  ]
  %gcc_127681 = splice.exec "gcc" at 127681 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#375, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revoutput.o" file 644 mtime 1795046439 "a47c7d7f212274bc2bcc23be384d154a939233ceda97271bb269e6bb8a7ee53e">
  ]
  %glue_127776 = splice.literal "glue" at 127776 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/revoutput.loT" file 644 mtime 1795046439 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_127776 = splice.exec "cat" at 127776(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_127776) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/revoutput.loT" file 644 mtime 1795046439 "1690964240d9bdf1ae204f73ab44cd2a8c9f13dbefe330aacf63243e260f9bea">
  ]
  %mv_127788 = splice.copy "mv" at 127788(%cat_127776) -> <"/build/gawk-5.4.1/extension/revoutput.lo" file 644 mtime 1795046439 "1690964240d9bdf1ae204f73ab44cd2a8c9f13dbefe330aacf63243e260f9bea">
  %bash_127807:4 = splice.exec "bash" at 127807(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_127681, %bash_26987#9, %mv_127788) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revoutput.la" link 0 mtime 1795046440 "../revoutput.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revoutput.lai" file 644 mtime 1795046440 "0401555825de5f50f012e7f2307b1eb577f808e6e8057f3524757ded500443c5">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revoutput.so" file 755 mtime 1795046440 "80e84e070d4e04c560870712c25b82eff37d854ca503157f1e457f5aa20cb253">,
      #splice.entry<"/build/gawk-5.4.1/extension/revoutput.la" file 644 mtime 1795046440 "b3db02b04a391b94fbe2ace07e7bd17a32b4863901cf04ac0b15f891818fb746">
  ]
  %gcc_129075 = splice.exec "gcc" at 129075 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#377, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revtwoway.o" file 644 mtime 1795046440 "f2015bd879462613d5f527c7050acf9a645c82e67eb71a9cdf197f08d7eace7a">
  ]
  %glue_129169 = splice.literal "glue" at 129169 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/revtwoway.loT" file 644 mtime 1795046440 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_129169 = splice.exec "cat" at 129169(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_129169) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/revtwoway.loT" file 644 mtime 1795046440 "3eceb507c8435ce4ec824d105cb22754a4f2dbdd91ba0f133ed67cfe0f4b127c">
  ]
  %mv_129181 = splice.copy "mv" at 129181(%cat_129169) -> <"/build/gawk-5.4.1/extension/revtwoway.lo" file 644 mtime 1795046440 "3eceb507c8435ce4ec824d105cb22754a4f2dbdd91ba0f133ed67cfe0f4b127c">
  %bash_129200:4 = splice.exec "bash" at 129200(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_129075, %bash_26987#9, %mv_129181) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revtwoway.la" link 0 mtime 1795046440 "../revtwoway.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revtwoway.lai" file 644 mtime 1795046440 "7a2450d03d7786196d66ea2d1eb61588340dd171b9bdf85de8b016e3b383c305">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/revtwoway.so" file 755 mtime 1795046440 "9c286458dfd3ad5acc4aa3a30fbab99f48af6515a92841f10b21021e7220bdc1">,
      #splice.entry<"/build/gawk-5.4.1/extension/revtwoway.la" file 644 mtime 1795046440 "a423c7b7c23aba3eda2d22a4f0bff11980ab44ad84a33603163bb1ea3e813157">
  ]
  %gcc_130464 = splice.exec "gcc" at 130464 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#379, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/rwarray.o" file 644 mtime 1795046440 "2f39fc595cd024753b395185fe05941f5d670728534e007901e0018dc23c9887">
  ]
  %glue_130568 = splice.literal "glue" at 130568 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/rwarray.loT" file 644 mtime 1795046440 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_130568 = splice.exec "cat" at 130568(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_130568) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/rwarray.loT" file 644 mtime 1795046440 "bf8edc15a6a7f71ad63417c816caa386906e87a6fca6657851a0a923d360e315">
  ]
  %mv_130580 = splice.copy "mv" at 130580(%cat_130568) -> <"/build/gawk-5.4.1/extension/rwarray.lo" file 644 mtime 1795046440 "bf8edc15a6a7f71ad63417c816caa386906e87a6fca6657851a0a923d360e315">
  %bash_130599:4 = splice.exec "bash" at 130599(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_130464, %bash_26987#9, %mv_130580) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/rwarray.la" link 0 mtime 1795046440 "../rwarray.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/rwarray.lai" file 644 mtime 1795046440 "22a779c908454c01056beef66631230a3ec3f3b3413601a02a35af1b093b6bee">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/rwarray.so" file 755 mtime 1795046440 "2d1d641f2207eb6513d06745cf83c8feff57f742f05940cce1eba84f8f6ffb7b">,
      #splice.entry<"/build/gawk-5.4.1/extension/rwarray.la" file 644 mtime 1795046440 "52b5b207916b031e4c3440b7c57cce630246acffcd456b80b72e99b5d0e38a09">
  ]
  %gcc_131866 = splice.exec "gcc" at 131866 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %bash_26987#6, %tar_xz_1467_0#340, %tar_xz_1467_0#384, %tar_xz_1467_0#395, %tar_xz_1467_0#398) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/time.o" file 644 mtime 1795046440 "b0f52206fc0b285da38127815b63b211e4cc5f5130f3fc1219d0b830eb8f6080">
  ]
  %glue_131971 = splice.literal "glue" at 131971 -> [
      #splice.entry<"/build/gawk-5.4.1/extension/time.loT" file 644 mtime 1795046440 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_131971 = splice.exec "cat" at 131971(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %glue_131971) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/time.loT" file 644 mtime 1795046440 "8f01d9e3dc681ddc870a2c94782c44a6ec2634062fbdaf7405f8b50e1e586ad6">
  ]
  %mv_131983 = splice.copy "mv" at 131983(%cat_131971) -> <"/build/gawk-5.4.1/extension/time.lo" file 644 mtime 1795046440 "8f01d9e3dc681ddc870a2c94782c44a6ec2634062fbdaf7405f8b50e1e586ad6">
  %bash_132002:4 = splice.exec "bash" at 132002(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#8, %mkdir_114089, %gcc_131866, %bash_26987#9, %mv_131983) -> [
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/time.la" link 0 mtime 1795046440 "../time.la">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/time.lai" file 644 mtime 1795046440 "84e5320644806e547970feb7891e27a8b33e427ee5d11a0ab672479e8f55ae7f">,
      #splice.entry<"/build/gawk-5.4.1/extension/.libs/time.so" file 755 mtime 1795046440 "5dbeafd79246db32ab61225ae1760e6be4c57e19d81fc92cd4e03296da9bd985">,
      #splice.entry<"/build/gawk-5.4.1/extension/time.la" file 644 mtime 1795046440 "eaf51bc2b984bf9569151eac82a2d28a73bfb299e940c4a7d44fe9cff8ea35a6">
  ]
  %ln_132977 = splice.literal "ln" at 132977 folded -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/pwcat.c" link 0 mtime 1795046440 "./eg/lib/pwcat.c">
  ]
  %gcc_132997 = splice.exec "gcc" at 132997 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#2, %tar_xz_1467#3, %tar_xz_1467#4, %tar_xz_1467_0#78, %ln_132977, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/pwcat.o" file 644 mtime 1795046440 "b9b112234178be5dfcfcae7959ccc826f00ca340792edf3b4361a282a60e2d3b">
  ]
  %gcc_133158 = splice.exec "gcc" at 133158 as "cc_binary"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#2, %gcc_132997) -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/pwcat" file 755 mtime 1795046440 "0c08f7d3f00fdf186c3df0c508249a87820a6b7b52f06cc4ca75044709188cad">
  ]
  %ln_133380 = splice.literal "ln" at 133380 folded -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/grcat.c" link 0 mtime 1795046440 "./eg/lib/grcat.c">
  ]
  %gcc_133399 = splice.exec "gcc" at 133399 as "cc_object"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#2, %tar_xz_1467#3, %tar_xz_1467#4, %tar_xz_1467_0#65, %ln_133380, %bash_26987#2, %tar_xz_1467_0#173, %tar_xz_1467#16, %tar_xz_1467_0#615) -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/grcat.o" file 644 mtime 1795046440 "9daf9b9813bd5cf2a9a8fa249a3e8110f878472e33bc93b30f84a4597294182a">
  ]
  %gcc_133562 = splice.exec "gcc" at 133562 as "cc_binary"(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#2, %gcc_133399) -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/grcat" file 755 mtime 1795046440 "ed2c16001176a68379c36db57678d0ffe888f1a14d06b58ac01f2a81571b1e3e">
  ]
  %glue_133778 = splice.literal "glue" at 133778 -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/passwd.awk" file 644 mtime 1795046440 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %sed_133778 = splice.exec "sed" at 133778(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#2, %tar_xz_1467#3, %tar_xz_1467#4, %tar_xz_1467_0#76, %glue_133778) -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/passwd.awk" file 644 mtime 1795046440 "6f92cb99c9c9c01c2932ade5cc479af8e7bc9b93efabb23028a7a913ffb9c42e">
  ]
  %glue_133802 = splice.literal "glue" at 133802 -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/group.awk" file 644 mtime 1795046440 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %sed_133802 = splice.exec "sed" at 133802(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#2, %tar_xz_1467#3, %tar_xz_1467#4, %tar_xz_1467_0#66, %glue_133802) -> [
      #splice.entry<"/build/gawk-5.4.1/awklib/group.awk" file 644 mtime 1795046440 "5ad050d6b61afdb3c1710da61b649356687b2f0b3a2b200816f28f75865349ba">
  ]
  %mkdir_133918 = splice.literal "mkdir" at 133918 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1" dir 755 mtime 1795046440>
  ]
  %mkdir_134147 = splice.literal "mkdir" at 134147 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/bin" dir 755 mtime 1795046440>
  ]
  %sed_sed_gawk_basename__3_134190 = splice.copy "sed|sed|gawk|basename|+3" at 134190(%gcc_112594) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/bin/gawk" file 755 mtime 1795046440 "e06af91d1f2467f1e6b0b17040f0a502459f11d847a4021e08b732d2659fc7d5">
  %ln_134495 = splice.literal "ln" at 134495 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/bin/awk" link 0 mtime 1795046440 "gawk">
  ]
  %mkdir_134527 = splice.literal "mkdir" at 134527 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/include" dir 755 mtime 1795046440>
  ]
  %sed_sed_basename_cp__2_134548 = splice.copy "sed|sed|basename|cp|+2" at 134548(%tar_xz_1467_0#395) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/include/gawkapi.h" file 644 mtime 1795046440 "3480eb870c9b88cca3f4df58e069ba91c944954d7f1610944ef557350c8b0713">
  %bash_135816:4 = splice.literal "bash" at 135816 folded -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3" dir 755 mtime 1795046440>
  ]
  %bash_135816_20 = splice.copy "bash" at 135816(%tar_xz_1467_0#341) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/filefuncs.3am" file 644 mtime 1795046440 "b7a6a3d383ba5023d87729841fe3ab5ecdeedecd80d56f43a8a9f7d68c2ef3f0">
  %bash_135816_21 = splice.copy "bash" at 135816(%tar_xz_1467_0#343) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/fnmatch.3am" file 644 mtime 1795046440 "82bed00452298d35b380fae5e9d9cc6116cdb4be847af92304851e425915f65d">
  %bash_135816_22 = splice.copy "bash" at 135816(%tar_xz_1467_0#345) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/fork.3am" file 644 mtime 1795046440 "6087be91a06c38fb0d88164d66c6a243b01cfa74ef296592ea088762ca2f96ee">
  %bash_135816_23 = splice.copy "bash" at 135816(%tar_xz_1467_0#351) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/inplace.3am" file 644 mtime 1795046440 "6c1986772fbd61a2c01efc6e27903580585f57459faac2b1a204f9f9abed41c9">
  %bash_135816_24 = splice.copy "bash" at 135816(%tar_xz_1467_0#353) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/intdiv.3am" file 644 mtime 1795046440 "5d58913b34a1136d9132f6fb43e9e363b3d84a8cc17c3c596e96de304a506d9b">
  %bash_135816_25 = splice.copy "bash" at 135816(%tar_xz_1467_0#355) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/ordchr.3am" file 644 mtime 1795046440 "a6dc5edfdc0143e5ccb31e82cada9a3ad00813f5c9ceedaede39795a81034705">
  %bash_135816_26 = splice.copy "bash" at 135816(%tar_xz_1467_0#370) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/readdir.3am" file 644 mtime 1795046440 "4422a0ea43f96678c193b03c34da368214b1db6d6a080774bde3798a081e0cf6">
  %bash_135816_27 = splice.copy "bash" at 135816(%tar_xz_1467_0#372) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/readfile.3am" file 644 mtime 1795046440 "104dc74f6470fafe24e76a1c2b5208ba2af4d2efa1075807206bfd06d20a9325">
  %bash_135816_28 = splice.copy "bash" at 135816(%tar_xz_1467_0#374) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/revoutput.3am" file 644 mtime 1795046440 "2edd40390f8014bb4de42f0df9fb1635016946337d5534c98870aa4449b74766">
  %bash_135816_29 = splice.copy "bash" at 135816(%tar_xz_1467_0#376) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/revtwoway.3am" file 644 mtime 1795046440 "88ce804829dc66d684c287a327cd49ce44eae77cee26566886805d1919dad5f9">
  %bash_135816_30 = splice.copy "bash" at 135816(%tar_xz_1467_0#378) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/rwarray.3am" file 644 mtime 1795046440 "18cfd1aa5bdb1781abbb2bf51d1e7003ab3410fdc0f994b5119d195739d88c53">
  %bash_135816_31 = splice.copy "bash" at 135816(%tar_xz_1467_0#383) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/time.3am" file 644 mtime 1795046440 "67b05e73ba18d68e27a6d99f8fbdae39916a68150c3924d9464c6f55abbafeb8">
  %mkdir_136597:2 = splice.literal "mkdir" at 136597 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk" dir 755 mtime 1795046440>
  ]
  %mv_136954 = splice.copy "mv" at 136954(%bash_116655#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/filefuncs.so" file 755 mtime 1795046440 "bdb6bae4acd198fbc91128067df4ac6989a044b3c60036b6102de2a04d4d71c7">
  %mv_137147 = splice.copy "mv" at 137147(%bash_118059#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/fnmatch.so" file 755 mtime 1795046440 "9d2efe22ac4f2e3fb78f9d0e79d7f341169a4bda42bccd75af1cae18ce4e0064">
  %mv_137328 = splice.copy "mv" at 137328(%bash_119448#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/fork.so" file 755 mtime 1795046440 "3c195c9589f58de735f5a57cec3ff39f3e04713c274c9f7091bd495709e33634">
  %mv_137510 = splice.copy "mv" at 137510(%bash_120847#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/inplace.so" file 755 mtime 1795046440 "319516596f8154293f846afaa3d9bad8296c58a0d0daf0db7de3e37d36fc783c">
  %mv_137692 = splice.copy "mv" at 137692(%bash_122226#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/intdiv.so" file 755 mtime 1795046440 "2d01436c0481acd54ba7dcb728bce68972dc6eabb4a176fd21cfd052e1be754e">
  %mv_137884 = splice.copy "mv" at 137884(%bash_123637#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/ordchr.so" file 755 mtime 1795046440 "95fe74cc2cd669efabcf81449a88be164d31a30a3bb61aa7dcc7cbbdad67d4c7">
  %mv_138066 = splice.copy "mv" at 138066(%bash_125024#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/readdir.so" file 755 mtime 1795046440 "002dfc0dfe28f7441834d1128e487c59550edefc212e174ab0cfb726d653ab70">
  %mv_138248 = splice.copy "mv" at 138248(%bash_126414#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/readfile.so" file 755 mtime 1795046440 "2e37bd30a5efac63bb089cd7d683fd27a7f2ad983640562ecc24044d14506532">
  %mv_138439 = splice.copy "mv" at 138439(%bash_127807#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/revoutput.so" file 755 mtime 1795046440 "80e84e070d4e04c560870712c25b82eff37d854ca503157f1e457f5aa20cb253">
  %mv_138618 = splice.copy "mv" at 138618(%bash_129200#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/revtwoway.so" file 755 mtime 1795046440 "9c286458dfd3ad5acc4aa3a30fbab99f48af6515a92841f10b21021e7220bdc1">
  %mv_138800 = splice.copy "mv" at 138800(%bash_130599#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/rwarray.so" file 755 mtime 1795046440 "2d1d641f2207eb6513d06745cf83c8feff57f742f05940cce1eba84f8f6ffb7b">
  %mv_138982 = splice.copy "mv" at 138982(%bash_132002#2) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/time.so" file 755 mtime 1795046440 "5dbeafd79246db32ab61225ae1760e6be4c57e19d81fc92cd4e03296da9bd985">
  %mkdir_139639:2 = splice.literal "mkdir" at 139639 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/etc" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/etc/profile.d" dir 755 mtime 1795046440>
  ]
  %sed_sed_basename_cp__6_139667 = splice.copy "sed|sed|basename|cp|+6" at 139667(%tar_xz_1467_0#389) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/etc/profile.d/gawk.csh" file 644 mtime 1795046440 "9ba2af9853121df6dd5edff9254a2946e39eab8dc6513348fea28f739ee96648">
  %sed_sed_basename_cp__6_139667_32 = splice.copy "sed|sed|basename|cp|+6" at 139667(%tar_xz_1467_0#390) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/etc/profile.d/gawk.sh" file 644 mtime 1795046440 "70621a3b586d3d523b020e76977633b444a70013ba50e1ea901a3a07a676f15f">
  %mkdir_139847:3 = splice.literal "mkdir" at 139847 folded -> [
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info" dir 755 mtime 1795046440>
  ]
  %sed_sed_basename_cp__26_139871 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#195) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_api-figure1.png" file 644 mtime 1795046440 "41e42a3d6934d030133f6cd2c3efdcf41c6bb01ce9c3efbec095dc001fdccbb2">
  %sed_sed_basename_cp__26_139871_33 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#202) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_api-figure2.png" file 644 mtime 1795046440 "041787ff295495430fcb207791ed9be2a790609b7b403b0b97ff4908d457b67a">
  %sed_sed_basename_cp__26_139871_34 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#209) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_api-figure3.png" file 644 mtime 1795046440 "98e28671fe6b83eb18af7942d29b730638c556b548b78a8a38d2c639919d9afa">
  %sed_sed_basename_cp__26_139871_35 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#216) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_array-elements.png" file 644 mtime 1795046440 "452e2a51e60558f5bbe744c14bf085328c89b1b66e112835b3b6c98c9b9a4f58">
  %sed_sed_basename_cp__26_139871_36 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#223) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_general-program.png" file 644 mtime 1795046440 "98a9ea38ab5764a614273faf5aa5b359f95a2b9d8782d77986cbbfc3515e0f90">
  %sed_sed_basename_cp__26_139871_37 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#230) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_process-flow.png" file 644 mtime 1795046440 "33dd3a96fb977c56aeab7d63893ac72a0ce1f157667e88cd5cb2b7cf93c596fb">
  %sed_sed_basename_cp__26_139871_38 = splice.copy "sed|sed|basename|cp|+26" at 139871(%tar_xz_1467_0#234) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk_statist.jpg" file 644 mtime 1795046440 "99c2883a5fb95fa4e69f929cc12f4dca039af30da85c30970af5f18d81f1c4ce">
  %bash_140254 = splice.copy "bash" at 140254(%tar_xz_1467_0#189) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawk.info" file 644 mtime 1795046440 "f1d0e6e94809016338209f905cde6efbad12fa040994feb6abc691d131ed41b9">
  %bash_140254_39 = splice.copy "bash" at 140254(%tar_xz_1467_0#239) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawkinet.info" file 644 mtime 1795046440 "441dff55ce3c51278c0f20ddd6f52ad795cb5d9d464b9b10dbd60baecfabb131">
  %bash_140254_40 = splice.copy "bash" at 140254(%tar_xz_1467_0#241) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawknotes.info" file 644 mtime 1795046440 "cc3121516b0c5a402723dab3a14df21d6b2fe356caefb8faf17f020772f4d03d">
  %bash_140254_41 = splice.copy "bash" at 140254(%tar_xz_1467_0#243) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/gawkworkflow.info" file 644 mtime 1795046440 "ea14f7170d410f563dd3249e0772cc05d052c53afd0e1886dc5ee8d256e57edf">
  %bash_140254_42 = splice.copy "bash" at 140254(%tar_xz_1467_0#306) -> <"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/pm-gawk.info" file 644 mtime 1795046440 "77e2fc87fdf547f82210796fbf6396b90fe854df7602f4abd8d49a6c76557e28">
  %install_info_140957 = splice.exec "install-info" at 140957(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#6, %mkdir_139847#0, %mkdir_139847#1, %mkdir_139847#2, %bash_140254) -> [
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/dir" file 644 mtime 1795046440 "eeb335625c2aaab137372c2bb3d6cc57cff9ea7f7f225e381cbf449a8ac89c74">
  ]
  %install_info_141027 = splice.exec "install-info" at 141027(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#6, %mkdir_139847#0, %mkdir_139847#1, %mkdir_139847#2, %install_info_140957, %bash_140254_39) -> [
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/dir" file 644 mtime 1795046440 "b1b8b690efe835043754737f2d347f5a3bc8f9ad379750a921e70862b0fd11c3">
  ]
  %install_info_141084 = splice.exec "install-info" at 141084(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#6, %mkdir_139847#0, %mkdir_139847#1, %mkdir_139847#2, %install_info_141027, %bash_140254_41) -> [
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/dir" file 644 mtime 1795046440 "fc4f09bf5463bfd545a25b354201ea6570781210c456c559f8f791db0e4bf19f">
  ]
  %install_info_141140 = splice.exec "install-info" at 141140(%sandbox_720#0, %tar_xz_1467#0, %tar_xz_1467#6, %mkdir_139847#0, %mkdir_139847#1, %mkdir_139847#2, %install_info_141084, %bash_140254_42) -> [
      #splice.entry<"/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info/share/info/dir" file 644 mtime 1795046440 "8b700d3aca21fb91a79c7f74622589dfa6987a7606e9061f3de3c35282a7f86d">
  ]
  %bash_141225 = splice.literal "bash" at 141225 folded -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1" dir 755 mtime 1795046440>
  ]
  %bash_141225_43 = splice.copy "bash" at 141225(%tar_xz_1467_0#188) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/gawk.1" file 644 mtime 1795046440 "db0f483e496c8cf3bceb5848f52726f5020210518cbd3f9c56b3223f39c23df6">
  %bash_141225_44 = splice.copy "bash" at 141225(%tar_xz_1467_0#238) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/gawkbug.1" file 644 mtime 1795046440 "a38b98a8f092a13b0e8af51a64cf1cd81cab2cbbb86b0bf8e09ee7d294b292a6">
  %bash_141225_45 = splice.copy "bash" at 141225(%tar_xz_1467_0#305) -> <"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/pm-gawk.1" file 644 mtime 1795046440 "bfabb30f69222ed9f9f9bd960158fd95b938ed3535275bf5c32f3282aa20730e">
  %mkdir_141566:2 = splice.literal "mkdir" at 141566 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk" dir 755 mtime 1795046440>
  ]
  %sed_sed_gawk_basename__7_141609 = splice.copy "sed|sed|gawk|basename|+7" at 141609(%gcc_133562) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk/grcat" file 755 mtime 1795046440 "ed2c16001176a68379c36db57678d0ffe888f1a14d06b58ac01f2a81571b1e3e">
  %sed_sed_gawk_basename__7_141609_46 = splice.copy "sed|sed|gawk|basename|+7" at 141609(%gcc_133158) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk/pwcat" file 755 mtime 1795046440 "0c08f7d3f00fdf186c3df0c508249a87820a6b7b52f06cc4ca75044709188cad">
  %mkdir_141859:2 = splice.literal "mkdir" at 141859 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk" dir 755 mtime 1795046440>
  ]
  %mv_141954 = splice.copy "mv" at 141954(%sed_133778) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/passwd.awk" file 644 mtime 1795046440 "6f92cb99c9c9c01c2932ade5cc479af8e7bc9b93efabb23028a7a913ffb9c42e">
  %mv_142053 = splice.copy "mv" at 142053(%sed_133802) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/group.awk" file 644 mtime 1795046440 "5ad050d6b61afdb3c1710da61b649356687b2f0b3a2b200816f28f75865349ba">
  %mv_142142 = splice.copy "mv" at 142142(%tar_xz_1467_0#58) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/assert.awk" file 644 mtime 1795046440 "6c4b3f24dd0c225f3ece786eee7fa75f4ef2fb7ffedddaacbc2edb03c68c90b9">
  %mv_142232 = splice.copy "mv" at 142232(%tar_xz_1467_0#59) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/bits2str.awk" file 644 mtime 1795046440 "77c2504aa2d6385d4d3c0d350515b8791070060ace1414bccc6dc99153743237">
  %mv_142322 = splice.copy "mv" at 142322(%tar_xz_1467_0#60) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/cliff_rand.awk" file 644 mtime 1795046440 "c405417ad13fe4ca0ba783b6fdcf90c1e2a8ae80ffebc0f2107ddd6ac22ecd82">
  %mv_142411 = splice.copy "mv" at 142411(%tar_xz_1467_0#61) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/ctime.awk" file 644 mtime 1795046440 "2e20e707381b7cd48abdd70e8f7aed8d86db28a35193bf296964e82de3b754f8">
  %mv_142500 = splice.copy "mv" at 142500(%tar_xz_1467_0#62) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/ftrans.awk" file 644 mtime 1795046440 "11b367afeda7cc11b3f829d931965ea56b10fcfe87b3833ac4a9ccfce5830ee1">
  %mv_142589 = splice.copy "mv" at 142589(%tar_xz_1467_0#63) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/getopt.awk" file 644 mtime 1795046440 "7394647d52ed67c12097db732a96f25c808e5d432d74a8c3f0724602f7d41bb6">
  %mv_142678 = splice.copy "mv" at 142678(%tar_xz_1467_0#64) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/gettime.awk" file 644 mtime 1795046440 "bc0fe06e7fb41531748177f255a20c0db6732472851154b0370532fc302c1864">
  %mv_142767 = splice.copy "mv" at 142767(%tar_xz_1467_0#67) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/have_mpfr.awk" file 644 mtime 1795046440 "a017c0ef4b5311bd94228c366a896a4a5af417c41930f7ea2b46d9d67f2a663b">
  %mv_142868 = splice.copy "mv" at 142868(%tar_xz_1467_0#68) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/inplace.awk" file 644 mtime 1795046440 "c74afe20269e7747b55211dd48bef10fb1b9177dbd2997905ba261f2f4fe1243">
  %mv_142957 = splice.copy "mv" at 142957(%tar_xz_1467_0#69) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/intdiv0.awk" file 644 mtime 1795046440 "26b599f90636b540d77e36724f7339c1330307cf2fafe32d00e7977764bc87ad">
  %mv_143046 = splice.copy "mv" at 143046(%tar_xz_1467_0#70) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/isnumeric.awk" file 644 mtime 1795046440 "8749b7f590a8997387fbb1cb7317352f05089778d8223b03b8a7891f4c55dfed">
  %mv_143135 = splice.copy "mv" at 143135(%tar_xz_1467_0#71) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/join.awk" file 644 mtime 1795046440 "49de451cda05448408cb6e5210eb7d886dea05f182e57edd1ecd65afabee8a66">
  %mv_143224 = splice.copy "mv" at 143224(%tar_xz_1467_0#72) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/libintl.awk" file 644 mtime 1795046440 "293d54512ccf8b6eb41c3f0c9e7ae6d1a20b1c9e7eb559d4975de45ba478f6e1">
  %mv_143313 = splice.copy "mv" at 143313(%tar_xz_1467_0#73) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/noassign.awk" file 644 mtime 1795046440 "63a84996567a8be236bb4955ee55d525387d0513b12e2121e92267ad72a9c20d">
  %mv_143402 = splice.copy "mv" at 143402(%tar_xz_1467_0#74) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/ns_passwd.awk" file 644 mtime 1795046440 "6d4b76c1cb895dd7cdae0f1e9e34f474003486e653693684784d0bbcbb18389b">
  %mv_143491 = splice.copy "mv" at 143491(%tar_xz_1467_0#75) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/ord.awk" file 644 mtime 1795046440 "23bf677aa27bed203790002eeade4996910505445d560ac330236a11b63884e8">
  %mv_143590 = splice.copy "mv" at 143590(%tar_xz_1467_0#77) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/processarray.awk" file 644 mtime 1795046440 "8aba77f62a7d63ee84717fa019175bb3f389406f8266188aaaaa0544d08ba302">
  %mv_143679 = splice.copy "mv" at 143679(%tar_xz_1467_0#79) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/quicksort.awk" file 644 mtime 1795046440 "c04bc6a885680793fc06a9fb3c0d57903c36383ecf3a5b1c5b05d137b141d7e7">
  %mv_143768 = splice.copy "mv" at 143768(%tar_xz_1467_0#80) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/readable.awk" file 644 mtime 1795046440 "dfb704d2168f9a1742c4f662c8ae3d17cee8844829fd92249bff79c5f5152942">
  %mv_143857 = splice.copy "mv" at 143857(%tar_xz_1467_0#81) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/readfile.awk" file 644 mtime 1795046440 "d7c4f63b17c19b2a769ed0c0cd80c94d594e7c413d774ddf629e7464b06f961d">
  %mv_143946 = splice.copy "mv" at 143946(%tar_xz_1467_0#82) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/rewind.awk" file 644 mtime 1795046440 "6b16e49c6a1e99da1d3c05f5ea9b9128a130002f5c67e1f94e81e6e697b15a61">
  %mv_144035 = splice.copy "mv" at 144035(%tar_xz_1467_0#83) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/round.awk" file 644 mtime 1795046440 "024ed109f713670ddfa752de0379019f95d6b10cd774a181943f2cf0ea024f80">
  %mv_144124 = splice.copy "mv" at 144124(%tar_xz_1467_0#84) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/shellquote.awk" file 644 mtime 1795046440 "2efde58fd4fca1f0b27eeec6c04fb7869f9abb1ddaf2f776ec9553ca18b2728e">
  %mv_144213 = splice.copy "mv" at 144213(%tar_xz_1467_0#85) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/strtonum.awk" file 644 mtime 1795046440 "4af52a0653670b997a3365713bbed43737a07cd6b5064434e863484a0a074122">
  %mv_144302 = splice.copy "mv" at 144302(%tar_xz_1467_0#86) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/tocsv.awk" file 644 mtime 1795046440 "022016e528bae702238cfc65a6a466cb3ac4883ea7f542a9dbcf8530776761d8">
  %mv_144402 = splice.copy "mv" at 144402(%tar_xz_1467_0#87) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/walkarray.awk" file 644 mtime 1795046440 "90a9543fa6e49afb453a41e00dce7353d44e2c189ec7cc1c640585bcf1398c54">
  %mv_144490 = splice.copy "mv" at 144490(%tar_xz_1467_0#88) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/awk/zerofile.awk" file 644 mtime 1795046440 "2aaae54a27113af872b61cd969196be9d21a309cac9d5307a1db3b33530eda86">
  %mkdir_144580:3 = splice.literal "mkdir" at 144580 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ar" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ar/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_144636 = splice.copy "mv" at 144636(%tar_xz_1467_0#523) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ar/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "48774da3bf925455bebef55f1ebbc19ac081c8c6008c548ae940c13377fbe27b">
  %mkdir_144691:2 = splice.literal "mkdir" at 144691 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/bg" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/bg/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_144747 = splice.copy "mv" at 144747(%tar_xz_1467_0#525) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/bg/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "21a707a9a95f70d2e1aa6ada17b914c5e273d5f2737d15031067d7b95145e225">
  %mkdir_144802:2 = splice.literal "mkdir" at 144802 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/de" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/de/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_144858 = splice.copy "mv" at 144858(%tar_xz_1467_0#528) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/de/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "09b71d7cd3b3fce323e223525648a321c055076ad21a637e1aa9b56b7256f329">
  %mkdir_144913:2 = splice.literal "mkdir" at 144913 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/es" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/es/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_144969 = splice.copy "mv" at 144969(%tar_xz_1467_0#532) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/es/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "5a5fa47c0bdb475a4b70ae5172ee71c2cd27e215d375da8b88bf18a82e0520a4">
  %mkdir_145024:2 = splice.literal "mkdir" at 145024 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/fr" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/fr/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145086 = splice.copy "mv" at 145086(%tar_xz_1467_0#534) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/fr/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "a83a91fcbd637f2076670d995931e408cb80201f1dab9e6f1b86a6139868d6e7">
  %mkdir_145139:2 = splice.literal "mkdir" at 145139 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/he" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/he/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145195 = splice.copy "mv" at 145195(%tar_xz_1467_0#537) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/he/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "cc7ddfe25cabfb02a0c2f195ef6a300c60be9a267c8fcd3e56826779b6ef0d45">
  %mkdir_145250:2 = splice.literal "mkdir" at 145250 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/id" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/id/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145307 = splice.copy "mv" at 145307(%tar_xz_1467_0#539) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/id/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "c98cd37fedf7a085b7bfbbaec5756ae9504efe4ff7da729ba7b54aa51313a8a4">
  %mkdir_145362:2 = splice.literal "mkdir" at 145362 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/it" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/it/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145418 = splice.copy "mv" at 145418(%tar_xz_1467_0#542) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/it/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "3e8be808adadb94e4cee366fc624a837d941595e440076d85edee1158eb3c6cb">
  %mkdir_145473:2 = splice.literal "mkdir" at 145473 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ka" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ka/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145529 = splice.copy "mv" at 145529(%tar_xz_1467_0#544) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ka/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "59df374f5479e9b930ec2df12603a6eb97c552049c2cfe18ee562dd3d626521f">
  %mkdir_145584:2 = splice.literal "mkdir" at 145584 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ko" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ko/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145640 = splice.copy "mv" at 145640(%tar_xz_1467_0#546) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ko/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "b77447a805997385ab9f5b3ca9fcba0da801dce5c90395774ba31b797b70d194">
  %mkdir_145695:2 = splice.literal "mkdir" at 145695 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/nl" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/nl/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145751 = splice.copy "mv" at 145751(%tar_xz_1467_0#548) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/nl/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "2fdea38e0f249490f67c21743d277e9ff7d87520a54181403f19ffbbde8b2546">
  %mkdir_145806:2 = splice.literal "mkdir" at 145806 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pl" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pl/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145868 = splice.copy "mv" at 145868(%tar_xz_1467_0#550) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pl/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "ee0548d4f8c9abd2336c25747956ab53e0addeb2daee58e3799fb6af4e4ab45b">
  %mkdir_145920:2 = splice.literal "mkdir" at 145920 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pt" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pt/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_145976 = splice.copy "mv" at 145976(%tar_xz_1467_0#552) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pt/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "27605ef60422d0fd9b471151ef4bd6071a5ccc528f7a05e83f03bfc04b86ec0c">
  %mkdir_146031:2 = splice.literal "mkdir" at 146031 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pt_BR" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pt_BR/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146087 = splice.copy "mv" at 146087(%tar_xz_1467_0#554) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/pt_BR/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "1eb3db2211cbdfe6d1b095ce014907494183aee8de017c22d8dd73a80774c3c9">
  %mkdir_146142:2 = splice.literal "mkdir" at 146142 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ro" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ro/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146198 = splice.copy "mv" at 146198(%tar_xz_1467_0#558) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/ro/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "6f38622d4fb10de8e1ebb12e3f7d6b1dfa0d8190168a1ed57adee00f365b6b63">
  %mkdir_146253:2 = splice.literal "mkdir" at 146253 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/sr" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/sr/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146309 = splice.copy "mv" at 146309(%tar_xz_1467_0#560) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/sr/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "0e480e50e37de7ca77ad7d802ccbc15994ba092d297c679e9f12466e89ac893f">
  %mkdir_146364:2 = splice.literal "mkdir" at 146364 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/sv" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/sv/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146420 = splice.copy "mv" at 146420(%tar_xz_1467_0#563) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/sv/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "97b8dfacb77e11e2b207188952c54408a6cae29812c0ef5ee006d68666cddd1b">
  %mkdir_146475:2 = splice.literal "mkdir" at 146475 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/tr" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/tr/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146531 = splice.copy "mv" at 146531(%tar_xz_1467_0#565) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/tr/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "2f2761eebdc66c30ea337480508cd0f1ffc5489b76f8f5042d7090fca7c7b734">
  %mkdir_146586:2 = splice.literal "mkdir" at 146586 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/uk" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/uk/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146642 = splice.copy "mv" at 146642(%tar_xz_1467_0#567) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/uk/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "6b122a7d814f2eae300ce6fcaad4a650cb1970fda19c23945a5f3a90e6ed231f">
  %mkdir_146703:2 = splice.literal "mkdir" at 146703 folded -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/zh_CN" dir 755 mtime 1795046440>,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/zh_CN/LC_MESSAGES" dir 755 mtime 1795046440>
  ]
  %mv_146759 = splice.copy "mv" at 146759(%tar_xz_1467_0#569) -> <"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/share/locale/zh_CN/LC_MESSAGES/gawk.mo" file 644 mtime 1795046440 "9ac1b985c7cedb91be451e7bf7d7470ed84cdbe085cfb29262a5a9bcef542512">
  %gzip_147507 = splice.exec "gzip" at 147507(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_141225, %bash_141225_45) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/pm-gawk.1.gz" file 644 mtime 1795046440 "2eff1ad7ed78b205bd5479ff041c1c0102947d46ddcb8d70ce2cec6b1d8f4eee">
  ]
  %gzip_147523 = splice.exec "gzip" at 147523(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_141225, %bash_141225_44) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/gawkbug.1.gz" file 644 mtime 1795046440 "5420f1832d369adee475266fb7d03d90bec7e41b1164c85223dbe60506fc666d">
  ]
  %gzip_147536 = splice.exec "gzip" at 147536(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_141225, %bash_141225_43) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/gawk.1.gz" file 644 mtime 1795046440 "3d3f1fd77a694e3edcdb8388aa37d0fb306274a9e10f1bd94dde06a3e2b64457">
  ]
  %gzip_147559 = splice.exec "gzip" at 147559(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_31) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/time.3am.gz" file 644 mtime 1795046440 "93af0ab036b15c6aefd7d067417bd2f3bccd4cb894472c0903a4c5557da7cbf2">
  ]
  %gzip_147572 = splice.exec "gzip" at 147572(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_30) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/rwarray.3am.gz" file 644 mtime 1795046440 "092bf430490fb23149a72fd5f53ed1f0a18124cfaeefd4913c19df38bb43c01b">
  ]
  %gzip_147585 = splice.exec "gzip" at 147585(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_29) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/revtwoway.3am.gz" file 644 mtime 1795046440 "902fa9c37a73e4834c3713580ab4f6581837b659af6f54fc2bf50aa6c1eccfca">
  ]
  %gzip_147599 = splice.exec "gzip" at 147599(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_28) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/revoutput.3am.gz" file 644 mtime 1795046440 "5b107d64e8069b4cbb52dc378c91c22f3b1c806efbaa0ea7efa5198312770688">
  ]
  %gzip_147610 = splice.exec "gzip" at 147610(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_27) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/readfile.3am.gz" file 644 mtime 1795046440 "74088bf97b0bec4303ab04a75227e24f42fbab859a4c826e1ae0e5d540efa61e">
  ]
  %gzip_147621 = splice.exec "gzip" at 147621(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_26) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/readdir.3am.gz" file 644 mtime 1795046440 "8534a56cec67e4e5b646b59dc7a733299ddff89dc5a16eccfd373e5c7498ccdd">
  ]
  %gzip_147634 = splice.exec "gzip" at 147634(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_25) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/ordchr.3am.gz" file 644 mtime 1795046440 "b903e918f8eb815e06c680265cdfee9fa34dc4c3e2f9a46c47c83dec65149c2a">
  ]
  %gzip_147648 = splice.exec "gzip" at 147648(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_24) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/intdiv.3am.gz" file 644 mtime 1795046440 "b42d93d989b0d224d9c2abcdc2bd290728fc8924168fcb38eddff8a1614edc48">
  ]
  %gzip_147661 = splice.exec "gzip" at 147661(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_23) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/inplace.3am.gz" file 644 mtime 1795046440 "e0a7b993ce7ab490d41b1190baeced0be46c6b051fdb928ebfcf14f7319ce550">
  ]
  %gzip_147675 = splice.exec "gzip" at 147675(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_22) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/fork.3am.gz" file 644 mtime 1795046440 "be27d449cbe97eea9cc87edbfa0b7afbd8af4a1329042aa3f71adf2f8a7de464">
  ]
  %gzip_147686 = splice.exec "gzip" at 147686(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_21) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/fnmatch.3am.gz" file 644 mtime 1795046440 "811c59a29e965de15da587cd13acfddea888b3dc6c14bd467d73c92d3697dd61">
  ]
  %gzip_147698 = splice.exec "gzip" at 147698(%sandbox_720#0, %tar_xz_1467#0, %bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_135816#3, %bash_135816_20) -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man3/filefuncs.3am.gz" file 644 mtime 1795046440 "c6b67fb4985cb6dd6c11635801ea6ccf7a224d720560fb5999b9b1e348e43409">
  ]
  %find_patchelf_patchelf_patchelf__12_147816:15 = splice.exec "find|patchelf|patchelf|patchelf|+12" at 147816(%sandbox_720#0, %tar_xz_1467#0, %mkdir_133918, %mkdir_134147, %sed_sed_gawk_basename__3_134190, %mkdir_136597#0, %mkdir_136597#1, %mv_136954, %mv_137147, %mv_137328, %mv_137510, %mv_137692, %mv_137884, %mv_138066, %mv_138248, %mv_138439, %mv_138618, %mv_138800, %mv_138982, %mkdir_141566#0, %mkdir_141566#1, %sed_sed_gawk_basename__7_141609, %sed_sed_gawk_basename__7_141609_46) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/bin/gawk" file 755 mtime 1795046441 "0d694e6c542662c313598cfdd5f36e88c2a674c49289becdf96b2135e6178e03">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/filefuncs.so" file 755 mtime 1795046441 "dbdad7b0608f7d587acd56d85fe85b7ebb5c4925bbec2e7fad87db5f0b4053f9">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/fnmatch.so" file 755 mtime 1795046441 "b7bf3915e3785bb7205c2273ac1a083190534375f075168598323ca9d008fef4">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/fork.so" file 755 mtime 1795046441 "89249dc025f22285cee13ab5d4d58cbdbd2848771fa3ebf033a2e6c299049293">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/inplace.so" file 755 mtime 1795046441 "87aa1e9e2ba14beb0b6e6866e1cbb9f9aa6f20e192bf1a8aa59c9b083bbcae42">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/intdiv.so" file 755 mtime 1795046441 "360997b0c170a88af34096bb478c3b02310b84d2c3f53503f6beb5f6498a197e">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/ordchr.so" file 755 mtime 1795046441 "7cd4dafa7fa033d3e7fdb1ed7fb528ffaeae2a7c8555b2a8859c252e5bb3d73c">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/readdir.so" file 755 mtime 1795046441 "a4491cd1286f82deddc8047d8df9a5f0bda238f98b97dd4f7c86ce10dd5f67ae">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/readfile.so" file 755 mtime 1795046441 "7286b70a92ba5b3d9feee8c9ef1d9847d7bdc3f942367dde3653eaa97b4da259">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/revoutput.so" file 755 mtime 1795046441 "e16e24d92eded0cac748993cf299ac1173c519d8f1e3f9ff49b1bfc4964176a2">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/revtwoway.so" file 755 mtime 1795046441 "4f91f3f07cb7782ffaa468c46432db5d58d46e6c5bd2bc22ac0ba79b4bfede2d">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/rwarray.so" file 755 mtime 1795046441 "48f9edcf895d4a6b386e02009700d693bd010025d5250a87a6201e583c12b7f0">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/time.so" file 755 mtime 1795046441 "61d306049125d950b77edcd79a6a5ffb1b59798933ad73a1a659fec90d1c7fd7">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk/grcat" file 755 mtime 1795046441 "ecfed963922eeba1c456eb29601ea620ba70e5747a57b31ce5fa7b5e5eb94447">,
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk/pwcat" file 755 mtime 1795046441 "70e40634fb6ed6e744689b307fde81d5ea0791c89617d48fdcf757566299192e">
  ]
  %mktemp_149224 = splice.literal "mktemp" at 149224 folded -> [
      #splice.entry<"/build/striperr.6WxUp8" file 600 mtime 1795046441 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_149271 = splice.exec "strip" at 149271(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_134147, %find_patchelf_patchelf_patchelf__12_147816#0) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/bin/gawk" file 755 mtime 1795046441 "9f1cf85334b7c451c95b4b97771e4dbcf804e50c92f436883b37de8fbf4cba0c">
  ]
  %strip_149299 = splice.exec "strip" at 149299(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#1) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/filefuncs.so" file 755 mtime 1795046441 "0174375b44a37db986adc025519f5dc0f2d3e5bc41b1d73e28f55b1007b67675">
  ]
  %strip_149330 = splice.exec "strip" at 149330(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#2) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/fnmatch.so" file 755 mtime 1795046441 "0e5d9baebc65c332c21242a7dc690326598dd8686581d18ed46248a485344011">
  ]
  %strip_149359 = splice.exec "strip" at 149359(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#3) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/fork.so" file 755 mtime 1795046441 "ee4b07d00287b219a16297370dac48f5ff9217cc273f90dcfca4c747e7f2c4a0">
  ]
  %strip_149389 = splice.exec "strip" at 149389(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#4) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/inplace.so" file 755 mtime 1795046441 "961e3364567699fb533d5546cd1a6a7595b9d9657005145168e5bf3d255a31fa">
  ]
  %strip_149421 = splice.exec "strip" at 149421(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#5) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/intdiv.so" file 755 mtime 1795046441 "9f9f2400a7c1faaae8059a1c0f016d19396dec53b88dd846c233e0012e7c4f45">
  ]
  %strip_149447 = splice.exec "strip" at 149447(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#6) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/ordchr.so" file 755 mtime 1795046441 "4a0460aad4606c76cbcb6def7b154344a579c8b49e3f61e62520f3f6902e446a">
  ]
  %strip_149479 = splice.exec "strip" at 149479(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#7) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/readdir.so" file 755 mtime 1795046441 "4bc06f58e187477a0fa46690b35cf3b56054f441868c93dad68ef4ec5c4cb452">
  ]
  %strip_149505 = splice.exec "strip" at 149505(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#8) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/readfile.so" file 755 mtime 1795046441 "2ad5c85c4b87b538636b78246328c91ef99ead898a78f0e37f668e1c99ef5ef7">
  ]
  %strip_149537 = splice.exec "strip" at 149537(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#9) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/revoutput.so" file 755 mtime 1795046441 "13944ed58f74d1509e10fd825b881bbf51182c18824bf085afe54f52a16a3c52">
  ]
  %strip_149563 = splice.exec "strip" at 149563(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#10) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/revtwoway.so" file 755 mtime 1795046441 "09a78364cb66bec97a827a042f69cc67848d8f830b84b2b3441a7636c718c6a2">
  ]
  %strip_149595 = splice.exec "strip" at 149595(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#11) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/rwarray.so" file 755 mtime 1795046441 "271011e9d58e4e8699ccce5903e455e414c44763405748f535c0079127fe7b5a">
  ]
  %strip_149621 = splice.exec "strip" at 149621(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_136597#0, %mkdir_136597#1, %find_patchelf_patchelf_patchelf__12_147816#12) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/lib/gawk/time.so" file 755 mtime 1795046441 "315c38962036e8bf4603da9c05a189906fd619a9e190b9604d1be7ce290a6ecd">
  ]
  %strip_149653 = splice.exec "strip" at 149653(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_141566#0, %mkdir_141566#1, %find_patchelf_patchelf_patchelf__12_147816#14) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk/pwcat" file 755 mtime 1795046441 "c8b93109de2156c64d06f9fecb104b8a3c4a104a6da143099ea791b4b9d82d13">
  ]
  %strip_149679 = splice.exec "strip" at 149679(%sandbox_720#0, %tar_xz_1467#0, %mktemp_149224, %mkdir_133918, %mkdir_141566#0, %mkdir_141566#1, %find_patchelf_patchelf_patchelf__12_147816#13) -> [
      #splice.entry<"/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1/libexec/awk/grcat" file 755 mtime 1795046441 "f8740eb29fb46a3ee9d1b8a7c8832042975c6299f986f5ccf831ac0872770405">
  ]
  %ln_149896 = splice.literal "ln" at 149896 folded -> [
      #splice.entry<"/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man/share/man/man1/awk.1.gz" link 0 mtime 1795046441 "gawk.1.gz">
  ]
  splice.output "info" "/nix/store/l4pwpdc6hrgy8n3diy24n389k53jqqjk-gawk-5.4.1-info"(%mkdir_139847#0, %mkdir_139847#1, %mkdir_139847#2, %install_info_141140, %bash_140254, %sed_sed_basename_cp__26_139871, %sed_sed_basename_cp__26_139871_33, %sed_sed_basename_cp__26_139871_34, %sed_sed_basename_cp__26_139871_35, %sed_sed_basename_cp__26_139871_36, %sed_sed_basename_cp__26_139871_37, %sed_sed_basename_cp__26_139871_38, %bash_140254_39, %bash_140254_40, %bash_140254_41, %bash_140254_42)
  splice.output "man" "/nix/store/0azvqykndxs3clnj974q99cjfnmpprjv-gawk-5.4.1-man"(%bash_135816#0, %bash_135816#1, %bash_135816#2, %bash_141225, %ln_149896, %gzip_147536, %gzip_147523, %gzip_147507, %bash_135816#3, %gzip_147698, %gzip_147686, %gzip_147675, %gzip_147661, %gzip_147648, %gzip_147634, %gzip_147621, %gzip_147610, %gzip_147599, %gzip_147585, %gzip_147572, %gzip_147559)
  splice.output "out" "/nix/store/63g104xwbzfpcq0h7c99w19m6j9ly3p1-gawk-5.4.1"(%mkdir_133918, %mkdir_134147, %ln_134495, %strip_149271, %mkdir_139639#0, %mkdir_139639#1, %sed_sed_basename_cp__6_139667, %sed_sed_basename_cp__6_139667_32, %mkdir_134527, %sed_sed_basename_cp__2_134548, %mkdir_136597#0, %mkdir_136597#1, %strip_149299, %strip_149330, %strip_149359, %strip_149389, %strip_149421, %strip_149447, %strip_149479, %strip_149505, %strip_149537, %strip_149563, %strip_149595, %strip_149621, %mkdir_141566#0, %mkdir_141566#1, %strip_149679, %strip_149653, %mkdir_141859#0, %mkdir_141859#1, %mv_142142, %mv_142232, %mv_142322, %mv_142411, %mv_142500, %mv_142589, %mv_142678, %mv_142053, %mv_142767, %mv_142868, %mv_142957, %mv_143046, %mv_143135, %mv_143224, %mv_143313, %mv_143402, %mv_143491, %mv_141954, %mv_143590, %mv_143679, %mv_143768, %mv_143857, %mv_143946, %mv_144035, %mv_144124, %mv_144213, %mv_144302, %mv_144402, %mv_144490, %mkdir_144580#0, %mkdir_144580#1, %mkdir_144580#2, %mv_144636, %mkdir_144691#0, %mkdir_144691#1, %mv_144747, %mkdir_144802#0, %mkdir_144802#1, %mv_144858, %mkdir_144913#0, %mkdir_144913#1, %mv_144969, %mkdir_145024#0, %mkdir_145024#1, %mv_145086, %mkdir_145139#0, %mkdir_145139#1, %mv_145195, %mkdir_145250#0, %mkdir_145250#1, %mv_145307, %mkdir_145362#0, %mkdir_145362#1, %mv_145418, %mkdir_145473#0, %mkdir_145473#1, %mv_145529, %mkdir_145584#0, %mkdir_145584#1, %mv_145640, %mkdir_145695#0, %mkdir_145695#1, %mv_145751, %mkdir_145806#0, %mkdir_145806#1, %mv_145868, %mkdir_145920#0, %mkdir_145920#1, %mv_145976, %mkdir_146031#0, %mkdir_146031#1, %mv_146087, %mkdir_146142#0, %mkdir_146142#1, %mv_146198, %mkdir_146253#0, %mkdir_146253#1, %mv_146309, %mkdir_146364#0, %mkdir_146364#1, %mv_146420, %mkdir_146475#0, %mkdir_146475#1, %mv_146531, %mkdir_146586#0, %mkdir_146586#1, %mv_146642, %mkdir_146703#0, %mkdir_146703#1, %mv_146759)
}

