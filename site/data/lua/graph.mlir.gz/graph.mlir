module {
  %sandbox_720:3 = splice.literal "sandbox" at 720 -> [
      #splice.entry<"/build" dir 700 mtime 1795046400>,
      #splice.entry<"/build/.attrs.json" file 644 mtime 1795046400 "8b9c61c630098b0761acfa1f86c6e3757dc764e4fe98456903b6ce986f475934">,
      #splice.entry<"/build/.attrs.sh" file 644 mtime 1795046400 "bee2b439bdf8dcb06c63393297c6f4b4cfe9bd10c38f5753d1a509c20e288df7">
  ]
  %tar_1421:3 = splice.literal "tar" at 1421 folded -> [
      #splice.entry<"/build/lua-5.2.4" dir 755 mtime 1424910717>,
      #splice.entry<"/build/lua-5.2.4/doc" dir 755 mtime 1424910603>,
      #splice.entry<"/build/lua-5.2.4/src" dir 755 mtime 1424741481>
  ]
  %tar_1421_0:74 = splice.exec "tar" at 1421(%sandbox_720#0) -> [
      #splice.entry<"/build/lua-5.2.4" dir 755 mtime 1424910717>,
      #splice.entry<"/build/lua-5.2.4/Makefile" file 644 mtime 1424741334 "03bc16024f6b68adc7a044928ddb017869a275eb17b1374f098e825608718538">,
      #splice.entry<"/build/lua-5.2.4/README" file 644 mtime 1424910717 "746ef475168b8efdaf19f8733fb84fa88bf8b4855e8f06ad4a97aceb8fb0664f">,
      #splice.entry<"/build/lua-5.2.4/doc" dir 755 mtime 1424910603>,
      #splice.entry<"/build/lua-5.2.4/doc/contents.html" file 644 mtime 1424741076 "99ce749a42678b3c98755156b04c88f500347f99085749ab2e2f40aacc857fd0">,
      #splice.entry<"/build/lua-5.2.4/doc/logo.gif" file 644 mtime 1003840755 "9c3a3208ef05e12110f9b7b491cef676e650e4ebf3d36c4414268666bcc95d8a">,
      #splice.entry<"/build/lua-5.2.4/doc/lua.1" file 644 mtime 1321463818 "a44ed64aaf16121f193ac0a83322e4b5cd78a6932056dc5de5cc032856d90786">,
      #splice.entry<"/build/lua-5.2.4/doc/lua.css" file 644 mtime 1424779941 "d3bb1d56bc03379397c7f607802d8530ccb599009a5321b26dfc9fdc43ddd8a7">,
      #splice.entry<"/build/lua-5.2.4/doc/luac.1" file 644 mtime 1321463818 "ac60e6992db478539dff611beed7ad01f52622c897657a9152165470039b0494">,
      #splice.entry<"/build/lua-5.2.4/doc/manual.css" file 644 mtime 1384044308 "1a97ea6df44fb79a99160f88dd142aa80552583786d40de47e2d13c38cb0a137">,
      #splice.entry<"/build/lua-5.2.4/doc/manual.html" file 644 mtime 1424741085 "ca14a5d410f4485abb559d8ee30d05fed2c4f50739e56bc6ef21b084327dcee5">,
      #splice.entry<"/build/lua-5.2.4/doc/osi-certified-72x60.png" file 644 mtime 1163705966 "9d6ed62bd2f453c986f1aa1ed9e8920572cc746b944320a9aa0993cea6f55248">,
      #splice.entry<"/build/lua-5.2.4/doc/readme.html" file 644 mtime 1424741109 "a686d9158c8878ee4c6e1c90d719949c2b70031b74d6e945e6e218a063ebcb20">,
      #splice.entry<"/build/lua-5.2.4/src" dir 755 mtime 1424741481>,
      #splice.entry<"/build/lua-5.2.4/src/Makefile" file 644 mtime 1384170349 "440ff273dbf75a7212d5e60c00fa15839482d6f1f2b608ef187e3d1a38f22e2c">,
      #splice.entry<"/build/lua-5.2.4/src/lapi.c" file 644 mtime 1365792527 "0d3e39133f9589fa5481e02023de3282827706c885cd94f1df5d322594218505">,
      #splice.entry<"/build/lua-5.2.4/src/lapi.h" file 644 mtime 1365792527 "bc4b6d44a799257ad640bb220607b3a3c986f807ac8ea75d71632db7e8a3ef36">,
      #splice.entry<"/build/lua-5.2.4/src/lauxlib.c" file 644 mtime 1365792527 "2a6a7a1bb55e4a2021492cb51ba6966a3e32d1eea87c274a1d0734d0a4ed4133">,
      #splice.entry<"/build/lua-5.2.4/src/lauxlib.h" file 644 mtime 1365792527 "6c82fcd9d264a6a028b5fe308007c66bfe2443f6680bb4d6b94203ba296b9922">,
      #splice.entry<"/build/lua-5.2.4/src/lbaselib.c" file 644 mtime 1365792527 "99648b9cf49e601ab8002c640763a50afae151335b2b453c1b1a8cb37ac216c0">,
      #splice.entry<"/build/lua-5.2.4/src/lbitlib.c" file 644 mtime 1373392901 "5f8809a690a6da8fff5bc662262e98a4f7b0431f4b91f4c58d5bafde2cee6ced">,
      #splice.entry<"/build/lua-5.2.4/src/lcode.c" file 644 mtime 1365792527 "0b59a5ef6ad666df1e2833ac201d05418456fcce943ae3b49aa19464ceb4f79d">,
      #splice.entry<"/build/lua-5.2.4/src/lcode.h" file 644 mtime 1365792527 "85698d9239819880dea12bd856ad29c976438afaffe37e5aeda8907d6b60389b">,
      #splice.entry<"/build/lua-5.2.4/src/lcorolib.c" file 644 mtime 1365792527 "d391ce54268a17c2b959c4080e560e350b2c970ce81a5f063f1e42e2368b7098">,
      #splice.entry<"/build/lua-5.2.4/src/lctype.c" file 644 mtime 1365792527 "997f372a3f524d34524e57694d203f820d4b0a6ef2ba84bae556e4eb6d410706">,
      #splice.entry<"/build/lua-5.2.4/src/lctype.h" file 644 mtime 1365792527 "8af05e71837aa8ad8539c4ebd0e17f8a46e02e7b01e7ff1b5c13bf569f64805b">,
      #splice.entry<"/build/lua-5.2.4/src/ldblib.c" file 644 mtime 1424366215 "b03120fc9aa12f48d8d58ba66df9ac7ddfa444c4eaf34053beba8958babf7274">,
      #splice.entry<"/build/lua-5.2.4/src/ldebug.c" file 644 mtime 1424365513 "d1d04b777ed10c7705a8326c9483c8e7f42f5762b22a7c864e2d1b4c47a18ee9">,
      #splice.entry<"/build/lua-5.2.4/src/ldebug.h" file 644 mtime 1365792527 "1b57646b9e4eab27d1e89083b5b53966512304820a19d225d8430b3d51f734b3">,
      #splice.entry<"/build/lua-5.2.4/src/ldo.c" file 644 mtime 1383934970 "be540843fc0a62a7051cb334a4c893ad12773b1e1b2d6554846bca07d74af89d">,
      #splice.entry<"/build/lua-5.2.4/src/ldo.h" file 644 mtime 1365792527 "6b106aa8099f18e125f1481771f90c899d950bf54387aca0a5fc573a77afe7eb">,
      #splice.entry<"/build/lua-5.2.4/src/ldump.c" file 644 mtime 1365792527 "025ba49b676819079582cb59ff8ef36093d80002eb24702ef4eeb6c6fea1e8eb">,
      #splice.entry<"/build/lua-5.2.4/src/lfunc.c" file 644 mtime 1365792527 "1c07865498826785953d08fa97889f913bb11b77a3078e2d49226607b61dc526">,
      #splice.entry<"/build/lua-5.2.4/src/lfunc.h" file 644 mtime 1365792527 "31d8f6a1731edcf6513b13a37061e9b8a09efc37d0493c5fa6cca7f05450480e">,
      #splice.entry<"/build/lua-5.2.4/src/lgc.c" file 644 mtime 1409590508 "d11cafe3bb183dd5a69b3608d97ae7447be66a798c1efdb9e66b520535cfa1a2">,
      #splice.entry<"/build/lua-5.2.4/src/lgc.h" file 644 mtime 1365792527 "a13574f1e9f816ea09d425d33ec8082c41a8febe7f53c76255c81ff22a67cb96">,
      #splice.entry<"/build/lua-5.2.4/src/linit.c" file 644 mtime 1365792527 "2576eb77c85f996f6ffcaa1db11b549be8370cc632e2db87bd2a895c59f0840f">,
      #splice.entry<"/build/lua-5.2.4/src/liolib.c" file 644 mtime 1365792527 "e3cba668db638f0a95c70417e6fdead54106c45cb414490b063ee194eaff543b">,
      #splice.entry<"/build/lua-5.2.4/src/llex.c" file 644 mtime 1423504594 "33dc332cd5ad98e037b28e6448b9005e1f6511567865f0c607ae846fdb64124d">,
      #splice.entry<"/build/lua-5.2.4/src/llex.h" file 644 mtime 1365792527 "813a0bb0e530eff7816130c79433b2baefddc2508d851fde335c371b10fe3d22">,
      #splice.entry<"/build/lua-5.2.4/src/llimits.h" file 644 mtime 1365792527 "7e12687d1c9534b4325907cff9fb63a1d9831ab5e4fb79f9395b5bfb1a54991f">,
      #splice.entry<"/build/lua-5.2.4/src/lmathlib.c" file 644 mtime 1365792527 "f0fc98eb043b701813c79048e50da6527cc994aa827ab3cc72095b9bc88bcde6">,
      #splice.entry<"/build/lua-5.2.4/src/lmem.c" file 644 mtime 1365792527 "8dcaee2b4206d7b6c62f493c9ea06dbe2d6e0f4274d18d81357588d60274bc4b">,
      #splice.entry<"/build/lua-5.2.4/src/lmem.h" file 644 mtime 1365792527 "de1acb69555c0e57a6f0195d7ecd68752fd92c602a558e656c26121186391fa9">,
      #splice.entry<"/build/lua-5.2.4/src/loadlib.c" file 644 mtime 1365792527 "354ea52cc59313d68684f6bc070be9fed2cce23d40c83ecf75934371bcdc8811">,
      #splice.entry<"/build/lua-5.2.4/src/lobject.c" file 644 mtime 1365792527 "afa1f407b9c30620de9dad809998f21f2fe9826dc370cc99127e824181ce564f">,
      #splice.entry<"/build/lua-5.2.4/src/lobject.h" file 644 mtime 1399472098 "69e4a240d6f95511de1815462f5696260973ad74c1da6a9246c39fde5cd363f6">,
      #splice.entry<"/build/lua-5.2.4/src/lopcodes.c" file 644 mtime 1365792527 "0f0456408a3513ea7f1a4f865f38166921ed41a56b311ff807f054c91b96d1f0">,
      #splice.entry<"/build/lua-5.2.4/src/lopcodes.h" file 644 mtime 1413829929 "9af5efd2b0d23119199f53d3d36c238e40f9384c627bbe014811d4e222635d22">,
      #splice.entry<"/build/lua-5.2.4/src/loslib.c" file 644 mtime 1365792527 "d6e0ad34f103f6235ff27871e3dc0530df2e8592dbdcaeab3648d550b292bf6e">,
      #splice.entry<"/build/lua-5.2.4/src/lparser.c" file 644 mtime 1365792527 "26f1cf92c39620afc4b5a6b17864bde0e4fe607fd19be0d2af260a214c979e8d">,
      #splice.entry<"/build/lua-5.2.4/src/lparser.h" file 644 mtime 1365792527 "513ff1818fc101f4e4ab04d2cbc4527fd83096f5908f894c4025fd1c32c6f3e0">,
      #splice.entry<"/build/lua-5.2.4/src/lstate.c" file 644 mtime 1383932731 "9bf9f6504b824a4f4060314b041e13db45dd17f0b4a7f3114d159c403d55708c">,
      #splice.entry<"/build/lua-5.2.4/src/lstate.h" file 644 mtime 1365792527 "7bd5600ac8fa3ab82c5634b19bd961af9aa2a3b6c35ad9bbcda4e37f7e832a0e">,
      #splice.entry<"/build/lua-5.2.4/src/lstring.c" file 644 mtime 1365792527 "c0569349fb9ade9ba14fbda557b38052b2d6348dd1658f6da8aed1c5da973155">,
      #splice.entry<"/build/lua-5.2.4/src/lstring.h" file 644 mtime 1365792527 "a2b1c08e6680c0f3c5245081fcf756f70f6204481e5c9b665f9930ede50f7751">,
      #splice.entry<"/build/lua-5.2.4/src/lstrlib.c" file 644 mtime 1365792527 "219607b495ad420a2beb59d21f8b5e381a75cdb8e9e6e8a021ad60cd853c4ce1">,
      #splice.entry<"/build/lua-5.2.4/src/ltable.c" file 644 mtime 1365792527 "bcb5187916ef09c79fea6277198e81cd424995b2acb43df038fcb7859dd9ca3b">,
      #splice.entry<"/build/lua-5.2.4/src/ltable.h" file 644 mtime 1377877781 "94acdca581cf0f8faf64bb8bc5fee833cdf2359f6891eb7a03925919443ae390">,
      #splice.entry<"/build/lua-5.2.4/src/ltablib.c" file 644 mtime 1399480375 "3a6b7b2549878dd5e0741666a9d4e1d53752d2aa7ac77bfbed8cf3ecc934d43d">,
      #splice.entry<"/build/lua-5.2.4/src/ltm.c" file 644 mtime 1365792527 "98c801c1bd7616520d5b818fa88bdcfd4f0bdfbbb44b00fe7812d75c76f01053">,
      #splice.entry<"/build/lua-5.2.4/src/ltm.h" file 644 mtime 1365792527 "885e878c08709a6296d5fe703e7342dfbab1f616c3c45a918be4fab0a200252f">,
      #splice.entry<"/build/lua-5.2.4/src/lua.c" file 644 mtime 1365792527 "338a75e02b099a3dd6a1aedd70de6ca33bf71faf531cf73775d2cdd6e7b50a55">,
      #splice.entry<"/build/lua-5.2.4/src/lua.h" file 644 mtime 1424527490 "aaa571c445bdafe72c7e116bda8f2a415e8dcb05d988e4072e6dc15029c32fae">,
      #splice.entry<"/build/lua-5.2.4/src/lua.hpp" file 644 mtime 1103763184 "fd83f7e823cfbb03ac2da937ec83f01b4a6ddaac220a4fa1ffd6c6c3842c5890">,
      #splice.entry<"/build/lua-5.2.4/src/luac.c" file 644 mtime 1372899826 "2d7004c66f0847ec58804767161e31e2064cc0fc3cd39818bf234af4cfc4b033">,
      #splice.entry<"/build/lua-5.2.4/src/luaconf.h" file 644 mtime 1385054776 "249e50b06561883a077a4d3ad121754099606ab94a6ae086a058e6192530fe72">,
      #splice.entry<"/build/lua-5.2.4/src/lualib.h" file 644 mtime 1365792527 "471f53456ba85f9c5ff9ab7b3236e5bd5169579455c74794e9d7addf3a3c3534">,
      #splice.entry<"/build/lua-5.2.4/src/lundump.c" file 644 mtime 1365792527 "c9143f5ad8bd2433d1a6f077f809407a2f8b9cb703d5baa9597c6b83ba609df8">,
      #splice.entry<"/build/lua-5.2.4/src/lundump.h" file 644 mtime 1365792527 "a4b5d9b06f297eb9b2fe0d8516e87dd168a6214959accbeda6b782fb0f6abdce">,
      #splice.entry<"/build/lua-5.2.4/src/lvm.c" file 644 mtime 1365792527 "2795e35874bef9d292e669f7b252739ff2007484ce8d57ee3ba2df436e109dd9">,
      #splice.entry<"/build/lua-5.2.4/src/lvm.h" file 644 mtime 1365792527 "b5b759c88780bc150d4438897b177a09b9a633b8eb3511102ca24d27661073aa">,
      #splice.entry<"/build/lua-5.2.4/src/lzio.c" file 644 mtime 1365792527 "655c93deabdf42d6755cd9658d9e09f94a43dc3486d233d102504e5c2d512d1e">,
      #splice.entry<"/build/lua-5.2.4/src/lzio.h" file 644 mtime 1365792527 "85d50d679dd16497b8c4df760f89c60347483e7fc0b102dbe259b61d7bf841ea">
  ]
  %cat_patch_1969 = splice.exec "cat|patch" at 1969(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#50) -> [
      #splice.entry<"/build/lua-5.2.4/src/lparser.c" file 644 mtime 1795046400 "4cb6f9bb076b750ac8b8b4ec79d01809015b9baef3b8cd19ccac217f264ede0b">
  ]
  %sed_2017 = splice.exec "sed" at 2017(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#66) -> [
      #splice.entry<"/build/lua-5.2.4/src/luaconf.h" file 644 mtime 1795046400 "bb401944163eb62091f84a94ada09be5eb04b0aef47325ea47231e649f535ac6">
  ]
  %gcc_2566 = splice.exec "gcc" at 2566 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#15, %tar_1421_0#16, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#69, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lapi.o" file 644 mtime 1795046400 "c5c7cde6a789f443ad3f38d13faf9579d27b144dfb7f7548f5dc672a04088ed2">
  ]
  %gcc_2697 = splice.exec "gcc" at 2697 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#21, %tar_1421_0#22, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#35, %tar_1421_0#39, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#48, %tar_1421_0#51, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lcode.o" file 644 mtime 1795046400 "6da69b0e1bc7e7545068a69e6fe71462f8b597f55b604d592331f9b61b45c757">
  ]
  %gcc_2832 = splice.exec "gcc" at 2832 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#24, %tar_1421_0#25, %tar_1421_0#40, %tar_1421_0#63, %sed_2017) -> [
      #splice.entry<"/build/lua-5.2.4/src/lctype.o" file 644 mtime 1795046400 "a29fb85801336ea78d5704784d09d7a66325248a20406e7d0ab535d551ffaa5f">
  ]
  %gcc_2939 = splice.exec "gcc" at 2939 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#16, %tar_1421_0#22, %tar_1421_0#27, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#39, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#48, %tar_1421_0#51, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldebug.o" file 644 mtime 1795046400 "f52e2de17310990d097713cc5aecfb9c5536e91c62d03430b318e2863df056c8">
  ]
  %gcc_3053 = splice.exec "gcc" at 3053 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#16, %tar_1421_0#28, %tar_1421_0#29, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#48, %tar_1421_0#51, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#69, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldo.o" file 644 mtime 1795046400 "f40ae73ad95cc964bfddc4d102b19e22b655b84a78def9e6bb32886802f32211">
  ]
  %gcc_3175 = splice.exec "gcc" at 3175 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#31, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#69, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldump.o" file 644 mtime 1795046400 "4e6b5e3e19b396c10be3fdcbe478e6ae1a41daf882032d5d964753f447d591c3">
  ]
  %gcc_3296 = splice.exec "gcc" at 3296 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#32, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lfunc.o" file 644 mtime 1795046401 "d9b9e40bba32a2b9d474a7bf6860b25528565254e724d84e9474eaeb5e242dc0">
  ]
  %gcc_3422 = splice.exec "gcc" at 3422 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#34, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lgc.o" file 644 mtime 1795046401 "47c7d556721fc067278f0eac2b2bf0a4445a632faa6c57b54a5d8b855fc0d8d8">
  ]
  %gcc_3539 = splice.exec "gcc" at 3539 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#25, %tar_1421_0#30, %tar_1421_0#35, %tar_1421_0#38, %tar_1421_0#39, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#51, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/llex.o" file 644 mtime 1795046401 "85e4ed29fed5f6906a97194477f5a0b025c64277b900aed101131a05af883ab5">
  ]
  %gcc_3670 = splice.exec "gcc" at 3670 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#42, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lmem.o" file 644 mtime 1795046401 "d2cddd585feafc284211efc470ba85acfa145c521160c725713b042923950e56">
  ]
  %gcc_3801 = splice.exec "gcc" at 3801 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#25, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#45, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lobject.o" file 644 mtime 1795046401 "fa2655e4ce5bb4d57964f2ef05cc96ba2a8f997d92857b47e9e6095ef980cbb2">
  ]
  %gcc_3913 = splice.exec "gcc" at 3913 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#40, %tar_1421_0#47, %tar_1421_0#48, %tar_1421_0#63, %sed_2017) -> [
      #splice.entry<"/build/lua-5.2.4/src/lopcodes.o" file 644 mtime 1795046401 "51bf384143be4957d3f28e557a9c982a5886447ee04f64fbc30de2556c8a559d">
  ]
  %gcc_4031 = splice.exec "gcc" at 4031 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#22, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#39, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#48, %cat_patch_1969, %tar_1421_0#51, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lparser.o" file 644 mtime 1795046401 "9f21868cf8895c985a4c28a4d2b5e44835001c3b0b66d3805b76ce956f0b8384">
  ]
  %gcc_4153 = splice.exec "gcc" at 4153 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#16, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#39, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#52, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lstate.o" file 644 mtime 1795046402 "4957aeaca07784a4f41e2734203602e7d4dd6869fd87bb18b6991052bf01f2d7">
  ]
  %gcc_4266 = splice.exec "gcc" at 4266 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#54, %tar_1421_0#55, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lstring.o" file 644 mtime 1795046402 "a968f5fa36416fe8a4ba5ab6c4f340e3490b7ef3b9e3960a731ae23e623e252e">
  ]
  %gcc_4398 = splice.exec "gcc" at 4398 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#57, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ltable.o" file 644 mtime 1795046402 "72a972fe99f3012bbc47f501c2a17a65ac628e4eb68fddac8397bf2e5782b358">
  ]
  %gcc_4520 = splice.exec "gcc" at 4520 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#60, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ltm.o" file 644 mtime 1795046402 "bb84205750eefacaece3a51a7b2baaa85a81a3ff5a3ebf73cb5161e5b8da0fbd">
  ]
  %gcc_4632 = splice.exec "gcc" at 4632 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#68, %tar_1421_0#69, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lundump.o" file 644 mtime 1795046402 "f0a1b975b2e88b012d2b7f2d7f0c4d86ba9f140b7ec5d51515376919bf96426c">
  ]
  %gcc_4754 = splice.exec "gcc" at 4754 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#28, %tar_1421_0#30, %tar_1421_0#33, %tar_1421_0#35, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#48, %tar_1421_0#53, %tar_1421_0#55, %tar_1421_0#58, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#70, %tar_1421_0#71, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lvm.o" file 644 mtime 1795046402 "afe61ba9a57c5daf58c7c2dce99315038d0913667340f5a33e9b7d0567d0f14d">
  ]
  %gcc_4876 = splice.exec "gcc" at 4876 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#53, %tar_1421_0#61, %tar_1421_0#63, %sed_2017, %tar_1421_0#72, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lzio.o" file 644 mtime 1795046402 "8fb36a3984ac6ba2603d83276b5162a584bf531fbfbc8bbad52a9b3c77016808">
  ]
  %gcc_4993 = splice.exec "gcc" at 4993 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#17, %tar_1421_0#18, %tar_1421_0#63, %sed_2017) -> [
      #splice.entry<"/build/lua-5.2.4/src/lauxlib.o" file 644 mtime 1795046402 "209830029501d099f19cb62fb9dc2267b78b4de4171772e82a2e256e01dad8af">
  ]
  %gcc_5125 = splice.exec "gcc" at 5125 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#19, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lbaselib.o" file 644 mtime 1795046403 "087031e08a8e9d441f4115555cefb5dfe400993bc89daeda26d947005a63b67c">
  ]
  %gcc_5247 = splice.exec "gcc" at 5247 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#20, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lbitlib.o" file 644 mtime 1795046403 "27eb610e6fe68ea99140d714e471d1eefb945546eab6fab25ac068e0a83daaa6">
  ]
  %gcc_5368 = splice.exec "gcc" at 5368 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#23, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lcorolib.o" file 644 mtime 1795046403 "e7c649eb66e8a2cf7773b1b8d4f90630a2ad63a97d6aeb2842bb139da99b14dd">
  ]
  %gcc_5489 = splice.exec "gcc" at 5489 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#26, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldblib.o" file 644 mtime 1795046403 "61ae90cb80b61e9a82dcb76c4ec0a02d5d525726402327fd361c0e0511c204fe">
  ]
  %gcc_5614 = splice.exec "gcc" at 5614 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#37, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/liolib.o" file 644 mtime 1795046403 "8d90124ce45772dba68fe431f468d26ac86b4969f638058cc2e75adb7cedcb3e">
  ]
  %gcc_5738 = splice.exec "gcc" at 5738 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#41, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lmathlib.o" file 644 mtime 1795046403 "5a6c54ed28d9935edecd1e1444a47b4c17a8f817606499448eedfa01141e028c">
  ]
  %gcc_5861 = splice.exec "gcc" at 5861 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#49, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/loslib.o" file 644 mtime 1795046403 "1fca5e07abc7065af41307470c927fc47ee4e0106aea738647e9576be08bc262">
  ]
  %gcc_5974 = splice.exec "gcc" at 5974 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#56, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lstrlib.o" file 644 mtime 1795046403 "84198f777839dd7e51b98418bee8e3da1dbaf765cde967d2b67e600bbebc5792">
  ]
  %gcc_6105 = splice.exec "gcc" at 6105 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#59, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/ltablib.o" file 644 mtime 1795046403 "3452909503e5522b0146ef782da3daf5d3681f5c6f99e71e3c0b271b5a853499">
  ]
  %gcc_6227 = splice.exec "gcc" at 6227 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#44, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/loadlib.o" file 644 mtime 1795046404 "145c7f188e6874e93bca0bf25b3024fdff6293889a0d42006c8a9eaf23dec143">
  ]
  %gcc_6348 = splice.exec "gcc" at 6348 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#36, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/linit.o" file 644 mtime 1795046404 "d26394fb5e71ffa18977e99c481a017137bc25762b06919400ffae68b0f93a87">
  ]
  %gcc_6519 = splice.exec "gcc" at 6519 as "cc_shared_library"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %gcc_2566, %gcc_4993, %gcc_5125, %gcc_5247, %gcc_2697, %gcc_5368, %gcc_2832, %gcc_5489, %gcc_2939, %gcc_3053, %gcc_3175, %gcc_3296, %gcc_3422, %gcc_6348, %gcc_5614, %gcc_3539, %gcc_5738, %gcc_3670, %gcc_6227, %gcc_3801, %gcc_3913, %gcc_5861, %gcc_4031, %gcc_4153, %gcc_4266, %gcc_5974, %gcc_4398, %gcc_6105, %gcc_4520, %gcc_4632, %gcc_4754, %gcc_4876) -> [
      #splice.entry<"/build/lua-5.2.4/src/liblua.so.5.2.4" file 755 mtime 1795046404 "000cdac07fe6c607a57f13794ed39489db4d25985cdc8132017cd2606a56bfcd">
  ]
  %ar_6940 = splice.exec "ar" at 6940 as "cc_library"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %gcc_2566, %gcc_4993, %gcc_5125, %gcc_5247, %gcc_2697, %gcc_5368, %gcc_2832, %gcc_5489, %gcc_2939, %gcc_3053, %gcc_3175, %gcc_3296, %gcc_3422, %gcc_6348, %gcc_5614, %gcc_3539, %gcc_5738, %gcc_3670, %gcc_6227, %gcc_3801, %gcc_3913, %gcc_5861, %gcc_4031, %gcc_4153, %gcc_4266, %gcc_5974, %gcc_4398, %gcc_6105, %gcc_4520, %gcc_4632, %gcc_4754, %gcc_4876) -> [
      #splice.entry<"/build/lua-5.2.4/src/liblua.a" file 644 mtime 1795046404 "4e7031a5d591162a581f1da33e052c8437836215dc2e27fa7df7e85dd67abb21">
  ]
  %gcc_7039 = splice.exec "gcc" at 7039 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#62, %tar_1421_0#63, %sed_2017, %tar_1421_0#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lua.o" file 644 mtime 1795046404 "5e9f5fea696d72fab7d0b81a684f02cac26d92f4fbb7b1807f25889bc3dc3bef">
  ]
  %gcc_7200 = splice.exec "gcc" at 7200 as "cc_binary"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %ar_6940, %gcc_7039) -> [
      #splice.entry<"/build/lua-5.2.4/src/lua" file 755 mtime 1795046404 "d4639f2e4af1f0203b9dd9080af82f5675e915346e996e497ed78e1e391a73bb">
  ]
  %gcc_7564 = splice.exec "gcc" at 7564 as "cc_object"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %tar_1421_0#18, %tar_1421_0#28, %tar_1421_0#40, %tar_1421_0#43, %tar_1421_0#46, %tar_1421_0#48, %tar_1421_0#53, %tar_1421_0#61, %tar_1421_0#63, %tar_1421_0#65, %sed_2017, %tar_1421_0#69, %tar_1421_0#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/luac.o" file 644 mtime 1795046404 "e7552512880549297fee77494a64eb13fcacec92c3dee8ec8582b8ca9f1ef8cb">
  ]
  %gcc_7728 = splice.exec "gcc" at 7728 as "cc_binary"(%sandbox_720#0, %tar_1421#0, %tar_1421#2, %ar_6940, %gcc_7564) -> [
      #splice.entry<"/build/lua-5.2.4/src/luac" file 755 mtime 1795046404 "e6e39a6c24e17a93eb83c2501039354c5f0683c97bfa610dfd4d698642e72ef7">
  ]
  %mkdir_8145 = splice.literal "mkdir" at 8145 folded -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4" dir 755 mtime 1795046404>
  ]
  %mkdir_8242:6 = splice.literal "mkdir" at 8242 folded -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1" dir 755 mtime 1795046404>
  ]
  %install_8278 = splice.copy "install" at 8278(%gcc_7200) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/lua" file 755 mtime 1795046404 "d4639f2e4af1f0203b9dd9080af82f5675e915346e996e497ed78e1e391a73bb">
  %install_8278_1 = splice.copy "install" at 8278(%gcc_7728) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/luac" file 755 mtime 1795046404 "e6e39a6c24e17a93eb83c2501039354c5f0683c97bfa610dfd4d698642e72ef7">
  %cp_8326 = splice.copy "cp" at 8326(%tar_1421_0#18) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lauxlib.h" file 644 mtime 1795046404 "6c82fcd9d264a6a028b5fe308007c66bfe2443f6680bb4d6b94203ba296b9922">
  %cp_8326_2 = splice.copy "cp" at 8326(%tar_1421_0#63) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lua.h" file 644 mtime 1795046404 "aaa571c445bdafe72c7e116bda8f2a415e8dcb05d988e4072e6dc15029c32fae">
  %cp_8326_3 = splice.copy "cp" at 8326(%tar_1421_0#64) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lua.hpp" file 644 mtime 1795046404 "fd83f7e823cfbb03ac2da937ec83f01b4a6ddaac220a4fa1ffd6c6c3842c5890">
  %cp_8326_4 = splice.copy "cp" at 8326(%sed_2017) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/luaconf.h" file 644 mtime 1795046404 "bb401944163eb62091f84a94ada09be5eb04b0aef47325ea47231e649f535ac6">
  %cp_8326_5 = splice.copy "cp" at 8326(%tar_1421_0#67) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lualib.h" file 644 mtime 1795046404 "471f53456ba85f9c5ff9ab7b3236e5bd5169579455c74794e9d7addf3a3c3534">
  %cp_8381:2 = splice.literal "cp" at 8381 folded -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so" link 0 mtime 1795046404 "liblua.so.5.2.4">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2" link 0 mtime 1795046404 "liblua.so.5.2.4">
  ]
  %cp_8381_6 = splice.copy "cp" at 8381(%ar_6940) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.a" file 644 mtime 1795046404 "4e7031a5d591162a581f1da33e052c8437836215dc2e27fa7df7e85dd67abb21">
  %cp_8381_7 = splice.copy "cp" at 8381(%gcc_6519) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2.4" file 755 mtime 1795046404 "000cdac07fe6c607a57f13794ed39489db4d25985cdc8132017cd2606a56bfcd">
  %cp_8424 = splice.copy "cp" at 8424(%tar_1421_0#6) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/lua.1" file 644 mtime 1795046404 "a44ed64aaf16121f193ac0a83322e4b5cd78a6932056dc5de5cc032856d90786">
  %cp_8424_8 = splice.copy "cp" at 8424(%tar_1421_0#8) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/luac.1" file 644 mtime 1795046404 "ac60e6992db478539dff611beed7ad01f52622c897657a9152165470039b0494">
  %mkdir_8461:4 = splice.literal "mkdir" at 8461 folded -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua" dir 755 mtime 1795046404>
  ]
  %cp_8482 = splice.exec "cp" at 8482(%sandbox_720#0, %tar_1421#0, %mkdir_8145, %mkdir_8461#1) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support/utils.sh" file 444 mtime 1795046404 "49433a60f3778649a904d7fc9658a3ffc9ca0c232f95d546853e344866a7a1e4">
  ]
  %glue_8606 = splice.literal "glue" at 8606 -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc" file 644 mtime 1795046404 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_8606 = splice.exec "cat" at 8606(%sandbox_720#0, %tar_1421#0, %mkdir_8145, %mkdir_8242#2, %mkdir_8461#0, %glue_8606) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc" file 644 mtime 1795046404 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  ]
  %chmod_8778 = splice.copy "chmod" at 8778(%cp_8482) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support/utils.sh" file 644 mtime 1795046404 "49433a60f3778649a904d7fc9658a3ffc9ca0c232f95d546853e344866a7a1e4">
  %mkdir_8885:2 = splice.literal "mkdir" at 8885 folded -> [
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share" dir 755 mtime 1795046404>
  ]
  %mv_8906:2 = splice.literal "mv" at 8906 folded -> [
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4" dir 755 mtime 1795046404>
  ]
  %mv_8906_9 = splice.copy "mv" at 8906(%tar_1421_0#4) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/contents.html" file 644 mtime 1424741076 "99ce749a42678b3c98755156b04c88f500347f99085749ab2e2f40aacc857fd0">
  %mv_8906_10 = splice.copy "mv" at 8906(%tar_1421_0#5) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/logo.gif" file 644 mtime 1003840755 "9c3a3208ef05e12110f9b7b491cef676e650e4ebf3d36c4414268666bcc95d8a">
  %mv_8906_11 = splice.copy "mv" at 8906(%tar_1421_0#7) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/lua.css" file 644 mtime 1424779941 "d3bb1d56bc03379397c7f607802d8530ccb599009a5321b26dfc9fdc43ddd8a7">
  %mv_8906_12 = splice.copy "mv" at 8906(%tar_1421_0#9) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/manual.css" file 644 mtime 1384044308 "1a97ea6df44fb79a99160f88dd142aa80552583786d40de47e2d13c38cb0a137">
  %mv_8906_13 = splice.copy "mv" at 8906(%tar_1421_0#10) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/manual.html" file 644 mtime 1424741085 "ca14a5d410f4485abb559d8ee30d05fed2c4f50739e56bc6ef21b084327dcee5">
  %mv_8906_14 = splice.copy "mv" at 8906(%tar_1421_0#11) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/osi-certified-72x60.png" file 644 mtime 1163705966 "9d6ed62bd2f453c986f1aa1ed9e8920572cc746b944320a9aa0993cea6f55248">
  %mv_8906_15 = splice.copy "mv" at 8906(%tar_1421_0#12) -> <"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/readme.html" file 644 mtime 1424741109 "a686d9158c8878ee4c6e1c90d719949c2b70031b74d6e945e6e218a063ebcb20">
  %sed_9081 = splice.copy "sed" at 9081(%cat_8606) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua-5.2.pc" file 644 mtime 1795046404 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  %sed_9132 = splice.copy "sed" at 9132(%cat_8606) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua5.2.pc" file 644 mtime 1795046404 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  %sed_9161 = splice.copy "sed" at 9161(%cat_8606) -> <"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua52.pc" file 644 mtime 1795046404 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  %find_patchelf_patchelf_patchelf_9459:3 = splice.exec "find|patchelf|patchelf|patchelf" at 9459(%sandbox_720#0, %tar_1421#0, %mkdir_8145, %mkdir_8242#0, %install_8278, %install_8278_1, %mkdir_8242#2, %cp_8381_7) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/lua" file 755 mtime 1795046404 "9b5095c0de855417438e61ffb96525bea7279195ced62cbc16c754944c5959d7">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/luac" file 755 mtime 1795046404 "d5a95a0487ade4af77549966494fa19644220070a9aa4c8e1a35d682992d20f3">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2.4" file 755 mtime 1795046404 "18bb499494f707d0a327fc792abce7010a4051ae889d625718282be07b8aa2a2">
  ]
  %gzip_9978 = splice.exec "gzip" at 9978(%sandbox_720#0, %tar_1421#0, %mkdir_8145, %mkdir_8242#3, %mkdir_8242#4, %mkdir_8242#5, %cp_8424_8) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/luac.1.gz" file 644 mtime 1795046404 "59983673b10e7dd1d5a5a0c5b1a58074e00aa073f5828d8fb7f4e0baa5701fc2">
  ]
  %gzip_10005 = splice.exec "gzip" at 10005(%sandbox_720#0, %tar_1421#0, %mkdir_8145, %mkdir_8242#3, %mkdir_8242#4, %mkdir_8242#5, %cp_8424) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/lua.1.gz" file 644 mtime 1795046404 "80a8d8b22fb75f9adad3d786faad8f8ad42bc02db02a2a716c082e653cc8f074">
  ]
  %mktemp_10136 = splice.literal "mktemp" at 10136 folded -> [
      #splice.entry<"/build/striperr.M74Qm1" file 600 mtime 1795046404 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_10242 = splice.exec "strip" at 10242(%sandbox_720#0, %tar_1421#0, %mktemp_10136, %mkdir_8145, %mkdir_8242#0, %find_patchelf_patchelf_patchelf_9459#0) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/lua" file 755 mtime 1795046404 "e85bc886d36d21379a3d6dbf032a52ea6b2ba7c3fbf124ab252bbae9b426bcbc">
  ]
  %strip_10287 = splice.exec "strip" at 10287(%sandbox_720#0, %tar_1421#0, %mktemp_10136, %mkdir_8145, %mkdir_8242#0, %find_patchelf_patchelf_patchelf_9459#1) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/luac" file 755 mtime 1795046404 "5bdb9384b132ca31cee911150adf04f653d181954b0ee3f0738aa506226b2f12">
  ]
  %strip_10334 = splice.exec "strip" at 10334(%sandbox_720#0, %tar_1421#0, %mktemp_10136, %mkdir_8145, %mkdir_8242#2, %cp_8381_6) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.a" file 644 mtime 1795046404 "6cbf8d2772191887a38ad2365fe72a2604ee9f96428962cdd83c12080293237e">
  ]
  %strip_10536 = splice.exec "strip" at 10536(%sandbox_720#0, %tar_1421#0, %mktemp_10136, %mkdir_8145, %mkdir_8242#2, %find_patchelf_patchelf_patchelf_9459#2) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2.4" file 755 mtime 1795046404 "16af0fb60f0228e8b0588efcb72536a7a8af710b5dd6b6d5efbe531c306591c4">
  ]
  %glue_10860 = splice.literal "glue" at 10860 -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support/setup-hook" file 644 mtime 1795046404 "1107b8ed77fca0fb383cc533b5e0d7dfefb327c1da01941c60c0486f1516cee8">
  ]
  splice.output "doc" "/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc"(%mkdir_8885#0, %mkdir_8885#1, %mv_8906#0, %mv_8906#1, %mv_8906_9, %mv_8906_10, %mv_8906_11, %mv_8906_12, %mv_8906_13, %mv_8906_14, %mv_8906_15)
  splice.output "out" "/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4"(%mkdir_8145, %mkdir_8242#0, %strip_10242, %strip_10287, %mkdir_8242#1, %cp_8326, %cp_8326_2, %cp_8326_3, %cp_8326_4, %cp_8326_5, %mkdir_8242#2, %strip_10334, %cp_8381#0, %cp_8381#1, %strip_10536, %mkdir_8461#0, %sed_9081, %cat_8606, %sed_9132, %sed_9161, %mkdir_8461#1, %glue_10860, %chmod_8778, %mkdir_8242#3, %mkdir_8242#4, %mkdir_8242#5, %gzip_10005, %gzip_9978)
}

