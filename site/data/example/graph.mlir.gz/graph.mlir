module {
  %sandbox_717 = splice.literal "sandbox" at 717 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %dd_735 = splice.exec "dd" at 735(%sandbox_717) -> [
      #splice.entry<"/build/bundle" file 644 mtime 1 "cb94740ad765d0c3cb3742959e2f7556d4c7adb712660bfbacb1ba2c6f50e671">
  ]
  %dd_764 = splice.exec "dd" at 764(%sandbox_717, %dd_735) -> [
      #splice.entry<"/build/bundle" file 644 mtime 1 "50f55425c6b2fa76153714d7097567804eabbe75984a18b4534537973c24d9fa">
  ]
  %dd_782 = splice.copy "dd" at 782(%dd_764) -> <"/nix/store/l1dx8g9mr73bdp8y6i2yp92xprmz8xzg-genrulify-example" file 644 mtime 1 "50f55425c6b2fa76153714d7097567804eabbe75984a18b4534537973c24d9fa">
  splice.output "out" "/nix/store/l1dx8g9mr73bdp8y6i2yp92xprmz8xzg-genrulify-example"(%dd_782)
}

