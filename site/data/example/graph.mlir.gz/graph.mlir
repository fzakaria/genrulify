module {
  %0 = splice.literal "sandbox" at 717 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %1 = splice.exec "dd" at 735(%0) -> [
      #splice.entry<"/build/bundle" file 644 mtime 1 "cb94740ad765d0c3cb3742959e2f7556d4c7adb712660bfbacb1ba2c6f50e671">
  ]
  %2 = splice.exec "dd" at 764(%0, %1) -> [
      #splice.entry<"/build/bundle" file 644 mtime 1 "50f55425c6b2fa76153714d7097567804eabbe75984a18b4534537973c24d9fa">
  ]
  %3 = splice.exec "dd" at 782(%0, %2) -> [
      #splice.entry<"/nix/store/l1dx8g9mr73bdp8y6i2yp92xprmz8xzg-genrulify-example" file 644 mtime 1 "50f55425c6b2fa76153714d7097567804eabbe75984a18b4534537973c24d9fa">
  ]
  splice.output "out" "/nix/store/l1dx8g9mr73bdp8y6i2yp92xprmz8xzg-genrulify-example"(%3)
}

