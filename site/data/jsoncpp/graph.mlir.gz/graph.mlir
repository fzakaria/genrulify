module {
  %sandbox_721:3 = splice.literal "sandbox" at 721 -> [
      #splice.entry<"/build" dir 700 mtime 1794960000>,
      #splice.entry<"/build/.attrs.json" file 644 mtime 1794960000 "a196b3a6e02af7d3834b19fb330f75bd787652d5513e3eea35aa141dbca0a836">,
      #splice.entry<"/build/.attrs.sh" file 644 mtime 1794960000 "0eba046c30e69de56bcbe4bc2fc95959abdae514f5851ea7b47065a4a5636453">
  ]
  %cp_1473:286 = splice.exec "cp" at 1473(%sandbox_721#0) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/.clang-format" file 444 mtime 1 "a67060501ad83a5e868621aa7630753101a3d412b885fde3b5c99f41ca69ac86">,
      #splice.entry<"/build/source/.clang-tidy" file 444 mtime 1 "c535c60b29c12bf873790b4fed5c4d4b78e1b17e2c9b1f401ee7ccc4b4a8bea9">,
      #splice.entry<"/build/source/.gitattributes" file 444 mtime 1 "42b2be87f57cd0e4d54db154f6e2ac801b4aede45ecff607cab489c8a69687ed">,
      #splice.entry<"/build/source/.github" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE/bug_report.md" file 444 mtime 1 "559951936498209cc84ba6d9e4d2f12ca4a517dd5e30cb25107ef1bb4ec27141">,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE/feature_request.md" file 444 mtime 1 "1f48c52f209a971b8e7eae4120144d28fcf8ee38a7778a7b4d8cf1ab356617d2">,
      #splice.entry<"/build/source/.github/workflows" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/workflows/abi-compatibility.yml" file 444 mtime 1 "3b8f60010d08b438dbadfef614e6fc7c969e651b18b5247efde0180e06607f33">,
      #splice.entry<"/build/source/.github/workflows/amalgamate.yml" file 444 mtime 1 "6813eef882424d4331e63689c90522e1a79a5e8e21a230ab78a3042b67289bcf">,
      #splice.entry<"/build/source/.github/workflows/clang-format.yml" file 444 mtime 1 "8a6f41fd9a8f9d6bff960c49b371ff87a36b2dc64d5122e4029d6e9a471a93e4">,
      #splice.entry<"/build/source/.github/workflows/cmake.yml" file 444 mtime 1 "771336000ed34ab260e30e61c3a44a87a72daff0086157526e213ccc52237a89">,
      #splice.entry<"/build/source/.github/workflows/meson.yml" file 444 mtime 1 "667dea22b2ce0235bd463cfe8d04e72cd4382d0216c531fc0b3a76251a1a6507">,
      #splice.entry<"/build/source/.github/workflows/update-project-version.yml" file 444 mtime 1 "c9c44ce02e2e37c73d1a11f6a573bf643057033b46cc4157daea9307471d8d7d">,
      #splice.entry<"/build/source/.gitignore" file 444 mtime 1 "4904ae7765ccb12c8b08d2fce5c853458c6c150adc9d94a674c70e51037ac8a2">,
      #splice.entry<"/build/source/AUTHORS" file 444 mtime 1 "490315d88914139485bf00e9d66011a4e2e8be30d1c5c55555597db2913c7fd7">,
      #splice.entry<"/build/source/BUILD.bazel" file 444 mtime 1 "03873bab3054b711096a50b05c9f0254df5e65cfc799650d1377a4f2fdfa10ce">,
      #splice.entry<"/build/source/CMakeLists.txt" file 444 mtime 1 "50e2180e0fb9d628050766d19213feaaf86f27d6abb4a27fefa6797b7cae13a5">,
      #splice.entry<"/build/source/CONTRIBUTING.md" file 444 mtime 1 "3e18bee4de151ce264f7231cbee6ed6b6662a78f446fd77f8f0d7776ee2264a3">,
      #splice.entry<"/build/source/CTestConfig.cmake" file 444 mtime 1 "754be28d2e0742e88c9087cc09500204004f9883432e0df3ec4c92b84672c920">,
      #splice.entry<"/build/source/LICENSE" file 444 mtime 1 "cec0db5f6d7ed6b3a72647bd50aed02e13c3377fd44382b96dc2915534c042ad">,
      #splice.entry<"/build/source/MODULE.bazel" file 444 mtime 1 "7667ff9bf1bba31f59426a0233bc7b211678183afc9e0ef07d5de9b2b2864c5c">,
      #splice.entry<"/build/source/README.md" file 444 mtime 1 "1c7082dd001f03e4f55cbe743a30b26141aee2ad2ac148b9269914fa3ee479b6">,
      #splice.entry<"/build/source/SECURITY.md" file 444 mtime 1 "940cc420889f225fa0b32e8e848103748c39fd4ea68aef6461a866b67c998dc9">,
      #splice.entry<"/build/source/amalgamate.py" file 555 mtime 1 "d48c7d9fd354b59f4fa6b84ef998f6fabb254ef1ddef642f984b77c87f18d7f3">,
      #splice.entry<"/build/source/appveyor.yml" file 444 mtime 1 "2989857f863160b8a57d77129bb8e809ee5fd10fd303e4b4fbfa88b5b3ec22ad">,
      #splice.entry<"/build/source/cmake" dir 555 mtime 1>,
      #splice.entry<"/build/source/cmake/JoinPaths.cmake" file 444 mtime 1 "861e8bba5577de156ccc23f8b128717648a774e1cefb88897a09105c11d38cc0">,
      #splice.entry<"/build/source/dev.makefile" file 444 mtime 1 "cfe0a8bd103a84f2eb794201522a37ce74d17517060a56f5a176c2cc8fb78183">,
      #splice.entry<"/build/source/devtools" dir 555 mtime 1>,
      #splice.entry<"/build/source/devtools/__init__.py" file 444 mtime 1 "50d44eee1449fd56cf5843a260c2146e91e2239ab0b7c49579b3159580dbbf9e">,
      #splice.entry<"/build/source/devtools/agent_vmw7.json" file 444 mtime 1 "441984c5c22c40c27e0e54ec2068143cd400edd5dc60689419b75d73e446ae2c">,
      #splice.entry<"/build/source/devtools/agent_vmxp.json" file 444 mtime 1 "a6f6aa0490cc2298a5d0ee16bb844d8b56ca23f88ee6dc81212891f96422535a">,
      #splice.entry<"/build/source/devtools/antglob.py" file 444 mtime 1 "28c64608546d58f3beb2fabbbb21477ebb26709759514d14f7339f691c48dbe3">,
      #splice.entry<"/build/source/devtools/batchbuild.py" file 444 mtime 1 "0056ec830428d48d10efd9fea78bef68f0fceab1803b6ddde5dd465d6af33279">,
      #splice.entry<"/build/source/devtools/fixeol.py" file 444 mtime 1 "deba2388311419989636db6c7f12afb8665839a52e322826002d33a9cdd9079d">,
      #splice.entry<"/build/source/devtools/licenseupdater.py" file 444 mtime 1 "81d0fc4498e695444090a0ba9a74398f8738cd1ae18c788734be93fec2dc3515">,
      #splice.entry<"/build/source/devtools/tarball.py" file 444 mtime 1 "d393421db48cd31738bdbb064bf1b9cf42e3d8a6f4c7bbf40a9ca9343e173ad6">,
      #splice.entry<"/build/source/doc" dir 555 mtime 1>,
      #splice.entry<"/build/source/doc/doxyfile.in" file 444 mtime 1 "5c9259c15342d244595dd0e08851b167d4ed7b7e632d08b7e059eeb01679b251">,
      #splice.entry<"/build/source/doc/footer.html" file 444 mtime 1 "69eb40e1906db07c9a521dfc0bf5f4b094748cafad71117e2a4fd39df49a39d4">,
      #splice.entry<"/build/source/doc/header.html" file 444 mtime 1 "ab20d7418cd41642d08702a9c3b8182ef22dbed574367e6414670367f3d12524">,
      #splice.entry<"/build/source/doc/jsoncpp.dox" file 444 mtime 1 "25a4c4a882c5c627604cea8755d6a5816795a9eaef0babf5ecf4a62c83819373">,
      #splice.entry<"/build/source/doc/readme.txt" file 444 mtime 1 "557140d25a4213b1c64ae7663a11a98258f36f4b9c8fca44b710f9359ca36a82">,
      #splice.entry<"/build/source/doc/roadmap.dox" file 444 mtime 1 "448aa510f07ade61d496d3830ba1dc46fa5a685604889d12cab26289d20d6466">,
      #splice.entry<"/build/source/doc/web_doxyfile.in" file 444 mtime 1 "a1a8ecac246779d1a8d93b0d931bc3ab8affcfe29d871dd4e08de0be9679517b">,
      #splice.entry<"/build/source/doxybuild.py" file 444 mtime 1 "15618dabe099d751533683566ef5af6243ec04327e5d399c212b2ef5453885e4">,
      #splice.entry<"/build/source/example" dir 555 mtime 1>,
      #splice.entry<"/build/source/example/BUILD.bazel" file 444 mtime 1 "3eebfe5f5f05a24c2d606306b4d0e5203551d226d9fd23474e08aab412a47e2e">,
      #splice.entry<"/build/source/example/CMakeLists.txt" file 444 mtime 1 "fe40eb997a0e2950d32c9debda93df6291f30faa2a5fa52b7ea8f434d4c0602e">,
      #splice.entry<"/build/source/example/README.md" file 444 mtime 1 "a7e5ef904b7f617658d8580aabd6fb15f8ce9247d44ab974e99c0c3af58ef381">,
      #splice.entry<"/build/source/example/readFromStream" dir 555 mtime 1>,
      #splice.entry<"/build/source/example/readFromStream/errorFormat.json" file 444 mtime 1 "602bb28d233f16341b7c919f193c1e8fa5aa1a8805d04359c51cf7d80ed0a9ef">,
      #splice.entry<"/build/source/example/readFromStream/readFromStream.cpp" file 444 mtime 1 "4217f3c797691e1fe92df9777b1c13b0e1dd158b60536ac30fa4188b8960b846">,
      #splice.entry<"/build/source/example/readFromStream/withComment.json" file 444 mtime 1 "75425128ff68f45c1d3114ffa180b8a774727903147aef296ca581bb60b3c840">,
      #splice.entry<"/build/source/example/readFromString" dir 555 mtime 1>,
      #splice.entry<"/build/source/example/readFromString/readFromString.cpp" file 444 mtime 1 "2dd8ae4ff314215148bd95dd9da412bb362e697563021a56adf750c913051e13">,
      #splice.entry<"/build/source/example/streamWrite" dir 555 mtime 1>,
      #splice.entry<"/build/source/example/streamWrite/streamWrite.cpp" file 444 mtime 1 "e7472e895586c5c743153efb87a518f8fcbceaefc60ad5d4dd54534b0e2efae3">,
      #splice.entry<"/build/source/example/stringView" dir 555 mtime 1>,
      #splice.entry<"/build/source/example/stringView/stringView.cpp" file 444 mtime 1 "b7430c1ab6036e7ae946d910e38bbca2149d2aad0789b65ce82fbd8a851c50c4">,
      #splice.entry<"/build/source/example/stringWrite" dir 555 mtime 1>,
      #splice.entry<"/build/source/example/stringWrite/stringWrite.cpp" file 444 mtime 1 "5e8ad4597d3638a14d4bbbe1929d126d9a207d199493f78332248709346bfd7f">,
      #splice.entry<"/build/source/gcovr.cfg" file 444 mtime 1 "33fa69ef128a81df1cf5bcc65cb4dbffb156c83fb98a56276a2ed15c2645145b">,
      #splice.entry<"/build/source/get_version.pl" file 444 mtime 1 "1393ec18dab992ae0056e1ca1c48aaeefcafb10f16737bbe1472f50b162a5e35">,
      #splice.entry<"/build/source/include" dir 555 mtime 1>,
      #splice.entry<"/build/source/include/CMakeLists.txt" file 444 mtime 1 "873311b839db91f10514db29e129b28b42d86a0deaba802cf97e4d0f219bc932">,
      #splice.entry<"/build/source/include/PreventInBuildInstalls.cmake" file 444 mtime 1 "e9a62c62a516bd07cb765edec6c35cedba14b03cb7c5e3d221ac10cfa1d2bdf0">,
      #splice.entry<"/build/source/include/PreventInSourceBuilds.cmake" file 444 mtime 1 "e88a6582ecd3cd40db08ce2f88506338221ba95600c0d1e4b0da4fa3d81976c1">,
      #splice.entry<"/build/source/include/json" dir 555 mtime 1>,
      #splice.entry<"/build/source/include/json/allocator.h" file 444 mtime 1 "500a24a92dfbf8e8c8699e4eb654511e62619bd8d7f29bca4c62c24ca66c4101">,
      #splice.entry<"/build/source/include/json/assertions.h" file 444 mtime 1 "ea30b8fb30ef70a52a6435f6e6efbc37de03555fa192b33832e65cbd159b68bb">,
      #splice.entry<"/build/source/include/json/config.h" file 444 mtime 1 "7479aba8631e81d9a450ff3dd1ad8a18ef913656caac6555ce6c5fd507d51622">,
      #splice.entry<"/build/source/include/json/forwards.h" file 444 mtime 1 "92a8bfce5303164fb3620e2dd053333c22ab9a775e4da3817fb3e89cf547a299">,
      #splice.entry<"/build/source/include/json/json.h" file 444 mtime 1 "05ccb35afa55a068f8cc2a195db46d89a7f6a458d1943ae009465834c6404a67">,
      #splice.entry<"/build/source/include/json/json_features.h" file 444 mtime 1 "9a3a209af311356da182e0b768c7c1f5993863df9d2d0f9dfa8f96d492282494">,
      #splice.entry<"/build/source/include/json/reader.h" file 444 mtime 1 "c29e5a46b6204c6e166c31880be2483067cad5a851da3b07b06b8f46c1f583d0">,
      #splice.entry<"/build/source/include/json/value.h" file 444 mtime 1 "735bc075cbc8ac106e1fcb2e3aada2ee4da09feebf9d005c9b1486690293abe7">,
      #splice.entry<"/build/source/include/json/version.h" file 444 mtime 1 "c0a115d83a96ebfac02f4df50509b96619d2af4b639920cfe310a9ca99e040d0">,
      #splice.entry<"/build/source/include/json/writer.h" file 444 mtime 1 "1828e708ae2f28207b0b0c618aa14038c3e223af9d25de2efab0fcf4fbd25591">,
      #splice.entry<"/build/source/jsoncpp-namespaced-targets.cmake" file 444 mtime 1 "3ca99e17de275ce3c52e0d1591ecdfc20ec521f5a20e96776ee39a2f679fe739">,
      #splice.entry<"/build/source/jsoncppConfig.cmake.in" file 444 mtime 1 "6687cae93c0be2a17415e59cbaf9bf20a7d4050b4d68467985c7e60f5f156bc2">,
      #splice.entry<"/build/source/jsoncppConfig.cmake.meson.in" file 444 mtime 1 "7705f02885eb5d91bf449c09855befc8627291b5ddbb98f7500c067dc8b85ab9">,
      #splice.entry<"/build/source/meson.build" file 444 mtime 1 "469ba5b7e32a5f5cdf29fe6f5daba85437ecbd4d2c3d1b488dd787011d11e039">,
      #splice.entry<"/build/source/meson_options.txt" file 444 mtime 1 "327545202c4a99cbeff1240afb08eb7cf49e0869d3bcf3738d9bdef354706132">,
      #splice.entry<"/build/source/pkg-config" dir 555 mtime 1>,
      #splice.entry<"/build/source/pkg-config/jsoncpp.pc.in" file 444 mtime 1 "f2e4b18953c7b9cb33d0a5c043d329aad8151fff12283671be05561202239ac5">,
      #splice.entry<"/build/source/reformat.sh" file 555 mtime 1 "e01c4a76febe320be4784fe9168c907a0a217341471cf047d9e7a40347f32d79">,
      #splice.entry<"/build/source/src" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/CMakeLists.txt" file 444 mtime 1 "086c09ab7a410f40db8964d0e29ed2120ad110f78958b079468df70b39bf7e3b">,
      #splice.entry<"/build/source/src/jsontestrunner" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/jsontestrunner/BUILD.bazel" file 444 mtime 1 "1cee97e3ed2cec19a9b64f407c232b10ee590331b293dcf32ad27b67adc8f9d6">,
      #splice.entry<"/build/source/src/jsontestrunner/CMakeLists.txt" file 444 mtime 1 "5cea9dae3eddc1dc653933578ad552fdd7fe5740640ec49dfba4d42779575d57">,
      #splice.entry<"/build/source/src/jsontestrunner/main.cpp" file 444 mtime 1 "25bd9c905309938c6b645271b42555b77f36f562158fea3d13e3bccb7768b4b0">,
      #splice.entry<"/build/source/src/lib_json" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/lib_json/CMakeLists.txt" file 444 mtime 1 "c6c486b6c8851a8a7c2a6a6c95e12b53edac72055635cdc1d38ae25c39dfad5a">,
      #splice.entry<"/build/source/src/lib_json/json_reader.cpp" file 444 mtime 1 "bbf30e4ab2976853d75f54b2304d6f2e526978dee2188dffbcbc501e58166f28">,
      #splice.entry<"/build/source/src/lib_json/json_tool.h" file 444 mtime 1 "dd86b80bad3a960b34589b97047c63be63a34db1fcdd51a93dbc6aef150cfaf8">,
      #splice.entry<"/build/source/src/lib_json/json_value.cpp" file 444 mtime 1 "08dd3f7ddaa6f7c997b53e25a50be9354fb5263796aa7f9d2c4ff8562f01f0ba">,
      #splice.entry<"/build/source/src/lib_json/json_valueiterator.inl" file 444 mtime 1 "5b269ac0a6eb2dcd6f902fb4f51eb080a397d1e97e76b921d0932d000f76d7fa">,
      #splice.entry<"/build/source/src/lib_json/json_writer.cpp" file 444 mtime 1 "ffb0cac91aea2ce089d676626fafacad396cef9df2518b47938b0e49e105de9b">,
      #splice.entry<"/build/source/src/test_lib_json" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/test_lib_json/BUILD.bazel" file 444 mtime 1 "7a218e32d8fb010c8d12fa531129b4093d4ba24dce52a49d432cf958c8955e1b">,
      #splice.entry<"/build/source/src/test_lib_json/CMakeLists.txt" file 444 mtime 1 "57c3bf53b09ab0f9c6a4e14660d524110a7369400806bee6ad4ddcf129fd2794">,
      #splice.entry<"/build/source/src/test_lib_json/fuzz.cpp" file 444 mtime 1 "56b7839a8805fba7f9e5fa4558ba46f8d387efade70335a3dd982b6d000312f9">,
      #splice.entry<"/build/source/src/test_lib_json/fuzz.dict" file 444 mtime 1 "93219cb07c502247f422b036c17f0f3babdc04fa473d01f2ec93320a870be173">,
      #splice.entry<"/build/source/src/test_lib_json/fuzz.h" file 444 mtime 1 "61af29b33af2ebd56bd3e38b7d4296c4c6b9c777bf55cf441c677cb805af71dd">,
      #splice.entry<"/build/source/src/test_lib_json/jsontest.cpp" file 444 mtime 1 "5dbf5b122dcef5a9f993c0a32726aa18a4c80a397345e89718ca967e9241dce0">,
      #splice.entry<"/build/source/src/test_lib_json/jsontest.h" file 444 mtime 1 "dec28e7f0b46bf97af9386febb33e6dad1608436059ae8f0ff891289f7af66dc">,
      #splice.entry<"/build/source/src/test_lib_json/main.cpp" file 444 mtime 1 "462b28b7066a23eb04a2e52c8feacc2572b2e471c9d25ac21c2410564e58f083">,
      #splice.entry<"/build/source/test" dir 555 mtime 1>,
      #splice.entry<"/build/source/test/BUILD.bazel" file 444 mtime 1 "d66fb4b85f7bf294ccf60e62cc351b7a885aef1f26acc2f1220486f6bd9e197e">,
      #splice.entry<"/build/source/test/cleantests.py" file 444 mtime 1 "3aff20afa032dec4c7ab831c055bcf1d3a4ae930970898050f1710dd27f60fba">,
      #splice.entry<"/build/source/test/data" dir 555 mtime 1>,
      #splice.entry<"/build/source/test/data/fail_invalid_quote.json" file 444 mtime 1 "3455f41de9c8437dec9e64208884f198b2416bfbfb8188d809b033a2c7b3452f">,
      #splice.entry<"/build/source/test/data/fail_strict_comment_01.json" file 444 mtime 1 "5bbdb7f217a480b93acaaf080c2bb41e0fa095e5d1c5ee41caa638c46faebdb5">,
      #splice.entry<"/build/source/test/data/fail_strict_comment_02.json" file 444 mtime 1 "8082bd5b4f02b39be989947d9871ad3a55fa69f6b2bc7abe0290831e94587997">,
      #splice.entry<"/build/source/test/data/fail_strict_comment_03.json" file 444 mtime 1 "4b6f0717c456e01653162f0cefc4a9bacd0a2d8fc76a232bfff6d650f49570fa">,
      #splice.entry<"/build/source/test/data/fail_test_array_01.json" file 444 mtime 1 "ba632e3b0e558d4a4ddd6d94f7e8ee54531de7a906ecced62fcc8556d160b0a1">,
      #splice.entry<"/build/source/test/data/fail_test_array_02.json" file 444 mtime 1 "56690a7eea18d8e9a9208655b9fb924660c3a5f1ec22c713315b18c132b02ac4">,
      #splice.entry<"/build/source/test/data/fail_test_control_char_01.json" file 444 mtime 1 "a2bca62ab7e7f14c7d3990aa49b00f9f55700ff69e1131ca08534c8345828334">,
      #splice.entry<"/build/source/test/data/fail_test_object_01.json" file 444 mtime 1 "114ab302726bc520e41b6d6b295a347a63996cc91e725cb4232c44e47ac1f042">,
      #splice.entry<"/build/source/test/data/fail_test_object_02.json" file 444 mtime 1 "3bfc52221b1edf03333b90130cdec2d3008546a5c3277570ed3170408053073e">,
      #splice.entry<"/build/source/test/data/fail_test_stack_limit.json" file 444 mtime 1 "8447d235e9eb6f1b9ba359ce9f459d2ec26353dd1165e09ba7ae91d3caf1e84e">,
      #splice.entry<"/build/source/test/data/legacy_test_array_01.expected" file 444 mtime 1 "77f07f05766c910ff299e454d73e1c08927574e88a478d8f7c39310c8160c095">,
      #splice.entry<"/build/source/test/data/legacy_test_array_01.json" file 444 mtime 1 "37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570">,
      #splice.entry<"/build/source/test/data/legacy_test_array_02.expected" file 444 mtime 1 "daa5e6d09e5bdb2cb999971f3973013229ed8248967e6ce1db9c417a2b4800c1">,
      #splice.entry<"/build/source/test/data/legacy_test_array_02.json" file 444 mtime 1 "acc07b62f23f458923737c4cd4a66bd05d1e71eb4f384003baaf2dcc760d6349">,
      #splice.entry<"/build/source/test/data/legacy_test_array_03.expected" file 444 mtime 1 "96f1d95dabfae3e3a4c458a1282f7f8a893421bf71de38c7e593280ea4a2383b">,
      #splice.entry<"/build/source/test/data/legacy_test_array_03.json" file 444 mtime 1 "4e633466c855196e49ebc0ad737fdbb24eefb7eeb1fc871d28b571974fe77f4a">,
      #splice.entry<"/build/source/test/data/legacy_test_array_04.expected" file 444 mtime 1 "42b73678b9a915eab2931bc2ed4cea8edc0eb92c55a6270ba7a6cf6183cf4725">,
      #splice.entry<"/build/source/test/data/legacy_test_array_04.json" file 444 mtime 1 "71b9d8d6ca48ad274a199467213caa8cc67afdb142a1ec346366505825e63293">,
      #splice.entry<"/build/source/test/data/legacy_test_array_05.expected" file 444 mtime 1 "bfa9d003e3a9b262ef4bc5db4bfb409ccc6b12de9a0894187204ed709fcc147f">,
      #splice.entry<"/build/source/test/data/legacy_test_array_05.json" file 444 mtime 1 "15e28797a68120e90e101d0d5b56b2b935ce234d491819709b47fa0c67655465">,
      #splice.entry<"/build/source/test/data/legacy_test_array_06.expected" file 444 mtime 1 "d1232ec1eee85314c13212348cbc107ef9e67358c0e53e358720437e2cb00a92">,
      #splice.entry<"/build/source/test/data/legacy_test_array_06.json" file 444 mtime 1 "34614569b1c815a5580c49cf9bcabb8aa12b9483ec520d302d8a39185eb740eb">,
      #splice.entry<"/build/source/test/data/legacy_test_array_07.expected" file 444 mtime 1 "9b4d9d3f5e4905353bb9447c237608d061825b79658b827d82ed5f7173a8524d">,
      #splice.entry<"/build/source/test/data/legacy_test_array_07.json" file 444 mtime 1 "da196295d91bb5ab20dcf850735c3442a8bd08ced3f501e57e848e3f2d830ea8">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_01.expected" file 444 mtime 1 "3dc781528b800233837fac0f93b13e5d8959535e5a8cd5128e86e2d0e3995ed7">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_01.json" file 444 mtime 1 "c67c199595622dfbdc9e415c4a0ad6166eb49cbf74c6aac7bb3e958604d5ecb8">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_02.expected" file 444 mtime 1 "5c0bc69112c7193027799513f934f6d2c2907ce09576bbc7c87f4d611a239202">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_02.json" file 444 mtime 1 "ef4e4e90bc547008c323b3ccbd54c01ff1e0a10f4691c23f96f405e1a2f64039">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_03.expected" file 444 mtime 1 "7042bf2980acf79f7976fb955f9794927e155306ce452920ddb68b08aebaade6">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_03.json" file 444 mtime 1 "83e1254d394a1b14bf2812775e1aa589fff45fbcec0d4ab60e9ac3c32da4fb91">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_04.expected" file 444 mtime 1 "6e976c00b4d56ff0eec449c80e9d45426e64acd82c2f0da9072e33d74cb55f3b">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_04.json" file 444 mtime 1 "ef980df0c86fd16af296ad4a7f4198cc694105f3d018a15895ac86f5fceac11e">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_05.expected" file 444 mtime 1 "e76ff0e208a0410f89fd27e73df52c8a615174c0d14ac8f4d145bff66739f909">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_05.json" file 444 mtime 1 "d08e54f6aa60dc061aad4c6f0ba7b19961b7762c35ea199fa23632b753241db4">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_06.expected" file 444 mtime 1 "29669020f23f4ee10c830567d162cf4c7f88d18762a8789f5f573cb47e136c64">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_06.json" file 444 mtime 1 "e3949a4b725d800a0fe4abecf0429f8f90154826911cca138b05e47bdc683bd2">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_07.expected" file 444 mtime 1 "31fad8dcdd7f246e6988c32b4c62b99571e59f10a8a544c817d8906e5e0efcbc">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_07.json" file 444 mtime 1 "6a1b6c94b811b12562d66c6e2d26cf4f23f4e2ab0568c4366a0b3a217328dff5">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_08.expected" file 444 mtime 1 "a607df4de7b2d5f5ecce55dbc5e9ae7b7d944050beb4ed9e5886ee23b1e48c50">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_08.json" file 444 mtime 1 "3379d484baf5ce8037d032ae46f30af9e84ab1d47db010221317295945a1a0c5">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_09.expected" file 444 mtime 1 "1364b3db582818e17cf4fc5ab6da2f27a05123bf935be43282412d6d865c325c">,
      #splice.entry<"/build/source/test/data/legacy_test_basic_09.json" file 444 mtime 1 "13711768f7473d1dbee93d1b847627899a39263b03a87b41bfc7b0a4e0c4a386">,
      #splice.entry<"/build/source/test/data/legacy_test_comment_00.expected" file 444 mtime 1 "f8782f22360dd7abc4b1936b29f54ac88a8b92341e35f7aa6a927c53b1ed6928">,
      #splice.entry<"/build/source/test/data/legacy_test_comment_00.json" file 444 mtime 1 "20f9d769ce8699c2da5ffefb11e76779486450990383b099c7e1ba3f276cc67e">,
      #splice.entry<"/build/source/test/data/legacy_test_comment_01.expected" file 444 mtime 1 "d3c59292d0335afe7c551794aeecd3e4dca63a839bde7e40fa9759c14ed92d46">,
      #splice.entry<"/build/source/test/data/legacy_test_comment_01.json" file 444 mtime 1 "88a34b209436dba7183a769db3471f828b6ab5efb15b4364c59c2c39bb050444">,
      #splice.entry<"/build/source/test/data/legacy_test_comment_02.expected" file 444 mtime 1 "3793eae3b775e877b883a0ad9ac636332e3d19003ef520dd0f3f2f5275afad77">,
      #splice.entry<"/build/source/test/data/legacy_test_comment_02.json" file 444 mtime 1 "d3515ae647f4a263788f609585335f977ad9e83ae63997d38ef4fc3536d0bd61">,
      #splice.entry<"/build/source/test/data/legacy_test_complex_01.expected" file 444 mtime 1 "b23d99779e167fc193acb933016804dcdbb9d072ccee446dd6b1b283d397745f">,
      #splice.entry<"/build/source/test/data/legacy_test_complex_01.json" file 444 mtime 1 "f72fd6dfc8b0f441bf32759f0b7875803633c2a4e14dc580ae465ab1dd37f9f7">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_01.expected" file 444 mtime 1 "4744d5115a02d86016756ec92d3c59ce287fa05ab097bc4aaeee37264d881066">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_01.json" file 444 mtime 1 "c53c6bd2e0da0a4c79c98a6b6eb16fbd6b8470d01141a2337c3dced1e64b5a56">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_02.expected" file 444 mtime 1 "d7b1b8569b3c98ffe79e322ab2088ec6482f9a8f4f2c4df5a6b48939b073c8ce">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_02.json" file 444 mtime 1 "630cc3905a54938bf8d355a0afce2cb9cf06d9b07abe7828c89f47e181da01a6">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_03.expected" file 444 mtime 1 "4a8bc326ef8589201da7be8cc0fcb6d1e6f26df74b1fbcd49700c0f82c533963">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_03.json" file 444 mtime 1 "accd6692206fb310c1b5fda680196e29b41d6bc02c2f39eeca61a886fdf4f82b">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_04.expected" file 444 mtime 1 "4879bd2723faf1f3fbf651f871a0bc70484e04a8e4719a5e27a757f43661468e">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_04.json" file 444 mtime 1 "511736047f8e03c33917976cf63a442218a273b6e40df63b7f6772eadba46300">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_05.expected" file 444 mtime 1 "58e71e874b2648384e117692cc3a53c34bff05a852957a66a5226cbc1ae49e03">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_05.json" file 444 mtime 1 "5a0a2b76858bf8cc147613f783d84cd22c0047d142ba0d9ce13fcedf953b57ed">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_06_64bits.expected" file 444 mtime 1 "dacadeaaee2257f0aa890190b9740b9e7b4b30d91209e369ba4d14b97be9dd4e">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_06_64bits.json" file 444 mtime 1 "76f153aeaae282d8ef11dd18c8c0e90a525f20936c206cd144e8961591e45575">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_07_64bits.expected" file 444 mtime 1 "b79e26262565797854d099c59c1ffb8366ecc84e0c25a2a96daa6a215579901a">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_07_64bits.json" file 444 mtime 1 "821072bb7399748137189a9f5d032a6a7c8f3568cb3cd487064b8e9c0e4ee9c9">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_08_64bits.expected" file 444 mtime 1 "e09f147729c35ad1fe34ea862e5fbe703aaa562e5fa2290d6c10a068dfd20012">,
      #splice.entry<"/build/source/test/data/legacy_test_integer_08_64bits.json" file 444 mtime 1 "17dc9f57ff8954fd708b04653004b281f2feb1678fe6c90aa159a60cccb61e77">,
      #splice.entry<"/build/source/test/data/legacy_test_large_01.expected" file 444 mtime 1 "9b4d9d3f5e4905353bb9447c237608d061825b79658b827d82ed5f7173a8524d">,
      #splice.entry<"/build/source/test/data/legacy_test_large_01.json" file 444 mtime 1 "da196295d91bb5ab20dcf850735c3442a8bd08ced3f501e57e848e3f2d830ea8">,
      #splice.entry<"/build/source/test/data/legacy_test_object_01.expected" file 444 mtime 1 "44c7db60db7e621734900132c421d27de0824539cdc94435b66aa4eaf7a32f63">,
      #splice.entry<"/build/source/test/data/legacy_test_object_01.json" file 444 mtime 1 "ca3d163bab055381827226140568f3bef7eaac187cebd76878e0b63e9e442356">,
      #splice.entry<"/build/source/test/data/legacy_test_object_02.expected" file 444 mtime 1 "9e98db473e4d8b210281f8453e0a3131f5cfa1cca7b19f549ee0aac7de5af01f">,
      #splice.entry<"/build/source/test/data/legacy_test_object_02.json" file 444 mtime 1 "4d5d2e1fd2450cdb62865ab6ad4cda075f8e87e18903cf50476cab4e364ccb1f">,
      #splice.entry<"/build/source/test/data/legacy_test_object_03.expected" file 444 mtime 1 "cbf39bf70ee89de01d8dd4d58f2bc130843165ddce8d86c3aa43ba336890a408">,
      #splice.entry<"/build/source/test/data/legacy_test_object_03.json" file 444 mtime 1 "322cbc879ebbe3fb77f9448e78fef6f8c54fd79f096b5dcc8c22cb1683a71f30">,
      #splice.entry<"/build/source/test/data/legacy_test_object_04.expected" file 444 mtime 1 "2c91a528d6d022191cf6ac2f000885ec730f285d19ce47545f45e18ace8247ae">,
      #splice.entry<"/build/source/test/data/legacy_test_object_04.json" file 444 mtime 1 "6efafe060156ec04d91efd4883b4fe0ce05bca94afc0e7d0b33e53222c89f9a7">,
      #splice.entry<"/build/source/test/data/legacy_test_preserve_comment_01.expected" file 444 mtime 1 "9884760f3fbac5f461bd0da52d5a26e69d522cf476f2f30b4c4871fc0e50a27f">,
      #splice.entry<"/build/source/test/data/legacy_test_preserve_comment_01.json" file 444 mtime 1 "bb1826b49e0bf2a5da0e2a9725c804f35da0b32396b09390f684751e5e916079">,
      #splice.entry<"/build/source/test/data/legacy_test_real_01.expected" file 444 mtime 1 "c33823c6a96a0886ad71d087b7b3025eef6dd88616397ed763273f273c5f092d">,
      #splice.entry<"/build/source/test/data/legacy_test_real_01.json" file 444 mtime 1 "bf19a6c513b665d94f3fa521a36e7248d6c7e39f1b04989435962bfc6f2fef3b">,
      #splice.entry<"/build/source/test/data/legacy_test_real_02.expected" file 444 mtime 1 "e6a6aaea446f3f17abc401b173e11dfce9a8a5efebe02ae284835ba3c7a72e11">,
      #splice.entry<"/build/source/test/data/legacy_test_real_02.json" file 444 mtime 1 "a0f28c147988c26a7b0321e06f0c32b70cf6dfe5d9c7b0f4c02512b9f3370bac">,
      #splice.entry<"/build/source/test/data/legacy_test_real_03.expected" file 444 mtime 1 "e6a6aaea446f3f17abc401b173e11dfce9a8a5efebe02ae284835ba3c7a72e11">,
      #splice.entry<"/build/source/test/data/legacy_test_real_03.json" file 444 mtime 1 "a0f28c147988c26a7b0321e06f0c32b70cf6dfe5d9c7b0f4c02512b9f3370bac">,
      #splice.entry<"/build/source/test/data/legacy_test_real_04.expected" file 444 mtime 1 "f22f2a5ebfee7e6e544496d2fcd774a91de3f3330a1e269003fafe015e1af9eb">,
      #splice.entry<"/build/source/test/data/legacy_test_real_04.json" file 444 mtime 1 "338f311848ce83e287b918930c5bfecaa6c0048e28447cdce593b9cc0760fc01">,
      #splice.entry<"/build/source/test/data/legacy_test_real_05.expected" file 444 mtime 1 "42829ac5ecae4d0d470777bfb32a0da3701c698e95068e551aa10a1da635516d">,
      #splice.entry<"/build/source/test/data/legacy_test_real_05.json" file 444 mtime 1 "734df1383d838a9c24b5a435c018272ac4e855460aa44a892a94f3c7fc6986f3">,
      #splice.entry<"/build/source/test/data/legacy_test_real_06.expected" file 444 mtime 1 "f8d2bf0e46f4ab0c958c68e1bb95e75fb58c98e923ccdc2e30508978b1beca6d">,
      #splice.entry<"/build/source/test/data/legacy_test_real_06.json" file 444 mtime 1 "ae921d86c6deef54bc06469d3ff706817643cc6888dd95b37c716ba55ffa45e0">,
      #splice.entry<"/build/source/test/data/legacy_test_real_07.expected" file 444 mtime 1 "abdaa6db44c0bb870170d40406bda1ac9a514b2624af8e0f753613aad4406ded">,
      #splice.entry<"/build/source/test/data/legacy_test_real_07.json" file 444 mtime 1 "5b5a6b2a05743ee353da7088fde6c169eb181bb69e722ab2a6d277d4af493fc0">,
      #splice.entry<"/build/source/test/data/legacy_test_real_08.expected" file 444 mtime 1 "72c91e63378d089f84f2e21b1b26a18d2df19a280d5bc1924e07025979bc33de">,
      #splice.entry<"/build/source/test/data/legacy_test_real_08.json" file 444 mtime 1 "8394ecaba3468a9102f6803c2287778f797ccb8a4a15289fb56a118cc7ae0c03">,
      #splice.entry<"/build/source/test/data/legacy_test_real_09.expected" file 444 mtime 1 "f33535e448b9b5d158959a74a130aa451303c450742a5e091426045ef44d960c">,
      #splice.entry<"/build/source/test/data/legacy_test_real_09.json" file 444 mtime 1 "ad7894b09e8b267f055d37a66795dd9ac2d26d663baa7d6dbe2b8f6f598f77cc">,
      #splice.entry<"/build/source/test/data/legacy_test_real_10.expected" file 444 mtime 1 "ebbd15bb46373ce28ae02dda0b47eaf515d07b82f2f47e175f9dc69682976748">,
      #splice.entry<"/build/source/test/data/legacy_test_real_10.json" file 444 mtime 1 "2b8911292f66af818397099b4f802fc14810dd63d3ec69bd7c15bd6012fb81e4">,
      #splice.entry<"/build/source/test/data/legacy_test_real_11.expected" file 444 mtime 1 "bb5a3e1ad73d90f8c88a8a5e11901f8921ed8377e97f2671c782a87e89cf8f5e">,
      #splice.entry<"/build/source/test/data/legacy_test_real_11.json" file 444 mtime 1 "e876c96179bb9e7ebf0a44b196867e39d1aa50723f74fccd4c215a70a5d70169">,
      #splice.entry<"/build/source/test/data/legacy_test_real_12.expected" file 444 mtime 1 "a2a25aee2c3be39ea97b7060dcdedb5c67a86738b956bd74bc434b01bc7cda57">,
      #splice.entry<"/build/source/test/data/legacy_test_real_12.json" file 444 mtime 1 "dd50fc1100f45737991dcd7a9224dc751be141467762b5f62d8cd63c6f57dad0">,
      #splice.entry<"/build/source/test/data/legacy_test_real_13.expected" file 444 mtime 1 "7243c1dbbe79e7ca77730e58949b58a90d767e24875699ad312e4a1ea723da4b">,
      #splice.entry<"/build/source/test/data/legacy_test_real_13.json" file 444 mtime 1 "9fbe8b214da40b2e40c328f68e762c576b39715a0a516b2aa9871e4732358137">,
      #splice.entry<"/build/source/test/data/legacy_test_string_01.expected" file 444 mtime 1 "3ee77d9360068fb6e94d6386667eb2eb5651f42a262440aa1226278cbe733e83">,
      #splice.entry<"/build/source/test/data/legacy_test_string_01.json" file 444 mtime 1 "1f14615c12c9fb4a0dcc691daf2f6207c264147f838723a916d710a4b0fdecaf">,
      #splice.entry<"/build/source/test/data/legacy_test_string_02.expected" file 444 mtime 1 "e65f0ddcc4124dbfc99a29318b6de9425eda09b28b997394f39f5d6e83f47861">,
      #splice.entry<"/build/source/test/data/legacy_test_string_02.json" file 444 mtime 1 "3cae2cb030fac7e4c7d573ad1c1da8e467080edab25c6fa6bfffc6428acce859">,
      #splice.entry<"/build/source/test/data/legacy_test_string_03.expected" file 444 mtime 1 "3a6800d4a108fb8281732ff5e6c7e6d4d0b653f6a73f8340e8f448eb820bf3e7">,
      #splice.entry<"/build/source/test/data/legacy_test_string_03.json" file 444 mtime 1 "cc10ec5ead443b571fd21e0656911b177e5bf8b8780f66eb49178701bb6b97e1">,
      #splice.entry<"/build/source/test/data/legacy_test_string_04.expected" file 444 mtime 1 "44b2db505e6054cc288902d345bbd33150b06c005f5e371d636f1e383ec59bd8">,
      #splice.entry<"/build/source/test/data/legacy_test_string_04.json" file 444 mtime 1 "5172719d4d5763da959e68d0da6bcad22103e7f2f7ba6414d81e84bf0bf663ef">,
      #splice.entry<"/build/source/test/data/legacy_test_string_05.expected" file 444 mtime 1 "8e9e07d5e1606d7f1c827ac2883c7b9a9d6b95954532c4acbc2a78741cd03215">,
      #splice.entry<"/build/source/test/data/legacy_test_string_05.json" file 444 mtime 1 "5c4a29014638603583793d3ad484a368fd6e3e438fe80659cf1a6d75ae4f8c4f">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_01.expected" file 444 mtime 1 "cf12e1b6f19cdd9d2a91ee0dd308ed7b64e4ec5bfcc32754318b5421ffbe9af3">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_01.json" file 444 mtime 1 "0aeb95f62766e68469af9ce64f77530be1109235683599a36a2186b9584cbf53">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_02.expected" file 444 mtime 1 "367808997cd9800ed8f8c1ea674a5f39029fefc8b755b45ed9b3bed1d101a556">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_02.json" file 444 mtime 1 "9dff52fa9c14255abd41292e881a4655655731888c35ffe6720653e881cd1d09">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_03.expected" file 444 mtime 1 "dec185493a5059bc9fdf6df325b1b33cfb29995a0855f8380674ece80a8b2070">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_03.json" file 444 mtime 1 "8f25aa9a5ab78e1d2ecfe9363201fa103ee046c3010124dda178a2a6e41662b7">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_04.expected" file 444 mtime 1 "bbbc431c0408043d41127d6fa5a86deab73ca3da16fd6058beb953f4996a7fa8">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_04.json" file 444 mtime 1 "9d231df813d5c2c9ba7043e768d78043eb27262ebdaab8c00ec82ba3bed7124d">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_05.expected" file 444 mtime 1 "c402707058a3207c42cc64a3f756ba4b5ba29f7f8d93e709cc63fce65a2a7b95">,
      #splice.entry<"/build/source/test/data/legacy_test_string_unicode_05.json" file 444 mtime 1 "72b7af314741f7fa270965170ea838465f33666290da26b42064929f61953ffd">,
      #splice.entry<"/build/source/test/data/test_array_08.expected" file 444 mtime 1 "daa5e6d09e5bdb2cb999971f3973013229ed8248967e6ce1db9c417a2b4800c1">,
      #splice.entry<"/build/source/test/data/test_array_08.json" file 444 mtime 1 "b7573fde0a44ae5f41e83b2a28dbbaf6964f021285c83d8ea7d003a2cd241e91">,
      #splice.entry<"/build/source/test/data/test_object_05.expected" file 444 mtime 1 "9e98db473e4d8b210281f8453e0a3131f5cfa1cca7b19f549ee0aac7de5af01f">,
      #splice.entry<"/build/source/test/data/test_object_05.json" file 444 mtime 1 "5c31a0d435dab114aee9c9119b19d9407a9cccd723b6def6277a35b792b05a1d">,
      #splice.entry<"/build/source/test/generate_expected.py" file 444 mtime 1 "4c3669361e35bf8d4544e0631f73567f2e0185282a149dcaddaafc516db89c4a">,
      #splice.entry<"/build/source/test/jsonchecker" dir 555 mtime 1>,
      #splice.entry<"/build/source/test/jsonchecker/fail1.json" file 444 mtime 1 "438b1027386f69e8ff72306d162bba30745cfc3ad99522c06b77093f6b2868b1">,
      #splice.entry<"/build/source/test/jsonchecker/fail10.json" file 444 mtime 1 "ffea57a589f965c41b8778f1f0b69a1f4b7a14f072b868389cd6e2d249a33246">,
      #splice.entry<"/build/source/test/jsonchecker/fail11.json" file 444 mtime 1 "ba669b02c583cdc66458f9318ec64f2787e1edded69cee94361d9d04bf87b591">,
      #splice.entry<"/build/source/test/jsonchecker/fail12.json" file 444 mtime 1 "8033711342b67e573d96916fd820730a0a12ee291bd2e4ae324df3455c3f825f">,
      #splice.entry<"/build/source/test/jsonchecker/fail13.json" file 444 mtime 1 "a9235f6b3a47a700d45a8cba0c0b01b62ed4b2fd8a0f10cfe7964bde5e8cc1e0">,
      #splice.entry<"/build/source/test/jsonchecker/fail14.json" file 444 mtime 1 "4c353586a59fd208964f41f12547ef9e403520b87e9d9fe73c0bd6951de36933">,
      #splice.entry<"/build/source/test/jsonchecker/fail15.json" file 444 mtime 1 "656c4510d2ae41d28f3bb5498a7df7e87652bbbb35a7c7ef7c28d4a3d1d59eae">,
      #splice.entry<"/build/source/test/jsonchecker/fail16.json" file 444 mtime 1 "4514053448b28818d0d23041242b0e1705ea0bbf9f2ee84694d4e0100bd90cc4">,
      #splice.entry<"/build/source/test/jsonchecker/fail17.json" file 444 mtime 1 "a806d560ae63698f5082c7e51189395be458d1709db63244d26846f5a1e1a91d">,
      #splice.entry<"/build/source/test/jsonchecker/fail18.json" file 444 mtime 1 "e663fb0874bda154424bc35b9aff5f61d73d1a8cb926ccf41311827f30456997">,
      #splice.entry<"/build/source/test/jsonchecker/fail19.json" file 444 mtime 1 "f262f8944e9f4346e80ccab07d2cc74f95928193210bc7a95c634f665f105b03">,
      #splice.entry<"/build/source/test/jsonchecker/fail2.json" file 444 mtime 1 "9dbe48572aa40ff5e44b7b0e691e1b487d37cd4cfb34cf5bb506a5b6e965ec3b">,
      #splice.entry<"/build/source/test/jsonchecker/fail20.json" file 444 mtime 1 "beff780d4797749a6180792d96de68b52eafbe3558578e2486b51c0fc384d3f0">,
      #splice.entry<"/build/source/test/jsonchecker/fail21.json" file 444 mtime 1 "d786f4c34fc330006cfd6ef9a855d4233ce7ea4ffdce19a1aeb6498ae0341edc">,
      #splice.entry<"/build/source/test/jsonchecker/fail22.json" file 444 mtime 1 "dd22ed47b00f7977a8fd058adbf448e7af9b4cf7299c8a11f21298ded07b9e03">,
      #splice.entry<"/build/source/test/jsonchecker/fail23.json" file 444 mtime 1 "5b746985dd2a3406e0d457dc38583b5ed26c2691950a10e1e50049a93c924a78">,
      #splice.entry<"/build/source/test/jsonchecker/fail24.json" file 444 mtime 1 "0389d0d5920ee2996811974bdcbfe05c9ca0ed79af909704b8485bc86f6eaf25">,
      #splice.entry<"/build/source/test/jsonchecker/fail25.json" file 444 mtime 1 "8305373703e9a50e767c42929d22bb69b377cf62a5aeba4dc60bfbf28939411d">,
      #splice.entry<"/build/source/test/jsonchecker/fail26.json" file 444 mtime 1 "032ff03c5b7bf611b5015000312a290b6fa7878ccb508c5ed5cc73cb2b649179">,
      #splice.entry<"/build/source/test/jsonchecker/fail27.json" file 444 mtime 1 "4a6ce093f89d76306dc76ccb5f6e468fb95c189eaa16d6b6c80954c21b3be635">,
      #splice.entry<"/build/source/test/jsonchecker/fail28.json" file 444 mtime 1 "a4a310e88adb621126f6e044f7919728d6fdf1df6a7d5a445e7215539f2ac264">,
      #splice.entry<"/build/source/test/jsonchecker/fail29.json" file 444 mtime 1 "cd279aa777afca083b346dbc2b62a1847c24f1556b619b7564842457f8949c93">,
      #splice.entry<"/build/source/test/jsonchecker/fail3.json" file 444 mtime 1 "6903daf61af5b38e0bc66d8da4f13631e2c2d03598169fe2d7c45d2504d310b9">,
      #splice.entry<"/build/source/test/jsonchecker/fail30.json" file 444 mtime 1 "3f54bdbbd4e3ad547fa457b5810df7c96f2d2c3bc6985e11202ffd1d42116889">,
      #splice.entry<"/build/source/test/jsonchecker/fail31.json" file 444 mtime 1 "25981c42fdd25646ab17d57bfaa65e4b2d7b791fdf13840e75c5a9e8f66dec70">,
      #splice.entry<"/build/source/test/jsonchecker/fail32.json" file 444 mtime 1 "15388c40b8b3920b49a317f303140234fecaa37d6adc8056f54b8d7d79cfba87">,
      #splice.entry<"/build/source/test/jsonchecker/fail33.json" file 444 mtime 1 "df72f007b029ebe06bffcd6083deff92aae557aa172eaf7e2504a3222dc73b60">,
      #splice.entry<"/build/source/test/jsonchecker/fail4.json" file 444 mtime 1 "15836776fdc7d0473f68c35c1295e473d57c215af1232b439b28120f674be45f">,
      #splice.entry<"/build/source/test/jsonchecker/fail5.json" file 444 mtime 1 "40b23c469b617b09914010ee5c5aa0faa706061f77b4a96b374742c18bb17d42">,
      #splice.entry<"/build/source/test/jsonchecker/fail6.json" file 444 mtime 1 "9cac15bfc3db16d965b9074329f4b7b26443fd4ccbf21cc545cc718114cbda20">,
      #splice.entry<"/build/source/test/jsonchecker/fail7.json" file 444 mtime 1 "d9b01bb868ba4a6156085744bddf7acf119125aaf40e19e404b284e99b1973e0">,
      #splice.entry<"/build/source/test/jsonchecker/fail8.json" file 444 mtime 1 "fbb0928ebab6b0f1aa7b5a7f10453bf89cc7ed56185bd783836ceedeec248ea8">,
      #splice.entry<"/build/source/test/jsonchecker/fail9.json" file 444 mtime 1 "a3a4796b5ddb6c80e894113c690a75e5290ef109601dee2e277f652bc6d6a163">,
      #splice.entry<"/build/source/test/jsonchecker/pass1.json" file 444 mtime 1 "a46f670e9676dd3d5a22ccbd44be74391cd57867f0a20ee9c5bba2c1e9742239">,
      #splice.entry<"/build/source/test/jsonchecker/pass2.json" file 444 mtime 1 "7f9deff2652df58a02ca676ff9494de3d93f18db64c7f20f9596dffb8c92f187">,
      #splice.entry<"/build/source/test/jsonchecker/pass3.json" file 444 mtime 1 "45aaef317f170e5490aa4a18cc301f6d5e03ee617980dec1b15403abf6c537f4">,
      #splice.entry<"/build/source/test/jsonchecker/readme.txt" file 444 mtime 1 "c328f63bf745f377cc79490a3eafaab4e0482a97e4a8cd85b5f381c30304f253">,
      #splice.entry<"/build/source/test/pyjsontestrunner.py" file 444 mtime 1 "76f2665704d19d5aa6e174022dded0a0bd9ad19f6b77faeff67516f4e3a69007">,
      #splice.entry<"/build/source/test/runjsontests.py" file 444 mtime 1 "2be4a9aedecdfbdf421d58ccb373395004432f0fc9ffb3ca9eb4543864011cdb">,
      #splice.entry<"/build/source/test/rununittests.py" file 444 mtime 1 "ab719a1a40aed60ad6e4a7f99eafc839f3e8136711fd65b704857b8602f3a8d0">,
      #splice.entry<"/build/source/version.in" file 444 mtime 1 "0e0c37e12f0987b0f538e528597881fbcf2b35a0000b0df4c5c7a878bae92733">
  ]
  %chmod_2021:9 = splice.literal "chmod" at 2021 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>,
      #splice.entry<"/build/source/cmake" dir 755 mtime 1>,
      #splice.entry<"/build/source/include" dir 755 mtime 1>,
      #splice.entry<"/build/source/include/json" dir 755 mtime 1>,
      #splice.entry<"/build/source/pkg-config" dir 755 mtime 1>,
      #splice.entry<"/build/source/src" dir 755 mtime 1>,
      #splice.entry<"/build/source/src/jsontestrunner" dir 755 mtime 1>,
      #splice.entry<"/build/source/src/lib_json" dir 755 mtime 1>,
      #splice.entry<"/build/source/src/test_lib_json" dir 755 mtime 1>
  ]
  %chmod_2021_0 = splice.copy "chmod" at 2021(%cp_1473#18) -> <"/build/source/CMakeLists.txt" file 644 mtime 1 "50e2180e0fb9d628050766d19213feaaf86f27d6abb4a27fefa6797b7cae13a5">
  %chmod_2021_1 = splice.copy "chmod" at 2021(%cp_1473#28) -> <"/build/source/cmake/JoinPaths.cmake" file 644 mtime 1 "861e8bba5577de156ccc23f8b128717648a774e1cefb88897a09105c11d38cc0">
  %chmod_2021_2 = splice.copy "chmod" at 2021(%cp_1473#67) -> <"/build/source/include/CMakeLists.txt" file 644 mtime 1 "873311b839db91f10514db29e129b28b42d86a0deaba802cf97e4d0f219bc932">
  %chmod_2021_3 = splice.copy "chmod" at 2021(%cp_1473#68) -> <"/build/source/include/PreventInBuildInstalls.cmake" file 644 mtime 1 "e9a62c62a516bd07cb765edec6c35cedba14b03cb7c5e3d221ac10cfa1d2bdf0">
  %chmod_2021_4 = splice.copy "chmod" at 2021(%cp_1473#69) -> <"/build/source/include/PreventInSourceBuilds.cmake" file 644 mtime 1 "e88a6582ecd3cd40db08ce2f88506338221ba95600c0d1e4b0da4fa3d81976c1">
  %chmod_2021_5 = splice.copy "chmod" at 2021(%cp_1473#71) -> <"/build/source/include/json/allocator.h" file 644 mtime 1 "500a24a92dfbf8e8c8699e4eb654511e62619bd8d7f29bca4c62c24ca66c4101">
  %chmod_2021_6 = splice.copy "chmod" at 2021(%cp_1473#72) -> <"/build/source/include/json/assertions.h" file 644 mtime 1 "ea30b8fb30ef70a52a6435f6e6efbc37de03555fa192b33832e65cbd159b68bb">
  %chmod_2021_7 = splice.copy "chmod" at 2021(%cp_1473#73) -> <"/build/source/include/json/config.h" file 644 mtime 1 "7479aba8631e81d9a450ff3dd1ad8a18ef913656caac6555ce6c5fd507d51622">
  %chmod_2021_8 = splice.copy "chmod" at 2021(%cp_1473#74) -> <"/build/source/include/json/forwards.h" file 644 mtime 1 "92a8bfce5303164fb3620e2dd053333c22ab9a775e4da3817fb3e89cf547a299">
  %chmod_2021_9 = splice.copy "chmod" at 2021(%cp_1473#75) -> <"/build/source/include/json/json.h" file 644 mtime 1 "05ccb35afa55a068f8cc2a195db46d89a7f6a458d1943ae009465834c6404a67">
  %chmod_2021_10 = splice.copy "chmod" at 2021(%cp_1473#76) -> <"/build/source/include/json/json_features.h" file 644 mtime 1 "9a3a209af311356da182e0b768c7c1f5993863df9d2d0f9dfa8f96d492282494">
  %chmod_2021_11 = splice.copy "chmod" at 2021(%cp_1473#77) -> <"/build/source/include/json/reader.h" file 644 mtime 1 "c29e5a46b6204c6e166c31880be2483067cad5a851da3b07b06b8f46c1f583d0">
  %chmod_2021_12 = splice.copy "chmod" at 2021(%cp_1473#78) -> <"/build/source/include/json/value.h" file 644 mtime 1 "735bc075cbc8ac106e1fcb2e3aada2ee4da09feebf9d005c9b1486690293abe7">
  %chmod_2021_13 = splice.copy "chmod" at 2021(%cp_1473#79) -> <"/build/source/include/json/version.h" file 644 mtime 1 "c0a115d83a96ebfac02f4df50509b96619d2af4b639920cfe310a9ca99e040d0">
  %chmod_2021_14 = splice.copy "chmod" at 2021(%cp_1473#80) -> <"/build/source/include/json/writer.h" file 644 mtime 1 "1828e708ae2f28207b0b0c618aa14038c3e223af9d25de2efab0fcf4fbd25591">
  %chmod_2021_15 = splice.copy "chmod" at 2021(%cp_1473#81) -> <"/build/source/jsoncpp-namespaced-targets.cmake" file 644 mtime 1 "3ca99e17de275ce3c52e0d1591ecdfc20ec521f5a20e96776ee39a2f679fe739">
  %chmod_2021_16 = splice.copy "chmod" at 2021(%cp_1473#82) -> <"/build/source/jsoncppConfig.cmake.in" file 644 mtime 1 "6687cae93c0be2a17415e59cbaf9bf20a7d4050b4d68467985c7e60f5f156bc2">
  %chmod_2021_17 = splice.copy "chmod" at 2021(%cp_1473#87) -> <"/build/source/pkg-config/jsoncpp.pc.in" file 644 mtime 1 "f2e4b18953c7b9cb33d0a5c043d329aad8151fff12283671be05561202239ac5">
  %chmod_2021_18 = splice.copy "chmod" at 2021(%cp_1473#90) -> <"/build/source/src/CMakeLists.txt" file 644 mtime 1 "086c09ab7a410f40db8964d0e29ed2120ad110f78958b079468df70b39bf7e3b">
  %chmod_2021_19 = splice.copy "chmod" at 2021(%cp_1473#93) -> <"/build/source/src/jsontestrunner/CMakeLists.txt" file 644 mtime 1 "5cea9dae3eddc1dc653933578ad552fdd7fe5740640ec49dfba4d42779575d57">
  %chmod_2021_20 = splice.copy "chmod" at 2021(%cp_1473#94) -> <"/build/source/src/jsontestrunner/main.cpp" file 644 mtime 1 "25bd9c905309938c6b645271b42555b77f36f562158fea3d13e3bccb7768b4b0">
  %chmod_2021_21 = splice.copy "chmod" at 2021(%cp_1473#96) -> <"/build/source/src/lib_json/CMakeLists.txt" file 644 mtime 1 "c6c486b6c8851a8a7c2a6a6c95e12b53edac72055635cdc1d38ae25c39dfad5a">
  %chmod_2021_22 = splice.copy "chmod" at 2021(%cp_1473#97) -> <"/build/source/src/lib_json/json_reader.cpp" file 644 mtime 1 "bbf30e4ab2976853d75f54b2304d6f2e526978dee2188dffbcbc501e58166f28">
  %chmod_2021_23 = splice.copy "chmod" at 2021(%cp_1473#98) -> <"/build/source/src/lib_json/json_tool.h" file 644 mtime 1 "dd86b80bad3a960b34589b97047c63be63a34db1fcdd51a93dbc6aef150cfaf8">
  %chmod_2021_24 = splice.copy "chmod" at 2021(%cp_1473#99) -> <"/build/source/src/lib_json/json_value.cpp" file 644 mtime 1 "08dd3f7ddaa6f7c997b53e25a50be9354fb5263796aa7f9d2c4ff8562f01f0ba">
  %chmod_2021_25 = splice.copy "chmod" at 2021(%cp_1473#100) -> <"/build/source/src/lib_json/json_valueiterator.inl" file 644 mtime 1 "5b269ac0a6eb2dcd6f902fb4f51eb080a397d1e97e76b921d0932d000f76d7fa">
  %chmod_2021_26 = splice.copy "chmod" at 2021(%cp_1473#101) -> <"/build/source/src/lib_json/json_writer.cpp" file 644 mtime 1 "ffb0cac91aea2ce089d676626fafacad396cef9df2518b47938b0e49e105de9b">
  %chmod_2021_27 = splice.copy "chmod" at 2021(%cp_1473#104) -> <"/build/source/src/test_lib_json/CMakeLists.txt" file 644 mtime 1 "57c3bf53b09ab0f9c6a4e14660d524110a7369400806bee6ad4ddcf129fd2794">
  %chmod_2021_28 = splice.copy "chmod" at 2021(%cp_1473#105) -> <"/build/source/src/test_lib_json/fuzz.cpp" file 644 mtime 1 "56b7839a8805fba7f9e5fa4558ba46f8d387efade70335a3dd982b6d000312f9">
  %chmod_2021_29 = splice.copy "chmod" at 2021(%cp_1473#107) -> <"/build/source/src/test_lib_json/fuzz.h" file 644 mtime 1 "61af29b33af2ebd56bd3e38b7d4296c4c6b9c777bf55cf441c677cb805af71dd">
  %chmod_2021_30 = splice.copy "chmod" at 2021(%cp_1473#108) -> <"/build/source/src/test_lib_json/jsontest.cpp" file 644 mtime 1 "5dbf5b122dcef5a9f993c0a32726aa18a4c80a397345e89718ca967e9241dce0">
  %chmod_2021_31 = splice.copy "chmod" at 2021(%cp_1473#109) -> <"/build/source/src/test_lib_json/jsontest.h" file 644 mtime 1 "dec28e7f0b46bf97af9386febb33e6dad1608436059ae8f0ff891289f7af66dc">
  %chmod_2021_32 = splice.copy "chmod" at 2021(%cp_1473#110) -> <"/build/source/src/test_lib_json/main.cpp" file 644 mtime 1 "462b28b7066a23eb04a2e52c8feacc2572b2e471c9d25ac21c2410564e58f083">
  %chmod_2021_33 = splice.copy "chmod" at 2021(%cp_1473#285) -> <"/build/source/version.in" file 644 mtime 1 "0e0c37e12f0987b0f538e528597881fbcf2b35a0000b0df4c5c7a878bae92733">
  %mkdir_2328 = splice.literal "mkdir" at 2328 folded -> [
      #splice.entry<"/build/source/build" dir 755 mtime 1794960000>
  ]
  %cmake_2700:12 = splice.literal "cmake" at 2700 folded -> [
      #splice.entry<"/build/source/build/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/Export" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/Export/174b7859122d28b51b0f7e0efb4def31" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/include" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/lib" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/pkg-config" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/jsontestrunner" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/lib_json" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/test_lib_json" dir 755 mtime 1794960000>
  ]
  %cmake_2700_34:116 = splice.exec "cmake" at 2700(%sandbox_721#0, %chmod_2021#0, %chmod_2021_0, %mkdir_2328, %chmod_2021#1, %chmod_2021_1, %chmod_2021#2, %chmod_2021_2, %chmod_2021_3, %chmod_2021_4, %chmod_2021#3, %chmod_2021_5, %chmod_2021_6, %chmod_2021_7, %chmod_2021_8, %chmod_2021_9, %chmod_2021_10, %chmod_2021_11, %chmod_2021_12, %chmod_2021_13, %chmod_2021_14, %chmod_2021_15, %chmod_2021_16, %chmod_2021#4, %chmod_2021_17, %chmod_2021#5, %chmod_2021_18, %chmod_2021#6, %chmod_2021_19, %chmod_2021_20, %chmod_2021#7, %chmod_2021_21, %chmod_2021_22, %chmod_2021_23, %chmod_2021_24, %chmod_2021_25, %chmod_2021_26, %chmod_2021#8, %chmod_2021_27, %chmod_2021_28, %chmod_2021_29, %chmod_2021_30, %chmod_2021_31, %chmod_2021_32, %chmod_2021_33) -> [
      #splice.entry<"/build/source/build/CMakeCache.txt" file 644 mtime 1794960000 "72d8d34448b4e38ca16836f61beef915d655979b45fa2bc8d859bfb1cb58a061">,
      #splice.entry<"/build/source/build/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CMakeCXXCompiler.cmake" file 444 mtime 1794960000 "8bc400f646af082277106f438c6347d6864ebd328eb95d97e6177df4c2880bfe">,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CMakeDetermineCompilerABI_CXX.bin" file 755 mtime 1794960000 "d6556734605791254b5ff05e818a2289a47c605b3fb21702026c4652ba09cf7e">,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CMakeSystem.cmake" file 444 mtime 1794960000 "eae5d03bbac50975155042e73ebac342f07873e5a57de244df0dba37339b41c2">,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CompilerIdCXX" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CompilerIdCXX/CMakeCXXCompilerId.cpp" file 644 mtime 1794960000 "5b0cbdb2a0d0a5b91a89026321eb0202fdecb22328eb5c668566ce5cb17e3cd2">,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CompilerIdCXX/a.out" file 755 mtime 1794960000 "5e1978d189d2d00ae20433b5af021f62eecb824e1bb94d25cea0ed978984eb6f">,
      #splice.entry<"/build/source/build/CMakeFiles/4.4.3/CompilerIdCXX/tmp" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/CMakeConfigureLog.yaml" file 644 mtime 1794960000 "ff1bc75ff7f6c321b20425558980a6864a9675deb3a5933a0a12cdde57e370af">,
      #splice.entry<"/build/source/build/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1794960000 "1395125c1e0014138d9ab50bd638cfb6c3a6cbd912beb26264aaafd6e9f45e83">,
      #splice.entry<"/build/source/build/CMakeFiles/CMakeRuleHashes.txt" file 644 mtime 1794960000 "94b87a6046a8c87ccc9ba446d9e71249f14384ef0ff6e2a644db302e9e385160">,
      #splice.entry<"/build/source/build/CMakeFiles/CMakeScratch" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/CheckTypeSize" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/CheckTypeSize/LCONV_SIZE.bin" file 755 mtime 1794960000 "c2b23f8e2fd2393fd9ca52d980631e60d8d1f704793789dfb255619f28f97418">,
      #splice.entry<"/build/source/build/CMakeFiles/Export" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/Export/174b7859122d28b51b0f7e0efb4def31" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/Export/174b7859122d28b51b0f7e0efb4def31/jsoncpp-targets-release.cmake" file 644 mtime 1794960000 "ba2a88caf90faa8ba006212c12f9cef031697fb7d8fbe50fc1fb48194917d68f">,
      #splice.entry<"/build/source/build/CMakeFiles/Export/174b7859122d28b51b0f7e0efb4def31/jsoncpp-targets.cmake" file 644 mtime 1794960000 "f7cd25a3a9d3bd354734d10b815cadcee577e2e0270930d1bd583ccf9bf06ba9">,
      #splice.entry<"/build/source/build/CMakeFiles/InstallScripts.json" file 644 mtime 1794960000 "f57a4b4333548e1b5a4f22950b306c1fb09f0a4435ce929176a752b04d41b74c">,
      #splice.entry<"/build/source/build/CMakeFiles/Makefile.cmake" file 644 mtime 1794960000 "2a990ba31a262bb02eeee2dd361a758e013fd6f6705c67deb3d21c262a892fb4">,
      #splice.entry<"/build/source/build/CMakeFiles/Makefile2" file 644 mtime 1794960000 "ecb2e03d3183cdde3943b2ba78c07de99d00c6d5ab42f78b64d79dac59a14b39">,
      #splice.entry<"/build/source/build/CMakeFiles/TargetDirectories.txt" file 644 mtime 1794960000 "49fc11381c21a2a45f3da2e584f43eb21e24eda0d77f7330f67a5ad7018ecf00">,
      #splice.entry<"/build/source/build/CMakeFiles/cmake.check_cache" file 644 mtime 1794960000 "a26189e394421da57f45706a07713c5720acd200a41711b0c0c590c3c63371c4">,
      #splice.entry<"/build/source/build/CMakeFiles/pkgRedirects" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/CMakeFiles/progress.marks" file 644 mtime 1794960000 "917df3320d778ddbaa5c5c7742bc4046bf803c36ed2b050f30844ed206783469">,
      #splice.entry<"/build/source/build/CTestTestfile.cmake" file 644 mtime 1794960000 "0ba5460632397b1decbe8f4d18955a1b49dc8f157df5d830ef1a7f432c15d072">,
      #splice.entry<"/build/source/build/Makefile" file 644 mtime 1794960000 "42eb422e7777d5d0287b6acb210be2836dd863af2fa72ffca8ce4c841616a6ef">,
      #splice.entry<"/build/source/build/bin" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/cmake_install.cmake" file 644 mtime 1794960000 "90f2b0be2128ca1a570d0f040ff53a98c6c9c37d9b25c163a190366abde90c34">,
      #splice.entry<"/build/source/build/include" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/include/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/include/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1794960000 "1395125c1e0014138d9ab50bd638cfb6c3a6cbd912beb26264aaafd6e9f45e83">,
      #splice.entry<"/build/source/build/include/CMakeFiles/progress.marks" file 644 mtime 1794960000 "9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa">,
      #splice.entry<"/build/source/build/include/CTestTestfile.cmake" file 644 mtime 1794960000 "b708b4e85aec366ce4f80d2c829fc306c1c59449fc1127617b3ee8d5fdc6ea9f">,
      #splice.entry<"/build/source/build/include/Makefile" file 644 mtime 1794960000 "08677f92d7a062b34e14bdf386b398a5f7ec35ce0e2cfddcc1846d7b47efdc80">,
      #splice.entry<"/build/source/build/include/cmake_install.cmake" file 644 mtime 1794960000 "0b60637dec67b3b0173dd60d896dad8f8fceb692eae73f45339e81cd1e9101d0">,
      #splice.entry<"/build/source/build/jsoncppConfig.cmake" file 644 mtime 1794960000 "ec1f4a21226e612e697b0ef58a94fe48ed8cc60b2f06d71fa1a22535ea729b7f">,
      #splice.entry<"/build/source/build/jsoncppConfigVersion.cmake" file 444 mtime 1794960000 "8b4f3b5b889535fdb0a46aed783b13fd7dbe2e5e11016b9aa86cbdbb5a62d9a0">,
      #splice.entry<"/build/source/build/lib" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/pkg-config" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/pkg-config/jsoncpp.pc" file 644 mtime 1794960000 "e1503948bd06a498fe11adab67c6599015b50158371f0d5edf4c891849f68a54">,
      #splice.entry<"/build/source/build/src" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1794960000 "1395125c1e0014138d9ab50bd638cfb6c3a6cbd912beb26264aaafd6e9f45e83">,
      #splice.entry<"/build/source/build/src/CMakeFiles/progress.marks" file 644 mtime 1794960000 "917df3320d778ddbaa5c5c7742bc4046bf803c36ed2b050f30844ed206783469">,
      #splice.entry<"/build/source/build/src/CTestTestfile.cmake" file 644 mtime 1794960000 "680616a8bf4a8cdadbc268a5c3ab7e7d88e8afccd4cac0e013e275463371ee13">,
      #splice.entry<"/build/source/build/src/Makefile" file 644 mtime 1794960000 "8aa3ae91b923150ad2d88397f3c3658b0be021c8f3ea8e4ba5fba1891979c134">,
      #splice.entry<"/build/source/build/src/cmake_install.cmake" file 644 mtime 1794960000 "bed0bad38007c89b78d9e2f3453450e54f7b5d7e44b8bd48333f22b030c73807">,
      #splice.entry<"/build/source/build/src/jsontestrunner" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1794960000 "1395125c1e0014138d9ab50bd638cfb6c3a6cbd912beb26264aaafd6e9f45e83">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir/DependInfo.cmake" file 644 mtime 1794960000 "b2ca23380b5c9dd7f07b120e32fb11a157a4def74d801994559b1c8c88f92f55">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir/build.make" file 644 mtime 1794960000 "ec43d25eec4dcb40232cd8e3a9ff782209e470e62649d9bf16538d2f01e3338a">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir/cmake_clean.cmake" file 644 mtime 1794960000 "3515388b6921601c750e5e6bc9065192f54931280d8db2d095c298aa20e6f303">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir/compiler_depend.make" file 644 mtime 1794960000 "3073db88094497a226dffb037f14c524a7eab6daafb9c54e7ea5b7f04483b41f">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir/compiler_depend.ts" file 644 mtime 1794960000 "b8ff52221f9d1bbfd4034bbf91980bcd07334f8fb3558471c202d4fef645fb2e">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_check.dir/progress.make" file 644 mtime 1794960000 "01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir/DependInfo.cmake" file 644 mtime 1794960000 "b2ca23380b5c9dd7f07b120e32fb11a157a4def74d801994559b1c8c88f92f55">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir/build.make" file 644 mtime 1794960000 "73a8d625481b2539dca99c1e148143e32e9f5f9c28adf128bba6c3e8a38492a4">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir/cmake_clean.cmake" file 644 mtime 1794960000 "d4ee47500c1aa57f7fef8897b7d434b2452b8956bb689566fa5e2adfdf8b2f0d">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir/compiler_depend.make" file 644 mtime 1794960000 "07e433759dd6cecfed06f346d050b984446860e41bf3fae41298eeda8d1fd678">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir/compiler_depend.ts" file 644 mtime 1794960000 "0bef3a9f4a1fbebd65d52da17fba076524549583be79fd5993ccd33b0891d1aa">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsoncpp_readerwriter_tests.dir/progress.make" file 644 mtime 1794960000 "01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/DependInfo.cmake" file 644 mtime 1794960000 "bf7eba397539e6582ce82bc0c4434550802bd1c3b06468a53c1adfb11ffc8fc0">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/build.make" file 644 mtime 1794960000 "dd563ba78e6ea78f38c5bc994b35397cbf3f5d34ba1f054c5d58a58ed562707e">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/cmake_clean.cmake" file 644 mtime 1794960000 "ad8761b80c63b4dffc8a1cd7468fe6fa6504d81054e610be1c10745c3cc8b993">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/compiler_depend.make" file 644 mtime 1794960000 "50c4d3f30e0e109985d82710cfbaf375358507466b8634219dd48e1865660f14">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/compiler_depend.ts" file 644 mtime 1794960000 "c10d6f8b75fb8de0519317d8353c25d410670f9cc93ec8e57f90b78bbfeb4052">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/depend.make" file 644 mtime 1794960000 "ee1b39f1e5df0628374a04e64d6afcc7bb59d532a0697f4b400f2537138826d0">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/flags.make" file 644 mtime 1794960000 "accf5324e73f9532476579be2055092f796234429727e72d7c7de83a2806d79a">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/link.txt" file 644 mtime 1794960000 "cd93b945cb66d4721a8fd411d08613d5c4c374f51d1625f8383da2aa026c3595">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/jsontestrunner_exe.dir/progress.make" file 644 mtime 1794960000 "ed3daec5b65a9ed4ecd23ef55e215b9ba204c1e5e0226807abaec0693c6df14c">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CMakeFiles/progress.marks" file 644 mtime 1794960000 "06e9d52c1720fca412803e3b07c4b228ff113e303f4c7ab94665319d832bbfb7">,
      #splice.entry<"/build/source/build/src/jsontestrunner/CTestTestfile.cmake" file 644 mtime 1794960000 "1f34d92e0522e622996dd7ba4cc1fb2aa4d889bbbd6acf5b0913588643bd01d7">,
      #splice.entry<"/build/source/build/src/jsontestrunner/Makefile" file 644 mtime 1794960000 "5e147664f88a6e8b891b9c501a62fac98a0202caa9a479b961560680deb08777">,
      #splice.entry<"/build/source/build/src/jsontestrunner/cmake_install.cmake" file 644 mtime 1794960000 "6624aa7e4da12cf92ac4339faab6de3434f51b7eb55e857faddbb74ba310dfd5">,
      #splice.entry<"/build/source/build/src/lib_json" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1794960000 "1395125c1e0014138d9ab50bd638cfb6c3a6cbd912beb26264aaafd6e9f45e83">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/DependInfo.cmake" file 644 mtime 1794960000 "58cd63ff5215bd64646adc6cb43c7b728c7293a72f1a353ee33f06cee101ade5">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/build.make" file 644 mtime 1794960000 "adcb627c548e39663b21ba126398cbe58fe3848994ed486e09400e7fb218cef8">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/cmake_clean.cmake" file 644 mtime 1794960000 "67443a388e5f42f988d3cd6a6e315e632566bc0febed466d913594900eb3be8c">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/compiler_depend.make" file 644 mtime 1794960000 "a72e77969c0aa72c12fe6e727dc43670e1904bc929be84f69beb2b5ef26c7177">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/compiler_depend.ts" file 644 mtime 1794960000 "fbbf9a578424100dc526b6f0d73635c6d1ee81721406d4aa4043b1b1424cebaf">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/depend.make" file 644 mtime 1794960000 "f5469660ce5f64ac95652d608fe7c9b41d0678cf1656ef061e4d4807b63a03df">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/flags.make" file 644 mtime 1794960000 "4684e3f2a22ab067970be1ce5d3491fa3d63f6fde33f8f4e8f10a397f5fb219b">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/link.txt" file 644 mtime 1794960000 "985c27e5c292507e2fab274421f7779c2ec907875002dd66f1d69a74ea51eae8">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/progress.make" file 644 mtime 1794960000 "0256e132658b08ff6eec531330c116fec44bcf976ba3090f8047a3eb2fa33426">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/progress.marks" file 644 mtime 1794960000 "7de1555df0c2700329e815b93b32c571c3ea54dc967b89e81ab73b9972b72d1d">,
      #splice.entry<"/build/source/build/src/lib_json/CTestTestfile.cmake" file 644 mtime 1794960000 "2cc104a866966e993312a3b17fd54a400353dac4a4a3e9657445447bd4c5c04e">,
      #splice.entry<"/build/source/build/src/lib_json/Makefile" file 644 mtime 1794960000 "36529ff39ed9d12fe369de7766c668f48939b3411da65355d5a64b6cb2207449">,
      #splice.entry<"/build/source/build/src/lib_json/cmake_install.cmake" file 644 mtime 1794960000 "145d9f9997ec0129165696037a2033a5851c88e888218bb566b1a776de5e3aed">,
      #splice.entry<"/build/source/build/src/test_lib_json" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1794960000 "1395125c1e0014138d9ab50bd638cfb6c3a6cbd912beb26264aaafd6e9f45e83">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/DependInfo.cmake" file 644 mtime 1794960000 "55358a38d0c427fae12553d0abf07bde0be65805ae9fafce31d946049af95c9e">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/build.make" file 644 mtime 1794960000 "e1e6604f9c50b0414a2355c33ed64335d1acd38ea35c6b9c9858dcbc857aca7a">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/cmake_clean.cmake" file 644 mtime 1794960000 "c145385f0e6192812290e12e59c35fca425645a6f3aa5ff146e46c0e160788e4">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/compiler_depend.make" file 644 mtime 1794960000 "f2404071942463feb493678e4ca137f8c6a2ea0b9a30e16a0bf161bd8cf9e1ff">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/compiler_depend.ts" file 644 mtime 1794960000 "05b1b830128ace99e4e17daca00bf82cb9194c2836fed79d1a431aa2d775dcc2">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/depend.make" file 644 mtime 1794960000 "cc700575ba47a021e69abaa862dbf030432e83a638af1112f23a5ccabde6bb55">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/flags.make" file 644 mtime 1794960000 "accf5324e73f9532476579be2055092f796234429727e72d7c7de83a2806d79a">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/link.txt" file 644 mtime 1794960000 "c41b92eef6035d86f9d3814e12cc78d8520184c07cc1fcb1b3876f8cf8406c5b">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/jsoncpp_test.dir/progress.make" file 644 mtime 1794960000 "074b1ccfdc3bc7d065e48f3af1f207492224a3b187bb4aa50452c325a155828b">,
      #splice.entry<"/build/source/build/src/test_lib_json/CMakeFiles/progress.marks" file 644 mtime 1794960000 "aa67a169b0bba217aa0aa88a65346920c84c42447c36ba5f7ea65f422c1fe5d8">,
      #splice.entry<"/build/source/build/src/test_lib_json/CTestTestfile.cmake" file 644 mtime 1794960000 "a4280b6e42d434384a9539aa3e51a0f21e2068a07d5d563d3e73c240d33ab283">,
      #splice.entry<"/build/source/build/src/test_lib_json/Makefile" file 644 mtime 1794960000 "526beabf996f6c2b8467d7463e49cdd4659532cdabdf8ccf9baaa102d3cb3087">,
      #splice.entry<"/build/source/build/src/test_lib_json/cmake_install.cmake" file 644 mtime 1794960000 "a232904b2a94b1ab7af418ee039879c7848e990c3d87f99fbb6389f665f76446">,
      #splice.entry<"/build/source/build/version" file 644 mtime 1794960000 "c26a46257161da86b9bf36413d034e521588fb65044bc4dfbf5e17e136e499d9">
  ]
  %g___14676:2 = splice.exec "g++" at 14676 as "cc_object"(%sandbox_721#0, %chmod_2021#0, %mkdir_2328, %cmake_2700#6, %cmake_2700#8, %cmake_2700#9, %cmake_2700#10, %chmod_2021#2, %chmod_2021#3, %chmod_2021_5, %chmod_2021_6, %chmod_2021_7, %chmod_2021_8, %chmod_2021_10, %chmod_2021_11, %chmod_2021_12, %chmod_2021_13, %chmod_2021#5, %chmod_2021#7, %chmod_2021_22, %chmod_2021_23) -> [
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/json_reader.cpp.o" file 644 mtime 1794960003 "9ddd0b84d9e3863b224ddcc9e5d0e064d2d442eda7b8b3cc9e466bd46125a29d">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/json_reader.cpp.o.d" file 644 mtime 1794960003 "b066c7efa7e546a926d483388771726bac3a4df16e674255573089d7e16bf3c9">
  ]
  %g___14847:2 = splice.exec "g++" at 14847 as "cc_object"(%sandbox_721#0, %chmod_2021#0, %mkdir_2328, %cmake_2700#6, %cmake_2700#8, %cmake_2700#9, %cmake_2700#10, %chmod_2021#2, %chmod_2021#3, %chmod_2021_5, %chmod_2021_6, %chmod_2021_7, %chmod_2021_8, %chmod_2021_12, %chmod_2021_13, %chmod_2021_14, %chmod_2021#5, %chmod_2021#7, %chmod_2021_24, %chmod_2021_25) -> [
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/json_value.cpp.o" file 644 mtime 1794960005 "fd43bee32cae73105b9d7eef313129e5ac9fa86ef180cbb80736ae3006de46b8">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/json_value.cpp.o.d" file 644 mtime 1794960005 "a6f7b4b06dafd9e0c0ed50b98e1974a937ee1e18c0b4cd38fab2179ba345df29">
  ]
  %g___15019:2 = splice.exec "g++" at 15019 as "cc_object"(%sandbox_721#0, %chmod_2021#0, %mkdir_2328, %cmake_2700#6, %cmake_2700#8, %cmake_2700#9, %cmake_2700#10, %chmod_2021#2, %chmod_2021#3, %chmod_2021_5, %chmod_2021_7, %chmod_2021_8, %chmod_2021_12, %chmod_2021_13, %chmod_2021_14, %chmod_2021#5, %chmod_2021#7, %chmod_2021_23, %chmod_2021_26) -> [
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/json_writer.cpp.o" file 644 mtime 1794960008 "cf97823e4fd0c9e5f66e88475909b0b1ece001a15049e055b6716ef256dd2066">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/json_writer.cpp.o.d" file 644 mtime 1794960008 "c1b1212b7eee2ad0e98c1260ecdd3b169531808303ac659b272a640f8de1d431">
  ]
  %g___15270:2 = splice.exec "g++" at 15270 as "cc_shared_library"(%sandbox_721#0, %chmod_2021#0, %mkdir_2328, %cmake_2700#4, %cmake_2700#6, %cmake_2700#8, %cmake_2700#9, %cmake_2700#10, %g___14676#0, %g___14847#0, %g___15019#0, %cmake_2700_34#92) -> [
      #splice.entry<"/build/source/build/lib/libjsoncpp.so.1.9.8" file 755 mtime 1794960008 "eedb658aad1d77ebe1daa6ed3ea2084c8f26fbadd270f299cdf50ceface4dd40">,
      #splice.entry<"/build/source/build/src/lib_json/CMakeFiles/jsoncpp_lib.dir/link.d" file 644 mtime 1794960008 "36389042d1635588b98042ce26b52f5c59f3e7d0ac918d12c8740e0f6c9318bc">
  ]
  %mkdir_18013 = splice.literal "mkdir" at 18013 folded -> [
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8" dir 755 mtime 1794960021>
  ]
  %cmake_18858:9 = splice.literal "cmake" at 18858 folded -> [
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/cmake" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/cmake/jsoncpp" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/libjsoncpp.so" link 0 mtime 1794960021 "libjsoncpp.so.27">,
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/libjsoncpp.so.27" link 0 mtime 1794960021 "libjsoncpp.so.1.9.8">,
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/pkgconfig" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json" dir 755 mtime 1794960021>
  ]
  %cmake_18858_35 = splice.copy "cmake" at 18858(%g___15270#0) -> <"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/libjsoncpp.so.1.9.8" file 755 mtime 1794960008 "eedb658aad1d77ebe1daa6ed3ea2084c8f26fbadd270f299cdf50ceface4dd40">
  %cmake_18858_36 = splice.copy "cmake" at 18858(%cp_1473#71) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/allocator.h" file 644 mtime 1 "500a24a92dfbf8e8c8699e4eb654511e62619bd8d7f29bca4c62c24ca66c4101">
  %cmake_18858_37 = splice.copy "cmake" at 18858(%cp_1473#72) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/assertions.h" file 644 mtime 1 "ea30b8fb30ef70a52a6435f6e6efbc37de03555fa192b33832e65cbd159b68bb">
  %cmake_18858_38 = splice.copy "cmake" at 18858(%cp_1473#73) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/config.h" file 644 mtime 1 "7479aba8631e81d9a450ff3dd1ad8a18ef913656caac6555ce6c5fd507d51622">
  %cmake_18858_39 = splice.copy "cmake" at 18858(%cp_1473#74) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/forwards.h" file 644 mtime 1 "92a8bfce5303164fb3620e2dd053333c22ab9a775e4da3817fb3e89cf547a299">
  %cmake_18858_40 = splice.copy "cmake" at 18858(%cp_1473#75) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/json.h" file 644 mtime 1 "05ccb35afa55a068f8cc2a195db46d89a7f6a458d1943ae009465834c6404a67">
  %cmake_18858_41 = splice.copy "cmake" at 18858(%cp_1473#76) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/json_features.h" file 644 mtime 1 "9a3a209af311356da182e0b768c7c1f5993863df9d2d0f9dfa8f96d492282494">
  %cmake_18858_42 = splice.copy "cmake" at 18858(%cp_1473#77) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/reader.h" file 644 mtime 1 "c29e5a46b6204c6e166c31880be2483067cad5a851da3b07b06b8f46c1f583d0">
  %cmake_18858_43 = splice.copy "cmake" at 18858(%cp_1473#78) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/value.h" file 644 mtime 1 "735bc075cbc8ac106e1fcb2e3aada2ee4da09feebf9d005c9b1486690293abe7">
  %cmake_18858_44 = splice.copy "cmake" at 18858(%cp_1473#79) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/version.h" file 644 mtime 1 "c0a115d83a96ebfac02f4df50509b96619d2af4b639920cfe310a9ca99e040d0">
  %cmake_18858_45 = splice.copy "cmake" at 18858(%cp_1473#80) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/include/json/writer.h" file 644 mtime 1 "1828e708ae2f28207b0b0c618aa14038c3e223af9d25de2efab0fcf4fbd25591">
  %mkdir_19355 = splice.literal "mkdir" at 19355 folded -> [
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib" dir 755 mtime 1794960021>
  ]
  %mv_19376 = splice.literal "mv" at 19376 folded -> [
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/pkgconfig" dir 755 mtime 1794960021>
  ]
  %mv_19519:2 = splice.literal "mv" at 19519 folded -> [
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake" dir 755 mtime 1794960021>,
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake/jsoncpp" dir 755 mtime 1794960021>
  ]
  %mv_19519_46 = splice.copy "mv" at 19519(%cp_1473#81) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake/jsoncpp/jsoncpp-namespaced-targets.cmake" file 644 mtime 1 "3ca99e17de275ce3c52e0d1591ecdfc20ec521f5a20e96776ee39a2f679fe739">
  %mv_19519_47 = splice.copy "mv" at 19519(%cmake_2700_34#18) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake/jsoncpp/jsoncpp-targets-release.cmake" file 644 mtime 1794960000 "ba2a88caf90faa8ba006212c12f9cef031697fb7d8fbe50fc1fb48194917d68f">
  %mv_19519_48 = splice.copy "mv" at 19519(%cmake_2700_34#19) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake/jsoncpp/jsoncpp-targets.cmake" file 644 mtime 1794960000 "f7cd25a3a9d3bd354734d10b815cadcee577e2e0270930d1bd583ccf9bf06ba9">
  %mv_19519_49 = splice.copy "mv" at 19519(%cmake_2700_34#38) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake/jsoncpp/jsoncppConfig.cmake" file 644 mtime 1794960000 "ec1f4a21226e612e697b0ef58a94fe48ed8cc60b2f06d71fa1a22535ea729b7f">
  %mv_19519_50 = splice.copy "mv" at 19519(%cmake_2700_34#39) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/cmake/jsoncpp/jsoncppConfigVersion.cmake" file 644 mtime 1794960000 "8b4f3b5b889535fdb0a46aed783b13fd7dbe2e5e11016b9aa86cbdbb5a62d9a0">
  %sed_19603 = splice.copy "sed" at 19603(%cmake_2700_34#42) -> <"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/lib/pkgconfig/jsoncpp.pc" file 644 mtime 1794960021 "e1503948bd06a498fe11adab67c6599015b50158371f0d5edf4c891849f68a54">
  %find_patchelf_20356 = splice.exec "find|patchelf" at 20356(%sandbox_721#0, %chmod_2021#0, %mkdir_2328, %mkdir_18013, %cmake_18858#0, %cmake_18858_35) -> [
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/libjsoncpp.so.1.9.8" file 755 mtime 1794960021 "0647a22dd4f95f91a49c4b2abcec18f5ee0e88275879d8ed5c6ac9e0a0980bba">
  ]
  %mktemp_20704 = splice.literal "mktemp" at 20704 folded -> [
      #splice.entry<"/build/striperr.oq3yJI" file 600 mtime 1794960021 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_20810 = splice.exec "strip" at 20810(%sandbox_721#0, %chmod_2021#0, %mkdir_2328, %mktemp_20704, %mkdir_18013, %cmake_18858#0, %find_patchelf_20356) -> [
      #splice.entry<"/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8/lib/libjsoncpp.so.1.9.8" file 755 mtime 1794960021 "fc2bd72eb38597e7d9782956b50d9cb569f6f2f1e683fa99b87ed8b0f28c11e5">
  ]
  %mkdir_21366 = splice.literal "mkdir" at 21366 folded -> [
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/nix-support" dir 755 mtime 1794960021>
  ]
  %glue_21389 = splice.literal "glue" at 21389 -> [
      #splice.entry<"/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev/nix-support/propagated-build-inputs" file 644 mtime 1794960021 "381679dd329bca474e26ab674d2f7383f02c016d01d64390b6340c79b834ad24">
  ]
  splice.output "dev" "/nix/store/q957fj0pjwaa0b8hbyyvr51cksyh5bxi-jsoncpp-1.9.8-dev"(%cmake_18858#6, %cmake_18858#7, %cmake_18858#8, %cmake_18858_36, %cmake_18858_37, %cmake_18858_38, %cmake_18858_39, %cmake_18858_40, %cmake_18858_41, %cmake_18858_42, %cmake_18858_43, %cmake_18858_44, %cmake_18858_45, %mkdir_19355, %mv_19519#0, %mv_19519#1, %mv_19519_46, %mv_19519_47, %mv_19519_48, %mv_19519_49, %mv_19519_50, %mv_19376, %sed_19603, %mkdir_21366, %glue_21389)
  splice.output "out" "/nix/store/g1jcfq4b6favy36p099qwrh3f385cmlw-jsoncpp-1.9.8"(%mkdir_18013, %cmake_18858#0, %cmake_18858#3, %strip_20810, %cmake_18858#4)
}

