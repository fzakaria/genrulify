module {
  %sandbox_716 = splice.literal "sandbox" at 716 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %cp_2016:3 = splice.exec "cp" at 2016(%sandbox_716) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/LICENSE" file 444 mtime 1 "a2010f343487d3f7618affe54f789f5487602331c0a8d03f49e9a7c547cf0499">,
      #splice.entry<"/build/source/main.cpp" file 444 mtime 1 "c60e9167c6054107aa3267b87fea18c163f7f87da25e2c17da1b7eb763ced861">
  ]
  %chmod_2049 = splice.literal "chmod" at 2049 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>
  ]
  %chmod_2049_0 = splice.copy "chmod" at 2049(%cp_2016#2) -> <"/build/source/main.cpp" file 644 mtime 1 "c60e9167c6054107aa3267b87fea18c163f7f87da25e2c17da1b7eb763ced861">
  %g___2685 = splice.exec "g++" at 2685(%sandbox_716, %chmod_2049, %chmod_2049_0) -> [
      #splice.entry<"/build/source/a.out" file 755 mtime 1794960000 "bd25c4990c4631046d50dc0a711b878941fb24bc27e31e6d34512633b9615812">
  ]
  %install_3122:2 = splice.literal "install" at 3122 folded -> [
      #splice.entry<"/nix/store/s7lfxf6nljg66na31h9ay8qj8adiwdxs-colstr-1.0.0" dir 755 mtime 1794960000>,
      #splice.entry<"/nix/store/s7lfxf6nljg66na31h9ay8qj8adiwdxs-colstr-1.0.0/bin" dir 755 mtime 1794960000>
  ]
  %install_3122_1 = splice.copy "install" at 3122(%g___2685) -> <"/nix/store/s7lfxf6nljg66na31h9ay8qj8adiwdxs-colstr-1.0.0/bin/colstr" file 755 mtime 1794960000 "bd25c4990c4631046d50dc0a711b878941fb24bc27e31e6d34512633b9615812">
  %find_patchelf_3345 = splice.exec "find|patchelf" at 3345(%sandbox_716, %chmod_2049, %install_3122#0, %install_3122#1, %install_3122_1) -> [
      #splice.entry<"/nix/store/s7lfxf6nljg66na31h9ay8qj8adiwdxs-colstr-1.0.0/bin/colstr" file 755 mtime 1794960000 "c764b687f2f8d20e3a004571038143609f2e7e6af9a302bf302a9788dcdc08a8">
  ]
  %mktemp_3690 = splice.literal "mktemp" at 3690 folded -> [
      #splice.entry<"/build/striperr.WNwmmf" file 600 mtime 1794960000 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_3796 = splice.exec "strip" at 3796(%sandbox_716, %chmod_2049, %mktemp_3690, %install_3122#0, %install_3122#1, %find_patchelf_3345) -> [
      #splice.entry<"/nix/store/s7lfxf6nljg66na31h9ay8qj8adiwdxs-colstr-1.0.0/bin/colstr" file 755 mtime 1794960000 "99d3ec89bbef74dd78b0ba3ae753696ee3153105c4d34b05dd907cdfb0d9c2c7">
  ]
  splice.output "out" "/nix/store/s7lfxf6nljg66na31h9ay8qj8adiwdxs-colstr-1.0.0"(%install_3122#0, %install_3122#1, %strip_3796)
}

