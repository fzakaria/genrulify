module {
  %sandbox_716 = splice.literal "sandbox" at 716 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %cp_2098:11 = splice.exec "cp" at 2098(%sandbox_716) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/.gitignore" file 444 mtime 1 "b6c49994d4ac8e9c963f86fbbcbdc602e09f4fcea204b4cc1e2467e271a0f1d4">,
      #splice.entry<"/build/source/LICENSE" file 444 mtime 1 "72c7d262e2c9ddf019edc90af852a01a410338efff4e75e1c005b77ada4be7c4">,
      #splice.entry<"/build/source/Makefile" file 444 mtime 1 "dc8a4358768ef0bdf20e064cd5203ac5c67fb5e283acd5e2fcb0fae9b360f517">,
      #splice.entry<"/build/source/README.ja.md" file 444 mtime 1 "2a01b6b7d7fb8e658a22b0c80633f8bf3da3bed5cb1a19c347bcf8c3e71a5adc">,
      #splice.entry<"/build/source/README.md" file 444 mtime 1 "2e602db77ec71fc2e9fa75f85c5d1a33588cb613227df2d6e8d02eff016dc7f4">,
      #splice.entry<"/build/source/demo.gif" file 444 mtime 1 "cd29dd2d45e941679a71762e1fdd315e040034cfd9c2849d2bf60ae3e7f2be6b">,
      #splice.entry<"/build/source/sl.1" file 444 mtime 1 "a598abda4950f6dfca0351cacf776267da065cfe67c540ec2a21ed4039a334f7">,
      #splice.entry<"/build/source/sl.1.ja" file 444 mtime 1 "e516ffe42b2b0993e5dbfcf216314342b10a2f5a2eacfa7d9d5fc6bfa2ba0581">,
      #splice.entry<"/build/source/sl.c" file 444 mtime 1 "bb61dbb2c20ba279cb96e2c21c0a5ad8f8a6bb0b74bce7b4268e8d1434138bb1">,
      #splice.entry<"/build/source/sl.h" file 444 mtime 1 "02847f3f0a00fb0f8d5ccb493ae0f00dc8617a8c416c9a4ecd1b5a0d0ee7c4d7">
  ]
  %chmod_2140 = splice.literal "chmod" at 2140 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>
  ]
  %chmod_2140_0 = splice.copy "chmod" at 2140(%cp_2098#9) -> <"/build/source/sl.c" file 644 mtime 1 "bb61dbb2c20ba279cb96e2c21c0a5ad8f8a6bb0b74bce7b4268e8d1434138bb1">
  %chmod_2140_1 = splice.copy "chmod" at 2140(%cp_2098#10) -> <"/build/source/sl.h" file 644 mtime 1 "02847f3f0a00fb0f8d5ccb493ae0f00dc8617a8c416c9a4ecd1b5a0d0ee7c4d7">
  %gcc_2853 = splice.exec "gcc" at 2853 as "cc_binary"(%sandbox_716, %chmod_2140, %chmod_2140_0, %chmod_2140_1) -> [
      #splice.entry<"/build/source/sl" file 755 mtime 1795046400 "f81e4c853bb247377aed69cc62781458530732bad945f45bfcfe60cfe12d7694">
  ]
  %install_3347:2 = splice.literal "install" at 3347 folded -> [
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/bin" dir 755 mtime 1795046400>
  ]
  %install_3347_2 = splice.copy "install" at 3347(%gcc_2853) -> <"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/bin/sl" file 755 mtime 1795046400 "f81e4c853bb247377aed69cc62781458530732bad945f45bfcfe60cfe12d7694">
  %install_3374:3 = splice.literal "install" at 3374 folded -> [
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share/man" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share/man/man1" dir 755 mtime 1795046400>
  ]
  %install_3374_3 = splice.copy "install" at 3374(%cp_2098#7) -> <"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share/man/man1/sl.1" file 644 mtime 1795046400 "a598abda4950f6dfca0351cacf776267da065cfe67c540ec2a21ed4039a334f7">
  %install_3374_4 = splice.copy "install" at 3374(%cp_2098#8) -> <"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share/man/man1/sl.1.ja" file 644 mtime 1795046400 "e516ffe42b2b0993e5dbfcf216314342b10a2f5a2eacfa7d9d5fc6bfa2ba0581">
  %find_patchelf_3609 = splice.exec "find|patchelf" at 3609(%sandbox_716, %chmod_2140, %install_3347#0, %install_3347#1, %install_3347_2) -> [
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/bin/sl" file 755 mtime 1795046400 "083fe23d6f7b5e542165516652a9fda8b722e71403e3d1c8b2c7ea0b1701b67c">
  ]
  %gzip_3933 = splice.exec "gzip" at 3933(%sandbox_716, %chmod_2140, %install_3347#0, %install_3374#0, %install_3374#1, %install_3374#2, %install_3374_4) -> [
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share/man/man1/sl.1.ja.gz" file 644 mtime 1795046400 "696ec8692ec4b2306f29708c421a4e638b168bef2421d9cbbd8e41e38d8b18bc">
  ]
  %gzip_3959 = splice.exec "gzip" at 3959(%sandbox_716, %chmod_2140, %install_3347#0, %install_3374#0, %install_3374#1, %install_3374#2, %install_3374_3) -> [
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/share/man/man1/sl.1.gz" file 644 mtime 1795046400 "693d688135a74230c743b33d157d21be3d55409e49d7834e019dc2034cfd1872">
  ]
  %mktemp_4092 = splice.literal "mktemp" at 4092 folded -> [
      #splice.entry<"/build/striperr.lHyxAi" file 600 mtime 1795046400 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_4198 = splice.exec "strip" at 4198(%sandbox_716, %chmod_2140, %mktemp_4092, %install_3347#0, %install_3347#1, %find_patchelf_3609) -> [
      #splice.entry<"/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05/bin/sl" file 755 mtime 1795046400 "a6cd1b3e5b91dc867985bdb433c507ddd3a26e3be7974c24b967c968e281e0c7">
  ]
  splice.output "out" "/nix/store/0n7j2s7fawm2m7m3zmqapsjwv8xlq3yf-sl-5.05"(%install_3347#0, %install_3347#1, %strip_4198, %install_3374#0, %install_3374#1, %install_3374#2, %gzip_3959, %gzip_3933)
}

