module {
  %sandbox_716 = splice.literal "sandbox" at 716 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %cp_2139:251 = splice.exec "cp" at 2139(%sandbox_716) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/.circleci" dir 555 mtime 1>,
      #splice.entry<"/build/source/.circleci/config.yml" file 444 mtime 1 "6c113a8499cf7a54eb5591c4682e85bd302edfba9dd2364d5b786d30b282fd1b">,
      #splice.entry<"/build/source/.circleci/images" dir 555 mtime 1>,
      #splice.entry<"/build/source/.circleci/images/primary" dir 555 mtime 1>,
      #splice.entry<"/build/source/.circleci/images/primary/Dockerfile" file 444 mtime 1 "089c2787497982d7d452965ecf2afd93c6ef784c1aae7f37132edd064db7b5de">,
      #splice.entry<"/build/source/.cirrus.yml" file 444 mtime 1 "e722a00d220a188578251a429fbb1a71fd4f8083f1c7411525ad790505888f81">,
      #splice.entry<"/build/source/.clang-format" file 444 mtime 1 "16e5bda1506fb355634ada730bc26ed838ca800b1d8a2c0a0161e22fff36ba12">,
      #splice.entry<"/build/source/.gitattributes" file 444 mtime 1 "0ee157945a4a1cc81ac5bd2f9d6a985363516201f50cda9602f4a6a16fb778bb">,
      #splice.entry<"/build/source/.github" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE/bug_report.md" file 444 mtime 1 "028e2a11008f4cea32c73c1ef2e761ec8deb1ab2fa7440704ce6eaf3ffe3fd40">,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE/feature_request.md" file 444 mtime 1 "1f48c52f209a971b8e7eae4120144d28fcf8ee38a7778a7b4d8cf1ab356617d2">,
      #splice.entry<"/build/source/.github/dependabot.yaml" file 444 mtime 1 "9804ed1afdf6b83d6284bf86e24804121fedbd19000ac33dd332960618d00cb7">,
      #splice.entry<"/build/source/.github/workflows" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/workflows/README.md" file 444 mtime 1 "0564491e914090654c14e6297e96edc0b2b74699dbdf99d2f16938e366633d0e">,
      #splice.entry<"/build/source/.github/workflows/ci.yml" file 444 mtime 1 "4a9f2253ec0f6e67289db1b5bb012ee4a077ed1b1ba5f86dbe4a31f8b2dde09f">,
      #splice.entry<"/build/source/.github/workflows/scorecard.yml" file 444 mtime 1 "430feb09dacc383b24c5dbad98b583f794d1b21bab76f7aa849f918316fb1d07">,
      #splice.entry<"/build/source/.gitignore" file 444 mtime 1 "ed881bec37d9dc626660f772f079d0ef6901aae43df41466e395fda64f0c5b73">,
      #splice.entry<"/build/source/CODING_STYLE" file 444 mtime 1 "4d58f5535566c9abf3ea506e5133dbea88cb2cbcba6a255feeb3e08f99903fc9">,
      #splice.entry<"/build/source/INSTALL" file 444 mtime 1 "e40cb31226d6f2e42ccc84eb8e0d867776d06846d7c5b7889bc733a5618debad">,
      #splice.entry<"/build/source/LICENSE" file 444 mtime 1 "4bc9c403f6b679cc076dee210e0e21c27b4e8f6d3fb43d85364c76657bfaaac5">,
      #splice.entry<"/build/source/Makefile" file 444 mtime 1 "db7644c69a321c101dc629f4cef78fe8bf7bc3ea3a0cd25509be9de77b6ab8bb">,
      #splice.entry<"/build/source/Makefile.inc" file 444 mtime 1 "baca7e166c422e03601afa31f280ce2e524ad11c0d277f20241c4b3930e74184">,
      #splice.entry<"/build/source/NEWS" file 444 mtime 1 "8fe6e56a9c40846fdf47caa045bef1e0db7c7f020164fd127de0fa1222c2f7f8">,
      #splice.entry<"/build/source/README.md" file 444 mtime 1 "ac443b7277c11613ffe1f80796bc5fcaaa32e5c746e8c77f689a501431d685be">,
      #splice.entry<"/build/source/SECURITY.md" file 444 mtime 1 "45156d03a137a23adf8d424aa29bd02212c47678e98b910dabea4f228b671404">,
      #splice.entry<"/build/source/appveyor.yml" file 444 mtime 1 "abc939aebe97490e58ee3962f78c9346e10cae1d95cf2b884d67b380042d05fd">,
      #splice.entry<"/build/source/build" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/.gitignore" file 444 mtime 1 "e61f3bd7d02901a8119359dd16f079c36972c5125b13ab599821fb050893f6ce">,
      #splice.entry<"/build/source/build/README.md" file 444 mtime 1 "507db4abd9c27524ef4c3b3a9f41963b23cebdda5b9d390ca3f4306c9b0c2d6f">,
      #splice.entry<"/build/source/build/VS2022" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/_build.bat" file 444 mtime 1 "f2041923370d9173d0f95e39a6d9c485ef2c72e8028cdad16bc76d5c2b29967b">,
      #splice.entry<"/build/source/build/VS2022/_setup.bat" file 444 mtime 1 "d218dd97e1a446a4ab4ad7774f5099618af3bec78b94418be14e9e655576c51b">,
      #splice.entry<"/build/source/build/VS2022/_test.bat" file 444 mtime 1 "f9f0f29042b29dadb7ff13ca951b9fd849979fbee1ab434095ae4f69ecb4d8a8">,
      #splice.entry<"/build/source/build/VS2022/build-and-test-win32-debug.bat" file 444 mtime 1 "8bce077079f0783a4bb77c0278e51b93dca5b0f9111a506bf3bd77a33d387250">,
      #splice.entry<"/build/source/build/VS2022/build-and-test-win32-release.bat" file 444 mtime 1 "66439d2595a06a23728949282db54553f73fc9250ad4c604d2f661a5cbc409b2">,
      #splice.entry<"/build/source/build/VS2022/build-and-test-x64-debug.bat" file 444 mtime 1 "979634ed143cf5bf10ebafea58f36c3dc46f0bcc1f00a65f293c9ea62f59c731">,
      #splice.entry<"/build/source/build/VS2022/build-and-test-x64-release.bat" file 444 mtime 1 "12737b37acbe59f39351b5071d1aa86ee0bdfcbae88967d8376ec3aad6bf3258">,
      #splice.entry<"/build/source/build/VS2022/datagen" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/datagen/datagen.vcxproj" file 444 mtime 1 "5d77e7f65b963d4ccab4f0518b5894b13590456387affe561eccc699f96f8bae">,
      #splice.entry<"/build/source/build/VS2022/frametest" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/frametest/frametest.vcxproj" file 444 mtime 1 "ac5b303ce5971b40d0a3a6b59c06b5fb256ef21415b609813bacc47113d79309">,
      #splice.entry<"/build/source/build/VS2022/fullbench" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/fullbench-dll" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/fullbench-dll/fullbench-dll.vcxproj" file 444 mtime 1 "2c478b4bc6735e502626168d8a1bb6b881b963a2e6d2906e78f2fc12d043f863">,
      #splice.entry<"/build/source/build/VS2022/fullbench/fullbench.vcxproj" file 444 mtime 1 "f997c657ccb4544aa68527c3e5c8e244cf8688fc2334c628eef9d98717b03213">,
      #splice.entry<"/build/source/build/VS2022/fuzzer" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/fuzzer/fuzzer.vcxproj" file 444 mtime 1 "e25903cd48256c8e82da75e647ac8735594b1bbca412148bc3e2c951855e0834">,
      #splice.entry<"/build/source/build/VS2022/liblz4" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/liblz4-dll" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/liblz4-dll/liblz4-dll.rc" file 444 mtime 1 "1e5895921e87a4f20e01142b83dabcedc8629eec825c519ab05363ecfa64019f">,
      #splice.entry<"/build/source/build/VS2022/liblz4-dll/liblz4-dll.vcxproj" file 444 mtime 1 "d8ccd02405f160675e71a998341511b293d6bd452e61cf9eed776f3995d1f74d">,
      #splice.entry<"/build/source/build/VS2022/liblz4/liblz4.vcxproj" file 444 mtime 1 "2edaf8aa9f667c353ad79f18e54d1165222a2fc68e32f317df65725bddd437e7">,
      #splice.entry<"/build/source/build/VS2022/lz4" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/lz4.sln" file 444 mtime 1 "dff63cc02684d6be5ff8a47a2a583ff896ab12fd30c063f54bc25337e0fbe6ed">,
      #splice.entry<"/build/source/build/VS2022/lz4/lz4.rc" file 444 mtime 1 "a7573b7b465664ca2a6df59202b9cf32b348b40e73a57fe4b81618542679ecf8">,
      #splice.entry<"/build/source/build/VS2022/lz4/lz4.vcxproj" file 444 mtime 1 "b5d6a8c6f946be257789b1f6cfd374c3f49fe60dd2da24dcfa9af9c16802c6ec">,
      #splice.entry<"/build/source/build/cmake" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/cmake/.gitignore" file 444 mtime 1 "df63e2dcb7f9c24d2f703e19bd21a7946355f6280f650a650d12beef6c3e1094">,
      #splice.entry<"/build/source/build/cmake/CMakeLists.txt" file 444 mtime 1 "2cbb76cb53831a81d4970b8e41d96a75cf7db219c45914fc99be038a7eb7c8ab">,
      #splice.entry<"/build/source/build/cmake/lz4Config.cmake.in" file 444 mtime 1 "5b24cac80e8a438e3a52a11721b0fbc9d00f7bf532eef5d62f0d894434f32462">,
      #splice.entry<"/build/source/build/meson" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/GetLz4LibraryVersion.py" file 444 mtime 1 "07e29b20bbe36d92e19a9b12492645b353fe0b255c0d0f2481d7db5e0b6b44fa">,
      #splice.entry<"/build/source/build/meson/README.md" file 444 mtime 1 "16be5030767265e9887c595769c6c234f2ae2002a565fa6f430d95b8bb48f350">,
      #splice.entry<"/build/source/build/meson/meson" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson.build" file 444 mtime 1 "0637f14491a2087768c45f2580cbc3e54cd2d9f9157c80cdb37a1a9d180e4ff4">,
      #splice.entry<"/build/source/build/meson/meson/contrib" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/contrib/gen_manual" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/contrib/gen_manual/meson.build" file 444 mtime 1 "a66b74be0b0a0013f842bdbf1623bdfeca6a2d1c8062e9f9f07bbb3753be6087">,
      #splice.entry<"/build/source/build/meson/meson/contrib/meson.build" file 444 mtime 1 "4add6ee98356607280803194f4321ef9d181d5bb13a03cc41ff80caed57734cc">,
      #splice.entry<"/build/source/build/meson/meson/examples" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/examples/meson.build" file 444 mtime 1 "78cde83e9ac2235635afb3ad1553968f9e702bdf85c961bea0ed58e4738e8538">,
      #splice.entry<"/build/source/build/meson/meson/lib" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/lib/meson.build" file 444 mtime 1 "ff14075868a7e3daf4b12a60875d4b156659cde45a7f87cb181c282cc82d52dd">,
      #splice.entry<"/build/source/build/meson/meson/meson.build" file 444 mtime 1 "a2e489cc2024d87d1af98792c791fc07dda905c266dd8b15ba4293783780bd84">,
      #splice.entry<"/build/source/build/meson/meson/ossfuzz" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/ossfuzz/meson.build" file 444 mtime 1 "4e1ddfc72bb94b789dcd0c9d4419e525e20e0f3a5456976472fdb9a020aecbc1">,
      #splice.entry<"/build/source/build/meson/meson/programs" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/programs/meson.build" file 444 mtime 1 "0ec6b53e92243a0c6af17c47e42e58244539a2b8d6c6a4c76753d65379d87837">,
      #splice.entry<"/build/source/build/meson/meson/tests" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/tests/meson.build" file 444 mtime 1 "2738e7d2a29a76aaa277834509404d3ef19f6883b62183c59a79247c4a1f17fc">,
      #splice.entry<"/build/source/build/meson/meson_options.txt" file 444 mtime 1 "4b98332d54b838775708f9b94784b692b45a78d4cda758f5d147c0ab88f9f2f2">,
      #splice.entry<"/build/source/build/visual" dir 555 mtime 1>,
      #splice.entry<"/build/source/build/visual/README.md" file 444 mtime 1 "a9cbf6a75a656a8991460f8560686ca1e230724e9e0c097940b18d960aa26bc4">,
      #splice.entry<"/build/source/build/visual/generate_solution.cmd" file 444 mtime 1 "533a5451fab9591834285c850d190faabd6e273e869ed2d4a283c8e73ee1e97b">,
      #splice.entry<"/build/source/build/visual/generate_vs2015.cmd" file 444 mtime 1 "5bbcb4cd1f52279b239abf9525589cdc7d082a85080ef7d50eb9ccbaba2b1c06">,
      #splice.entry<"/build/source/build/visual/generate_vs2017.cmd" file 444 mtime 1 "5b2cea61d288ce78518886f4e5c9525f7114bc32aba493a345913ad8e01ea03a">,
      #splice.entry<"/build/source/build/visual/generate_vs2019.cmd" file 444 mtime 1 "ab1d7d2d4c22c78efd47e97e67866f275c20b9e9ca0f3d1f2a75e042853a71d7">,
      #splice.entry<"/build/source/build/visual/generate_vs2022.cmd" file 444 mtime 1 "c6fe773f05470e0af8fef0a3672a4506f8c2a04b9b171c87eb64d827cc40087b">,
      #splice.entry<"/build/source/contrib" dir 555 mtime 1>,
      #splice.entry<"/build/source/contrib/debian" dir 555 mtime 1>,
      #splice.entry<"/build/source/contrib/debian/changelog" file 444 mtime 1 "f7ab7d42941c818b67d13e72023be47600b9832b009585b0715c567efe770843">,
      #splice.entry<"/build/source/contrib/debian/compat" file 444 mtime 1 "10159baf262b43a92d95db59dae1f72c645127301661e0a3ce4e38b295a97c58">,
      #splice.entry<"/build/source/contrib/debian/control" file 444 mtime 1 "3ecfdd58076228049fec9a91abc2284a7b2e3b7c28ed9e20281c7a8585098af7">,
      #splice.entry<"/build/source/contrib/debian/copyright" file 444 mtime 1 "4f6ef9d0e844bf432d6a0abb2623f5a61175ae40f7f0e3665490311d89e3af87">,
      #splice.entry<"/build/source/contrib/debian/dirs" file 444 mtime 1 "5afd130d6d03c8c12e124ce767ed367ce303c84605fc32727db31534cb4e3916">,
      #splice.entry<"/build/source/contrib/debian/docs" file 444 mtime 1 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/source/contrib/debian/liblz4-dev.install" file 444 mtime 1 "7916058e85e36af6a8fc1e0001e8305520c584da9e0ccbea0d497968e1508dae">,
      #splice.entry<"/build/source/contrib/debian/liblz4.install" file 444 mtime 1 "1d6e28a20190fd6c9a965211a9c7b93b5bb9f84bdf5200656dabf672d266e76c">,
      #splice.entry<"/build/source/contrib/debian/rules" file 555 mtime 1 "947dff0b3c6be7f7e6f8a316d11794d68e5ba9beb96893a4a4fc556376c01109">,
      #splice.entry<"/build/source/contrib/djgpp" dir 555 mtime 1>,
      #splice.entry<"/build/source/contrib/djgpp/LICENSE" file 444 mtime 1 "d011d1e02cb32b71c1ce2922ab41a2e2ad30f4ecf8de22c078d53618205abc05">,
      #splice.entry<"/build/source/contrib/djgpp/Makefile" file 444 mtime 1 "e667732ec353b760939999a94dcba2907b289bf9e7e2ebb8feeaa426e95ba205">,
      #splice.entry<"/build/source/contrib/djgpp/README.MD" file 444 mtime 1 "1ec3f0dd6c6644bc3938fb52bc6caf29be557610f61ea60590c05d1bc02dd30c">,
      #splice.entry<"/build/source/contrib/gen_manual" dir 555 mtime 1>,
      #splice.entry<"/build/source/contrib/gen_manual/.gitignore" file 444 mtime 1 "811706a7c3519391761ad5796aec9454585cbbb98757faa282e5745a2e0b5cce">,
      #splice.entry<"/build/source/contrib/gen_manual/Makefile" file 444 mtime 1 "08d432ee7fec941c1b53bcf083832e954770320bd0a4d6347d274ac96e11df8f">,
      #splice.entry<"/build/source/contrib/gen_manual/README.md" file 444 mtime 1 "26efd8ee20dddef8b9e076b170dd932a82467259a07e02180e68b78e10f453ed">,
      #splice.entry<"/build/source/contrib/gen_manual/gen-lz4-manual.sh" file 444 mtime 1 "7a888d6f86b4c61f830396a3421e18a9c47786a782d923a0f1f9b0d9dae0ff75">,
      #splice.entry<"/build/source/contrib/gen_manual/gen_manual.cpp" file 444 mtime 1 "97dac662a59fac29a965c88724d43d960c53b7594f24660dd8e5dd825f310098">,
      #splice.entry<"/build/source/contrib/snap" dir 555 mtime 1>,
      #splice.entry<"/build/source/contrib/snap/README.md" file 444 mtime 1 "9b9d26c4c296d459c7d0daf3adf47895249a7b03fb3eb29f2b5dd60f0ff33e3b">,
      #splice.entry<"/build/source/contrib/snap/snapcraft.yaml" file 444 mtime 1 "fe0ef6db6d0ca2e900243d74bb15fba058a1d901f9cfd2e23356eb4d88eb55aa">,
      #splice.entry<"/build/source/doc" dir 555 mtime 1>,
      #splice.entry<"/build/source/doc/lz4_Block_format.md" file 444 mtime 1 "dce3c34a8738c44ed1dffb48c73e30297fca98ba7881408dc228865912c9a42e">,
      #splice.entry<"/build/source/doc/lz4_Frame_format.md" file 444 mtime 1 "8c2a10c4b99be177b874020cf4839d374d7a895b3c4d5292623edf948a13cc8f">,
      #splice.entry<"/build/source/doc/lz4_manual.html" file 444 mtime 1 "d3ba8f6d993890c7c6c077354944c67aa85b319a3a74a361ab5d5590fea37772">,
      #splice.entry<"/build/source/doc/lz4frame_manual.html" file 444 mtime 1 "16d83fc4920d1df5e26c3de9e1c6c24fe0233033fb1c8c52c0ef689cb20a11d3">,
      #splice.entry<"/build/source/examples" dir 555 mtime 1>,
      #splice.entry<"/build/source/examples/.gitignore" file 444 mtime 1 "459867356142284a4f69797f425965807fecf3854cf4a83f9c83ac93b029a09b">,
      #splice.entry<"/build/source/examples/COPYING" file 444 mtime 1 "609b910ef05c9c855ecc1da155a36ed0f57514eac452cf93446530b5ea4b3bc3">,
      #splice.entry<"/build/source/examples/Makefile" file 444 mtime 1 "acffd261b81d8f4cff9910fb53a5d415d0b706262795202655be404b44fca4b2">,
      #splice.entry<"/build/source/examples/README.md" file 444 mtime 1 "3dac202b4aa4c03b4921da6ffd2db11791373826ad668614b8ae48fab8283bb5">,
      #splice.entry<"/build/source/examples/bench_functions.c" file 444 mtime 1 "a3b55cf6bdde878639823a8879dde969b6e0f42f565bae56b9b3a38edc89d7fa">,
      #splice.entry<"/build/source/examples/blockStreaming_doubleBuffer.c" file 444 mtime 1 "8eb96317f1454db6b400b9da7b73ac435b16c50401b68b3e571e7efa7d29d72c">,
      #splice.entry<"/build/source/examples/blockStreaming_doubleBuffer.md" file 444 mtime 1 "186607a249d039a9b558592719845ee13222284d4bc8c90eb577a1697007dab0">,
      #splice.entry<"/build/source/examples/blockStreaming_lineByLine.c" file 444 mtime 1 "f236d3e7a2511475ebf25f8d354ee2d6733c73e67587c65670aeecabc3f1669d">,
      #splice.entry<"/build/source/examples/blockStreaming_lineByLine.md" file 444 mtime 1 "ed6bf3a195f0aa55c710c9cb785da3247f0285e7269478cced0b320d4405b312">,
      #splice.entry<"/build/source/examples/blockStreaming_ringBuffer.c" file 444 mtime 1 "de8fd5cdc83552ff190203004ddb1cacd54174ad3adab68dae7cc20d4994debf">,
      #splice.entry<"/build/source/examples/dictionaryRandomAccess.c" file 444 mtime 1 "c169b03e47269c445ce3adf028bd76ae8c011735a1322f51e2a13a792d7945e5">,
      #splice.entry<"/build/source/examples/dictionaryRandomAccess.md" file 444 mtime 1 "013d1e25de9217ff6224d14522f2a562901c78216cafd832f77c1921175abfe7">,
      #splice.entry<"/build/source/examples/fileCompress.c" file 444 mtime 1 "4f0842885669b01d003ec2a8c6fc9ef22705053a2d787ab145c3fa0a66fc1aa1">,
      #splice.entry<"/build/source/examples/frameCompress.c" file 444 mtime 1 "bd6e2e3b7243769dce5a35837c6c4cef726d93405e887844355784ee39d7f3c2">,
      #splice.entry<"/build/source/examples/print_version.c" file 444 mtime 1 "dcc2f58fe93bb7f50a1b459e54e99abae5ebd41363b0abf54e5a683f5340fbf0">,
      #splice.entry<"/build/source/examples/simple_buffer.c" file 444 mtime 1 "ac685d4e02a449d067f35720b92297643c6b1e639e3bf29ec4197143c98304f9">,
      #splice.entry<"/build/source/examples/streamingHC_ringBuffer.c" file 444 mtime 1 "de97d059a99a6db0934930eff946ccbc9daf7f111ec5e60651e65f2b79153de5">,
      #splice.entry<"/build/source/examples/streaming_api_basics.md" file 444 mtime 1 "f5f623970b6f533586fe2cb6dd12bcd82f0852a35d1d3406eef2ab86323831e7">,
      #splice.entry<"/build/source/lib" dir 555 mtime 1>,
      #splice.entry<"/build/source/lib/.gitignore" file 444 mtime 1 "406c783739cdb6f0adeca09a62d91ef94d35c9ba5abda0374bd214ee12b1882c">,
      #splice.entry<"/build/source/lib/LICENSE" file 444 mtime 1 "8b58c446121a109ccf32edc094bba3010a3d85e4ee3702950db55e4d3e87736c">,
      #splice.entry<"/build/source/lib/Makefile" file 444 mtime 1 "f5347c9e0c5e36e8be3329c8ca91c6bafbf4f6494f0484c2e8017eaa932e8c8f">,
      #splice.entry<"/build/source/lib/README.md" file 444 mtime 1 "a26e68719f64ebdef6ea1a9c0ca7bf76892a49d041e336364bcf91bbfb1875eb">,
      #splice.entry<"/build/source/lib/dll" dir 555 mtime 1>,
      #splice.entry<"/build/source/lib/dll/example" dir 555 mtime 1>,
      #splice.entry<"/build/source/lib/dll/example/Makefile" file 444 mtime 1 "1e035be57a8c3613726d39a56ebcffb20a8f4560e89bb3827edd3b98535561f7">,
      #splice.entry<"/build/source/lib/dll/example/README.md" file 444 mtime 1 "3bfef50f199e2d06312368ecfb7198f7b5e34eff03720b9aee6783a76277cff2">,
      #splice.entry<"/build/source/lib/dll/example/fullbench-dll.sln" file 444 mtime 1 "af0c9152e1109cea3e7a997e59dc435f032526c238e95681741e2a2f12ad0a74">,
      #splice.entry<"/build/source/lib/dll/example/fullbench-dll.vcxproj" file 444 mtime 1 "aadb61a66fb7f024a55406e253b7443742f7eb68193e0f143a73dcaf7ec6b240">,
      #splice.entry<"/build/source/lib/liblz4-dll.rc.in" file 444 mtime 1 "22860be8bafdeb276f3616177c32e00a8e620c59877d97600f43b0853ca6216d">,
      #splice.entry<"/build/source/lib/liblz4.pc.in" file 444 mtime 1 "f2fc76098b8b3282bf63d4b3b5654195097e2125c14bbcea83a4897118412227">,
      #splice.entry<"/build/source/lib/lz4.c" file 444 mtime 1 "9396f7de527bc8435de9c7569fb7998e56545a84b4f3c2d808c0235c01774539">,
      #splice.entry<"/build/source/lib/lz4.h" file 444 mtime 1 "26b82efc53d1570f3b54eef02e9c4764c1ad374ff03cac04e2ced5ea4d4c552f">,
      #splice.entry<"/build/source/lib/lz4file.c" file 444 mtime 1 "9c920fb21890bdce47d753bcd4a4dd3699ae75ac81ae7a999397c64fef012bec">,
      #splice.entry<"/build/source/lib/lz4file.h" file 444 mtime 1 "400ed90bc74324abcf338d37235dd81aa431fd815c22db4b369b88c12b213115">,
      #splice.entry<"/build/source/lib/lz4frame.c" file 444 mtime 1 "44f421bea199c7f11da263c717f063228cd2c8c05a8384d327b49cc81ccfbac4">,
      #splice.entry<"/build/source/lib/lz4frame.h" file 444 mtime 1 "b845db4b7ee1bfa64b8f641a94f62e7f636a8b5d673cc61766413782283aaad1">,
      #splice.entry<"/build/source/lib/lz4frame_static.h" file 444 mtime 1 "31ab72a6e97e4fa0bedd4420d24a3f1f8024cbfa1d8ffad88c87cbb4e04f769d">,
      #splice.entry<"/build/source/lib/lz4hc.c" file 444 mtime 1 "126cafafdb91767e6e55238298a910903851b35b2cee27ce80ae2280469ee232">,
      #splice.entry<"/build/source/lib/lz4hc.h" file 444 mtime 1 "e43824e8a9ba16f54100c4ccbccfa5782a858ca9ab83c48aac303fea3e76e21e">,
      #splice.entry<"/build/source/lib/xxhash.c" file 444 mtime 1 "b667033dc735fb5ea5648e0a61a2e065e5ef5bbda53669730063bd856c643c48">,
      #splice.entry<"/build/source/lib/xxhash.h" file 444 mtime 1 "aefdd236f35130495c18764cabed3f7b216906855fc5e6a9025cd2040bc84444">,
      #splice.entry<"/build/source/ossfuzz" dir 555 mtime 1>,
      #splice.entry<"/build/source/ossfuzz/.gitignore" file 444 mtime 1 "b640076c614fd77b7b33a023cc583eaecdf99332f4f18fa24f504ec7d91c9dfd">,
      #splice.entry<"/build/source/ossfuzz/Makefile" file 444 mtime 1 "f78aeb70e53a7bccd0dd947183a9727ebf8bfb1ce1c1df105860da00641518ad">,
      #splice.entry<"/build/source/ossfuzz/compress_frame_fuzzer.c" file 444 mtime 1 "3329efba2287ce33e5bf58c2f3460c407afebdb5d7bfdb5560fb9dd7b102f782">,
      #splice.entry<"/build/source/ossfuzz/compress_fuzzer.c" file 444 mtime 1 "f1ae2f302b1ad5a6aa160c792f9d1c0ce2c291b28a16bf2429de0fce3971857d">,
      #splice.entry<"/build/source/ossfuzz/compress_hc_fuzzer.c" file 444 mtime 1 "444b476026723697c8bc0be68a44ab434e281dd025a6a65d39c70981b422e6f3">,
      #splice.entry<"/build/source/ossfuzz/decompress_frame_fuzzer.c" file 444 mtime 1 "baf0dab7bfae0c7440f0488048dd45c846f809c11dcc0a9a781941f18df033b2">,
      #splice.entry<"/build/source/ossfuzz/decompress_fuzzer.c" file 444 mtime 1 "462b122196f8a2069e5e5c444528eacb04e8140b11bea20c835d6b6c67b88cb6">,
      #splice.entry<"/build/source/ossfuzz/fuzz.h" file 444 mtime 1 "0a004654a5e1ed8a40663f14136b9b36eb546567e8fa87a0dd50e4269d4bbf46">,
      #splice.entry<"/build/source/ossfuzz/fuzz_data_producer.c" file 444 mtime 1 "a12393758430ea5c2d1ec51118d9fc74e0c55444072a83adc00feb6037c888e0">,
      #splice.entry<"/build/source/ossfuzz/fuzz_data_producer.h" file 444 mtime 1 "4e30f91d4d61f7da92b285ba33dd1c6fc40fd9058fe95652b38808f45a38bda1">,
      #splice.entry<"/build/source/ossfuzz/fuzz_helpers.h" file 444 mtime 1 "877718ed9f8406883774f086402dbac72af4e4e5aa3965859b7624dd95c7c0d4">,
      #splice.entry<"/build/source/ossfuzz/lz4_helpers.c" file 444 mtime 1 "69b9957ae889774e3084f8b96e0d486ecb4816f2561a13dc42ebabf6e32faa58">,
      #splice.entry<"/build/source/ossfuzz/lz4_helpers.h" file 444 mtime 1 "a858177044de8a5921951ab4aa8fddae6130b1d257d637ba1ea012c541029734">,
      #splice.entry<"/build/source/ossfuzz/ossfuzz.sh" file 555 mtime 1 "31138e44b71510cc1a942e128facd1911cf9c20c6a3c610316e9d830700fb13a">,
      #splice.entry<"/build/source/ossfuzz/round_trip_frame_fuzzer.c" file 444 mtime 1 "3a07589f1deeabea74b1a4728b8528c45b3a1c7a27a783f503dbca5a35247071">,
      #splice.entry<"/build/source/ossfuzz/round_trip_frame_uncompressed_fuzzer.c" file 444 mtime 1 "a87dde93037a39eabc89950c31730b3d4d26f5a349cfb36491dc4265c7149804">,
      #splice.entry<"/build/source/ossfuzz/round_trip_fuzzer.c" file 444 mtime 1 "0c87880bd1301c4fc1255c34f9aca341479e22f0e5440c877b0db52aa9e04e0a">,
      #splice.entry<"/build/source/ossfuzz/round_trip_hc_fuzzer.c" file 444 mtime 1 "bc8aa628675f0366939fb583319c5fcc48e164439b03f4eef770ffab42086273">,
      #splice.entry<"/build/source/ossfuzz/round_trip_stream_fuzzer.c" file 444 mtime 1 "16f4773cee11b62a998f3d383be4a55780a910dcb5cc7299d8b2f87b444d13f1">,
      #splice.entry<"/build/source/ossfuzz/standaloneengine.c" file 444 mtime 1 "45a219de4aa04f76b2a7103fa82c10581131a7e5b486eedc8f65142cbe12fc40">,
      #splice.entry<"/build/source/ossfuzz/travisoss.sh" file 555 mtime 1 "bb5c86548ba064366499e334b2a845ee2074179876a10374e7492c9f4cb0e06d">,
      #splice.entry<"/build/source/programs" dir 555 mtime 1>,
      #splice.entry<"/build/source/programs/.gitignore" file 444 mtime 1 "b4b1d863ddf4c13ddcdbea5a5e513d16668ffd8ac8af090913c4e984d55b82b4">,
      #splice.entry<"/build/source/programs/COPYING" file 444 mtime 1 "609b910ef05c9c855ecc1da155a36ed0f57514eac452cf93446530b5ea4b3bc3">,
      #splice.entry<"/build/source/programs/Makefile" file 444 mtime 1 "968a0e4d62bbe67c35a3febb7d13c81fda7959d5641f10bf5d07e4e18759ca6c">,
      #splice.entry<"/build/source/programs/README.md" file 444 mtime 1 "d432e342c1f8dae1ce59732904c3ed36aa8e4604a0f1bb5e5af6c9f6c107e599">,
      #splice.entry<"/build/source/programs/bench.c" file 444 mtime 1 "53be2d318b2889d907a03e66a064d1a56dcca0b24c607296c722b9edfbbc5b70">,
      #splice.entry<"/build/source/programs/bench.h" file 444 mtime 1 "2ff152b06793b2010e1b3ed8cde8b13ff8720efd98acbdeab43595b730e07404">,
      #splice.entry<"/build/source/programs/lorem.c" file 444 mtime 1 "036908c08290d655ce45bbbc75c283da6bc8d2b31cd2106fffacf7fbb753839a">,
      #splice.entry<"/build/source/programs/lorem.h" file 444 mtime 1 "cabf55c784b8a53bfe0a4cbd159b9f5d5bfd335aedfb03be3ab9949719b53de9">,
      #splice.entry<"/build/source/programs/lz4-exe.rc.in" file 444 mtime 1 "685d449242bf97f2e89be11631755bf7ca4e3da325f2cc20b4ae5e797de92290">,
      #splice.entry<"/build/source/programs/lz4.1" file 444 mtime 1 "84e711b1283c2b79f5c5d225ed3dbe70a516e0b6bdda5279f395bd3d12ea7d19">,
      #splice.entry<"/build/source/programs/lz4.1.md" file 444 mtime 1 "dab60aab6e9890a5d547e4f501fc334cb067c17054ff186dfd94eba468231f3f">,
      #splice.entry<"/build/source/programs/lz4cli.c" file 444 mtime 1 "ac054905a90a0b12e7166d1299a5ab36df133345ed3a979c418914c9afb71f56">,
      #splice.entry<"/build/source/programs/lz4conf.h" file 444 mtime 1 "a764239ce093e7387ddac748246c7ca75d567ff011fbf23cba1b674a32f02fb2">,
      #splice.entry<"/build/source/programs/lz4io.c" file 444 mtime 1 "a9eb8e230cc3f80df64be6447ae3d425723313a37eb48dec3fc38d25c4c74575">,
      #splice.entry<"/build/source/programs/lz4io.h" file 444 mtime 1 "7134b42d8a90f33a5f304f18cac08517c777a4c8d8884d32244748008c3c833b">,
      #splice.entry<"/build/source/programs/platform.h" file 444 mtime 1 "35dd5a8f8d885efb81bfe9b2c7c47fa7a6ae353a6a47db8fc8a5b5029c43e430">,
      #splice.entry<"/build/source/programs/threadpool.c" file 444 mtime 1 "ce6e698084572f3fa6fd79709637c5b27d73a4fd03c21bb8b6fd4b9812156c03">,
      #splice.entry<"/build/source/programs/threadpool.h" file 444 mtime 1 "a196bdd5d2e790fa1daccd6165e9bc38f62a214813c0523b419a65f5b1642aba">,
      #splice.entry<"/build/source/programs/timefn.c" file 444 mtime 1 "ff3169880747ed50062081dac428d38f44eb26181fd53201f8add4b8a7b570be">,
      #splice.entry<"/build/source/programs/timefn.h" file 444 mtime 1 "e0667688ea12664799144b312f5765e1396136ef2e9dec20e2cf891cb8a1726b">,
      #splice.entry<"/build/source/programs/util.c" file 444 mtime 1 "c8ee5579f705d0b303e1332b60af4dccf03f802d6c4bf76e27be5ddc174de60f">,
      #splice.entry<"/build/source/programs/util.h" file 444 mtime 1 "b01eb516568cf9e18278a61b0c23fb46d48a25bb448c2a0bc9d609593d260a6d">,
      #splice.entry<"/build/source/tests" dir 555 mtime 1>,
      #splice.entry<"/build/source/tests/.gitignore" file 444 mtime 1 "e110e5d3e03c7a491bda4f5aab73a69bdbd8774f9c053a5004c879f496575373">,
      #splice.entry<"/build/source/tests/COPYING" file 444 mtime 1 "609b910ef05c9c855ecc1da155a36ed0f57514eac452cf93446530b5ea4b3bc3">,
      #splice.entry<"/build/source/tests/Makefile" file 444 mtime 1 "664522d40f4eef7908feaa4b50835d094f9bc6c0d70053449503c54b7e1cbbc7">,
      #splice.entry<"/build/source/tests/README.md" file 444 mtime 1 "5d54eb643e35a35c813034a5898643e527a371d72c699e68e46f74ce47cce1c1">,
      #splice.entry<"/build/source/tests/abiTest.c" file 444 mtime 1 "bc5dcbbe88d4c1ce369f191b71231f15e7a59fe632731dd9cfa3967d5a7ce930">,
      #splice.entry<"/build/source/tests/checkFrame.c" file 444 mtime 1 "dc99d353ba1ca94cd7f90fbccda489f04c6c9d2f413132ad36e5e9c78f298dbf">,
      #splice.entry<"/build/source/tests/checkTag.c" file 444 mtime 1 "a49419f21d05aa45c7d82c7972064e1cd0d87ba6fe0a3417686337545d276445">,
      #splice.entry<"/build/source/tests/check_liblz4_version.sh" file 555 mtime 1 "e47a787d307711a2e1dd39bc04aa3ceeab0dbe5ec390e4b56891543706b6d0fb">,
      #splice.entry<"/build/source/tests/cmake" dir 555 mtime 1>,
      #splice.entry<"/build/source/tests/cmake/CMakeLists.txt" file 444 mtime 1 "7b618a9ede9eb205cfd63b01bfb207918be8b71317a1b45aaf032c3c694c082a">,
      #splice.entry<"/build/source/tests/datagen.c" file 444 mtime 1 "78e3ace5a00312a60350687c915d6dd6c3626ecf2b4fecb6906c7cbec4600c91">,
      #splice.entry<"/build/source/tests/datagen.h" file 444 mtime 1 "49ff2d1b70db6329f3b5d28d2befa11060a42fddbdad84b9388c40521ea6e71f">,
      #splice.entry<"/build/source/tests/datagencli.c" file 444 mtime 1 "5efac455360aa1e880e50ad3272b91aa0f606862b68d80bbe9e48167b246a249">,
      #splice.entry<"/build/source/tests/decompress-partial-usingDict.c" file 444 mtime 1 "71a5c13989dd6a5d3bb25631c3de5fc45c2c0e813d4e9db36bf8b934632b6499">,
      #splice.entry<"/build/source/tests/decompress-partial.c" file 444 mtime 1 "1414d2a725042c8fef07faa38ff373b8fe96d49042fc1035b75ad07b59232d6c">,
      #splice.entry<"/build/source/tests/frametest.c" file 444 mtime 1 "5427f269bff29a542302fd6a24990cee5f0bdf35387e71f9a5fce9f12279205a">,
      #splice.entry<"/build/source/tests/freestanding.c" file 444 mtime 1 "ba375837e8ec8b597023f57c071470741b6359c7b4cbcdf9729f13173faec116">,
      #splice.entry<"/build/source/tests/fullbench.c" file 444 mtime 1 "b0cc4fc9efdb1586a6325161334655406de82bb4bf33fcea48f7a7f0c31e4c41">,
      #splice.entry<"/build/source/tests/fuzzer.c" file 444 mtime 1 "12b107129e9ad71430a8a3693bd8b5aeb3b9fb443ee04ff7778952d1ec971b84">,
      #splice.entry<"/build/source/tests/goldenSamples" dir 555 mtime 1>,
      #splice.entry<"/build/source/tests/goldenSamples/skip.bin" file 444 mtime 1 "3fec2ac0604510a1327930b4450f2b48080d648a1d593d7b3b2072394275adc4">,
      #splice.entry<"/build/source/tests/loremOut.c" file 444 mtime 1 "fc958cac885b4a161f52e9be7d83f27c0ac481e71f78ad2074f7124c2b03576f">,
      #splice.entry<"/build/source/tests/loremOut.h" file 444 mtime 1 "a5fcb7823171e68f64e607a729ab47b44ad5c3488a86221de05301d692e68582">,
      #splice.entry<"/build/source/tests/roundTripTest.c" file 444 mtime 1 "8266d37dff64896b6d31684b74c17e8b0a9e03c2d439699011fe568cf0ba44e8">,
      #splice.entry<"/build/source/tests/test-lz4-abi.py" file 444 mtime 1 "aaf306f9902e293d4c756d9ef1de2bb68dd254312136b7e0f069a29d302d9bcd">,
      #splice.entry<"/build/source/tests/test-lz4-basic.sh" file 555 mtime 1 "b8d7ba818315a8669c5996ed66c6b44d651fd9d23a5e0691efa9e5cc2ae6d528">,
      #splice.entry<"/build/source/tests/test-lz4-contentSize.sh" file 555 mtime 1 "6004277857d437379f858651fdc3debf0758c3c41168077da183aecc8604167a">,
      #splice.entry<"/build/source/tests/test-lz4-dict.sh" file 555 mtime 1 "2daa93e9c380933793616760b3d2c1c6cc4f32a3fc76302b96be429c73937d87">,
      #splice.entry<"/build/source/tests/test-lz4-fast-hugefile.sh" file 555 mtime 1 "01b9924b5e2b4a0bcc56e28b7a677c750a21b27acb28715ac377f2fd6facdb4e">,
      #splice.entry<"/build/source/tests/test-lz4-frame-concatenation.sh" file 555 mtime 1 "4b9184b3fe9bba488a7bc2709f4555c3befc83412d453bad47bf5b5853d5f30d">,
      #splice.entry<"/build/source/tests/test-lz4-list.py" file 444 mtime 1 "8b1492a9ce36b612f979ec2bf9e9813b4ef78cf8234ef16f424686e7db602a27">,
      #splice.entry<"/build/source/tests/test-lz4-multiple-legacy.sh" file 555 mtime 1 "ac081caecc1a6f807d9ff507fbaa678281c6cac78c9e7968c985ec76e41c6cd4">,
      #splice.entry<"/build/source/tests/test-lz4-multiple.sh" file 555 mtime 1 "3f70ecf7801f4fc9ba29cca094118ab907e387c01e0209bf7afeda6297298eaa">,
      #splice.entry<"/build/source/tests/test-lz4-opt-parser.sh" file 555 mtime 1 "7a8196f8753bf2572eb2665a149dc892894dc10461ad9b4f0ac1517c0d1f4d21">,
      #splice.entry<"/build/source/tests/test-lz4-skippable.sh" file 555 mtime 1 "cf65c010400f37147f7de8921328c80f48f6f98c00cfa6522f0c9b2089baf0f4">,
      #splice.entry<"/build/source/tests/test-lz4-sparse.sh" file 555 mtime 1 "7f790027646768ae8968ab78f13a8d187c71bce6d591f5f36758f4053da2b7b4">,
      #splice.entry<"/build/source/tests/test-lz4-speed.py" file 444 mtime 1 "1a4e6d0aa1e54c809cf69547dfbd7bca20d0792e5bf54b0651d279f271de5d1e">,
      #splice.entry<"/build/source/tests/test-lz4-testmode.sh" file 555 mtime 1 "dd4c1a0a2431b02fd4385e241f7115467b26f5d825fc3440c55133a5293f821b">,
      #splice.entry<"/build/source/tests/test-lz4-versions.py" file 444 mtime 1 "55bc0eae86cf1cd1200563bf236ffc49514c8d99493fef5d6562f772e5b219ac">,
      #splice.entry<"/build/source/tests/test-lz4hc-hugefile.sh" file 555 mtime 1 "d91f4b3199377453b034e5ef7857abac0bbda0f4b566b797dac6a6ecc11bc165">,
      #splice.entry<"/build/source/tests/test_custom_block_sizes.sh" file 555 mtime 1 "8466f9a3cf99bf29085ad6cbf8f28b3cae90ed2bf7acc456e4cd5ecdc7f91130">,
      #splice.entry<"/build/source/tests/test_install.sh" file 555 mtime 1 "772b9013a80289806af837968afda5055531a5456e9ecba056ba82ec67a222d1">,
      #splice.entry<"/build/source/tests/unicode_lint.sh" file 444 mtime 1 "db8249c743951146f1b76746344a86bf08eec17c307700244a2f17340981ba69">
  ]
  %chmod_2578:44 = splice.literal "chmod" at 2578 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>,
      #splice.entry<"/build/source/.circleci" dir 755 mtime 1>,
      #splice.entry<"/build/source/.circleci/images" dir 755 mtime 1>,
      #splice.entry<"/build/source/.circleci/images/primary" dir 755 mtime 1>,
      #splice.entry<"/build/source/.github" dir 755 mtime 1>,
      #splice.entry<"/build/source/.github/ISSUE_TEMPLATE" dir 755 mtime 1>,
      #splice.entry<"/build/source/.github/workflows" dir 755 mtime 1>,
      #splice.entry<"/build/source/build" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/datagen" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/frametest" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/fullbench" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/fullbench-dll" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/fuzzer" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/liblz4" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/liblz4-dll" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/VS2022/lz4" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/cmake" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/contrib" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/contrib/gen_manual" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/examples" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/lib" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/ossfuzz" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/programs" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/meson/meson/tests" dir 755 mtime 1>,
      #splice.entry<"/build/source/build/visual" dir 755 mtime 1>,
      #splice.entry<"/build/source/contrib" dir 755 mtime 1>,
      #splice.entry<"/build/source/contrib/debian" dir 755 mtime 1>,
      #splice.entry<"/build/source/contrib/debian/docs" file 644 mtime 1 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/source/contrib/djgpp" dir 755 mtime 1>,
      #splice.entry<"/build/source/contrib/gen_manual" dir 755 mtime 1>,
      #splice.entry<"/build/source/contrib/snap" dir 755 mtime 1>,
      #splice.entry<"/build/source/doc" dir 755 mtime 1>,
      #splice.entry<"/build/source/examples" dir 755 mtime 1>,
      #splice.entry<"/build/source/lib" dir 755 mtime 1>,
      #splice.entry<"/build/source/lib/dll" dir 755 mtime 1>,
      #splice.entry<"/build/source/lib/dll/example" dir 755 mtime 1>,
      #splice.entry<"/build/source/ossfuzz" dir 755 mtime 1>,
      #splice.entry<"/build/source/programs" dir 755 mtime 1>,
      #splice.entry<"/build/source/tests" dir 755 mtime 1>,
      #splice.entry<"/build/source/tests/cmake" dir 755 mtime 1>,
      #splice.entry<"/build/source/tests/goldenSamples" dir 755 mtime 1>
  ]
  %chmod_2578_0 = splice.copy "chmod" at 2578(%cp_2139#2) -> <"/build/source/.circleci/config.yml" file 644 mtime 1 "6c113a8499cf7a54eb5591c4682e85bd302edfba9dd2364d5b786d30b282fd1b">
  %chmod_2578_1 = splice.copy "chmod" at 2578(%cp_2139#5) -> <"/build/source/.circleci/images/primary/Dockerfile" file 644 mtime 1 "089c2787497982d7d452965ecf2afd93c6ef784c1aae7f37132edd064db7b5de">
  %chmod_2578_2 = splice.copy "chmod" at 2578(%cp_2139#6) -> <"/build/source/.cirrus.yml" file 644 mtime 1 "e722a00d220a188578251a429fbb1a71fd4f8083f1c7411525ad790505888f81">
  %chmod_2578_3 = splice.copy "chmod" at 2578(%cp_2139#7) -> <"/build/source/.clang-format" file 644 mtime 1 "16e5bda1506fb355634ada730bc26ed838ca800b1d8a2c0a0161e22fff36ba12">
  %chmod_2578_4 = splice.copy "chmod" at 2578(%cp_2139#8) -> <"/build/source/.gitattributes" file 644 mtime 1 "0ee157945a4a1cc81ac5bd2f9d6a985363516201f50cda9602f4a6a16fb778bb">
  %chmod_2578_5 = splice.copy "chmod" at 2578(%cp_2139#11) -> <"/build/source/.github/ISSUE_TEMPLATE/bug_report.md" file 644 mtime 1 "028e2a11008f4cea32c73c1ef2e761ec8deb1ab2fa7440704ce6eaf3ffe3fd40">
  %chmod_2578_6 = splice.copy "chmod" at 2578(%cp_2139#12) -> <"/build/source/.github/ISSUE_TEMPLATE/feature_request.md" file 644 mtime 1 "1f48c52f209a971b8e7eae4120144d28fcf8ee38a7778a7b4d8cf1ab356617d2">
  %chmod_2578_7 = splice.copy "chmod" at 2578(%cp_2139#13) -> <"/build/source/.github/dependabot.yaml" file 644 mtime 1 "9804ed1afdf6b83d6284bf86e24804121fedbd19000ac33dd332960618d00cb7">
  %chmod_2578_8 = splice.copy "chmod" at 2578(%cp_2139#15) -> <"/build/source/.github/workflows/README.md" file 644 mtime 1 "0564491e914090654c14e6297e96edc0b2b74699dbdf99d2f16938e366633d0e">
  %chmod_2578_9 = splice.copy "chmod" at 2578(%cp_2139#16) -> <"/build/source/.github/workflows/ci.yml" file 644 mtime 1 "4a9f2253ec0f6e67289db1b5bb012ee4a077ed1b1ba5f86dbe4a31f8b2dde09f">
  %chmod_2578_10 = splice.copy "chmod" at 2578(%cp_2139#17) -> <"/build/source/.github/workflows/scorecard.yml" file 644 mtime 1 "430feb09dacc383b24c5dbad98b583f794d1b21bab76f7aa849f918316fb1d07">
  %chmod_2578_11 = splice.copy "chmod" at 2578(%cp_2139#18) -> <"/build/source/.gitignore" file 644 mtime 1 "ed881bec37d9dc626660f772f079d0ef6901aae43df41466e395fda64f0c5b73">
  %chmod_2578_12 = splice.copy "chmod" at 2578(%cp_2139#19) -> <"/build/source/CODING_STYLE" file 644 mtime 1 "4d58f5535566c9abf3ea506e5133dbea88cb2cbcba6a255feeb3e08f99903fc9">
  %chmod_2578_13 = splice.copy "chmod" at 2578(%cp_2139#20) -> <"/build/source/INSTALL" file 644 mtime 1 "e40cb31226d6f2e42ccc84eb8e0d867776d06846d7c5b7889bc733a5618debad">
  %chmod_2578_14 = splice.copy "chmod" at 2578(%cp_2139#21) -> <"/build/source/LICENSE" file 644 mtime 1 "4bc9c403f6b679cc076dee210e0e21c27b4e8f6d3fb43d85364c76657bfaaac5">
  %chmod_2578_15 = splice.copy "chmod" at 2578(%cp_2139#22) -> <"/build/source/Makefile" file 644 mtime 1 "db7644c69a321c101dc629f4cef78fe8bf7bc3ea3a0cd25509be9de77b6ab8bb">
  %chmod_2578_16 = splice.copy "chmod" at 2578(%cp_2139#23) -> <"/build/source/Makefile.inc" file 644 mtime 1 "baca7e166c422e03601afa31f280ce2e524ad11c0d277f20241c4b3930e74184">
  %chmod_2578_17 = splice.copy "chmod" at 2578(%cp_2139#24) -> <"/build/source/NEWS" file 644 mtime 1 "8fe6e56a9c40846fdf47caa045bef1e0db7c7f020164fd127de0fa1222c2f7f8">
  %chmod_2578_18 = splice.copy "chmod" at 2578(%cp_2139#25) -> <"/build/source/README.md" file 644 mtime 1 "ac443b7277c11613ffe1f80796bc5fcaaa32e5c746e8c77f689a501431d685be">
  %chmod_2578_19 = splice.copy "chmod" at 2578(%cp_2139#26) -> <"/build/source/SECURITY.md" file 644 mtime 1 "45156d03a137a23adf8d424aa29bd02212c47678e98b910dabea4f228b671404">
  %chmod_2578_20 = splice.copy "chmod" at 2578(%cp_2139#27) -> <"/build/source/appveyor.yml" file 644 mtime 1 "abc939aebe97490e58ee3962f78c9346e10cae1d95cf2b884d67b380042d05fd">
  %chmod_2578_21 = splice.copy "chmod" at 2578(%cp_2139#29) -> <"/build/source/build/.gitignore" file 644 mtime 1 "e61f3bd7d02901a8119359dd16f079c36972c5125b13ab599821fb050893f6ce">
  %chmod_2578_22 = splice.copy "chmod" at 2578(%cp_2139#30) -> <"/build/source/build/README.md" file 644 mtime 1 "507db4abd9c27524ef4c3b3a9f41963b23cebdda5b9d390ca3f4306c9b0c2d6f">
  %chmod_2578_23 = splice.copy "chmod" at 2578(%cp_2139#32) -> <"/build/source/build/VS2022/_build.bat" file 644 mtime 1 "f2041923370d9173d0f95e39a6d9c485ef2c72e8028cdad16bc76d5c2b29967b">
  %chmod_2578_24 = splice.copy "chmod" at 2578(%cp_2139#33) -> <"/build/source/build/VS2022/_setup.bat" file 644 mtime 1 "d218dd97e1a446a4ab4ad7774f5099618af3bec78b94418be14e9e655576c51b">
  %chmod_2578_25 = splice.copy "chmod" at 2578(%cp_2139#34) -> <"/build/source/build/VS2022/_test.bat" file 644 mtime 1 "f9f0f29042b29dadb7ff13ca951b9fd849979fbee1ab434095ae4f69ecb4d8a8">
  %chmod_2578_26 = splice.copy "chmod" at 2578(%cp_2139#35) -> <"/build/source/build/VS2022/build-and-test-win32-debug.bat" file 644 mtime 1 "8bce077079f0783a4bb77c0278e51b93dca5b0f9111a506bf3bd77a33d387250">
  %chmod_2578_27 = splice.copy "chmod" at 2578(%cp_2139#36) -> <"/build/source/build/VS2022/build-and-test-win32-release.bat" file 644 mtime 1 "66439d2595a06a23728949282db54553f73fc9250ad4c604d2f661a5cbc409b2">
  %chmod_2578_28 = splice.copy "chmod" at 2578(%cp_2139#37) -> <"/build/source/build/VS2022/build-and-test-x64-debug.bat" file 644 mtime 1 "979634ed143cf5bf10ebafea58f36c3dc46f0bcc1f00a65f293c9ea62f59c731">
  %chmod_2578_29 = splice.copy "chmod" at 2578(%cp_2139#38) -> <"/build/source/build/VS2022/build-and-test-x64-release.bat" file 644 mtime 1 "12737b37acbe59f39351b5071d1aa86ee0bdfcbae88967d8376ec3aad6bf3258">
  %chmod_2578_30 = splice.copy "chmod" at 2578(%cp_2139#40) -> <"/build/source/build/VS2022/datagen/datagen.vcxproj" file 644 mtime 1 "5d77e7f65b963d4ccab4f0518b5894b13590456387affe561eccc699f96f8bae">
  %chmod_2578_31 = splice.copy "chmod" at 2578(%cp_2139#42) -> <"/build/source/build/VS2022/frametest/frametest.vcxproj" file 644 mtime 1 "ac5b303ce5971b40d0a3a6b59c06b5fb256ef21415b609813bacc47113d79309">
  %chmod_2578_32 = splice.copy "chmod" at 2578(%cp_2139#45) -> <"/build/source/build/VS2022/fullbench-dll/fullbench-dll.vcxproj" file 644 mtime 1 "2c478b4bc6735e502626168d8a1bb6b881b963a2e6d2906e78f2fc12d043f863">
  %chmod_2578_33 = splice.copy "chmod" at 2578(%cp_2139#46) -> <"/build/source/build/VS2022/fullbench/fullbench.vcxproj" file 644 mtime 1 "f997c657ccb4544aa68527c3e5c8e244cf8688fc2334c628eef9d98717b03213">
  %chmod_2578_34 = splice.copy "chmod" at 2578(%cp_2139#48) -> <"/build/source/build/VS2022/fuzzer/fuzzer.vcxproj" file 644 mtime 1 "e25903cd48256c8e82da75e647ac8735594b1bbca412148bc3e2c951855e0834">
  %chmod_2578_35 = splice.copy "chmod" at 2578(%cp_2139#51) -> <"/build/source/build/VS2022/liblz4-dll/liblz4-dll.rc" file 644 mtime 1 "1e5895921e87a4f20e01142b83dabcedc8629eec825c519ab05363ecfa64019f">
  %chmod_2578_36 = splice.copy "chmod" at 2578(%cp_2139#52) -> <"/build/source/build/VS2022/liblz4-dll/liblz4-dll.vcxproj" file 644 mtime 1 "d8ccd02405f160675e71a998341511b293d6bd452e61cf9eed776f3995d1f74d">
  %chmod_2578_37 = splice.copy "chmod" at 2578(%cp_2139#53) -> <"/build/source/build/VS2022/liblz4/liblz4.vcxproj" file 644 mtime 1 "2edaf8aa9f667c353ad79f18e54d1165222a2fc68e32f317df65725bddd437e7">
  %chmod_2578_38 = splice.copy "chmod" at 2578(%cp_2139#55) -> <"/build/source/build/VS2022/lz4.sln" file 644 mtime 1 "dff63cc02684d6be5ff8a47a2a583ff896ab12fd30c063f54bc25337e0fbe6ed">
  %chmod_2578_39 = splice.copy "chmod" at 2578(%cp_2139#56) -> <"/build/source/build/VS2022/lz4/lz4.rc" file 644 mtime 1 "a7573b7b465664ca2a6df59202b9cf32b348b40e73a57fe4b81618542679ecf8">
  %chmod_2578_40 = splice.copy "chmod" at 2578(%cp_2139#57) -> <"/build/source/build/VS2022/lz4/lz4.vcxproj" file 644 mtime 1 "b5d6a8c6f946be257789b1f6cfd374c3f49fe60dd2da24dcfa9af9c16802c6ec">
  %chmod_2578_41 = splice.copy "chmod" at 2578(%cp_2139#59) -> <"/build/source/build/cmake/.gitignore" file 644 mtime 1 "df63e2dcb7f9c24d2f703e19bd21a7946355f6280f650a650d12beef6c3e1094">
  %chmod_2578_42 = splice.copy "chmod" at 2578(%cp_2139#60) -> <"/build/source/build/cmake/CMakeLists.txt" file 644 mtime 1 "2cbb76cb53831a81d4970b8e41d96a75cf7db219c45914fc99be038a7eb7c8ab">
  %chmod_2578_43 = splice.copy "chmod" at 2578(%cp_2139#61) -> <"/build/source/build/cmake/lz4Config.cmake.in" file 644 mtime 1 "5b24cac80e8a438e3a52a11721b0fbc9d00f7bf532eef5d62f0d894434f32462">
  %chmod_2578_44 = splice.copy "chmod" at 2578(%cp_2139#63) -> <"/build/source/build/meson/GetLz4LibraryVersion.py" file 644 mtime 1 "07e29b20bbe36d92e19a9b12492645b353fe0b255c0d0f2481d7db5e0b6b44fa">
  %chmod_2578_45 = splice.copy "chmod" at 2578(%cp_2139#64) -> <"/build/source/build/meson/README.md" file 644 mtime 1 "16be5030767265e9887c595769c6c234f2ae2002a565fa6f430d95b8bb48f350">
  %chmod_2578_46 = splice.copy "chmod" at 2578(%cp_2139#66) -> <"/build/source/build/meson/meson.build" file 644 mtime 1 "0637f14491a2087768c45f2580cbc3e54cd2d9f9157c80cdb37a1a9d180e4ff4">
  %chmod_2578_47 = splice.copy "chmod" at 2578(%cp_2139#69) -> <"/build/source/build/meson/meson/contrib/gen_manual/meson.build" file 644 mtime 1 "a66b74be0b0a0013f842bdbf1623bdfeca6a2d1c8062e9f9f07bbb3753be6087">
  %chmod_2578_48 = splice.copy "chmod" at 2578(%cp_2139#70) -> <"/build/source/build/meson/meson/contrib/meson.build" file 644 mtime 1 "4add6ee98356607280803194f4321ef9d181d5bb13a03cc41ff80caed57734cc">
  %chmod_2578_49 = splice.copy "chmod" at 2578(%cp_2139#72) -> <"/build/source/build/meson/meson/examples/meson.build" file 644 mtime 1 "78cde83e9ac2235635afb3ad1553968f9e702bdf85c961bea0ed58e4738e8538">
  %chmod_2578_50 = splice.copy "chmod" at 2578(%cp_2139#74) -> <"/build/source/build/meson/meson/lib/meson.build" file 644 mtime 1 "ff14075868a7e3daf4b12a60875d4b156659cde45a7f87cb181c282cc82d52dd">
  %chmod_2578_51 = splice.copy "chmod" at 2578(%cp_2139#75) -> <"/build/source/build/meson/meson/meson.build" file 644 mtime 1 "a2e489cc2024d87d1af98792c791fc07dda905c266dd8b15ba4293783780bd84">
  %chmod_2578_52 = splice.copy "chmod" at 2578(%cp_2139#77) -> <"/build/source/build/meson/meson/ossfuzz/meson.build" file 644 mtime 1 "4e1ddfc72bb94b789dcd0c9d4419e525e20e0f3a5456976472fdb9a020aecbc1">
  %chmod_2578_53 = splice.copy "chmod" at 2578(%cp_2139#79) -> <"/build/source/build/meson/meson/programs/meson.build" file 644 mtime 1 "0ec6b53e92243a0c6af17c47e42e58244539a2b8d6c6a4c76753d65379d87837">
  %chmod_2578_54 = splice.copy "chmod" at 2578(%cp_2139#81) -> <"/build/source/build/meson/meson/tests/meson.build" file 644 mtime 1 "2738e7d2a29a76aaa277834509404d3ef19f6883b62183c59a79247c4a1f17fc">
  %chmod_2578_55 = splice.copy "chmod" at 2578(%cp_2139#82) -> <"/build/source/build/meson/meson_options.txt" file 644 mtime 1 "4b98332d54b838775708f9b94784b692b45a78d4cda758f5d147c0ab88f9f2f2">
  %chmod_2578_56 = splice.copy "chmod" at 2578(%cp_2139#84) -> <"/build/source/build/visual/README.md" file 644 mtime 1 "a9cbf6a75a656a8991460f8560686ca1e230724e9e0c097940b18d960aa26bc4">
  %chmod_2578_57 = splice.copy "chmod" at 2578(%cp_2139#85) -> <"/build/source/build/visual/generate_solution.cmd" file 644 mtime 1 "533a5451fab9591834285c850d190faabd6e273e869ed2d4a283c8e73ee1e97b">
  %chmod_2578_58 = splice.copy "chmod" at 2578(%cp_2139#86) -> <"/build/source/build/visual/generate_vs2015.cmd" file 644 mtime 1 "5bbcb4cd1f52279b239abf9525589cdc7d082a85080ef7d50eb9ccbaba2b1c06">
  %chmod_2578_59 = splice.copy "chmod" at 2578(%cp_2139#87) -> <"/build/source/build/visual/generate_vs2017.cmd" file 644 mtime 1 "5b2cea61d288ce78518886f4e5c9525f7114bc32aba493a345913ad8e01ea03a">
  %chmod_2578_60 = splice.copy "chmod" at 2578(%cp_2139#88) -> <"/build/source/build/visual/generate_vs2019.cmd" file 644 mtime 1 "ab1d7d2d4c22c78efd47e97e67866f275c20b9e9ca0f3d1f2a75e042853a71d7">
  %chmod_2578_61 = splice.copy "chmod" at 2578(%cp_2139#89) -> <"/build/source/build/visual/generate_vs2022.cmd" file 644 mtime 1 "c6fe773f05470e0af8fef0a3672a4506f8c2a04b9b171c87eb64d827cc40087b">
  %chmod_2578_62 = splice.copy "chmod" at 2578(%cp_2139#92) -> <"/build/source/contrib/debian/changelog" file 644 mtime 1 "f7ab7d42941c818b67d13e72023be47600b9832b009585b0715c567efe770843">
  %chmod_2578_63 = splice.copy "chmod" at 2578(%cp_2139#93) -> <"/build/source/contrib/debian/compat" file 644 mtime 1 "10159baf262b43a92d95db59dae1f72c645127301661e0a3ce4e38b295a97c58">
  %chmod_2578_64 = splice.copy "chmod" at 2578(%cp_2139#94) -> <"/build/source/contrib/debian/control" file 644 mtime 1 "3ecfdd58076228049fec9a91abc2284a7b2e3b7c28ed9e20281c7a8585098af7">
  %chmod_2578_65 = splice.copy "chmod" at 2578(%cp_2139#95) -> <"/build/source/contrib/debian/copyright" file 644 mtime 1 "4f6ef9d0e844bf432d6a0abb2623f5a61175ae40f7f0e3665490311d89e3af87">
  %chmod_2578_66 = splice.copy "chmod" at 2578(%cp_2139#96) -> <"/build/source/contrib/debian/dirs" file 644 mtime 1 "5afd130d6d03c8c12e124ce767ed367ce303c84605fc32727db31534cb4e3916">
  %chmod_2578_67 = splice.copy "chmod" at 2578(%cp_2139#98) -> <"/build/source/contrib/debian/liblz4-dev.install" file 644 mtime 1 "7916058e85e36af6a8fc1e0001e8305520c584da9e0ccbea0d497968e1508dae">
  %chmod_2578_68 = splice.copy "chmod" at 2578(%cp_2139#99) -> <"/build/source/contrib/debian/liblz4.install" file 644 mtime 1 "1d6e28a20190fd6c9a965211a9c7b93b5bb9f84bdf5200656dabf672d266e76c">
  %chmod_2578_69 = splice.copy "chmod" at 2578(%cp_2139#100) -> <"/build/source/contrib/debian/rules" file 755 mtime 1 "947dff0b3c6be7f7e6f8a316d11794d68e5ba9beb96893a4a4fc556376c01109">
  %chmod_2578_70 = splice.copy "chmod" at 2578(%cp_2139#102) -> <"/build/source/contrib/djgpp/LICENSE" file 644 mtime 1 "d011d1e02cb32b71c1ce2922ab41a2e2ad30f4ecf8de22c078d53618205abc05">
  %chmod_2578_71 = splice.copy "chmod" at 2578(%cp_2139#103) -> <"/build/source/contrib/djgpp/Makefile" file 644 mtime 1 "e667732ec353b760939999a94dcba2907b289bf9e7e2ebb8feeaa426e95ba205">
  %chmod_2578_72 = splice.copy "chmod" at 2578(%cp_2139#104) -> <"/build/source/contrib/djgpp/README.MD" file 644 mtime 1 "1ec3f0dd6c6644bc3938fb52bc6caf29be557610f61ea60590c05d1bc02dd30c">
  %chmod_2578_73 = splice.copy "chmod" at 2578(%cp_2139#106) -> <"/build/source/contrib/gen_manual/.gitignore" file 644 mtime 1 "811706a7c3519391761ad5796aec9454585cbbb98757faa282e5745a2e0b5cce">
  %chmod_2578_74 = splice.copy "chmod" at 2578(%cp_2139#107) -> <"/build/source/contrib/gen_manual/Makefile" file 644 mtime 1 "08d432ee7fec941c1b53bcf083832e954770320bd0a4d6347d274ac96e11df8f">
  %chmod_2578_75 = splice.copy "chmod" at 2578(%cp_2139#108) -> <"/build/source/contrib/gen_manual/README.md" file 644 mtime 1 "26efd8ee20dddef8b9e076b170dd932a82467259a07e02180e68b78e10f453ed">
  %chmod_2578_76 = splice.copy "chmod" at 2578(%cp_2139#109) -> <"/build/source/contrib/gen_manual/gen-lz4-manual.sh" file 644 mtime 1 "7a888d6f86b4c61f830396a3421e18a9c47786a782d923a0f1f9b0d9dae0ff75">
  %chmod_2578_77 = splice.copy "chmod" at 2578(%cp_2139#110) -> <"/build/source/contrib/gen_manual/gen_manual.cpp" file 644 mtime 1 "97dac662a59fac29a965c88724d43d960c53b7594f24660dd8e5dd825f310098">
  %chmod_2578_78 = splice.copy "chmod" at 2578(%cp_2139#112) -> <"/build/source/contrib/snap/README.md" file 644 mtime 1 "9b9d26c4c296d459c7d0daf3adf47895249a7b03fb3eb29f2b5dd60f0ff33e3b">
  %chmod_2578_79 = splice.copy "chmod" at 2578(%cp_2139#113) -> <"/build/source/contrib/snap/snapcraft.yaml" file 644 mtime 1 "fe0ef6db6d0ca2e900243d74bb15fba058a1d901f9cfd2e23356eb4d88eb55aa">
  %chmod_2578_80 = splice.copy "chmod" at 2578(%cp_2139#115) -> <"/build/source/doc/lz4_Block_format.md" file 644 mtime 1 "dce3c34a8738c44ed1dffb48c73e30297fca98ba7881408dc228865912c9a42e">
  %chmod_2578_81 = splice.copy "chmod" at 2578(%cp_2139#116) -> <"/build/source/doc/lz4_Frame_format.md" file 644 mtime 1 "8c2a10c4b99be177b874020cf4839d374d7a895b3c4d5292623edf948a13cc8f">
  %chmod_2578_82 = splice.copy "chmod" at 2578(%cp_2139#117) -> <"/build/source/doc/lz4_manual.html" file 644 mtime 1 "d3ba8f6d993890c7c6c077354944c67aa85b319a3a74a361ab5d5590fea37772">
  %chmod_2578_83 = splice.copy "chmod" at 2578(%cp_2139#118) -> <"/build/source/doc/lz4frame_manual.html" file 644 mtime 1 "16d83fc4920d1df5e26c3de9e1c6c24fe0233033fb1c8c52c0ef689cb20a11d3">
  %chmod_2578_84 = splice.copy "chmod" at 2578(%cp_2139#120) -> <"/build/source/examples/.gitignore" file 644 mtime 1 "459867356142284a4f69797f425965807fecf3854cf4a83f9c83ac93b029a09b">
  %chmod_2578_85 = splice.copy "chmod" at 2578(%cp_2139#121) -> <"/build/source/examples/COPYING" file 644 mtime 1 "609b910ef05c9c855ecc1da155a36ed0f57514eac452cf93446530b5ea4b3bc3">
  %chmod_2578_86 = splice.copy "chmod" at 2578(%cp_2139#122) -> <"/build/source/examples/Makefile" file 644 mtime 1 "acffd261b81d8f4cff9910fb53a5d415d0b706262795202655be404b44fca4b2">
  %chmod_2578_87 = splice.copy "chmod" at 2578(%cp_2139#123) -> <"/build/source/examples/README.md" file 644 mtime 1 "3dac202b4aa4c03b4921da6ffd2db11791373826ad668614b8ae48fab8283bb5">
  %chmod_2578_88 = splice.copy "chmod" at 2578(%cp_2139#124) -> <"/build/source/examples/bench_functions.c" file 644 mtime 1 "a3b55cf6bdde878639823a8879dde969b6e0f42f565bae56b9b3a38edc89d7fa">
  %chmod_2578_89 = splice.copy "chmod" at 2578(%cp_2139#125) -> <"/build/source/examples/blockStreaming_doubleBuffer.c" file 644 mtime 1 "8eb96317f1454db6b400b9da7b73ac435b16c50401b68b3e571e7efa7d29d72c">
  %chmod_2578_90 = splice.copy "chmod" at 2578(%cp_2139#126) -> <"/build/source/examples/blockStreaming_doubleBuffer.md" file 644 mtime 1 "186607a249d039a9b558592719845ee13222284d4bc8c90eb577a1697007dab0">
  %chmod_2578_91 = splice.copy "chmod" at 2578(%cp_2139#127) -> <"/build/source/examples/blockStreaming_lineByLine.c" file 644 mtime 1 "f236d3e7a2511475ebf25f8d354ee2d6733c73e67587c65670aeecabc3f1669d">
  %chmod_2578_92 = splice.copy "chmod" at 2578(%cp_2139#128) -> <"/build/source/examples/blockStreaming_lineByLine.md" file 644 mtime 1 "ed6bf3a195f0aa55c710c9cb785da3247f0285e7269478cced0b320d4405b312">
  %chmod_2578_93 = splice.copy "chmod" at 2578(%cp_2139#129) -> <"/build/source/examples/blockStreaming_ringBuffer.c" file 644 mtime 1 "de8fd5cdc83552ff190203004ddb1cacd54174ad3adab68dae7cc20d4994debf">
  %chmod_2578_94 = splice.copy "chmod" at 2578(%cp_2139#130) -> <"/build/source/examples/dictionaryRandomAccess.c" file 644 mtime 1 "c169b03e47269c445ce3adf028bd76ae8c011735a1322f51e2a13a792d7945e5">
  %chmod_2578_95 = splice.copy "chmod" at 2578(%cp_2139#131) -> <"/build/source/examples/dictionaryRandomAccess.md" file 644 mtime 1 "013d1e25de9217ff6224d14522f2a562901c78216cafd832f77c1921175abfe7">
  %chmod_2578_96 = splice.copy "chmod" at 2578(%cp_2139#132) -> <"/build/source/examples/fileCompress.c" file 644 mtime 1 "4f0842885669b01d003ec2a8c6fc9ef22705053a2d787ab145c3fa0a66fc1aa1">
  %chmod_2578_97 = splice.copy "chmod" at 2578(%cp_2139#133) -> <"/build/source/examples/frameCompress.c" file 644 mtime 1 "bd6e2e3b7243769dce5a35837c6c4cef726d93405e887844355784ee39d7f3c2">
  %chmod_2578_98 = splice.copy "chmod" at 2578(%cp_2139#134) -> <"/build/source/examples/print_version.c" file 644 mtime 1 "dcc2f58fe93bb7f50a1b459e54e99abae5ebd41363b0abf54e5a683f5340fbf0">
  %chmod_2578_99 = splice.copy "chmod" at 2578(%cp_2139#135) -> <"/build/source/examples/simple_buffer.c" file 644 mtime 1 "ac685d4e02a449d067f35720b92297643c6b1e639e3bf29ec4197143c98304f9">
  %chmod_2578_100 = splice.copy "chmod" at 2578(%cp_2139#136) -> <"/build/source/examples/streamingHC_ringBuffer.c" file 644 mtime 1 "de97d059a99a6db0934930eff946ccbc9daf7f111ec5e60651e65f2b79153de5">
  %chmod_2578_101 = splice.copy "chmod" at 2578(%cp_2139#137) -> <"/build/source/examples/streaming_api_basics.md" file 644 mtime 1 "f5f623970b6f533586fe2cb6dd12bcd82f0852a35d1d3406eef2ab86323831e7">
  %chmod_2578_102 = splice.copy "chmod" at 2578(%cp_2139#139) -> <"/build/source/lib/.gitignore" file 644 mtime 1 "406c783739cdb6f0adeca09a62d91ef94d35c9ba5abda0374bd214ee12b1882c">
  %chmod_2578_103 = splice.copy "chmod" at 2578(%cp_2139#140) -> <"/build/source/lib/LICENSE" file 644 mtime 1 "8b58c446121a109ccf32edc094bba3010a3d85e4ee3702950db55e4d3e87736c">
  %chmod_2578_104 = splice.copy "chmod" at 2578(%cp_2139#141) -> <"/build/source/lib/Makefile" file 644 mtime 1 "f5347c9e0c5e36e8be3329c8ca91c6bafbf4f6494f0484c2e8017eaa932e8c8f">
  %chmod_2578_105 = splice.copy "chmod" at 2578(%cp_2139#142) -> <"/build/source/lib/README.md" file 644 mtime 1 "a26e68719f64ebdef6ea1a9c0ca7bf76892a49d041e336364bcf91bbfb1875eb">
  %chmod_2578_106 = splice.copy "chmod" at 2578(%cp_2139#145) -> <"/build/source/lib/dll/example/Makefile" file 644 mtime 1 "1e035be57a8c3613726d39a56ebcffb20a8f4560e89bb3827edd3b98535561f7">
  %chmod_2578_107 = splice.copy "chmod" at 2578(%cp_2139#146) -> <"/build/source/lib/dll/example/README.md" file 644 mtime 1 "3bfef50f199e2d06312368ecfb7198f7b5e34eff03720b9aee6783a76277cff2">
  %chmod_2578_108 = splice.copy "chmod" at 2578(%cp_2139#147) -> <"/build/source/lib/dll/example/fullbench-dll.sln" file 644 mtime 1 "af0c9152e1109cea3e7a997e59dc435f032526c238e95681741e2a2f12ad0a74">
  %chmod_2578_109 = splice.copy "chmod" at 2578(%cp_2139#148) -> <"/build/source/lib/dll/example/fullbench-dll.vcxproj" file 644 mtime 1 "aadb61a66fb7f024a55406e253b7443742f7eb68193e0f143a73dcaf7ec6b240">
  %chmod_2578_110 = splice.copy "chmod" at 2578(%cp_2139#149) -> <"/build/source/lib/liblz4-dll.rc.in" file 644 mtime 1 "22860be8bafdeb276f3616177c32e00a8e620c59877d97600f43b0853ca6216d">
  %chmod_2578_111 = splice.copy "chmod" at 2578(%cp_2139#150) -> <"/build/source/lib/liblz4.pc.in" file 644 mtime 1 "f2fc76098b8b3282bf63d4b3b5654195097e2125c14bbcea83a4897118412227">
  %chmod_2578_112 = splice.copy "chmod" at 2578(%cp_2139#151) -> <"/build/source/lib/lz4.c" file 644 mtime 1 "9396f7de527bc8435de9c7569fb7998e56545a84b4f3c2d808c0235c01774539">
  %chmod_2578_113 = splice.copy "chmod" at 2578(%cp_2139#152) -> <"/build/source/lib/lz4.h" file 644 mtime 1 "26b82efc53d1570f3b54eef02e9c4764c1ad374ff03cac04e2ced5ea4d4c552f">
  %chmod_2578_114 = splice.copy "chmod" at 2578(%cp_2139#153) -> <"/build/source/lib/lz4file.c" file 644 mtime 1 "9c920fb21890bdce47d753bcd4a4dd3699ae75ac81ae7a999397c64fef012bec">
  %chmod_2578_115 = splice.copy "chmod" at 2578(%cp_2139#154) -> <"/build/source/lib/lz4file.h" file 644 mtime 1 "400ed90bc74324abcf338d37235dd81aa431fd815c22db4b369b88c12b213115">
  %chmod_2578_116 = splice.copy "chmod" at 2578(%cp_2139#155) -> <"/build/source/lib/lz4frame.c" file 644 mtime 1 "44f421bea199c7f11da263c717f063228cd2c8c05a8384d327b49cc81ccfbac4">
  %chmod_2578_117 = splice.copy "chmod" at 2578(%cp_2139#156) -> <"/build/source/lib/lz4frame.h" file 644 mtime 1 "b845db4b7ee1bfa64b8f641a94f62e7f636a8b5d673cc61766413782283aaad1">
  %chmod_2578_118 = splice.copy "chmod" at 2578(%cp_2139#157) -> <"/build/source/lib/lz4frame_static.h" file 644 mtime 1 "31ab72a6e97e4fa0bedd4420d24a3f1f8024cbfa1d8ffad88c87cbb4e04f769d">
  %chmod_2578_119 = splice.copy "chmod" at 2578(%cp_2139#158) -> <"/build/source/lib/lz4hc.c" file 644 mtime 1 "126cafafdb91767e6e55238298a910903851b35b2cee27ce80ae2280469ee232">
  %chmod_2578_120 = splice.copy "chmod" at 2578(%cp_2139#159) -> <"/build/source/lib/lz4hc.h" file 644 mtime 1 "e43824e8a9ba16f54100c4ccbccfa5782a858ca9ab83c48aac303fea3e76e21e">
  %chmod_2578_121 = splice.copy "chmod" at 2578(%cp_2139#160) -> <"/build/source/lib/xxhash.c" file 644 mtime 1 "b667033dc735fb5ea5648e0a61a2e065e5ef5bbda53669730063bd856c643c48">
  %chmod_2578_122 = splice.copy "chmod" at 2578(%cp_2139#161) -> <"/build/source/lib/xxhash.h" file 644 mtime 1 "aefdd236f35130495c18764cabed3f7b216906855fc5e6a9025cd2040bc84444">
  %chmod_2578_123 = splice.copy "chmod" at 2578(%cp_2139#163) -> <"/build/source/ossfuzz/.gitignore" file 644 mtime 1 "b640076c614fd77b7b33a023cc583eaecdf99332f4f18fa24f504ec7d91c9dfd">
  %chmod_2578_124 = splice.copy "chmod" at 2578(%cp_2139#164) -> <"/build/source/ossfuzz/Makefile" file 644 mtime 1 "f78aeb70e53a7bccd0dd947183a9727ebf8bfb1ce1c1df105860da00641518ad">
  %chmod_2578_125 = splice.copy "chmod" at 2578(%cp_2139#165) -> <"/build/source/ossfuzz/compress_frame_fuzzer.c" file 644 mtime 1 "3329efba2287ce33e5bf58c2f3460c407afebdb5d7bfdb5560fb9dd7b102f782">
  %chmod_2578_126 = splice.copy "chmod" at 2578(%cp_2139#166) -> <"/build/source/ossfuzz/compress_fuzzer.c" file 644 mtime 1 "f1ae2f302b1ad5a6aa160c792f9d1c0ce2c291b28a16bf2429de0fce3971857d">
  %chmod_2578_127 = splice.copy "chmod" at 2578(%cp_2139#167) -> <"/build/source/ossfuzz/compress_hc_fuzzer.c" file 644 mtime 1 "444b476026723697c8bc0be68a44ab434e281dd025a6a65d39c70981b422e6f3">
  %chmod_2578_128 = splice.copy "chmod" at 2578(%cp_2139#168) -> <"/build/source/ossfuzz/decompress_frame_fuzzer.c" file 644 mtime 1 "baf0dab7bfae0c7440f0488048dd45c846f809c11dcc0a9a781941f18df033b2">
  %chmod_2578_129 = splice.copy "chmod" at 2578(%cp_2139#169) -> <"/build/source/ossfuzz/decompress_fuzzer.c" file 644 mtime 1 "462b122196f8a2069e5e5c444528eacb04e8140b11bea20c835d6b6c67b88cb6">
  %chmod_2578_130 = splice.copy "chmod" at 2578(%cp_2139#170) -> <"/build/source/ossfuzz/fuzz.h" file 644 mtime 1 "0a004654a5e1ed8a40663f14136b9b36eb546567e8fa87a0dd50e4269d4bbf46">
  %chmod_2578_131 = splice.copy "chmod" at 2578(%cp_2139#171) -> <"/build/source/ossfuzz/fuzz_data_producer.c" file 644 mtime 1 "a12393758430ea5c2d1ec51118d9fc74e0c55444072a83adc00feb6037c888e0">
  %chmod_2578_132 = splice.copy "chmod" at 2578(%cp_2139#172) -> <"/build/source/ossfuzz/fuzz_data_producer.h" file 644 mtime 1 "4e30f91d4d61f7da92b285ba33dd1c6fc40fd9058fe95652b38808f45a38bda1">
  %chmod_2578_133 = splice.copy "chmod" at 2578(%cp_2139#173) -> <"/build/source/ossfuzz/fuzz_helpers.h" file 644 mtime 1 "877718ed9f8406883774f086402dbac72af4e4e5aa3965859b7624dd95c7c0d4">
  %chmod_2578_134 = splice.copy "chmod" at 2578(%cp_2139#174) -> <"/build/source/ossfuzz/lz4_helpers.c" file 644 mtime 1 "69b9957ae889774e3084f8b96e0d486ecb4816f2561a13dc42ebabf6e32faa58">
  %chmod_2578_135 = splice.copy "chmod" at 2578(%cp_2139#175) -> <"/build/source/ossfuzz/lz4_helpers.h" file 644 mtime 1 "a858177044de8a5921951ab4aa8fddae6130b1d257d637ba1ea012c541029734">
  %chmod_2578_136 = splice.copy "chmod" at 2578(%cp_2139#176) -> <"/build/source/ossfuzz/ossfuzz.sh" file 755 mtime 1 "31138e44b71510cc1a942e128facd1911cf9c20c6a3c610316e9d830700fb13a">
  %chmod_2578_137 = splice.copy "chmod" at 2578(%cp_2139#177) -> <"/build/source/ossfuzz/round_trip_frame_fuzzer.c" file 644 mtime 1 "3a07589f1deeabea74b1a4728b8528c45b3a1c7a27a783f503dbca5a35247071">
  %chmod_2578_138 = splice.copy "chmod" at 2578(%cp_2139#178) -> <"/build/source/ossfuzz/round_trip_frame_uncompressed_fuzzer.c" file 644 mtime 1 "a87dde93037a39eabc89950c31730b3d4d26f5a349cfb36491dc4265c7149804">
  %chmod_2578_139 = splice.copy "chmod" at 2578(%cp_2139#179) -> <"/build/source/ossfuzz/round_trip_fuzzer.c" file 644 mtime 1 "0c87880bd1301c4fc1255c34f9aca341479e22f0e5440c877b0db52aa9e04e0a">
  %chmod_2578_140 = splice.copy "chmod" at 2578(%cp_2139#180) -> <"/build/source/ossfuzz/round_trip_hc_fuzzer.c" file 644 mtime 1 "bc8aa628675f0366939fb583319c5fcc48e164439b03f4eef770ffab42086273">
  %chmod_2578_141 = splice.copy "chmod" at 2578(%cp_2139#181) -> <"/build/source/ossfuzz/round_trip_stream_fuzzer.c" file 644 mtime 1 "16f4773cee11b62a998f3d383be4a55780a910dcb5cc7299d8b2f87b444d13f1">
  %chmod_2578_142 = splice.copy "chmod" at 2578(%cp_2139#182) -> <"/build/source/ossfuzz/standaloneengine.c" file 644 mtime 1 "45a219de4aa04f76b2a7103fa82c10581131a7e5b486eedc8f65142cbe12fc40">
  %chmod_2578_143 = splice.copy "chmod" at 2578(%cp_2139#183) -> <"/build/source/ossfuzz/travisoss.sh" file 755 mtime 1 "bb5c86548ba064366499e334b2a845ee2074179876a10374e7492c9f4cb0e06d">
  %chmod_2578_144 = splice.copy "chmod" at 2578(%cp_2139#185) -> <"/build/source/programs/.gitignore" file 644 mtime 1 "b4b1d863ddf4c13ddcdbea5a5e513d16668ffd8ac8af090913c4e984d55b82b4">
  %chmod_2578_145 = splice.copy "chmod" at 2578(%cp_2139#186) -> <"/build/source/programs/COPYING" file 644 mtime 1 "609b910ef05c9c855ecc1da155a36ed0f57514eac452cf93446530b5ea4b3bc3">
  %chmod_2578_146 = splice.copy "chmod" at 2578(%cp_2139#187) -> <"/build/source/programs/Makefile" file 644 mtime 1 "968a0e4d62bbe67c35a3febb7d13c81fda7959d5641f10bf5d07e4e18759ca6c">
  %chmod_2578_147 = splice.copy "chmod" at 2578(%cp_2139#188) -> <"/build/source/programs/README.md" file 644 mtime 1 "d432e342c1f8dae1ce59732904c3ed36aa8e4604a0f1bb5e5af6c9f6c107e599">
  %chmod_2578_148 = splice.copy "chmod" at 2578(%cp_2139#189) -> <"/build/source/programs/bench.c" file 644 mtime 1 "53be2d318b2889d907a03e66a064d1a56dcca0b24c607296c722b9edfbbc5b70">
  %chmod_2578_149 = splice.copy "chmod" at 2578(%cp_2139#190) -> <"/build/source/programs/bench.h" file 644 mtime 1 "2ff152b06793b2010e1b3ed8cde8b13ff8720efd98acbdeab43595b730e07404">
  %chmod_2578_150 = splice.copy "chmod" at 2578(%cp_2139#191) -> <"/build/source/programs/lorem.c" file 644 mtime 1 "036908c08290d655ce45bbbc75c283da6bc8d2b31cd2106fffacf7fbb753839a">
  %chmod_2578_151 = splice.copy "chmod" at 2578(%cp_2139#192) -> <"/build/source/programs/lorem.h" file 644 mtime 1 "cabf55c784b8a53bfe0a4cbd159b9f5d5bfd335aedfb03be3ab9949719b53de9">
  %chmod_2578_152 = splice.copy "chmod" at 2578(%cp_2139#193) -> <"/build/source/programs/lz4-exe.rc.in" file 644 mtime 1 "685d449242bf97f2e89be11631755bf7ca4e3da325f2cc20b4ae5e797de92290">
  %chmod_2578_153 = splice.copy "chmod" at 2578(%cp_2139#194) -> <"/build/source/programs/lz4.1" file 644 mtime 1 "84e711b1283c2b79f5c5d225ed3dbe70a516e0b6bdda5279f395bd3d12ea7d19">
  %chmod_2578_154 = splice.copy "chmod" at 2578(%cp_2139#195) -> <"/build/source/programs/lz4.1.md" file 644 mtime 1 "dab60aab6e9890a5d547e4f501fc334cb067c17054ff186dfd94eba468231f3f">
  %chmod_2578_155 = splice.copy "chmod" at 2578(%cp_2139#196) -> <"/build/source/programs/lz4cli.c" file 644 mtime 1 "ac054905a90a0b12e7166d1299a5ab36df133345ed3a979c418914c9afb71f56">
  %chmod_2578_156 = splice.copy "chmod" at 2578(%cp_2139#197) -> <"/build/source/programs/lz4conf.h" file 644 mtime 1 "a764239ce093e7387ddac748246c7ca75d567ff011fbf23cba1b674a32f02fb2">
  %chmod_2578_157 = splice.copy "chmod" at 2578(%cp_2139#198) -> <"/build/source/programs/lz4io.c" file 644 mtime 1 "a9eb8e230cc3f80df64be6447ae3d425723313a37eb48dec3fc38d25c4c74575">
  %chmod_2578_158 = splice.copy "chmod" at 2578(%cp_2139#199) -> <"/build/source/programs/lz4io.h" file 644 mtime 1 "7134b42d8a90f33a5f304f18cac08517c777a4c8d8884d32244748008c3c833b">
  %chmod_2578_159 = splice.copy "chmod" at 2578(%cp_2139#200) -> <"/build/source/programs/platform.h" file 644 mtime 1 "35dd5a8f8d885efb81bfe9b2c7c47fa7a6ae353a6a47db8fc8a5b5029c43e430">
  %chmod_2578_160 = splice.copy "chmod" at 2578(%cp_2139#201) -> <"/build/source/programs/threadpool.c" file 644 mtime 1 "ce6e698084572f3fa6fd79709637c5b27d73a4fd03c21bb8b6fd4b9812156c03">
  %chmod_2578_161 = splice.copy "chmod" at 2578(%cp_2139#202) -> <"/build/source/programs/threadpool.h" file 644 mtime 1 "a196bdd5d2e790fa1daccd6165e9bc38f62a214813c0523b419a65f5b1642aba">
  %chmod_2578_162 = splice.copy "chmod" at 2578(%cp_2139#203) -> <"/build/source/programs/timefn.c" file 644 mtime 1 "ff3169880747ed50062081dac428d38f44eb26181fd53201f8add4b8a7b570be">
  %chmod_2578_163 = splice.copy "chmod" at 2578(%cp_2139#204) -> <"/build/source/programs/timefn.h" file 644 mtime 1 "e0667688ea12664799144b312f5765e1396136ef2e9dec20e2cf891cb8a1726b">
  %chmod_2578_164 = splice.copy "chmod" at 2578(%cp_2139#205) -> <"/build/source/programs/util.c" file 644 mtime 1 "c8ee5579f705d0b303e1332b60af4dccf03f802d6c4bf76e27be5ddc174de60f">
  %chmod_2578_165 = splice.copy "chmod" at 2578(%cp_2139#206) -> <"/build/source/programs/util.h" file 644 mtime 1 "b01eb516568cf9e18278a61b0c23fb46d48a25bb448c2a0bc9d609593d260a6d">
  %chmod_2578_166 = splice.copy "chmod" at 2578(%cp_2139#208) -> <"/build/source/tests/.gitignore" file 644 mtime 1 "e110e5d3e03c7a491bda4f5aab73a69bdbd8774f9c053a5004c879f496575373">
  %chmod_2578_167 = splice.copy "chmod" at 2578(%cp_2139#209) -> <"/build/source/tests/COPYING" file 644 mtime 1 "609b910ef05c9c855ecc1da155a36ed0f57514eac452cf93446530b5ea4b3bc3">
  %chmod_2578_168 = splice.copy "chmod" at 2578(%cp_2139#210) -> <"/build/source/tests/Makefile" file 644 mtime 1 "664522d40f4eef7908feaa4b50835d094f9bc6c0d70053449503c54b7e1cbbc7">
  %chmod_2578_169 = splice.copy "chmod" at 2578(%cp_2139#211) -> <"/build/source/tests/README.md" file 644 mtime 1 "5d54eb643e35a35c813034a5898643e527a371d72c699e68e46f74ce47cce1c1">
  %chmod_2578_170 = splice.copy "chmod" at 2578(%cp_2139#212) -> <"/build/source/tests/abiTest.c" file 644 mtime 1 "bc5dcbbe88d4c1ce369f191b71231f15e7a59fe632731dd9cfa3967d5a7ce930">
  %chmod_2578_171 = splice.copy "chmod" at 2578(%cp_2139#213) -> <"/build/source/tests/checkFrame.c" file 644 mtime 1 "dc99d353ba1ca94cd7f90fbccda489f04c6c9d2f413132ad36e5e9c78f298dbf">
  %chmod_2578_172 = splice.copy "chmod" at 2578(%cp_2139#214) -> <"/build/source/tests/checkTag.c" file 644 mtime 1 "a49419f21d05aa45c7d82c7972064e1cd0d87ba6fe0a3417686337545d276445">
  %chmod_2578_173 = splice.copy "chmod" at 2578(%cp_2139#215) -> <"/build/source/tests/check_liblz4_version.sh" file 755 mtime 1 "e47a787d307711a2e1dd39bc04aa3ceeab0dbe5ec390e4b56891543706b6d0fb">
  %chmod_2578_174 = splice.copy "chmod" at 2578(%cp_2139#217) -> <"/build/source/tests/cmake/CMakeLists.txt" file 644 mtime 1 "7b618a9ede9eb205cfd63b01bfb207918be8b71317a1b45aaf032c3c694c082a">
  %chmod_2578_175 = splice.copy "chmod" at 2578(%cp_2139#218) -> <"/build/source/tests/datagen.c" file 644 mtime 1 "78e3ace5a00312a60350687c915d6dd6c3626ecf2b4fecb6906c7cbec4600c91">
  %chmod_2578_176 = splice.copy "chmod" at 2578(%cp_2139#219) -> <"/build/source/tests/datagen.h" file 644 mtime 1 "49ff2d1b70db6329f3b5d28d2befa11060a42fddbdad84b9388c40521ea6e71f">
  %chmod_2578_177 = splice.copy "chmod" at 2578(%cp_2139#220) -> <"/build/source/tests/datagencli.c" file 644 mtime 1 "5efac455360aa1e880e50ad3272b91aa0f606862b68d80bbe9e48167b246a249">
  %chmod_2578_178 = splice.copy "chmod" at 2578(%cp_2139#221) -> <"/build/source/tests/decompress-partial-usingDict.c" file 644 mtime 1 "71a5c13989dd6a5d3bb25631c3de5fc45c2c0e813d4e9db36bf8b934632b6499">
  %chmod_2578_179 = splice.copy "chmod" at 2578(%cp_2139#222) -> <"/build/source/tests/decompress-partial.c" file 644 mtime 1 "1414d2a725042c8fef07faa38ff373b8fe96d49042fc1035b75ad07b59232d6c">
  %chmod_2578_180 = splice.copy "chmod" at 2578(%cp_2139#223) -> <"/build/source/tests/frametest.c" file 644 mtime 1 "5427f269bff29a542302fd6a24990cee5f0bdf35387e71f9a5fce9f12279205a">
  %chmod_2578_181 = splice.copy "chmod" at 2578(%cp_2139#224) -> <"/build/source/tests/freestanding.c" file 644 mtime 1 "ba375837e8ec8b597023f57c071470741b6359c7b4cbcdf9729f13173faec116">
  %chmod_2578_182 = splice.copy "chmod" at 2578(%cp_2139#225) -> <"/build/source/tests/fullbench.c" file 644 mtime 1 "b0cc4fc9efdb1586a6325161334655406de82bb4bf33fcea48f7a7f0c31e4c41">
  %chmod_2578_183 = splice.copy "chmod" at 2578(%cp_2139#226) -> <"/build/source/tests/fuzzer.c" file 644 mtime 1 "12b107129e9ad71430a8a3693bd8b5aeb3b9fb443ee04ff7778952d1ec971b84">
  %chmod_2578_184 = splice.copy "chmod" at 2578(%cp_2139#228) -> <"/build/source/tests/goldenSamples/skip.bin" file 644 mtime 1 "3fec2ac0604510a1327930b4450f2b48080d648a1d593d7b3b2072394275adc4">
  %chmod_2578_185 = splice.copy "chmod" at 2578(%cp_2139#229) -> <"/build/source/tests/loremOut.c" file 644 mtime 1 "fc958cac885b4a161f52e9be7d83f27c0ac481e71f78ad2074f7124c2b03576f">
  %chmod_2578_186 = splice.copy "chmod" at 2578(%cp_2139#230) -> <"/build/source/tests/loremOut.h" file 644 mtime 1 "a5fcb7823171e68f64e607a729ab47b44ad5c3488a86221de05301d692e68582">
  %chmod_2578_187 = splice.copy "chmod" at 2578(%cp_2139#231) -> <"/build/source/tests/roundTripTest.c" file 644 mtime 1 "8266d37dff64896b6d31684b74c17e8b0a9e03c2d439699011fe568cf0ba44e8">
  %chmod_2578_188 = splice.copy "chmod" at 2578(%cp_2139#232) -> <"/build/source/tests/test-lz4-abi.py" file 644 mtime 1 "aaf306f9902e293d4c756d9ef1de2bb68dd254312136b7e0f069a29d302d9bcd">
  %chmod_2578_189 = splice.copy "chmod" at 2578(%cp_2139#233) -> <"/build/source/tests/test-lz4-basic.sh" file 755 mtime 1 "b8d7ba818315a8669c5996ed66c6b44d651fd9d23a5e0691efa9e5cc2ae6d528">
  %chmod_2578_190 = splice.copy "chmod" at 2578(%cp_2139#234) -> <"/build/source/tests/test-lz4-contentSize.sh" file 755 mtime 1 "6004277857d437379f858651fdc3debf0758c3c41168077da183aecc8604167a">
  %chmod_2578_191 = splice.copy "chmod" at 2578(%cp_2139#235) -> <"/build/source/tests/test-lz4-dict.sh" file 755 mtime 1 "2daa93e9c380933793616760b3d2c1c6cc4f32a3fc76302b96be429c73937d87">
  %chmod_2578_192 = splice.copy "chmod" at 2578(%cp_2139#236) -> <"/build/source/tests/test-lz4-fast-hugefile.sh" file 755 mtime 1 "01b9924b5e2b4a0bcc56e28b7a677c750a21b27acb28715ac377f2fd6facdb4e">
  %chmod_2578_193 = splice.copy "chmod" at 2578(%cp_2139#237) -> <"/build/source/tests/test-lz4-frame-concatenation.sh" file 755 mtime 1 "4b9184b3fe9bba488a7bc2709f4555c3befc83412d453bad47bf5b5853d5f30d">
  %chmod_2578_194 = splice.copy "chmod" at 2578(%cp_2139#238) -> <"/build/source/tests/test-lz4-list.py" file 644 mtime 1 "8b1492a9ce36b612f979ec2bf9e9813b4ef78cf8234ef16f424686e7db602a27">
  %chmod_2578_195 = splice.copy "chmod" at 2578(%cp_2139#239) -> <"/build/source/tests/test-lz4-multiple-legacy.sh" file 755 mtime 1 "ac081caecc1a6f807d9ff507fbaa678281c6cac78c9e7968c985ec76e41c6cd4">
  %chmod_2578_196 = splice.copy "chmod" at 2578(%cp_2139#240) -> <"/build/source/tests/test-lz4-multiple.sh" file 755 mtime 1 "3f70ecf7801f4fc9ba29cca094118ab907e387c01e0209bf7afeda6297298eaa">
  %chmod_2578_197 = splice.copy "chmod" at 2578(%cp_2139#241) -> <"/build/source/tests/test-lz4-opt-parser.sh" file 755 mtime 1 "7a8196f8753bf2572eb2665a149dc892894dc10461ad9b4f0ac1517c0d1f4d21">
  %chmod_2578_198 = splice.copy "chmod" at 2578(%cp_2139#242) -> <"/build/source/tests/test-lz4-skippable.sh" file 755 mtime 1 "cf65c010400f37147f7de8921328c80f48f6f98c00cfa6522f0c9b2089baf0f4">
  %chmod_2578_199 = splice.copy "chmod" at 2578(%cp_2139#243) -> <"/build/source/tests/test-lz4-sparse.sh" file 755 mtime 1 "7f790027646768ae8968ab78f13a8d187c71bce6d591f5f36758f4053da2b7b4">
  %chmod_2578_200 = splice.copy "chmod" at 2578(%cp_2139#244) -> <"/build/source/tests/test-lz4-speed.py" file 644 mtime 1 "1a4e6d0aa1e54c809cf69547dfbd7bca20d0792e5bf54b0651d279f271de5d1e">
  %chmod_2578_201 = splice.copy "chmod" at 2578(%cp_2139#245) -> <"/build/source/tests/test-lz4-testmode.sh" file 755 mtime 1 "dd4c1a0a2431b02fd4385e241f7115467b26f5d825fc3440c55133a5293f821b">
  %chmod_2578_202 = splice.copy "chmod" at 2578(%cp_2139#246) -> <"/build/source/tests/test-lz4-versions.py" file 644 mtime 1 "55bc0eae86cf1cd1200563bf236ffc49514c8d99493fef5d6562f772e5b219ac">
  %chmod_2578_203 = splice.copy "chmod" at 2578(%cp_2139#247) -> <"/build/source/tests/test-lz4hc-hugefile.sh" file 755 mtime 1 "d91f4b3199377453b034e5ef7857abac0bbda0f4b566b797dac6a6ecc11bc165">
  %chmod_2578_204 = splice.copy "chmod" at 2578(%cp_2139#248) -> <"/build/source/tests/test_custom_block_sizes.sh" file 755 mtime 1 "8466f9a3cf99bf29085ad6cbf8f28b3cae90ed2bf7acc456e4cd5ecdc7f91130">
  %chmod_2578_205 = splice.copy "chmod" at 2578(%cp_2139#249) -> <"/build/source/tests/test_install.sh" file 755 mtime 1 "772b9013a80289806af837968afda5055531a5456e9ecba056ba82ec67a222d1">
  %chmod_2578_206 = splice.copy "chmod" at 2578(%cp_2139#250) -> <"/build/source/tests/unicode_lint.sh" file 644 mtime 1 "db8249c743951146f1b76746344a86bf08eec17c307700244a2f17340981ba69">
  %cat_patch_2801 = splice.copy "cat|patch" at 2801(%cp_2139#155) -> <"/build/source/lib/lz4frame.c.orig" file 644 mtime 1 "44f421bea199c7f11da263c717f063228cd2c8c05a8384d327b49cc81ccfbac4">
  %cat_patch_2801_207 = splice.copy "cat|patch" at 2801(%cp_2139#223) -> <"/build/source/tests/frametest.c.orig" file 644 mtime 1 "5427f269bff29a542302fd6a24990cee5f0bdf35387e71f9a5fce9f12279205a">
  %cat_patch_2801_208:4 = splice.exec "cat|patch" at 2801(%sandbox_716, %chmod_2578#0, %chmod_2578#36, %chmod_2578_116, %chmod_2578#41, %chmod_2578_180) -> [
      #splice.entry<"/build/source/lib/lz4frame.c" file 644 mtime 1795046400 "7a5e7bf2d7f1eec45541b6ce9625ef7979471873ac0073086f17426763d9958e">,
      #splice.entry<"/build/source/lib/lz4frame.c.orig" file 644 mtime 1 "44f421bea199c7f11da263c717f063228cd2c8c05a8384d327b49cc81ccfbac4">,
      #splice.entry<"/build/source/tests/frametest.c" file 644 mtime 1795046400 "f288f1883f8831c3d65cea835069161113d183af21c03a4626dc75cfa419ddec">,
      #splice.entry<"/build/source/tests/frametest.c.orig" file 644 mtime 1 "5427f269bff29a542302fd6a24990cee5f0bdf35387e71f9a5fce9f12279205a">
  ]
  %mkdir_3041 = splice.literal "mkdir" at 3041 folded -> [
      #splice.entry<"/build/source/build-dist" dir 755 mtime 1795046400>
  ]
  %cmake_3415:19 = splice.literal "cmake" at 3415 folded -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CompilerIdC" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CompilerIdC/tmp" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/CMakeScratch" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Export" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Export/c6df35774e34eeb792fb3cefd00f3726" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/pkgRedirects" dir 755 mtime 1795046400>
  ]
  %cmake_3415_209:74 = splice.exec "cmake" at 3415(%sandbox_716, %chmod_2578#0, %chmod_2578_14, %chmod_2578_18, %chmod_2578#7, %mkdir_3041, %chmod_2578#17, %chmod_2578_42, %chmod_2578_43, %chmod_2578#36, %chmod_2578_102, %chmod_2578_103, %chmod_2578_104, %chmod_2578_105, %chmod_2578#37, %chmod_2578_110, %chmod_2578_111, %chmod_2578_112, %chmod_2578_113, %chmod_2578_114, %chmod_2578_115, %cat_patch_2801_208#0, %cat_patch_2801, %chmod_2578_117, %chmod_2578_118, %chmod_2578_119, %chmod_2578_120, %chmod_2578_121, %chmod_2578_122, %chmod_2578#40, %chmod_2578_144, %chmod_2578_145, %chmod_2578_146, %chmod_2578_147, %chmod_2578_148, %chmod_2578_149, %chmod_2578_150, %chmod_2578_151, %chmod_2578_152, %chmod_2578_153, %chmod_2578_154, %chmod_2578_155, %chmod_2578_156, %chmod_2578_157, %chmod_2578_158, %chmod_2578_159, %chmod_2578_160, %chmod_2578_161, %chmod_2578_162, %chmod_2578_163, %chmod_2578_164, %chmod_2578_165) -> [
      #splice.entry<"/build/source/build-dist/CMakeCache.txt" file 644 mtime 1795046400 "686f96f8de21b09ec9fef59ad2ad92efc7ec27213972b3f110fe5e8c625620ff">,
      #splice.entry<"/build/source/build-dist/CMakeFiles" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CMakeCCompiler.cmake" file 444 mtime 1795046400 "4d15c686f1de2f3cdeedd689c0c41e3d5347ef1baf61ea57e65947736b3d78eb">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CMakeDetermineCompilerABI_C.bin" file 755 mtime 1795046400 "fc6b8494927ece50d5555b125d81621aaaf8e09c53a6e55d6bb98d303668c739">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CompilerIdC" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CompilerIdC/CMakeCCompilerId.c" file 644 mtime 1795046400 "6ccdb729a0b1d02ba3d9b57e617d311fbac288d9c0d32416c048ef044157f041">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CompilerIdC/a.out" file 755 mtime 1795046400 "1349fbf0695af2a9462a9a26f2b6d527cd5f7759fadfb5084836823d0f72c093">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CompilerIdC/tmp" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/CMakeDirectoryInformation.cmake" file 644 mtime 1795046400 "80c8487146791d97b4cb0dc202e99d54a10365e673b12cb17f7c64eb554d2962">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/CMakeRuleHashes.txt" file 644 mtime 1795046400 "d6b848de17eaac9696d28e75d69dbbdb064584a54cae6831e1a85df20af551e2">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/CMakeScratch" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Export" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Export/c6df35774e34eeb792fb3cefd00f3726" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Export/c6df35774e34eeb792fb3cefd00f3726/lz4Targets-release.cmake" file 644 mtime 1795046400 "9277c227556c6e26c7710c2148eb38f0a7778df7fa01aff0175fe3eb369eb886">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Export/c6df35774e34eeb792fb3cefd00f3726/lz4Targets.cmake" file 644 mtime 1795046400 "e5c35fa5f1a81ad5e7d1b5ff3e1f8ea09f0366916fd6aba5b94f7b610e9ebc83">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/InstallScripts.json" file 644 mtime 1795046400 "2a6500b61b0c4e6e6c51cac4960db6ac3831c2e56c86dc5430ecba3fe698bfcd">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Makefile.cmake" file 644 mtime 1795046400 "7e41e743355e296ac51373f12c101e9352ac8d089854c40cfd0313d3b57deb0b">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/Makefile2" file 644 mtime 1795046400 "a84c3974a8a91e12f5cf83703ac4576c0f3e6f6b54f1ef4d3c2d9bbb66d04bf2">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/TargetDirectories.txt" file 644 mtime 1795046400 "bcd24899dca412427b038a847f7c17034fc32adbf75b28410787a6ab58a58ecb">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/cmake.check_cache" file 644 mtime 1795046400 "a26189e394421da57f45706a07713c5720acd200a41711b0c0c590c3c63371c4">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir/DependInfo.cmake" file 644 mtime 1795046400 "b2ca23380b5c9dd7f07b120e32fb11a157a4def74d801994559b1c8c88f92f55">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir/build.make" file 644 mtime 1795046400 "693fc3b4ef746b5203a4d2dde8c6db5a1bd77ec5b4512f1df6d7c592a60f1205">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir/cmake_clean.cmake" file 644 mtime 1795046400 "4793f697b795b0ef79e4f3e3c8c66e5c64c0c30cd08b307fec5e8049a93cebf0">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir/compiler_depend.make" file 644 mtime 1795046400 "bf7817516a7a60be8e0f4f3fc715ca07bd8a29aeab293b2a3b6627b429575b36">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir/compiler_depend.ts" file 644 mtime 1795046400 "e1370ee074233af77f59560318ee3656e64c9ee44ca82baff5912cf7e016b652">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_lz4cat_symlink.dir/progress.make" file 644 mtime 1795046400 "6b68f5b8790c40260614ca7e011802d52327e8390adf6727882f131e41083ade">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir/DependInfo.cmake" file 644 mtime 1795046400 "b2ca23380b5c9dd7f07b120e32fb11a157a4def74d801994559b1c8c88f92f55">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir/build.make" file 644 mtime 1795046400 "734eef1e78e06844c935fb91c8f1c470289431e57fab3b416f87ad830424a090">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir/cmake_clean.cmake" file 644 mtime 1795046400 "82d1d7942817717aa6b7514136abb22866610dd7b1f34ddc21f79d1d4cf35b5a">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir/compiler_depend.make" file 644 mtime 1795046400 "1ee8a212c306a2cc5040b468996930ce9e136033e589b29c5571e70fe3cbba20">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir/compiler_depend.ts" file 644 mtime 1795046400 "e4062532850e1e64a2242ff43099c817f6b9dffbccf3f6dfc2620b36a1c277c7">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/create_unlz4_symlink.dir/progress.make" file 644 mtime 1795046400 "c8b56f1a37ca31b2314c5941dea969318114637530da4f16188ae76848bc0730">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/DependInfo.cmake" file 644 mtime 1795046400 "a74f18f07d6e2b2833a984c3342bf50e42b2832178b18e3466bcd5ea1eefd3de">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build.make" file 644 mtime 1795046400 "8dfb1f8e8f3c89d8bf383a2290b78d469b8b7f9d59786bcfe5b53c2d1639179e">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/cmake_clean.cmake" file 644 mtime 1795046400 "db2818fb56891068dbd67f371a776424d3c32576c1bcd52a0e7cf54a5e6a1c15">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/compiler_depend.make" file 644 mtime 1795046400 "5fa1690f174bb16e2ceee0dc964a33b83df74f18e7c53beeb1868a6de3168de7">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/compiler_depend.ts" file 644 mtime 1795046400 "e74993a0a2dd8befa59d631fef6d6cb1fbca19f87b0cef56e312cdead4d6d236">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/depend.make" file 644 mtime 1795046400 "c0347b0798552ebb4712919a16608021b880625df1e1db3921d3170683811cd3">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/flags.make" file 644 mtime 1795046400 "f41d43deaefa147f2125d4672a6568739762843bcfb4ec4a003eff3d4242e642">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/link.txt" file 644 mtime 1795046400 "edc28013215c3a5f8aaee337573835bf699991b17427269a1d95afe99afc6e72">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/progress.make" file 644 mtime 1795046400 "8c206f4ad60943e9bb1fe398b5168822d4636e438c5038b1334e69ef9fc6b5ea">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/DependInfo.cmake" file 644 mtime 1795046400 "5a788ba8b3ea2c8ff1477cf68a19ca626bc3a7cfe858e93a77f8e43ffac04473">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build.make" file 644 mtime 1795046400 "465604fed90438b3cf0756f29f47c503328c742899d994e211aa29b245f81e8f">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/cmake_clean.cmake" file 644 mtime 1795046400 "f3371476da03452858fc1c1264097905f03789c195f24a8e7bf8bb750ed590ca">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/compiler_depend.make" file 644 mtime 1795046400 "6dfd0a0f2f4256f962ca3c3ffb4d77eb02600bac38668aa0d10155380a5dd8d9">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/compiler_depend.ts" file 644 mtime 1795046400 "d95177b8a02c09d1bd5c9897a4cd256fe068122703addc3b49273474278147f3">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/depend.make" file 644 mtime 1795046400 "3806816c501a69306807abcc5a29f94f39913474db1554d4bc2b07873f457ff1">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/flags.make" file 644 mtime 1795046400 "710e36500c504f94cb85f346f4f8b88fbf8be5fc3002c99a7fffc11e2f13e40c">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/link.txt" file 644 mtime 1795046400 "d8521ab39a8bf2e3007c32a7e9f98a09915ade34fd7e89281aaa7033504d1d8e">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/progress.make" file 644 mtime 1795046400 "c83120c5decc7cc4d95a0493df8639518e622fe3f845e52594fdd14aa2db516d">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/pkgRedirects" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build-dist/CMakeFiles/progress.marks" file 644 mtime 1795046400 "6e2ae11dad0616f66bbb2b6e6556f580bb987fd911d7132aa6bee2bfc7cc7b52">,
      #splice.entry<"/build/source/build-dist/CPackConfig.cmake" file 444 mtime 1795046400 "5b40d5bcdf2ddfbc81ef858348a35bb5b82078e154d1b6e9a9cf6d6604ba508a">,
      #splice.entry<"/build/source/build-dist/CPackSourceConfig.cmake" file 444 mtime 1795046400 "5b14038afccf53cc0776479434ab6a3fe16769cec10c1a785f5624bba89a241d">,
      #splice.entry<"/build/source/build-dist/Makefile" file 644 mtime 1795046400 "c3cec3c31a4e13702a2fd928233b0a4ab1d2a8a4943f2ebef898d3e0fd324d1e">,
      #splice.entry<"/build/source/build-dist/cmake_install.cmake" file 644 mtime 1795046400 "3edf4d696cc47507fc0f187c333ebd3af3cbec027f9a0e85f3aa4ee455a75758">,
      #splice.entry<"/build/source/build-dist/liblz4.pc" file 644 mtime 1795046400 "5bc7471a6b61f809e0c08d3f5ec96844858578ebff17b05304d4154950f7a158">,
      #splice.entry<"/build/source/build-dist/lz4Config.cmake" file 644 mtime 1795046400 "ad1ab6c71a43247e447d6fdeac7b0d3aca50be8fc55f7b38b87cf37fdd02620d">,
      #splice.entry<"/build/source/build-dist/lz4ConfigVersion.cmake" file 444 mtime 1795046400 "5b5982db4e416ff8aab0f0eebbe7d02994837073b15554096c8c7885b3c41c0f">,
      #splice.entry<"/build/source/build-dist/lz4Targets.cmake" file 644 mtime 1795046400 "50a80d84dbda7b134c9301ced39ce281834de0b3a7d7e9dcb8f3fa3572f5d5ff">,
      #splice.entry<"/build/source/build-dist/lz4cat.1" file 644 mtime 1795046400 "13b4bbca11af14a9658eaea8534d69a3857bdaf85797787e876927323890628a">,
      #splice.entry<"/build/source/build-dist/unlz4.1" file 644 mtime 1795046400 "13b4bbca11af14a9658eaea8534d69a3857bdaf85797787e876927323890628a">
  ]
  %cmake_3415_210:2 = splice.literal "cmake" at 3415 demoted -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/4.4.3/CMakeSystem.cmake" file 444 mtime 1795046400 "eae5d03bbac50975155042e73ebac342f07873e5a57de244df0dba37339b41c2">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/CMakeConfigureLog.yaml" file 644 mtime 1795046400 "70c5ae828acb4287cfbd911a46908b2acbe4b2174fbb1468729249e3bf5ba35c">
  ]
  %glue_15046 = splice.literal "glue" at 15046 -> [
      #splice.entry<"/build/env-vars" file 600 mtime 1795046400 "d85d5d6d0adcdb63e1ed7651ac2fc27120c60de5144cd01012356fe5b331381f">
  ]
  %cmake_15196 = splice.literal "cmake" at 15196 folded -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress" dir 755 mtime 1795046400>
  ]
  %cmake_15196_211 = splice.copy "cmake" at 15196(%cmake_3415_209#63) -> <"/build/source/build-dist/CMakeFiles/Progress/count.txt" file 644 mtime 1795046400 "6e2ae11dad0616f66bbb2b6e6556f580bb987fd911d7132aa6bee2bfc7cc7b52">
  %cmake_15381 = splice.exec "cmake" at 15381(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/3" file 644 mtime 1795046400 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_15444:2 = splice.exec "gcc" at 15444 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#9, %cmake_3415#10, %cmake_3415#11, %cmake_3415#12, %chmod_2578#36, %chmod_2578_112, %chmod_2578_113) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4.c.o" file 644 mtime 1795046404 "f200eb3002784ef06e8c650462d6b477322350610d6dac5e1cb1ef6848cef89c">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4.c.o.d" file 644 mtime 1795046404 "4ffe342ac62efe1c945d2e3d553a3a3b044710e0e1bfc8a466d25c8ad964b446">
  ]
  %cmake_15556 = splice.exec "cmake" at 15556(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/4" file 644 mtime 1795046404 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_15607:2 = splice.exec "gcc" at 15607 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#9, %cmake_3415#10, %cmake_3415#11, %cmake_3415#12, %chmod_2578#36, %chmod_2578_113, %chmod_2578_114, %chmod_2578_115, %chmod_2578_117, %chmod_2578_118) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4file.c.o" file 644 mtime 1795046404 "b2ebaff6eb4fd8e2f065f9355eee26d59e7d0181c3e167280fbf40144fa6bcdd">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4file.c.o.d" file 644 mtime 1795046404 "0437fefb70b523af7b636ede09fe7a3d9cae292fcf852188826a80fa69948d34">
  ]
  %cmake_15715 = splice.exec "cmake" at 15715(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/5" file 644 mtime 1795046404 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_15776:2 = splice.exec "gcc" at 15776 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#9, %cmake_3415#10, %cmake_3415#11, %cmake_3415#12, %chmod_2578#36, %chmod_2578_113, %cat_patch_2801_208#0, %chmod_2578_117, %chmod_2578_120, %chmod_2578_122) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4frame.c.o" file 644 mtime 1795046405 "131ee9ff40246b8e705f9e278424dd52dcb226ddbc98b8d3284f88c69596e909">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4frame.c.o.d" file 644 mtime 1795046405 "f4a0198781f8688d673f82fd940a04eb08d7dfc57da8df9c4b54300edda6139f">
  ]
  %cmake_15888 = splice.exec "cmake" at 15888(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/6" file 644 mtime 1795046405 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_15939:2 = splice.exec "gcc" at 15939 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#9, %cmake_3415#10, %cmake_3415#11, %cmake_3415#12, %chmod_2578#36, %chmod_2578_112, %chmod_2578_113, %chmod_2578_119, %chmod_2578_120) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4hc.c.o" file 644 mtime 1795046409 "8dc9673bcf21f6c68640c59d3d6126bbe75b0ec517cc78896f81bd06e8b43f1d">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/lz4hc.c.o.d" file 644 mtime 1795046409 "148145a315fb3aa8c9b8f16ab12ee3d51e5da61c559f87c80aa7e2b9d8418677">
  ]
  %cmake_16058 = splice.exec "cmake" at 16058(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/7" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_16109:2 = splice.exec "gcc" at 16109 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#9, %cmake_3415#10, %cmake_3415#11, %cmake_3415#12, %chmod_2578#36, %chmod_2578_121, %chmod_2578_122) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/xxhash.c.o" file 644 mtime 1795046409 "b07c921ff2be939b55e3b72bad344bb57423e27ab019b373f906a232251b5ba0">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/build/source/lib/xxhash.c.o.d" file 644 mtime 1795046409 "e48ccae29856094a30167fe4c41ec3d3f9958fe6a7569c6dfe66e544904dbfa3">
  ]
  %cmake_16215 = splice.exec "cmake" at 16215(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/8" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_16339:2 = splice.exec "gcc" at 16339 as "cc_shared_library"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#9, %cmake_3415#10, %cmake_3415#11, %cmake_3415#12, %gcc_15444#0, %gcc_15607#0, %gcc_15776#0, %gcc_15939#0, %gcc_16109#0, %cmake_3415_209#46) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4_shared.dir/link.d" file 644 mtime 1795046409 "e88f27ce23b80ddd9fb9be0505de240ed19f72df05485805ff47ef31c0c1a0e8">,
      #splice.entry<"/build/source/build-dist/liblz4.so.1.10.0" file 755 mtime 1795046409 "badb914a15e2fa86a2e3f8f775217a05fd440238f54b4997f7c8c633ed25c98d">
  ]
  %cmake_16658:2 = splice.literal "cmake" at 16658 folded -> [
      #splice.entry<"/build/source/build-dist/liblz4.so" link 0 mtime 1795046409 "liblz4.so.1">,
      #splice.entry<"/build/source/build-dist/liblz4.so.1" link 0 mtime 1795046409 "liblz4.so.1.10.0">
  ]
  %cmake_16735 = splice.copy "cmake" at 16735(%cmake_15381) -> <"/build/source/build-dist/CMakeFiles/Progress/3" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  %cmake_16735_212 = splice.copy "cmake" at 16735(%cmake_15556) -> <"/build/source/build-dist/CMakeFiles/Progress/4" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  %cmake_16735_213 = splice.copy "cmake" at 16735(%cmake_15715) -> <"/build/source/build-dist/CMakeFiles/Progress/5" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  %cmake_16735_214 = splice.copy "cmake" at 16735(%cmake_15888) -> <"/build/source/build-dist/CMakeFiles/Progress/6" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  %cmake_16894 = splice.exec "cmake" at 16894(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/9" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_16947:2 = splice.exec "gcc" at 16947 as "cc_object"(%sandbox_716, %glue_15046, %chmod_2578#0, %chmod_2578#1, %chmod_2578_0, %chmod_2578#2, %chmod_2578#3, %chmod_2578_1, %chmod_2578_2, %chmod_2578_3, %chmod_2578_4, %chmod_2578#4, %chmod_2578#5, %chmod_2578_5, %chmod_2578_6, %chmod_2578_7, %chmod_2578#6, %chmod_2578_8, %chmod_2578_9, %chmod_2578_10, %chmod_2578_11, %chmod_2578_12, %chmod_2578_13, %chmod_2578_14, %chmod_2578_15, %chmod_2578_16, %chmod_2578_17, %chmod_2578_18, %chmod_2578_19, %chmod_2578_20, %chmod_2578#7, %mkdir_3041, %cmake_3415_209#0, %cmake_3415#0, %cmake_3415#1, %cmake_3415_209#3, %cmake_3415_209#4, %cmake_3415_210#0, %cmake_3415#2, %cmake_3415_209#6, %cmake_3415_209#7, %cmake_3415#3, %cmake_3415_210#1, %cmake_3415_209#9, %cmake_3415_209#10, %cmake_3415#4, %cmake_3415#5, %cmake_3415#6, %cmake_3415_209#14, %cmake_3415_209#15, %cmake_3415_209#16, %cmake_3415_209#17, %cmake_3415_209#18, %cmake_15196, %cmake_16735, %cmake_16735_212, %cmake_16735_213, %cmake_16735_214, %cmake_16058, %cmake_16215, %cmake_16894, %cmake_15196_211, %cmake_3415_209#19, %cmake_3415_209#20, %cmake_3415#7, %cmake_3415_209#22, %cmake_3415_209#23, %cmake_3415_209#24, %cmake_3415_209#25, %cmake_3415_209#26, %cmake_3415_209#27, %cmake_3415#8, %cmake_3415_209#29, %cmake_3415_209#30, %cmake_3415_209#31, %cmake_3415_209#32, %cmake_3415_209#33, %cmake_3415_209#34, %cmake_3415#9, %cmake_3415_209#36, %cmake_3415#10, %cmake_3415_209#38, %cmake_3415#11, %cmake_3415#12, %gcc_15444#0, %gcc_15444#1, %gcc_15607#0, %gcc_15607#1, %gcc_15776#0, %gcc_15776#1, %gcc_15939#0, %gcc_15939#1, %gcc_16109#0, %gcc_16109#1, %cmake_3415_209#41, %cmake_3415_209#42, %cmake_3415_209#43, %cmake_3415_209#44, %cmake_3415_209#45, %gcc_16339#0, %cmake_3415_209#46, %cmake_3415_209#47, %cmake_3415#13, %cmake_3415_209#49, %cmake_3415#14, %cmake_3415_209#51, %cmake_3415#15, %cmake_3415#16, %cmake_3415#17, %cmake_3415_209#55, %cmake_3415_209#56, %cmake_3415_209#57, %cmake_3415_209#58, %cmake_3415_209#59, %cmake_3415_209#60, %cmake_3415_209#61, %cmake_3415#18, %cmake_3415_209#63, %cmake_3415_209#64, %cmake_3415_209#65, %cmake_3415_209#66, %cmake_3415_209#67, %cmake_3415_209#68, %cmake_16658#0, %cmake_16658#1, %gcc_16339#1, %cmake_3415_209#69, %cmake_3415_209#70, %cmake_3415_209#71, %cmake_3415_209#72, %cmake_3415_209#73, %chmod_2578_21, %chmod_2578_22, %chmod_2578#8, %chmod_2578_23, %chmod_2578_24, %chmod_2578_25, %chmod_2578_26, %chmod_2578_27, %chmod_2578_28, %chmod_2578_29, %chmod_2578#9, %chmod_2578_30, %chmod_2578#10, %chmod_2578_31, %chmod_2578#11, %chmod_2578#12, %chmod_2578_32, %chmod_2578_33, %chmod_2578#13, %chmod_2578_34, %chmod_2578#14, %chmod_2578#15, %chmod_2578_35, %chmod_2578_36, %chmod_2578_37, %chmod_2578#16, %chmod_2578_38, %chmod_2578_39, %chmod_2578_40, %chmod_2578#17, %chmod_2578_41, %chmod_2578_42, %chmod_2578_43, %chmod_2578#18, %chmod_2578_44, %chmod_2578_45, %chmod_2578#19, %chmod_2578_46, %chmod_2578#20, %chmod_2578#21, %chmod_2578_47, %chmod_2578_48, %chmod_2578#22, %chmod_2578_49, %chmod_2578#23, %chmod_2578_50, %chmod_2578_51, %chmod_2578#24, %chmod_2578_52, %chmod_2578#25, %chmod_2578_53, %chmod_2578#26, %chmod_2578_54, %chmod_2578_55, %chmod_2578#27, %chmod_2578_56, %chmod_2578_57, %chmod_2578_58, %chmod_2578_59, %chmod_2578_60, %chmod_2578_61, %chmod_2578#28, %chmod_2578#29, %chmod_2578_62, %chmod_2578_63, %chmod_2578_64, %chmod_2578_65, %chmod_2578_66, %chmod_2578#30, %chmod_2578_67, %chmod_2578_68, %chmod_2578_69, %chmod_2578#31, %chmod_2578_70, %chmod_2578_71, %chmod_2578_72, %chmod_2578#32, %chmod_2578_73, %chmod_2578_74, %chmod_2578_75, %chmod_2578_76, %chmod_2578_77, %chmod_2578#33, %chmod_2578_78, %chmod_2578_79, %chmod_2578#34, %chmod_2578_80, %chmod_2578_81, %chmod_2578_82, %chmod_2578_83, %chmod_2578#35, %chmod_2578_84, %chmod_2578_85, %chmod_2578_86, %chmod_2578_87, %chmod_2578_88, %chmod_2578_89, %chmod_2578_90, %chmod_2578_91, %chmod_2578_92, %chmod_2578_93, %chmod_2578_94, %chmod_2578_95, %chmod_2578_96, %chmod_2578_97, %chmod_2578_98, %chmod_2578_99, %chmod_2578_100, %chmod_2578_101, %chmod_2578#36, %chmod_2578_102, %chmod_2578_103, %chmod_2578_104, %chmod_2578_105, %chmod_2578#37, %chmod_2578#38, %chmod_2578_106, %chmod_2578_107, %chmod_2578_108, %chmod_2578_109, %chmod_2578_110, %chmod_2578_111, %chmod_2578_112, %chmod_2578_113, %chmod_2578_114, %chmod_2578_115, %cat_patch_2801_208#0, %cat_patch_2801, %chmod_2578_117, %chmod_2578_118, %chmod_2578_119, %chmod_2578_120, %chmod_2578_121, %chmod_2578_122, %chmod_2578#39, %chmod_2578_123, %chmod_2578_124, %chmod_2578_125, %chmod_2578_126, %chmod_2578_127, %chmod_2578_128, %chmod_2578_129, %chmod_2578_130, %chmod_2578_131, %chmod_2578_132, %chmod_2578_133, %chmod_2578_134, %chmod_2578_135, %chmod_2578_136, %chmod_2578_137, %chmod_2578_138, %chmod_2578_139, %chmod_2578_140, %chmod_2578_141, %chmod_2578_142, %chmod_2578_143, %chmod_2578#40, %chmod_2578_144, %chmod_2578_145, %chmod_2578_146, %chmod_2578_147, %chmod_2578_148, %chmod_2578_149, %chmod_2578_150, %chmod_2578_151, %chmod_2578_152, %chmod_2578_153, %chmod_2578_154, %chmod_2578_155, %chmod_2578_156, %chmod_2578_157, %chmod_2578_158, %chmod_2578_159, %chmod_2578_160, %chmod_2578_161, %chmod_2578_162, %chmod_2578_163, %chmod_2578_164, %chmod_2578_165, %chmod_2578#41, %chmod_2578_166, %chmod_2578_167, %chmod_2578_168, %chmod_2578_169, %chmod_2578_170, %chmod_2578_171, %chmod_2578_172, %chmod_2578_173, %chmod_2578#42, %chmod_2578_174, %chmod_2578_175, %chmod_2578_176, %chmod_2578_177, %chmod_2578_178, %chmod_2578_179, %cat_patch_2801_208#2, %cat_patch_2801_207, %chmod_2578_181, %chmod_2578_182, %chmod_2578_183, %chmod_2578#43, %chmod_2578_184, %chmod_2578_185, %chmod_2578_186, %chmod_2578_187, %chmod_2578_188, %chmod_2578_189, %chmod_2578_190, %chmod_2578_191, %chmod_2578_192, %chmod_2578_193, %chmod_2578_194, %chmod_2578_195, %chmod_2578_196, %chmod_2578_197, %chmod_2578_198, %chmod_2578_199, %chmod_2578_200, %chmod_2578_201, %chmod_2578_202, %chmod_2578_203, %chmod_2578_204, %chmod_2578_205, %chmod_2578_206) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/bench.c.o" file 644 mtime 1795046409 "6208d80baca4635293e4f39065d43eb0380efe1d67f81cf0a8c4ec3f1d74644a">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/bench.c.o.d" file 644 mtime 1795046409 "809d307bed1f239b687fee087dee7f44571dffab194e50289fda76c9cf6ba103">
  ]
  %cmake_17067 = splice.exec "cmake" at 17067(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/10" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_17118:2 = splice.exec "gcc" at 17118 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#17, %chmod_2578#40, %chmod_2578_150, %chmod_2578_151) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/lorem.c.o" file 644 mtime 1795046409 "ef9f0039713873724ed320c58470cc97cd87486ba621cfc936e416390e86b7e9">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/lorem.c.o.d" file 644 mtime 1795046409 "fd253653c86276a4f507e39d4d3ee8caad5757960661f46b860ef02f80772680">
  ]
  %cmake_17226 = splice.exec "cmake" at 17226(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/11" file 644 mtime 1795046409 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_17277:2 = splice.exec "gcc" at 17277 as "cc_object"(%sandbox_716, %glue_15046, %chmod_2578#0, %chmod_2578#1, %chmod_2578_0, %chmod_2578#2, %chmod_2578#3, %chmod_2578_1, %chmod_2578_2, %chmod_2578_3, %chmod_2578_4, %chmod_2578#4, %chmod_2578#5, %chmod_2578_5, %chmod_2578_6, %chmod_2578_7, %chmod_2578#6, %chmod_2578_8, %chmod_2578_9, %chmod_2578_10, %chmod_2578_11, %chmod_2578_12, %chmod_2578_13, %chmod_2578_14, %chmod_2578_15, %chmod_2578_16, %chmod_2578_17, %chmod_2578_18, %chmod_2578_19, %chmod_2578_20, %chmod_2578#7, %mkdir_3041, %cmake_3415_209#0, %cmake_3415#0, %cmake_3415#1, %cmake_3415_209#3, %cmake_3415_209#4, %cmake_3415_210#0, %cmake_3415#2, %cmake_3415_209#6, %cmake_3415_209#7, %cmake_3415#3, %cmake_3415_210#1, %cmake_3415_209#9, %cmake_3415_209#10, %cmake_3415#4, %cmake_3415#5, %cmake_3415#6, %cmake_3415_209#14, %cmake_3415_209#15, %cmake_3415_209#16, %cmake_3415_209#17, %cmake_3415_209#18, %cmake_15196, %cmake_17067, %cmake_17226, %cmake_16735, %cmake_16735_212, %cmake_16735_213, %cmake_16735_214, %cmake_16058, %cmake_16215, %cmake_16894, %cmake_15196_211, %cmake_3415_209#19, %cmake_3415_209#20, %cmake_3415#7, %cmake_3415_209#22, %cmake_3415_209#23, %cmake_3415_209#24, %cmake_3415_209#25, %cmake_3415_209#26, %cmake_3415_209#27, %cmake_3415#8, %cmake_3415_209#29, %cmake_3415_209#30, %cmake_3415_209#31, %cmake_3415_209#32, %cmake_3415_209#33, %cmake_3415_209#34, %cmake_3415#9, %cmake_3415_209#36, %cmake_3415#10, %cmake_3415_209#38, %cmake_3415#11, %cmake_3415#12, %gcc_15444#0, %gcc_15444#1, %gcc_15607#0, %gcc_15607#1, %gcc_15776#0, %gcc_15776#1, %gcc_15939#0, %gcc_15939#1, %gcc_16109#0, %gcc_16109#1, %cmake_3415_209#41, %cmake_3415_209#42, %cmake_3415_209#43, %cmake_3415_209#44, %cmake_3415_209#45, %gcc_16339#0, %cmake_3415_209#46, %cmake_3415_209#47, %cmake_3415#13, %cmake_3415_209#49, %cmake_3415#14, %cmake_3415_209#51, %cmake_3415#15, %cmake_3415#16, %cmake_3415#17, %gcc_16947#0, %gcc_16947#1, %gcc_17118#0, %gcc_17118#1, %cmake_3415_209#55, %cmake_3415_209#56, %cmake_3415_209#57, %cmake_3415_209#58, %cmake_3415_209#59, %cmake_3415_209#60, %cmake_3415_209#61, %cmake_3415#18, %cmake_3415_209#63, %cmake_3415_209#64, %cmake_3415_209#65, %cmake_3415_209#66, %cmake_3415_209#67, %cmake_3415_209#68, %cmake_16658#0, %cmake_16658#1, %gcc_16339#1, %cmake_3415_209#69, %cmake_3415_209#70, %cmake_3415_209#71, %cmake_3415_209#72, %cmake_3415_209#73, %chmod_2578_21, %chmod_2578_22, %chmod_2578#8, %chmod_2578_23, %chmod_2578_24, %chmod_2578_25, %chmod_2578_26, %chmod_2578_27, %chmod_2578_28, %chmod_2578_29, %chmod_2578#9, %chmod_2578_30, %chmod_2578#10, %chmod_2578_31, %chmod_2578#11, %chmod_2578#12, %chmod_2578_32, %chmod_2578_33, %chmod_2578#13, %chmod_2578_34, %chmod_2578#14, %chmod_2578#15, %chmod_2578_35, %chmod_2578_36, %chmod_2578_37, %chmod_2578#16, %chmod_2578_38, %chmod_2578_39, %chmod_2578_40, %chmod_2578#17, %chmod_2578_41, %chmod_2578_42, %chmod_2578_43, %chmod_2578#18, %chmod_2578_44, %chmod_2578_45, %chmod_2578#19, %chmod_2578_46, %chmod_2578#20, %chmod_2578#21, %chmod_2578_47, %chmod_2578_48, %chmod_2578#22, %chmod_2578_49, %chmod_2578#23, %chmod_2578_50, %chmod_2578_51, %chmod_2578#24, %chmod_2578_52, %chmod_2578#25, %chmod_2578_53, %chmod_2578#26, %chmod_2578_54, %chmod_2578_55, %chmod_2578#27, %chmod_2578_56, %chmod_2578_57, %chmod_2578_58, %chmod_2578_59, %chmod_2578_60, %chmod_2578_61, %chmod_2578#28, %chmod_2578#29, %chmod_2578_62, %chmod_2578_63, %chmod_2578_64, %chmod_2578_65, %chmod_2578_66, %chmod_2578#30, %chmod_2578_67, %chmod_2578_68, %chmod_2578_69, %chmod_2578#31, %chmod_2578_70, %chmod_2578_71, %chmod_2578_72, %chmod_2578#32, %chmod_2578_73, %chmod_2578_74, %chmod_2578_75, %chmod_2578_76, %chmod_2578_77, %chmod_2578#33, %chmod_2578_78, %chmod_2578_79, %chmod_2578#34, %chmod_2578_80, %chmod_2578_81, %chmod_2578_82, %chmod_2578_83, %chmod_2578#35, %chmod_2578_84, %chmod_2578_85, %chmod_2578_86, %chmod_2578_87, %chmod_2578_88, %chmod_2578_89, %chmod_2578_90, %chmod_2578_91, %chmod_2578_92, %chmod_2578_93, %chmod_2578_94, %chmod_2578_95, %chmod_2578_96, %chmod_2578_97, %chmod_2578_98, %chmod_2578_99, %chmod_2578_100, %chmod_2578_101, %chmod_2578#36, %chmod_2578_102, %chmod_2578_103, %chmod_2578_104, %chmod_2578_105, %chmod_2578#37, %chmod_2578#38, %chmod_2578_106, %chmod_2578_107, %chmod_2578_108, %chmod_2578_109, %chmod_2578_110, %chmod_2578_111, %chmod_2578_112, %chmod_2578_113, %chmod_2578_114, %chmod_2578_115, %cat_patch_2801_208#0, %cat_patch_2801, %chmod_2578_117, %chmod_2578_118, %chmod_2578_119, %chmod_2578_120, %chmod_2578_121, %chmod_2578_122, %chmod_2578#39, %chmod_2578_123, %chmod_2578_124, %chmod_2578_125, %chmod_2578_126, %chmod_2578_127, %chmod_2578_128, %chmod_2578_129, %chmod_2578_130, %chmod_2578_131, %chmod_2578_132, %chmod_2578_133, %chmod_2578_134, %chmod_2578_135, %chmod_2578_136, %chmod_2578_137, %chmod_2578_138, %chmod_2578_139, %chmod_2578_140, %chmod_2578_141, %chmod_2578_142, %chmod_2578_143, %chmod_2578#40, %chmod_2578_144, %chmod_2578_145, %chmod_2578_146, %chmod_2578_147, %chmod_2578_148, %chmod_2578_149, %chmod_2578_150, %chmod_2578_151, %chmod_2578_152, %chmod_2578_153, %chmod_2578_154, %chmod_2578_155, %chmod_2578_156, %chmod_2578_157, %chmod_2578_158, %chmod_2578_159, %chmod_2578_160, %chmod_2578_161, %chmod_2578_162, %chmod_2578_163, %chmod_2578_164, %chmod_2578_165, %chmod_2578#41, %chmod_2578_166, %chmod_2578_167, %chmod_2578_168, %chmod_2578_169, %chmod_2578_170, %chmod_2578_171, %chmod_2578_172, %chmod_2578_173, %chmod_2578#42, %chmod_2578_174, %chmod_2578_175, %chmod_2578_176, %chmod_2578_177, %chmod_2578_178, %chmod_2578_179, %cat_patch_2801_208#2, %cat_patch_2801_207, %chmod_2578_181, %chmod_2578_182, %chmod_2578_183, %chmod_2578#43, %chmod_2578_184, %chmod_2578_185, %chmod_2578_186, %chmod_2578_187, %chmod_2578_188, %chmod_2578_189, %chmod_2578_190, %chmod_2578_191, %chmod_2578_192, %chmod_2578_193, %chmod_2578_194, %chmod_2578_195, %chmod_2578_196, %chmod_2578_197, %chmod_2578_198, %chmod_2578_199, %chmod_2578_200, %chmod_2578_201, %chmod_2578_202, %chmod_2578_203, %chmod_2578_204, %chmod_2578_205, %chmod_2578_206) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/lz4cli.c.o" file 644 mtime 1795046410 "641920c57dc84105a64242257821780d9bbe7d8d40b0bd9ca9887746933ff0cc">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/lz4cli.c.o.d" file 644 mtime 1795046410 "38077ab737811749e38ad98b5760bf32a627d4715d602829004e4d983bbd1689">
  ]
  %cmake_17405 = splice.exec "cmake" at 17405(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_15196, %cmake_15196_211) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/Progress/12" file 644 mtime 1795046410 "2e1cfa82b035c26cbbbdae632cea070514eb8b773f616aaeaf668e2f0be8f10d">
  ]
  %gcc_17456:2 = splice.exec "gcc" at 17456 as "cc_object"(%sandbox_716, %glue_15046, %chmod_2578#0, %chmod_2578#1, %chmod_2578_0, %chmod_2578#2, %chmod_2578#3, %chmod_2578_1, %chmod_2578_2, %chmod_2578_3, %chmod_2578_4, %chmod_2578#4, %chmod_2578#5, %chmod_2578_5, %chmod_2578_6, %chmod_2578_7, %chmod_2578#6, %chmod_2578_8, %chmod_2578_9, %chmod_2578_10, %chmod_2578_11, %chmod_2578_12, %chmod_2578_13, %chmod_2578_14, %chmod_2578_15, %chmod_2578_16, %chmod_2578_17, %chmod_2578_18, %chmod_2578_19, %chmod_2578_20, %chmod_2578#7, %mkdir_3041, %cmake_3415_209#0, %cmake_3415#0, %cmake_3415#1, %cmake_3415_209#3, %cmake_3415_209#4, %cmake_3415_210#0, %cmake_3415#2, %cmake_3415_209#6, %cmake_3415_209#7, %cmake_3415#3, %cmake_3415_210#1, %cmake_3415_209#9, %cmake_3415_209#10, %cmake_3415#4, %cmake_3415#5, %cmake_3415#6, %cmake_3415_209#14, %cmake_3415_209#15, %cmake_3415_209#16, %cmake_3415_209#17, %cmake_3415_209#18, %cmake_15196, %cmake_17067, %cmake_17226, %cmake_17405, %cmake_16735, %cmake_16735_212, %cmake_16735_213, %cmake_16735_214, %cmake_16058, %cmake_16215, %cmake_16894, %cmake_15196_211, %cmake_3415_209#19, %cmake_3415_209#20, %cmake_3415#7, %cmake_3415_209#22, %cmake_3415_209#23, %cmake_3415_209#24, %cmake_3415_209#25, %cmake_3415_209#26, %cmake_3415_209#27, %cmake_3415#8, %cmake_3415_209#29, %cmake_3415_209#30, %cmake_3415_209#31, %cmake_3415_209#32, %cmake_3415_209#33, %cmake_3415_209#34, %cmake_3415#9, %cmake_3415_209#36, %cmake_3415#10, %cmake_3415_209#38, %cmake_3415#11, %cmake_3415#12, %gcc_15444#0, %gcc_15444#1, %gcc_15607#0, %gcc_15607#1, %gcc_15776#0, %gcc_15776#1, %gcc_15939#0, %gcc_15939#1, %gcc_16109#0, %gcc_16109#1, %cmake_3415_209#41, %cmake_3415_209#42, %cmake_3415_209#43, %cmake_3415_209#44, %cmake_3415_209#45, %gcc_16339#0, %cmake_3415_209#46, %cmake_3415_209#47, %cmake_3415#13, %cmake_3415_209#49, %cmake_3415#14, %cmake_3415_209#51, %cmake_3415#15, %cmake_3415#16, %cmake_3415#17, %gcc_16947#0, %gcc_16947#1, %gcc_17118#0, %gcc_17118#1, %gcc_17277#0, %gcc_17277#1, %cmake_3415_209#55, %cmake_3415_209#56, %cmake_3415_209#57, %cmake_3415_209#58, %cmake_3415_209#59, %cmake_3415_209#60, %cmake_3415_209#61, %cmake_3415#18, %cmake_3415_209#63, %cmake_3415_209#64, %cmake_3415_209#65, %cmake_3415_209#66, %cmake_3415_209#67, %cmake_3415_209#68, %cmake_16658#0, %cmake_16658#1, %gcc_16339#1, %cmake_3415_209#69, %cmake_3415_209#70, %cmake_3415_209#71, %cmake_3415_209#72, %cmake_3415_209#73, %chmod_2578_21, %chmod_2578_22, %chmod_2578#8, %chmod_2578_23, %chmod_2578_24, %chmod_2578_25, %chmod_2578_26, %chmod_2578_27, %chmod_2578_28, %chmod_2578_29, %chmod_2578#9, %chmod_2578_30, %chmod_2578#10, %chmod_2578_31, %chmod_2578#11, %chmod_2578#12, %chmod_2578_32, %chmod_2578_33, %chmod_2578#13, %chmod_2578_34, %chmod_2578#14, %chmod_2578#15, %chmod_2578_35, %chmod_2578_36, %chmod_2578_37, %chmod_2578#16, %chmod_2578_38, %chmod_2578_39, %chmod_2578_40, %chmod_2578#17, %chmod_2578_41, %chmod_2578_42, %chmod_2578_43, %chmod_2578#18, %chmod_2578_44, %chmod_2578_45, %chmod_2578#19, %chmod_2578_46, %chmod_2578#20, %chmod_2578#21, %chmod_2578_47, %chmod_2578_48, %chmod_2578#22, %chmod_2578_49, %chmod_2578#23, %chmod_2578_50, %chmod_2578_51, %chmod_2578#24, %chmod_2578_52, %chmod_2578#25, %chmod_2578_53, %chmod_2578#26, %chmod_2578_54, %chmod_2578_55, %chmod_2578#27, %chmod_2578_56, %chmod_2578_57, %chmod_2578_58, %chmod_2578_59, %chmod_2578_60, %chmod_2578_61, %chmod_2578#28, %chmod_2578#29, %chmod_2578_62, %chmod_2578_63, %chmod_2578_64, %chmod_2578_65, %chmod_2578_66, %chmod_2578#30, %chmod_2578_67, %chmod_2578_68, %chmod_2578_69, %chmod_2578#31, %chmod_2578_70, %chmod_2578_71, %chmod_2578_72, %chmod_2578#32, %chmod_2578_73, %chmod_2578_74, %chmod_2578_75, %chmod_2578_76, %chmod_2578_77, %chmod_2578#33, %chmod_2578_78, %chmod_2578_79, %chmod_2578#34, %chmod_2578_80, %chmod_2578_81, %chmod_2578_82, %chmod_2578_83, %chmod_2578#35, %chmod_2578_84, %chmod_2578_85, %chmod_2578_86, %chmod_2578_87, %chmod_2578_88, %chmod_2578_89, %chmod_2578_90, %chmod_2578_91, %chmod_2578_92, %chmod_2578_93, %chmod_2578_94, %chmod_2578_95, %chmod_2578_96, %chmod_2578_97, %chmod_2578_98, %chmod_2578_99, %chmod_2578_100, %chmod_2578_101, %chmod_2578#36, %chmod_2578_102, %chmod_2578_103, %chmod_2578_104, %chmod_2578_105, %chmod_2578#37, %chmod_2578#38, %chmod_2578_106, %chmod_2578_107, %chmod_2578_108, %chmod_2578_109, %chmod_2578_110, %chmod_2578_111, %chmod_2578_112, %chmod_2578_113, %chmod_2578_114, %chmod_2578_115, %cat_patch_2801_208#0, %cat_patch_2801, %chmod_2578_117, %chmod_2578_118, %chmod_2578_119, %chmod_2578_120, %chmod_2578_121, %chmod_2578_122, %chmod_2578#39, %chmod_2578_123, %chmod_2578_124, %chmod_2578_125, %chmod_2578_126, %chmod_2578_127, %chmod_2578_128, %chmod_2578_129, %chmod_2578_130, %chmod_2578_131, %chmod_2578_132, %chmod_2578_133, %chmod_2578_134, %chmod_2578_135, %chmod_2578_136, %chmod_2578_137, %chmod_2578_138, %chmod_2578_139, %chmod_2578_140, %chmod_2578_141, %chmod_2578_142, %chmod_2578_143, %chmod_2578#40, %chmod_2578_144, %chmod_2578_145, %chmod_2578_146, %chmod_2578_147, %chmod_2578_148, %chmod_2578_149, %chmod_2578_150, %chmod_2578_151, %chmod_2578_152, %chmod_2578_153, %chmod_2578_154, %chmod_2578_155, %chmod_2578_156, %chmod_2578_157, %chmod_2578_158, %chmod_2578_159, %chmod_2578_160, %chmod_2578_161, %chmod_2578_162, %chmod_2578_163, %chmod_2578_164, %chmod_2578_165, %chmod_2578#41, %chmod_2578_166, %chmod_2578_167, %chmod_2578_168, %chmod_2578_169, %chmod_2578_170, %chmod_2578_171, %chmod_2578_172, %chmod_2578_173, %chmod_2578#42, %chmod_2578_174, %chmod_2578_175, %chmod_2578_176, %chmod_2578_177, %chmod_2578_178, %chmod_2578_179, %cat_patch_2801_208#2, %cat_patch_2801_207, %chmod_2578_181, %chmod_2578_182, %chmod_2578_183, %chmod_2578#43, %chmod_2578_184, %chmod_2578_185, %chmod_2578_186, %chmod_2578_187, %chmod_2578_188, %chmod_2578_189, %chmod_2578_190, %chmod_2578_191, %chmod_2578_192, %chmod_2578_193, %chmod_2578_194, %chmod_2578_195, %chmod_2578_196, %chmod_2578_197, %chmod_2578_198, %chmod_2578_199, %chmod_2578_200, %chmod_2578_201, %chmod_2578_202, %chmod_2578_203, %chmod_2578_204, %chmod_2578_205, %chmod_2578_206) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/lz4io.c.o" file 644 mtime 1795046411 "6fe159edc9ee34f5cfa29f7ff00ca66f626c250c5009390b2719238c3e8682bc">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/lz4io.c.o.d" file 644 mtime 1795046411 "1ca81ef28ac340d71c6f1ea63bf747d52b4849ec6e3405d9eb7f044f47153b23">
  ]
  %gcc_17624:2 = splice.exec "gcc" at 17624 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#17, %chmod_2578#40, %chmod_2578_156, %chmod_2578_160, %chmod_2578_161) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/threadpool.c.o" file 644 mtime 1795046411 "32f9e2bfe3429d691a19270472648a3036656e2f90fcf2508504d74c94a70c20">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/threadpool.c.o.d" file 644 mtime 1795046411 "2bfa9b900d9cd0f7f40f562839745fe4e14ed9e32acc82570a8e01da8524bc70">
  ]
  %gcc_17782:2 = splice.exec "gcc" at 17782 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#17, %chmod_2578#40, %chmod_2578_162, %chmod_2578_163) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/timefn.c.o" file 644 mtime 1795046411 "5a27b4630ab4fcc3bb8d8915576869bd94eb8367fdfa317dac19cb7da72fb5c7">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/timefn.c.o.d" file 644 mtime 1795046411 "1b5e428789a7dc686ef0498afb6521af590b443048c7e651392d0d605237963b">
  ]
  %gcc_17947:2 = splice.exec "gcc" at 17947 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#17, %chmod_2578#40, %chmod_2578_159, %chmod_2578_164, %chmod_2578_165) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/util.c.o" file 644 mtime 1795046411 "34b416646e39c3f53f195b9f043e6c5796e9b085b725ebd995b58b3dde19d9ff">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/programs/util.c.o.d" file 644 mtime 1795046411 "2c8e4219e57f4d5ce876d666fe874c129392cb8a8e730a7a1d1e7a3a1fe08de3">
  ]
  %gcc_18096:2 = splice.exec "gcc" at 18096 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#16, %chmod_2578#36, %chmod_2578_112, %chmod_2578_113) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4.c.o" file 644 mtime 1795046415 "f200eb3002784ef06e8c650462d6b477322350610d6dac5e1cb1ef6848cef89c">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4.c.o.d" file 644 mtime 1795046415 "c7935c6fa36057e3b7f2766973d45cdea0edd557d42beadfa487de45866c7c0e">
  ]
  %gcc_18267:2 = splice.exec "gcc" at 18267 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#16, %chmod_2578#36, %chmod_2578_113, %chmod_2578_114, %chmod_2578_115, %chmod_2578_117, %chmod_2578_118) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4file.c.o" file 644 mtime 1795046415 "b2ebaff6eb4fd8e2f065f9355eee26d59e7d0181c3e167280fbf40144fa6bcdd">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4file.c.o.d" file 644 mtime 1795046415 "0a6ff2b0afe3d80c9c8bac22791ee07376331510a1c6bd1aad49d4e67519d973">
  ]
  %gcc_18437:2 = splice.exec "gcc" at 18437 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#16, %chmod_2578#36, %chmod_2578_113, %cat_patch_2801_208#0, %chmod_2578_117, %chmod_2578_120, %chmod_2578_122) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4frame.c.o" file 644 mtime 1795046415 "4e547e7c9e273f936bec5a5f3575e7861c3afc98046cdea95a3c82f2603a5d1c">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4frame.c.o.d" file 644 mtime 1795046415 "3a2e260edde169efca5441b69a81531aaf7948e12a93ba9f7a134c41bbc5ac45">
  ]
  %gcc_18607:2 = splice.exec "gcc" at 18607 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#16, %chmod_2578#36, %chmod_2578_112, %chmod_2578_113, %chmod_2578_119, %chmod_2578_120) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4hc.c.o" file 644 mtime 1795046419 "8dc9673bcf21f6c68640c59d3d6126bbe75b0ec517cc78896f81bd06e8b43f1d">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/lz4hc.c.o.d" file 644 mtime 1795046419 "b55d32bcdf49836fa7177e38fe49b0f7aabed89e883155af3d54dbac7ad8b493">
  ]
  %gcc_18767:2 = splice.exec "gcc" at 18767 as "cc_object"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#16, %chmod_2578#36, %chmod_2578_121, %chmod_2578_122) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/xxhash.c.o" file 644 mtime 1795046419 "1ac97eac2a023af95941abc4ec6c4b216c5c0993435cb34e9116cd8fb8a04a72">,
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/build/source/lib/xxhash.c.o.d" file 644 mtime 1795046419 "eff06e77c407e2bfcdf5f7cc67eb68bfa251cec16ebb03e03f3cc0c45d236a32">
  ]
  %gcc_19006:2 = splice.exec "gcc" at 19006 as "cc_binary"(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_3415#0, %cmake_3415#13, %cmake_3415#14, %cmake_3415#15, %cmake_3415#16, %gcc_18096#0, %gcc_18267#0, %gcc_18437#0, %gcc_18607#0, %gcc_18767#0, %cmake_3415#17, %gcc_16947#0, %gcc_17118#0, %gcc_17277#0, %gcc_17456#0, %gcc_17624#0, %gcc_17782#0, %gcc_17947#0, %cmake_3415_209#60) -> [
      #splice.entry<"/build/source/build-dist/CMakeFiles/lz4cli.dir/link.d" file 644 mtime 1795046419 "5f4db22dd8db20a3a4445075949f9ab81d080d49931d3d91dab0fd2aa5122b73">,
      #splice.entry<"/build/source/build-dist/lz4" file 755 mtime 1795046419 "2870f0493225da582e361acc575ff7b0a186684cae9c074efb2d2f6e15cf6615">
  ]
  %mkdir_19974 = splice.literal "mkdir" at 19974 folded -> [
      #splice.entry<"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0" dir 755 mtime 1795046419>
  ]
  %cmake_21146:16 = splice.literal "cmake" at 21146 folded -> [
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/include" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/cmake" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/cmake/lz4" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/liblz4.so" link 0 mtime 1795046419 "liblz4.so.1">,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/liblz4.so.1" link 0 mtime 1795046419 "liblz4.so.1.10.0">,
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/pkgconfig" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0/bin" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0/bin/lz4cat" link 0 mtime 1795046419 "lz4">,
      #splice.entry<"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0/bin/unlz4" link 0 mtime 1795046419 "lz4">
  ]
  %cmake_21146_215 = splice.copy "cmake" at 21146(%cp_2139#152) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/include/lz4.h" file 644 mtime 1 "26b82efc53d1570f3b54eef02e9c4764c1ad374ff03cac04e2ced5ea4d4c552f">
  %cmake_21146_216 = splice.copy "cmake" at 21146(%cp_2139#154) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/include/lz4file.h" file 644 mtime 1 "400ed90bc74324abcf338d37235dd81aa431fd815c22db4b369b88c12b213115">
  %cmake_21146_217 = splice.copy "cmake" at 21146(%cp_2139#156) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/include/lz4frame.h" file 644 mtime 1 "b845db4b7ee1bfa64b8f641a94f62e7f636a8b5d673cc61766413782283aaad1">
  %cmake_21146_218 = splice.copy "cmake" at 21146(%cp_2139#159) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/include/lz4hc.h" file 644 mtime 1 "e43824e8a9ba16f54100c4ccbccfa5782a858ca9ab83c48aac303fea3e76e21e">
  %cmake_21146_219 = splice.copy "cmake" at 21146(%gcc_16339#1) -> <"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/liblz4.so.1.10.0" file 755 mtime 1795046409 "badb914a15e2fa86a2e3f8f775217a05fd440238f54b4997f7c8c633ed25c98d">
  %cmake_21146_220 = splice.copy "cmake" at 21146(%cp_2139#194) -> <"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1/lz4.1" file 644 mtime 1 "84e711b1283c2b79f5c5d225ed3dbe70a516e0b6bdda5279f395bd3d12ea7d19">
  %cmake_21146_221 = splice.copy "cmake" at 21146(%cmake_3415_209#72) -> <"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1/lz4cat.1" file 644 mtime 1795046400 "13b4bbca11af14a9658eaea8534d69a3857bdaf85797787e876927323890628a">
  %cmake_21146_222 = splice.copy "cmake" at 21146(%cmake_3415_209#73) -> <"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1/unlz4.1" file 644 mtime 1795046400 "13b4bbca11af14a9658eaea8534d69a3857bdaf85797787e876927323890628a">
  %cmake_21146_223 = splice.copy "cmake" at 21146(%gcc_19006#1) -> <"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0/bin/lz4" file 755 mtime 1795046419 "2870f0493225da582e361acc575ff7b0a186684cae9c074efb2d2f6e15cf6615">
  %mkdir_21671 = splice.literal "mkdir" at 21671 folded -> [
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib" dir 755 mtime 1795046419>
  ]
  %mv_21692 = splice.literal "mv" at 21692 folded -> [
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/pkgconfig" dir 755 mtime 1795046419>
  ]
  %mv_21830:2 = splice.literal "mv" at 21830 folded -> [
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/cmake" dir 755 mtime 1795046419>,
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/cmake/lz4" dir 755 mtime 1795046419>
  ]
  %mv_21830_224 = splice.copy "mv" at 21830(%cmake_3415_209#69) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/cmake/lz4/lz4Config.cmake" file 644 mtime 1795046400 "ad1ab6c71a43247e447d6fdeac7b0d3aca50be8fc55f7b38b87cf37fdd02620d">
  %mv_21830_225 = splice.copy "mv" at 21830(%cmake_3415_209#70) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/cmake/lz4/lz4ConfigVersion.cmake" file 644 mtime 1795046400 "5b5982db4e416ff8aab0f0eebbe7d02994837073b15554096c8c7885b3c41c0f">
  %mv_21830_226 = splice.copy "mv" at 21830(%cmake_3415_209#14) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/cmake/lz4/lz4Targets-release.cmake" file 644 mtime 1795046400 "9277c227556c6e26c7710c2148eb38f0a7778df7fa01aff0175fe3eb369eb886">
  %mv_21830_227 = splice.copy "mv" at 21830(%cmake_3415_209#15) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/cmake/lz4/lz4Targets.cmake" file 644 mtime 1795046400 "e5c35fa5f1a81ad5e7d1b5ff3e1f8ea09f0366916fd6aba5b94f7b610e9ebc83">
  %sed_21914 = splice.copy "sed" at 21914(%cmake_3415_209#68) -> <"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/lib/pkgconfig/liblz4.pc" file 644 mtime 1795046419 "5bc7471a6b61f809e0c08d3f5ec96844858578ebff17b05304d4154950f7a158">
  %find_patchelf_22545 = splice.exec "find|patchelf" at 22545(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_21146#2, %cmake_21146#3, %cmake_21146_219) -> [
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/liblz4.so.1.10.0" file 755 mtime 1795046419 "8c5d41584e84ffdf7caa5506bfc270a20f9e0968da4a14aa35cefde2d0497dff">
  ]
  %mktemp_22899 = splice.literal "mktemp" at 22899 folded -> [
      #splice.entry<"/build/striperr.zODxNB" file 600 mtime 1795046419 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_23005 = splice.exec "strip" at 23005(%sandbox_716, %chmod_2578#0, %mkdir_3041, %mktemp_22899, %cmake_21146#2, %cmake_21146#3, %find_patchelf_22545) -> [
      #splice.entry<"/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib/lib/liblz4.so.1.10.0" file 755 mtime 1795046419 "f9ae55a7c6bc996e575f38e6d1487e51062a8208cc92a5f7291db3cb2389bb9c">
  ]
  %gzip_23316 = splice.exec "gzip" at 23316(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_21146#9, %cmake_21146#10, %cmake_21146#11, %cmake_21146#12, %cmake_21146_222) -> [
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1/unlz4.1.gz" file 644 mtime 1795046400 "ad24ae4bcf620d2a9a94a8e484c209d6d0c434786d985e794fc407408a65aff9">
  ]
  %gzip_23341 = splice.exec "gzip" at 23341(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_21146#9, %cmake_21146#10, %cmake_21146#11, %cmake_21146#12, %cmake_21146_221) -> [
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1/lz4cat.1.gz" file 644 mtime 1795046400 "ad24ae4bcf620d2a9a94a8e484c209d6d0c434786d985e794fc407408a65aff9">
  ]
  %gzip_23364 = splice.exec "gzip" at 23364(%sandbox_716, %chmod_2578#0, %mkdir_3041, %cmake_21146#9, %cmake_21146#10, %cmake_21146#11, %cmake_21146#12, %cmake_21146_220) -> [
      #splice.entry<"/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man/share/man/man1/lz4.1.gz" file 644 mtime 1 "58cb050d9b95046ac424332dce86251cfea294bf4e520105105fa0d6447dc636">
  ]
  %find_patchelf_23505 = splice.exec "find|patchelf" at 23505(%sandbox_716, %chmod_2578#0, %mkdir_3041, %mkdir_19974, %cmake_21146#13, %cmake_21146_223) -> [
      #splice.entry<"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0/bin/lz4" file 755 mtime 1795046419 "b24918edc18216c3cb7b63a1898b47839289e3d008571755f396064178f9bbeb">
  ]
  %mktemp_23847 = splice.literal "mktemp" at 23847 folded -> [
      #splice.entry<"/build/striperr.niy9NT" file 600 mtime 1795046419 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_23963 = splice.exec "strip" at 23963(%sandbox_716, %chmod_2578#0, %mkdir_3041, %mktemp_23847, %mkdir_19974, %cmake_21146#13, %find_patchelf_23505) -> [
      #splice.entry<"/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0/bin/lz4" file 755 mtime 1795046419 "649cdf71e9aa4b287bbd4930a535affa169e3bdc0ca846a04ca1abecf9703c3e">
  ]
  %mkdir_24769 = splice.literal "mkdir" at 24769 folded -> [
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/nix-support" dir 755 mtime 1795046420>
  ]
  %glue_24794 = splice.literal "glue" at 24794 -> [
      #splice.entry<"/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev/nix-support/propagated-build-inputs" file 644 mtime 1795046420 "5625b88b3c8ead0dda939fa24cc63af0df2c6ba61e45647d60f0f19428c65e69">
  ]
  splice.output "dev" "/nix/store/5mzhn4ckld94vqq8pkadqq8rf0fbi3r7-lz4-1.10.0-dev"(%cmake_21146#0, %cmake_21146#1, %cmake_21146_215, %cmake_21146_216, %cmake_21146_217, %cmake_21146_218, %mkdir_21671, %mv_21830#0, %mv_21830#1, %mv_21830_224, %mv_21830_225, %mv_21830_226, %mv_21830_227, %mv_21692, %sed_21914, %mkdir_24769, %glue_24794)
  splice.output "lib" "/nix/store/8327b5r0l5k48fpcqiaias8p2m7h52n5-lz4-1.10.0-lib"(%cmake_21146#2, %cmake_21146#3, %cmake_21146#6, %cmake_21146#7, %strip_23005)
  splice.output "man" "/nix/store/cvjg1abig6l4jc0av5v8kn31075p0msg-lz4-1.10.0-man"(%cmake_21146#9, %cmake_21146#10, %cmake_21146#11, %cmake_21146#12, %gzip_23364, %gzip_23341, %gzip_23316)
  splice.output "out" "/nix/store/dk9wf8nnmmwmy5wvp4n7kgr7r8y0ad3k-lz4-1.10.0"(%mkdir_19974, %cmake_21146#13, %strip_23963, %cmake_21146#14, %cmake_21146#15)
}

