module {
  %sandbox_717 = splice.literal "sandbox" at 717 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %cp_1698:69 = splice.exec "cp" at 1698(%sandbox_717) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/.gitattributes" file 444 mtime 1 "54bd282264b4eb2bfbef671b079a2eedee95be0158a62b361b866131310eb59e">,
      #splice.entry<"/build/source/.github" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/FUNDING.yml" file 444 mtime 1 "34f4b10158ece82e7d0371d9cafa317b533f4719f020c7675e22867e2be1106b">,
      #splice.entry<"/build/source/.github/workflows" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/workflows/tests.yml" file 444 mtime 1 "4747dc2180274d645edb5bf43e133e4d8b11d9119921b1ec05c8d100b46aae5c">,
      #splice.entry<"/build/source/.gitignore" file 444 mtime 1 "e52454f5fb735d5c75b84701244c83d96426cc11d0f25a353419be8d85073ffa">,
      #splice.entry<"/build/source/LICENSE.txt" file 444 mtime 1 "9ae3b39e83e9158e44b67733baa3bb2d84e80efdcfb14a5820210a42c7abdf7f">,
      #splice.entry<"/build/source/README.md" file 444 mtime 1 "480746651ef04e2757f21a78d501a47df70d34a91d4448d90d259588695e926c">,
      #splice.entry<"/build/source/cpp" dir 555 mtime 1>,
      #splice.entry<"/build/source/cpp/INIReader.cpp" file 444 mtime 1 "d8e3ce76ed09b379beef8d48ae428c9f383bf84131e5d4838f6c82eb746553c0">,
      #splice.entry<"/build/source/cpp/INIReader.h" file 444 mtime 1 "ec0e0d1c45b622f83664df6da3b9fcc646dabe308c354b971c14409f6d343cd9">,
      #splice.entry<"/build/source/examples" dir 555 mtime 1>,
      #splice.entry<"/build/source/examples/INIReaderExample.cpp" file 444 mtime 1 "4c70383935e86c15c211337e990a1efd050cbc97c9a757f6be60e0418ea3da19">,
      #splice.entry<"/build/source/examples/INIReaderExampleErrors.cpp" file 444 mtime 1 "0ba35b5a2a504155eace2ace8d4ccac60097469f072248154f3e647239faa436">,
      #splice.entry<"/build/source/examples/config.def" file 444 mtime 1 "a6c929577c2fb89d1557a5c121f4e155a682c727ea34bedc64e7f349543f8bff">,
      #splice.entry<"/build/source/examples/cpptest.sh" file 555 mtime 1 "ddc5675b08ee59a25f57709bad399fc08754fe8a5c427f7d0bbd84642a7d733e">,
      #splice.entry<"/build/source/examples/cpptest.txt" file 444 mtime 1 "801af84aae813c7ccd30e76aaa168f198c102e2c57c338dd9709c66dec72f749">,
      #splice.entry<"/build/source/examples/cpptesterrors.txt" file 444 mtime 1 "d85060db6d9ed33acdc3a1101974078847c6c14bbae3b4272134a98dafebc246">,
      #splice.entry<"/build/source/examples/ini_dump.c" file 444 mtime 1 "f1c232e256b1af732b8c340e981b3fb8777fea15c2120bd1a02d57c6cbb506f8">,
      #splice.entry<"/build/source/examples/ini_example.c" file 444 mtime 1 "e46bb0bba8644f14c9af2e2fced4aff3a1a38dd4d76f717e1873b7851715ffea">,
      #splice.entry<"/build/source/examples/ini_xmacros.c" file 444 mtime 1 "54fac4f830d88a062dd75d2edfbc09cf0602b709cbe74ce4b532357e6464408c">,
      #splice.entry<"/build/source/examples/meson.build" file 444 mtime 1 "eb7dd837bd1edcabdd012cd278cc7fda14961b3fa52273dcab0acecdaaea5830">,
      #splice.entry<"/build/source/examples/test.ini" file 444 mtime 1 "41eacdf14015e89ad7db2134f09052d5b935cea65993298a5c1730c3f2dda3e0">,
      #splice.entry<"/build/source/fuzzing" dir 555 mtime 1>,
      #splice.entry<"/build/source/fuzzing/build.sh" file 555 mtime 1 "d91234983af19acd75dc890a2c133962813811870b2969e78ec2df2ab725ab7e">,
      #splice.entry<"/build/source/fuzzing/fuzz.sh" file 555 mtime 1 "ceba4153fa4f6cbb58bb924cfc2a25d373e1a595a5f07a6eb22f2c98547b33cb">,
      #splice.entry<"/build/source/fuzzing/inihfuzz.c" file 444 mtime 1 "a2261b70b1add3116be19a1eaee7dcc8570b7e74f60e89aa2a81ddeaa54dd208">,
      #splice.entry<"/build/source/fuzzing/testcases" dir 555 mtime 1>,
      #splice.entry<"/build/source/fuzzing/testcases/case1.ini" file 444 mtime 1 "9284ad7f3fa8b5d15bdc9bfa729ce15f8d5198fc15a5cac211914a3a83de6fdd">,
      #splice.entry<"/build/source/ini.c" file 444 mtime 1 "cdba16f9e826d2c692efaecbbe010c17b417315db8261fbd48b66aaab8a9d46f">,
      #splice.entry<"/build/source/ini.h" file 444 mtime 1 "154b56f8437ec3e08d19f9c455a409ddccd4462cff33babe5f2713269d6dd64e">,
      #splice.entry<"/build/source/meson.build" file 444 mtime 1 "53223582f9a897fa6d8ec537af54bc8297ad165c2ad65eaa165c1adf4f6ee7c3">,
      #splice.entry<"/build/source/meson_options.txt" file 444 mtime 1 "2d9b08fda904192bb1060c21ac71e7adf9349c567a72c0b9eaf231e5d29b2543">,
      #splice.entry<"/build/source/tests" dir 555 mtime 1>,
      #splice.entry<"/build/source/tests/bad_comment.ini" file 444 mtime 1 "1126ecbebd70c2e8855fc16e47903b57987073b4168ebb9fa1ce598f1547c4e8">,
      #splice.entry<"/build/source/tests/bad_multi.ini" file 444 mtime 1 "25c32f97996dce00e1b52e726b6b6e77c50d288f5db12a2026cfd9aee8499718">,
      #splice.entry<"/build/source/tests/bad_section.ini" file 444 mtime 1 "718d3f71e0cff713ca84882cd6bc5ac69633b3755df80bfb8dd43685bd0fbead">,
      #splice.entry<"/build/source/tests/baseline_alloc.txt" file 444 mtime 1 "0a0cc8ba60919e7f570053c55c259885903433e6e49693b499d89bbeed3e6762">,
      #splice.entry<"/build/source/tests/baseline_allow_no_value.txt" file 444 mtime 1 "4031e7a3ff96ae3257f76a35746421c0ef945bddbb11bc549f83f7dec372b065">,
      #splice.entry<"/build/source/tests/baseline_call_handler_on_new_section.txt" file 444 mtime 1 "b1e4a49fe3315759165a41bbfd2e5c1480c91b2975e6fa2c326e3d4a9b9c2146">,
      #splice.entry<"/build/source/tests/baseline_disallow_inline_comments.txt" file 444 mtime 1 "cb208b9c7f0f35a5999e5e052b39d6c4cf8901540c7320ab71769ed3a51a62c0">,
      #splice.entry<"/build/source/tests/baseline_handler_lineno.txt" file 444 mtime 1 "eb55bb64b1d7f2f42f5c259626c9f8c19bb332dccf10d774ca0165d749ef030b">,
      #splice.entry<"/build/source/tests/baseline_heap.txt" file 444 mtime 1 "b51d778e28c66e922f6aab74bf592e6ad90a556b3f4c560c8c04359adb5a2c53">,
      #splice.entry<"/build/source/tests/baseline_heap_max_line.txt" file 444 mtime 1 "8c0f7b850457d1b1e4da1b145b86b12a2b309115ff1a2c1a5355313afec88156">,
      #splice.entry<"/build/source/tests/baseline_heap_realloc.txt" file 444 mtime 1 "b51d778e28c66e922f6aab74bf592e6ad90a556b3f4c560c8c04359adb5a2c53">,
      #splice.entry<"/build/source/tests/baseline_heap_realloc_max_line.txt" file 444 mtime 1 "8c0f7b850457d1b1e4da1b145b86b12a2b309115ff1a2c1a5355313afec88156">,
      #splice.entry<"/build/source/tests/baseline_heap_string.txt" file 444 mtime 1 "9bfb0de2d7e323a6502640f31a72a7473ada83c791b188187c429ee714d9fd40">,
      #splice.entry<"/build/source/tests/baseline_multi.txt" file 444 mtime 1 "b51d778e28c66e922f6aab74bf592e6ad90a556b3f4c560c8c04359adb5a2c53">,
      #splice.entry<"/build/source/tests/baseline_multi_max_line.txt" file 444 mtime 1 "8c0f7b850457d1b1e4da1b145b86b12a2b309115ff1a2c1a5355313afec88156">,
      #splice.entry<"/build/source/tests/baseline_single.txt" file 444 mtime 1 "d548e8dc1bc924a918c18e2610e6a86ace6e20404994cd466320ef0c1ba68395">,
      #splice.entry<"/build/source/tests/baseline_stop_on_first_error.txt" file 444 mtime 1 "3834f7beed984d0194bed16ffe18b9bbc85bf4aebd00d4693994498d63c8320a">,
      #splice.entry<"/build/source/tests/baseline_string.txt" file 444 mtime 1 "9bfb0de2d7e323a6502640f31a72a7473ada83c791b188187c429ee714d9fd40">,
      #splice.entry<"/build/source/tests/bom.ini" file 444 mtime 1 "1277480adb4ef1398aedc8a3bccf1abc3ead79c2cbea207628a02a389cafeb6c">,
      #splice.entry<"/build/source/tests/duplicate_sections.ini" file 444 mtime 1 "e431760754ba1fa6dcc7b4021b6eac55efb3297a327aadfb0a79553fd8e11389">,
      #splice.entry<"/build/source/tests/long_line.ini" file 444 mtime 1 "0982ef47ea2372dbc971f51238bd4c58a69089cd976a4fb92b71e7dff02b4e8a">,
      #splice.entry<"/build/source/tests/long_section.ini" file 444 mtime 1 "d30b9e083f71c6bd2782152d1caa3e5bfc301cf531b6a7de53e14563b9f99ce0">,
      #splice.entry<"/build/source/tests/meson.build" file 444 mtime 1 "e6001d7bea71b0e4ba7afd6ec5ff3b65e4e7ea630a6d3c474073289d843e40d1">,
      #splice.entry<"/build/source/tests/multi_line.ini" file 444 mtime 1 "8c7cf26b6d12123e9e8f7035b312575c730ec7b67dca6f2e002651b33e051bf1">,
      #splice.entry<"/build/source/tests/name_only_after_error.ini" file 444 mtime 1 "a61332751cf055e364322e8fa6332a7d0748cc53c932b87dd984a58b872ab5f6">,
      #splice.entry<"/build/source/tests/no_value.ini" file 444 mtime 1 "3ff488d63951f9e6b9f01097745beec8aab4abac8e591d9449a3c2a56665b4ef">,
      #splice.entry<"/build/source/tests/normal.ini" file 444 mtime 1 "1698dab99f3d161a6af374bc0073f6c0b7954ff53eec5fcc812aae5a4f210adf">,
      #splice.entry<"/build/source/tests/runtest.sh" file 555 mtime 1 "2138bfb0caab8e3da2733f1535f8b5e681c25d838e9ba774b534c92455a1a6fa">,
      #splice.entry<"/build/source/tests/unittest.bat" file 444 mtime 1 "907dd3a3acfa09f5ecbd45d789a64fd59002250cf0e2293dbb517d6473caf4ab">,
      #splice.entry<"/build/source/tests/unittest.c" file 444 mtime 1 "761a665d40b845863edcd2d63f03dae3e814dbf98e17637af47d2b6009a1f300">,
      #splice.entry<"/build/source/tests/unittest.sh" file 555 mtime 1 "2259f2637f5619a0a4b79f2d2672b14145d467a24997e6dba390db33697e4780">,
      #splice.entry<"/build/source/tests/unittest_alloc.c" file 444 mtime 1 "d07a2a8a796bcef765093dfb64f05eaf8c826fa95f7edcc46f5105820bc6e669">,
      #splice.entry<"/build/source/tests/unittest_string.c" file 444 mtime 1 "e4e442c73c29aad8aca54da8702b7d9852d14788461c9dc45c86eb0fee79678f">,
      #splice.entry<"/build/source/tests/user_error.ini" file 444 mtime 1 "0983ca845483eb5349765aa78bf39a27ca249bc0825383578c8cf9dccf7b044b">
  ]
  %chmod_1853:4 = splice.literal "chmod" at 1853 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>,
      #splice.entry<"/build/source/cpp" dir 755 mtime 1>,
      #splice.entry<"/build/source/examples" dir 755 mtime 1>,
      #splice.entry<"/build/source/tests" dir 755 mtime 1>
  ]
  %chmod_1853_0 = splice.copy "chmod" at 1853(%cp_1698#10) -> <"/build/source/cpp/INIReader.cpp" file 644 mtime 1 "d8e3ce76ed09b379beef8d48ae428c9f383bf84131e5d4838f6c82eb746553c0">
  %chmod_1853_1 = splice.copy "chmod" at 1853(%cp_1698#11) -> <"/build/source/cpp/INIReader.h" file 644 mtime 1 "ec0e0d1c45b622f83664df6da3b9fcc646dabe308c354b971c14409f6d343cd9">
  %chmod_1853_2 = splice.copy "chmod" at 1853(%cp_1698#13) -> <"/build/source/examples/INIReaderExample.cpp" file 644 mtime 1 "4c70383935e86c15c211337e990a1efd050cbc97c9a757f6be60e0418ea3da19">
  %chmod_1853_3 = splice.copy "chmod" at 1853(%cp_1698#17) -> <"/build/source/examples/cpptest.txt" file 644 mtime 1 "801af84aae813c7ccd30e76aaa168f198c102e2c57c338dd9709c66dec72f749">
  %chmod_1853_4 = splice.copy "chmod" at 1853(%cp_1698#22) -> <"/build/source/examples/meson.build" file 644 mtime 1 "eb7dd837bd1edcabdd012cd278cc7fda14961b3fa52273dcab0acecdaaea5830">
  %chmod_1853_5 = splice.copy "chmod" at 1853(%cp_1698#30) -> <"/build/source/ini.c" file 644 mtime 1 "cdba16f9e826d2c692efaecbbe010c17b417315db8261fbd48b66aaab8a9d46f">
  %chmod_1853_6 = splice.copy "chmod" at 1853(%cp_1698#31) -> <"/build/source/ini.h" file 644 mtime 1 "154b56f8437ec3e08d19f9c455a409ddccd4462cff33babe5f2713269d6dd64e">
  %chmod_1853_7 = splice.copy "chmod" at 1853(%cp_1698#32) -> <"/build/source/meson.build" file 644 mtime 1 "53223582f9a897fa6d8ec537af54bc8297ad165c2ad65eaa165c1adf4f6ee7c3">
  %chmod_1853_8 = splice.copy "chmod" at 1853(%cp_1698#33) -> <"/build/source/meson_options.txt" file 644 mtime 1 "2d9b08fda904192bb1060c21ac71e7adf9349c567a72c0b9eaf231e5d29b2543">
  %chmod_1853_9 = splice.copy "chmod" at 1853(%cp_1698#38) -> <"/build/source/tests/baseline_alloc.txt" file 644 mtime 1 "0a0cc8ba60919e7f570053c55c259885903433e6e49693b499d89bbeed3e6762">
  %chmod_1853_10 = splice.copy "chmod" at 1853(%cp_1698#39) -> <"/build/source/tests/baseline_allow_no_value.txt" file 644 mtime 1 "4031e7a3ff96ae3257f76a35746421c0ef945bddbb11bc549f83f7dec372b065">
  %chmod_1853_11 = splice.copy "chmod" at 1853(%cp_1698#40) -> <"/build/source/tests/baseline_call_handler_on_new_section.txt" file 644 mtime 1 "b1e4a49fe3315759165a41bbfd2e5c1480c91b2975e6fa2c326e3d4a9b9c2146">
  %chmod_1853_12 = splice.copy "chmod" at 1853(%cp_1698#41) -> <"/build/source/tests/baseline_disallow_inline_comments.txt" file 644 mtime 1 "cb208b9c7f0f35a5999e5e052b39d6c4cf8901540c7320ab71769ed3a51a62c0">
  %chmod_1853_13 = splice.copy "chmod" at 1853(%cp_1698#42) -> <"/build/source/tests/baseline_handler_lineno.txt" file 644 mtime 1 "eb55bb64b1d7f2f42f5c259626c9f8c19bb332dccf10d774ca0165d749ef030b">
  %chmod_1853_14 = splice.copy "chmod" at 1853(%cp_1698#43) -> <"/build/source/tests/baseline_heap.txt" file 644 mtime 1 "b51d778e28c66e922f6aab74bf592e6ad90a556b3f4c560c8c04359adb5a2c53">
  %chmod_1853_15 = splice.copy "chmod" at 1853(%cp_1698#44) -> <"/build/source/tests/baseline_heap_max_line.txt" file 644 mtime 1 "8c0f7b850457d1b1e4da1b145b86b12a2b309115ff1a2c1a5355313afec88156">
  %chmod_1853_16 = splice.copy "chmod" at 1853(%cp_1698#45) -> <"/build/source/tests/baseline_heap_realloc.txt" file 644 mtime 1 "b51d778e28c66e922f6aab74bf592e6ad90a556b3f4c560c8c04359adb5a2c53">
  %chmod_1853_17 = splice.copy "chmod" at 1853(%cp_1698#46) -> <"/build/source/tests/baseline_heap_realloc_max_line.txt" file 644 mtime 1 "8c0f7b850457d1b1e4da1b145b86b12a2b309115ff1a2c1a5355313afec88156">
  %chmod_1853_18 = splice.copy "chmod" at 1853(%cp_1698#47) -> <"/build/source/tests/baseline_heap_string.txt" file 644 mtime 1 "9bfb0de2d7e323a6502640f31a72a7473ada83c791b188187c429ee714d9fd40">
  %chmod_1853_19 = splice.copy "chmod" at 1853(%cp_1698#48) -> <"/build/source/tests/baseline_multi.txt" file 644 mtime 1 "b51d778e28c66e922f6aab74bf592e6ad90a556b3f4c560c8c04359adb5a2c53">
  %chmod_1853_20 = splice.copy "chmod" at 1853(%cp_1698#49) -> <"/build/source/tests/baseline_multi_max_line.txt" file 644 mtime 1 "8c0f7b850457d1b1e4da1b145b86b12a2b309115ff1a2c1a5355313afec88156">
  %chmod_1853_21 = splice.copy "chmod" at 1853(%cp_1698#50) -> <"/build/source/tests/baseline_single.txt" file 644 mtime 1 "d548e8dc1bc924a918c18e2610e6a86ace6e20404994cd466320ef0c1ba68395">
  %chmod_1853_22 = splice.copy "chmod" at 1853(%cp_1698#51) -> <"/build/source/tests/baseline_stop_on_first_error.txt" file 644 mtime 1 "3834f7beed984d0194bed16ffe18b9bbc85bf4aebd00d4693994498d63c8320a">
  %chmod_1853_23 = splice.copy "chmod" at 1853(%cp_1698#52) -> <"/build/source/tests/baseline_string.txt" file 644 mtime 1 "9bfb0de2d7e323a6502640f31a72a7473ada83c791b188187c429ee714d9fd40">
  %chmod_1853_24 = splice.copy "chmod" at 1853(%cp_1698#57) -> <"/build/source/tests/meson.build" file 644 mtime 1 "e6001d7bea71b0e4ba7afd6ec5ff3b65e4e7ea630a6d3c474073289d843e40d1">
  %chmod_1853_25 = splice.copy "chmod" at 1853(%cp_1698#62) -> <"/build/source/tests/runtest.sh" file 755 mtime 1 "2138bfb0caab8e3da2733f1535f8b5e681c25d838e9ba774b534c92455a1a6fa">
  %chmod_1853_26 = splice.copy "chmod" at 1853(%cp_1698#64) -> <"/build/source/tests/unittest.c" file 644 mtime 1 "761a665d40b845863edcd2d63f03dae3e814dbf98e17637af47d2b6009a1f300">
  %chmod_1853_27 = splice.copy "chmod" at 1853(%cp_1698#66) -> <"/build/source/tests/unittest_alloc.c" file 644 mtime 1 "d07a2a8a796bcef765093dfb64f05eaf8c826fa95f7edcc46f5105820bc6e669">
  %chmod_1853_28 = splice.copy "chmod" at 1853(%cp_1698#67) -> <"/build/source/tests/unittest_string.c" file 644 mtime 1 "e4e442c73c29aad8aca54da8702b7d9852d14788461c9dc45c86eb0fee79678f">
  %meson_2273:5 = splice.literal "meson" at 2273 folded -> [
      #splice.entry<"/build/source/build" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/libINIReader.so.0.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/libinih.so.0.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-logs" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-private" dir 755 mtime 1795046400>
  ]
  %meson_2273_29:60 = splice.exec "meson" at 2273(%sandbox_717, %chmod_1853#0, %chmod_1853#1, %chmod_1853_0, %chmod_1853_1, %chmod_1853#2, %chmod_1853_2, %chmod_1853_3, %chmod_1853_4, %chmod_1853_5, %chmod_1853_6, %chmod_1853_7, %chmod_1853_8, %chmod_1853#3, %chmod_1853_9, %chmod_1853_10, %chmod_1853_11, %chmod_1853_12, %chmod_1853_13, %chmod_1853_14, %chmod_1853_15, %chmod_1853_16, %chmod_1853_17, %chmod_1853_18, %chmod_1853_19, %chmod_1853_20, %chmod_1853_21, %chmod_1853_22, %chmod_1853_23, %chmod_1853_24, %chmod_1853_25, %chmod_1853_26, %chmod_1853_27, %chmod_1853_28) -> [
      #splice.entry<"/build/source/build" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/.gitignore" file 644 mtime 1795046400 "819ebd0aeb8f0b73d237a02d9344ad1fd6fae6ad763cacf1694a6d13c1986cde">,
      #splice.entry<"/build/source/build/.hgignore" file 644 mtime 1795046400 "76174f78786678776a5093c21a8b1c397aa108712422591077dc9ef92641f08b">,
      #splice.entry<"/build/source/build/build.ninja" file 644 mtime 1795046400 "cd3f9d26c17a2f9f9f3625cfb9a9f615dd971d11104cc8a1dc6cded43f79a26b">,
      #splice.entry<"/build/source/build/compile_commands.json" file 644 mtime 1795046400 "7473a866f3c62d6ada1b0eec3405ec9d0972b2c44f35e2cf926b2015f636e7e2">,
      #splice.entry<"/build/source/build/examples" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/examples/unittest_INIReaderExample.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/libINIReader.so" link 0 mtime 1795046400 "libINIReader.so.0">,
      #splice.entry<"/build/source/build/libINIReader.so.0.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/libinih.so" link 0 mtime 1795046400 "libinih.so.0">,
      #splice.entry<"/build/source/build/libinih.so.0.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-info" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-info/intro-benchmarks.json" file 644 mtime 1795046400 "4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945">,
      #splice.entry<"/build/source/build/meson-info/intro-buildoptions.json" file 644 mtime 1795046400 "7a9b38c43c44298c7cd0822232a69254827cc71318244a501ad0d731b9dcccee">,
      #splice.entry<"/build/source/build/meson-info/intro-buildsystem_files.json" file 644 mtime 1795046400 "fa579f78f4b18db3d866865a138f801de71744262419fea07e743d337e186c98">,
      #splice.entry<"/build/source/build/meson-info/intro-compilers.json" file 644 mtime 1795046400 "e1e652618cde9460ba7a4bfc5fcca86644b55ec9f4b6ed99ae4b105995805d46">,
      #splice.entry<"/build/source/build/meson-info/intro-dependencies.json" file 644 mtime 1795046400 "4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945">,
      #splice.entry<"/build/source/build/meson-info/intro-install_plan.json" file 644 mtime 1795046400 "06218af981b914265d62096ff582c8d13cb2211fa4eca2f7e002388cb34dd2ec">,
      #splice.entry<"/build/source/build/meson-info/intro-installed.json" file 644 mtime 1795046400 "5be6b6eceda9e55d571499775b5f0e361fe9fea4c00db1aff6d7d50ef150432d">,
      #splice.entry<"/build/source/build/meson-info/intro-machines.json" file 644 mtime 1795046400 "8cd6f4e915de02683cbedf981d386d68de82ec8752ae75086dcbce0dc3a51685">,
      #splice.entry<"/build/source/build/meson-info/intro-projectinfo.json" file 644 mtime 1795046400 "221ae0841a6796d1c7a652979c6d9e57b61900ce3ec27d931f9f94d2c36e6e86">,
      #splice.entry<"/build/source/build/meson-info/intro-targets.json" file 644 mtime 1795046400 "d531ed55c8e5aeaa12e63b84ace7e8e27f5b4246ac8422fb22ddff8bb5d844ed">,
      #splice.entry<"/build/source/build/meson-info/intro-tests.json" file 644 mtime 1795046400 "33d4c63abfc8639eff3968440bcdd2973a09f87fa56ab4860146ac31918642f4">,
      #splice.entry<"/build/source/build/meson-info/meson-info.json" file 644 mtime 1795046400 "16e2fae8b95db5f8795c45cdf22e6f93b700e17bdca6335bd47e7736477d4000">,
      #splice.entry<"/build/source/build/meson-logs" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-logs/meson-log.txt" file 644 mtime 1795046400 "4ee4bbacd65363573185878fdaad50c112c9cdba36815ce6c709f49219c2df99">,
      #splice.entry<"/build/source/build/meson-logs/meson-setup.txt" file 644 mtime 1795046400 "ef0e62ee5aaab21c66ce2efb30723201f6ce8de1b909b9eead4981c9d86a8abd">,
      #splice.entry<"/build/source/build/meson-private" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-private/INIReader.pc" file 644 mtime 1795046400 "30c72694522c8f2c290a1df321012afc03b2bad1fbd5e7a5eaf24140cb13e223">,
      #splice.entry<"/build/source/build/meson-private/build.dat" file 644 mtime 1795046400 "7c3ff9dfae96731e5dea3030ebc99071671395e22130898165fc1c1af3a23e48">,
      #splice.entry<"/build/source/build/meson-private/cmd_line.txt" file 644 mtime 1795046400 "6dcda9619587fd5d294459a05d62d58be7e0ae73b3d8db8c088f7fb5117b7d6e">,
      #splice.entry<"/build/source/build/meson-private/coredata.dat" file 644 mtime 1795046400 "580fb5f0cfb09848907c69b3af6eeeca5fe75470447fd2de1ac440bdd715fbc2">,
      #splice.entry<"/build/source/build/meson-private/inih.pc" file 644 mtime 1795046400 "ebae029a376964992ddc86e27a32ec949a7509b73a9a82cc2c2b27ea9bd17c09">,
      #splice.entry<"/build/source/build/meson-private/install.dat" file 644 mtime 1795046400 "67a93cd27b66a0b805e5876b29197b2a39e974a4d25bd42b18bf00068a8a1708">,
      #splice.entry<"/build/source/build/meson-private/meson.lock" file 644 mtime 1795046400 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">,
      #splice.entry<"/build/source/build/meson-private/meson_benchmark_setup.dat" file 644 mtime 1795046400 "ec0a6ccf9debf1c16781445c4b9106080d00478b0559469336db7c7b7b9711c8">,
      #splice.entry<"/build/source/build/meson-private/meson_test_setup.dat" file 644 mtime 1795046400 "c76d1dac2350f3dd114d6f256b5e1f576c22e23a92d5767f09e0ae84f51a6a46">,
      #splice.entry<"/build/source/build/meson-private/sanitycheckc.c" file 644 mtime 1795046400 "7cee72cb9c29201a501aa43d577f031bdc6e5b2d2e318a0900b7614ba260377e">,
      #splice.entry<"/build/source/build/meson-private/sanitycheckc.exe" file 755 mtime 1795046400 "1a93cc917bede9f53dfa95ea6e858f6d065a6f6afab9dc64dedbbb2d0c8eb6b9">,
      #splice.entry<"/build/source/build/meson-private/sanitycheckcpp.cc" file 644 mtime 1795046400 "ce59c88d321059b1ae99c9da670d7174ff5bbcb019faf3a5c49eced269a81b1f">,
      #splice.entry<"/build/source/build/meson-private/sanitycheckcpp.exe" file 755 mtime 1795046400 "53d01737705603b66d4cbdef18114597b51175b2601fae5e22e4b30f2365ac10">,
      #splice.entry<"/build/source/build/meson-uninstalled" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/meson-uninstalled/INIReader-uninstalled.pc" file 644 mtime 1795046400 "44909eec1435cf74133c2b7ded1780dcfce25680d4a2541c71fa2d3f97fdc3e9">,
      #splice.entry<"/build/source/build/meson-uninstalled/inih-uninstalled.pc" file 644 mtime 1795046400 "45e326370da6efc9dcce78ed1b54b41725a182243b4cc8c8d3fb539ac2de0ac3">,
      #splice.entry<"/build/source/build/tests" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_alloc.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_allow_no_value.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_call_handler_on_new_section.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_disallow_inline_comments.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_handler_lineno.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_heap.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_heap_max_line.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_heap_realloc.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_heap_realloc_max_line.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_heap_string.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_multi.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_multi_max_line.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_single.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_stop_on_first_error.p" dir 755 mtime 1795046400>,
      #splice.entry<"/build/source/build/tests/unittest_string.p" dir 755 mtime 1795046400>
  ]
  %gcc_9378:2 = splice.exec "gcc" at 9378 as "cc_object"(%sandbox_717, %chmod_1853#0, %meson_2273#0, %meson_2273#2, %chmod_1853_5, %chmod_1853_6) -> [
      #splice.entry<"/build/source/build/libinih.so.0.p/ini.c.o" file 644 mtime 1795046400 "5f74ea7105098956686fb46d4494f3f48ba2febd0cefb3ac6dbebbdc8a018721">,
      #splice.entry<"/build/source/build/libinih.so.0.p/ini.c.o.d" file 644 mtime 1795046400 "00716c35f737dc73b3a3d82f5c752ffab022cb5ef9f9093596174be40450b785">
  ]
  %gcc_9559 = splice.exec "gcc" at 9559 as "cc_shared_library"(%sandbox_717, %chmod_1853#0, %meson_2273#0, %meson_2273#2, %gcc_9378#0) -> [
      #splice.entry<"/build/source/build/libinih.so.0" file 755 mtime 1795046400 "8884526c197f2baf98c288abca857040a15c1e995cc95cc1b633e3564848483e">
  ]
  %g___14608:2 = splice.exec "g++" at 14608 as "cc_object"(%sandbox_717, %chmod_1853#0, %meson_2273#0, %meson_2273#1, %chmod_1853#1, %chmod_1853_0, %chmod_1853_1, %chmod_1853_6) -> [
      #splice.entry<"/build/source/build/libINIReader.so.0.p/cpp_INIReader.cpp.o" file 644 mtime 1795046402 "cef4202eb3b9a7f8af92c36c15960095b0624dd35ec2f1c86451a0f13ac16beb">,
      #splice.entry<"/build/source/build/libINIReader.so.0.p/cpp_INIReader.cpp.o.d" file 644 mtime 1795046402 "151bcdb99701a4cbcf36a6fc8388a06f02355f98df870f80d182964c25d946f9">
  ]
  %g___18177 = splice.exec "g++" at 18177 as "cc_shared_library"(%sandbox_717, %chmod_1853#0, %meson_2273#0, %meson_2273#1, %g___14608#0, %gcc_9559) -> [
      #splice.entry<"/build/source/build/libINIReader.so.0" file 755 mtime 1795046404 "51df7c5aed1021363d02a741805bc349c7e1f4d2d8fe6f0337b0667f2af6cf5a">
  ]
  %meson_18589:7 = splice.literal "meson" at 18589 folded -> [
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libINIReader.so" link 0 mtime 1795046404 "libINIReader.so.0">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libinih.so" link 0 mtime 1795046404 "libinih.so.0">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/pkgconfig" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/include" dir 755 mtime 1795046404>
  ]
  %meson_18589_30 = splice.copy "meson" at 18589(%gcc_9559) -> <"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libinih.so.0" file 755 mtime 1795046404 "8884526c197f2baf98c288abca857040a15c1e995cc95cc1b633e3564848483e">
  %meson_18589_31 = splice.copy "meson" at 18589(%cp_1698#11) -> <"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/include/INIReader.h" file 644 mtime 1 "ec0e0d1c45b622f83664df6da3b9fcc646dabe308c354b971c14409f6d343cd9">
  %meson_18589_32 = splice.copy "meson" at 18589(%cp_1698#31) -> <"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/include/ini.h" file 644 mtime 1 "154b56f8437ec3e08d19f9c455a409ddccd4462cff33babe5f2713269d6dd64e">
  %meson_18589_33:14 = splice.exec "meson" at 18589(%sandbox_717, %chmod_1853#0, %meson_2273#0, %g___18177, %gcc_9559, %meson_2273#3, %meson_2273#4, %meson_2273_29#28, %meson_2273_29#32, %meson_2273_29#33, %chmod_1853#1, %chmod_1853_1, %chmod_1853_6) -> [
      #splice.entry<"/build/source/build/meson-logs/install-log.txt" file 644 mtime 1795046404 "3ba41a7438d5bf6d80ad065dec95088e17438147a5fa81d597ea4c10b6f94bd7">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libINIReader.so" link 0 mtime 1795046404 "libINIReader.so.0">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libINIReader.so.0" file 755 mtime 1795046404 "d9dd57a2689f5ab4214791fd918cae9e4653ddddc25d23d955fce24420d50dc2">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libinih.so" link 0 mtime 1795046404 "libinih.so.0">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libinih.so.0" file 755 mtime 1795046404 "8884526c197f2baf98c288abca857040a15c1e995cc95cc1b633e3564848483e">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/pkgconfig" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/pkgconfig/INIReader.pc" file 644 mtime 1795046400 "30c72694522c8f2c290a1df321012afc03b2bad1fbd5e7a5eaf24140cb13e223">,
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/pkgconfig/inih.pc" file 644 mtime 1795046400 "ebae029a376964992ddc86e27a32ec949a7509b73a9a82cc2c2b27ea9bd17c09">,
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/include" dir 755 mtime 1795046404>,
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/include/INIReader.h" file 644 mtime 1 "ec0e0d1c45b622f83664df6da3b9fcc646dabe308c354b971c14409f6d343cd9">,
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/include/ini.h" file 644 mtime 1 "154b56f8437ec3e08d19f9c455a409ddccd4462cff33babe5f2713269d6dd64e">
  ]
  %mkdir_21861 = splice.literal "mkdir" at 21861 folded -> [
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/lib" dir 755 mtime 1795046404>
  ]
  %mv_21883 = splice.literal "mv" at 21883 folded -> [
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/lib/pkgconfig" dir 755 mtime 1795046404>
  ]
  %sed_21986 = splice.copy "sed" at 21986(%meson_2273_29#28) -> <"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/lib/pkgconfig/INIReader.pc" file 644 mtime 1795046404 "30c72694522c8f2c290a1df321012afc03b2bad1fbd5e7a5eaf24140cb13e223">
  %sed_22012 = splice.copy "sed" at 22012(%meson_2273_29#32) -> <"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/lib/pkgconfig/inih.pc" file 644 mtime 1795046404 "ebae029a376964992ddc86e27a32ec949a7509b73a9a82cc2c2b27ea9bd17c09">
  %find_patchelf_patchelf_22063 = splice.exec "find|patchelf|patchelf" at 22063(%sandbox_717, %chmod_1853#0, %meson_2273#0, %meson_18589#0, %meson_18589#1, %meson_18589_33#4, %meson_18589_30) -> [
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libinih.so.0" file 755 mtime 1795046404 "fb699855c883315ac80b568a7609282ddaa1d7ed2b13c09bd3f6c6e470420ad3">
  ]
  %mktemp_22498 = splice.literal "mktemp" at 22498 folded -> [
      #splice.entry<"/build/striperr.DV7StM" file 600 mtime 1795046404 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_22607 = splice.exec "strip" at 22607(%sandbox_717, %chmod_1853#0, %meson_2273#0, %mktemp_22498, %meson_18589#0, %meson_18589#1, %find_patchelf_patchelf_22063) -> [
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libinih.so.0" file 755 mtime 1795046404 "3f22f214f5296a70c41505a8cec295410d2452668d51aef2d30846fb22fc994b">
  ]
  %strip_22651 = splice.exec "strip" at 22651(%sandbox_717, %chmod_1853#0, %meson_2273#0, %mktemp_22498, %meson_18589#0, %meson_18589#1, %meson_18589_33#4) -> [
      #splice.entry<"/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62/lib/libINIReader.so.0" file 755 mtime 1795046404 "7f2331e54d66cdf3cceacf36334079d66bf402af49480f55436b162fef55a4a1">
  ]
  %mkdir_23644 = splice.literal "mkdir" at 23644 folded -> [
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/nix-support" dir 755 mtime 1795046404>
  ]
  %glue_23667 = splice.literal "glue" at 23667 -> [
      #splice.entry<"/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev/nix-support/propagated-build-inputs" file 644 mtime 1795046404 "aad9e7e10731c3ff7572583f73cdea095504b6c8b69704849e48114097edf0b1">
  ]
  splice.output "dev" "/nix/store/vsnhi4gz0dvl0ml700s97314kj58r9g4-inih-62-dev"(%meson_18589#5, %meson_18589#6, %meson_18589_31, %meson_18589_32, %mkdir_21861, %mv_21883, %sed_21986, %sed_22012, %mkdir_23644, %glue_23667)
  splice.output "out" "/nix/store/bgdzq5lb4ws5q6bmg07j5bgdqwdb4f4d-inih-62"(%meson_18589#0, %meson_18589#1, %meson_18589#2, %strip_22651, %meson_18589#3, %strip_22607)
}

