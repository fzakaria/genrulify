module {
  %sandbox_716 = splice.literal "sandbox" at 716 -> [
      #splice.entry<"/build" dir 700 mtime 1>
  ]
  %cp_2274:88 = splice.exec "cp" at 2274(%sandbox_716) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/.editorconfig" file 444 mtime 1 "617d611551afbacad70c75b7d3d48755d5dd67d2e23886ab58dd24a02082585b">,
      #splice.entry<"/build/source/.github" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/CONTRIBUTING.md" file 444 mtime 1 "0d29b2427ec0cbc98becc7fea115e1373ca520aba4b6b560ea21365fce054b1a">,
      #splice.entry<"/build/source/.gitignore" file 444 mtime 1 "e4970243a93cc439c1d9a0addb641ca775148208616ae38e14dd02b29990e979">,
      #splice.entry<"/build/source/CHANGELOG.md" file 444 mtime 1 "22a8a706b33c13fa54669334164eadb118537e2a7b245f4f26d6b2b8e226a2dd">,
      #splice.entry<"/build/source/CONTRIBUTORS.md" file 444 mtime 1 "4952ff9afc9ad1850a39f1dd29edaa8e2c0bd4d11473475ada0f2296f826d2db">,
      #splice.entry<"/build/source/INSTALL" file 444 mtime 1 "823d4907d91a258924281261a88d992e8efe852404386746ca50bd4ad224bb21">,
      #splice.entry<"/build/source/LICENSE.txt" file 444 mtime 1 "8ceb4b9ee5adedde47b31e975c1d90c73ad27b6b165a1dcd80c7c545eb65b903">,
      #splice.entry<"/build/source/Makefile" file 444 mtime 1 "f6e4f2598153a5f75281e0afcc2d1712ad806c5b0352a9e9a34068b707da8ef4">,
      #splice.entry<"/build/source/README" file 444 mtime 1 "5d7e2ec104b999bf6886b2d08bb4e26a0b6fc07846f66b408967a4561202386a">,
      #splice.entry<"/build/source/README.md" file 444 mtime 1 "73f35d62ed6e9e676a463b77f73e18e603d29f5b1420aecbef0ddad4e34484ad">,
      #splice.entry<"/build/source/archive" dir 555 mtime 1>,
      #splice.entry<"/build/source/archive/cows-off" dir 555 mtime 1>,
      #splice.entry<"/build/source/archive/cows-off/DragonAndCow.pm" file 444 mtime 1 "a19dac493e856bf749438f6632b7b2f62029a331c4b4af8baa7d30313bb7943e">,
      #splice.entry<"/build/source/archive/cows-off/Example.pm" file 444 mtime 1 "bdbb138a170abbe4f478ad2ab85ff8007db3fe2be26d4d14cdf687ef5a6259c4">,
      #splice.entry<"/build/source/archive/cows-off/Frogs.pm" file 444 mtime 1 "5fc96639da0098b630098ed3b139c22200d97d6a77e014e0895e81e5a808d2fa">,
      #splice.entry<"/build/source/archive/cows-off/MechAndCow.pm" file 444 mtime 1 "7d09bd0c4ae144b2b25da0b8ebb108f4fc92189e07bc7ea29efcc3338d20447d">,
      #splice.entry<"/build/source/archive/cows-off/Stegosaurus.pm" file 444 mtime 1 "0902d2f7f976329e42ea519cf413514357099ac4bc5e3f35c1f1b0617af0bf38">,
      #splice.entry<"/build/source/archive/cows-off/TextBalloon.pm" file 444 mtime 1 "9b5040497a8e877cf3c38b109d5f9039f95222941b904b151b917bbee191b8f5">,
      #splice.entry<"/build/source/archive/cows-off/TuxStab.pm" file 444 mtime 1 "76655a6f7ea4918272a5ad22aa4f4a5a59813c8495814e21ea9ca31ae2dc87a1">,
      #splice.entry<"/build/source/bin" dir 555 mtime 1>,
      #splice.entry<"/build/source/bin/cowsay" file 555 mtime 1 "b19fba7f1e2cbd1f34e5ceb298e3c1e5727c34ffa8fa8a28b9ec621071e2981d">,
      #splice.entry<"/build/source/bin/cowthink" link 0 mtime 1 "cowsay">,
      #splice.entry<"/build/source/doc-project" dir 555 mtime 1>,
      #splice.entry<"/build/source/doc-project/Developer Notes.md" file 444 mtime 1 "d034a2ff0e3ff9e0fc347693cade5c6003b8d6d04ec669d073fe9cda1d75369a">,
      #splice.entry<"/build/source/doc-project/Release Checklist.md" file 444 mtime 1 "6eaede7296d36aa74720d65e968ebdca896ef5685db9ddc88077c730bd02d081">,
      #splice.entry<"/build/source/man" dir 555 mtime 1>,
      #splice.entry<"/build/source/man-src" dir 555 mtime 1>,
      #splice.entry<"/build/source/man-src/man1" dir 555 mtime 1>,
      #splice.entry<"/build/source/man-src/man1/cowsay.1.adoc" file 444 mtime 1 "86e206d571cf4efff60c27cab70bc73bf787064dc55a725f2392d97d7373a5d6">,
      #splice.entry<"/build/source/man/man1" dir 555 mtime 1>,
      #splice.entry<"/build/source/man/man1/cowsay.1" file 444 mtime 1 "0d713f136b623336ea211e0dcf4f4127604a4b2dc91cb6573200ebab8cb5ca78">,
      #splice.entry<"/build/source/man/man1/cowthink.1" link 0 mtime 1 "cowsay.1">,
      #splice.entry<"/build/source/share" dir 555 mtime 1>,
      #splice.entry<"/build/source/share/cowsay" dir 555 mtime 1>,
      #splice.entry<"/build/source/share/cowsay/cows" dir 555 mtime 1>,
      #splice.entry<"/build/source/share/cowsay/cows/actually.cow" file 444 mtime 1 "988285293148e2b45fa6c2c7524dccc99559ef3dd5f8eff9e8b1172fb00ad4bf">,
      #splice.entry<"/build/source/share/cowsay/cows/alpaca.cow" file 444 mtime 1 "2bd90a3af14d15252ab29b2e6fe759fd17baf4e5bbb5139263b78faa3e578ee5">,
      #splice.entry<"/build/source/share/cowsay/cows/beavis.zen.cow" file 444 mtime 1 "39ede9994672a77537bfc0e453dd2fa9b0f65124d27084db5f648380b806f800">,
      #splice.entry<"/build/source/share/cowsay/cows/blowfish.cow" file 444 mtime 1 "a02f19f8018a58032a1a1ceb7527ee655a7bc2dc3e520faaeaece6781d82806b">,
      #splice.entry<"/build/source/share/cowsay/cows/bong.cow" file 444 mtime 1 "18dd05111f44d1fa0497b2ecf981151b28be2d7373a8d4793e55558d1b116e68">,
      #splice.entry<"/build/source/share/cowsay/cows/bud-frogs.cow" file 444 mtime 1 "7a43605a9b020bd86f421c6ac62b99285732b774de48747d5af388988df322ae">,
      #splice.entry<"/build/source/share/cowsay/cows/bunny.cow" file 444 mtime 1 "9b846abb1516a4d74cbec1647f97642542d1cc0beff012fc476afdc911d552cd">,
      #splice.entry<"/build/source/share/cowsay/cows/cheese.cow" file 444 mtime 1 "5edf516643619ac9ad9427795229ae548296c1aaaf707960a918eccc3078a6e3">,
      #splice.entry<"/build/source/share/cowsay/cows/cower.cow" file 444 mtime 1 "fd7999050385fa0218b429b0021f62a13fda72c0be49e0acc7db747c58ae368a">,
      #splice.entry<"/build/source/share/cowsay/cows/cupcake.cow" file 444 mtime 1 "c09bbb9aa756900c586e781775b093ee28ead65c2315a61aaf218c0206964f48">,
      #splice.entry<"/build/source/share/cowsay/cows/daemon.cow" file 444 mtime 1 "70d4e2177f5af1fb5f1e88da8ed51e08557aac7742979751562a213117e0f69f">,
      #splice.entry<"/build/source/share/cowsay/cows/default.cow" file 444 mtime 1 "da4d563fdbb2334a7b70a2c916c299696ffc53f546e456d6c3d3a9b3c69a7142">,
      #splice.entry<"/build/source/share/cowsay/cows/dragon-and-cow.cow" file 444 mtime 1 "a6da60034bebd5f93ca83ad2e3b3b55543b824874fc7540817ab3d955dc280fe">,
      #splice.entry<"/build/source/share/cowsay/cows/dragon.cow" file 444 mtime 1 "2d1584769f6d3fbe47fc7713685c012baf889e15ad5224e0340b9b31994c6e78">,
      #splice.entry<"/build/source/share/cowsay/cows/elephant-in-snake.cow" file 444 mtime 1 "869a18dfa0868c51403c90245e6d8d2c2cd19f8933b1897f0641c98eef27844b">,
      #splice.entry<"/build/source/share/cowsay/cows/elephant.cow" file 444 mtime 1 "ae35fee206515047f5226eed21fbdb413e523a20b9a932b9a10f3a1833ab5a78">,
      #splice.entry<"/build/source/share/cowsay/cows/eyes.cow" file 444 mtime 1 "079e48cbe0ec834af46c16e55ef0a5c9f2698c756f5fa24ced56e7a4df155aa4">,
      #splice.entry<"/build/source/share/cowsay/cows/flaming-sheep.cow" file 444 mtime 1 "4486fb19d1b4cfdcd04f5fc067e8f757f7d58881a2ff6fa7f479a1295e01a4ac">,
      #splice.entry<"/build/source/share/cowsay/cows/fox.cow" file 444 mtime 1 "b36d717168cde7cc5fe222fba6384de14d7b0bfd4a60a0e300f1df0414c0f2a5">,
      #splice.entry<"/build/source/share/cowsay/cows/ghostbusters.cow" file 444 mtime 1 "51769e176ac8a7dd1f394923be42a102ab7141eb5b9c8d3161af5cac5c10ae9a">,
      #splice.entry<"/build/source/share/cowsay/cows/head-in.cow" file 444 mtime 1 "194ae212191a2bca94544eeedc42a5b9dd9b1eb3b1acce4b243b3a8579542e2f">,
      #splice.entry<"/build/source/share/cowsay/cows/hellokitty.cow" file 444 mtime 1 "7b851f472108a68f2c9d46b4995d12b9f104d4b51c8d688072c11bdcf248eaeb">,
      #splice.entry<"/build/source/share/cowsay/cows/kiss.cow" file 444 mtime 1 "d850c026bc240896f9ef98667dee1f9d9c9a2b798453226b03025d96c52d4e5a">,
      #splice.entry<"/build/source/share/cowsay/cows/kitty.cow" file 444 mtime 1 "13fdc4ccbd29a372dbd44637c7a102cd757cac199242940fb9dff254d5aba280">,
      #splice.entry<"/build/source/share/cowsay/cows/koala.cow" file 444 mtime 1 "a99068fcc904aa8ba178aa0c7da8d4072fca4fdb02d3f351d389a9b2963bb847">,
      #splice.entry<"/build/source/share/cowsay/cows/kosh.cow" file 444 mtime 1 "7323132a0c8ccccb26ac2c2f56bff26362c9b509fe70232e188c878104d237d4">,
      #splice.entry<"/build/source/share/cowsay/cows/llama.cow" file 444 mtime 1 "1ff84a08491d5d0cc7673cb5b944f40d8437818ae3923e8d66850ce487ac8fe4">,
      #splice.entry<"/build/source/share/cowsay/cows/luke-koala.cow" file 444 mtime 1 "b939031e08a7316c81fa05f9e95793ac5a907c267bfe1166f44ecb04305e8baf">,
      #splice.entry<"/build/source/share/cowsay/cows/mech-and-cow.cow" file 444 mtime 1 "719853d6e24dd84d03f93ea87ef1681ce7d7e86425fbc4c80eee69d48b01b0a9">,
      #splice.entry<"/build/source/share/cowsay/cows/meow.cow" file 444 mtime 1 "70b9cb3472cbe11573369e64bfe7590adcabd3f705492282b6f07d052594bfba">,
      #splice.entry<"/build/source/share/cowsay/cows/milk.cow" file 444 mtime 1 "7196f5672664801f9944027bfada64c5927db72e1027466e2d75bca819bd47af">,
      #splice.entry<"/build/source/share/cowsay/cows/moofasa.cow" file 444 mtime 1 "638f1e9a5909ea492dca4f4d96464b343eb15b03e77be85e593e625d502fee25">,
      #splice.entry<"/build/source/share/cowsay/cows/moose.cow" file 444 mtime 1 "c8275cc4794af5bb21761ba724fa77372a59e3aaa60b3e15ae1c015eb3c94927">,
      #splice.entry<"/build/source/share/cowsay/cows/mutilated.cow" file 444 mtime 1 "53e572d163892c1f43e38114b42d59ce607032b40c744891fbcf60d5a581efa8">,
      #splice.entry<"/build/source/share/cowsay/cows/ren.cow" file 444 mtime 1 "c5b4baa4ed8215be5ceb8939fe0a8423895250c830f88483676cd8c892bb6c09">,
      #splice.entry<"/build/source/share/cowsay/cows/sheep.cow" file 444 mtime 1 "c9bfa802a20827c396fdbe5f002b173acb95e9ac138e23759fc6df89352be8f9">,
      #splice.entry<"/build/source/share/cowsay/cows/skeleton.cow" file 444 mtime 1 "16864e050225f3b7e3644fc861acb9dd1bd050dc37afe95f53a8e13b8bad0745">,
      #splice.entry<"/build/source/share/cowsay/cows/small.cow" file 444 mtime 1 "31f1c6f6221e2924b9c3b801db03f1f185af923c32e2d8773db4f28a6fd9662c">,
      #splice.entry<"/build/source/share/cowsay/cows/stegosaurus.cow" file 444 mtime 1 "2cd04f315f13f3feab7231b49f373900d18880cb7461ae0e6ea86793ba1e33ad">,
      #splice.entry<"/build/source/share/cowsay/cows/stimpy.cow" file 444 mtime 1 "07ad27813d038c1dfb42ce3040dff6bc6a8f60037003f9ddab8251f7620ba2da">,
      #splice.entry<"/build/source/share/cowsay/cows/supermilker.cow" file 444 mtime 1 "e9d0bbdb18fb7b0386eb88bec0465924b8184e040844591648d71b0b200804a2">,
      #splice.entry<"/build/source/share/cowsay/cows/surgery.cow" file 444 mtime 1 "257735413351fa6f2dba4ec2d15786a087244527ddf4c51043d711641844cee3">,
      #splice.entry<"/build/source/share/cowsay/cows/sus.cow" file 444 mtime 1 "571dd5e57453c908e66ea10a8d45e42b99e20fb6f44f3c7a71009398d104b0d7">,
      #splice.entry<"/build/source/share/cowsay/cows/three-eyes.cow" file 444 mtime 1 "cc68f32f395876abc4195fb60e4b3f5d26a1717c473a0454db7ebe6539c1b1bb">,
      #splice.entry<"/build/source/share/cowsay/cows/turkey.cow" file 444 mtime 1 "f04002cbd5d3fca201fa722c7aec3fbed8cea080f7cc30daa1740cd692ab6067">,
      #splice.entry<"/build/source/share/cowsay/cows/turtle.cow" file 444 mtime 1 "796ff5f3e6fe8fb658a78c874e40e0a2fb25cbf15079b152bcb5ac94e626eb07">,
      #splice.entry<"/build/source/share/cowsay/cows/tux.cow" file 444 mtime 1 "2afd7931c855323431b02eeb9450670c5f5d82305ee57a93df27b2c9cde826ee">,
      #splice.entry<"/build/source/share/cowsay/cows/udder.cow" file 444 mtime 1 "5c8b7f6e06fbe59412555f2e2e9b45761d0c38fef4391efd8e032703f827417b">,
      #splice.entry<"/build/source/share/cowsay/cows/vader-koala.cow" file 444 mtime 1 "05ece89aaa3ebca1ea27f5ebecf5056557a71f94ed6887af8322cded8e651fef">,
      #splice.entry<"/build/source/share/cowsay/cows/vader.cow" file 444 mtime 1 "7bf1a1faaf7ab74365fff6ad373abd0ce5e44f99f129e0b551bbc55b2097be9c">,
      #splice.entry<"/build/source/share/cowsay/cows/www.cow" file 444 mtime 1 "81f49ef787d66024118a9876078dcb1da6ad4af652c3ad3115697c73bcc047d1">
  ]
  %chmod_2443:7 = splice.literal "chmod" at 2443 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>,
      #splice.entry<"/build/source/bin" dir 755 mtime 1>,
      #splice.entry<"/build/source/man" dir 755 mtime 1>,
      #splice.entry<"/build/source/man/man1" dir 755 mtime 1>,
      #splice.entry<"/build/source/share" dir 755 mtime 1>,
      #splice.entry<"/build/source/share/cowsay" dir 755 mtime 1>,
      #splice.entry<"/build/source/share/cowsay/cows" dir 755 mtime 1>
  ]
  %mkdir_3239 = splice.literal "mkdir" at 3239 folded -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4" dir 755 mtime 1795046400>
  ]
  %install_3335:3 = splice.literal "install" at 3335 folded -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/etc" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/etc/cowsay" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/etc/cowsay/cowpath.d" dir 755 mtime 1795046400>
  ]
  %install_3371 = splice.literal "install" at 3371 folded -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin" dir 755 mtime 1795046400>
  ]
  %install_3479:3 = splice.literal "install" at 3479 folded -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/man" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/man/man1" dir 755 mtime 1795046400>
  ]
  %install_3588:2 = splice.literal "install" at 3588 folded -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows" dir 755 mtime 1795046400>
  ]
  %install_3633 = splice.copy "install" at 3633(%cp_2274#37) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/actually.cow" file 644 mtime 1795046400 "988285293148e2b45fa6c2c7524dccc99559ef3dd5f8eff9e8b1172fb00ad4bf">
  %install_3633_0 = splice.copy "install" at 3633(%cp_2274#38) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/alpaca.cow" file 644 mtime 1795046400 "2bd90a3af14d15252ab29b2e6fe759fd17baf4e5bbb5139263b78faa3e578ee5">
  %install_3633_1 = splice.copy "install" at 3633(%cp_2274#39) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/beavis.zen.cow" file 644 mtime 1795046400 "39ede9994672a77537bfc0e453dd2fa9b0f65124d27084db5f648380b806f800">
  %install_3633_2 = splice.copy "install" at 3633(%cp_2274#40) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/blowfish.cow" file 644 mtime 1795046400 "a02f19f8018a58032a1a1ceb7527ee655a7bc2dc3e520faaeaece6781d82806b">
  %install_3633_3 = splice.copy "install" at 3633(%cp_2274#41) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/bong.cow" file 644 mtime 1795046400 "18dd05111f44d1fa0497b2ecf981151b28be2d7373a8d4793e55558d1b116e68">
  %install_3633_4 = splice.copy "install" at 3633(%cp_2274#42) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/bud-frogs.cow" file 644 mtime 1795046400 "7a43605a9b020bd86f421c6ac62b99285732b774de48747d5af388988df322ae">
  %install_3633_5 = splice.copy "install" at 3633(%cp_2274#43) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/bunny.cow" file 644 mtime 1795046400 "9b846abb1516a4d74cbec1647f97642542d1cc0beff012fc476afdc911d552cd">
  %install_3633_6 = splice.copy "install" at 3633(%cp_2274#44) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/cheese.cow" file 644 mtime 1795046400 "5edf516643619ac9ad9427795229ae548296c1aaaf707960a918eccc3078a6e3">
  %install_3633_7 = splice.copy "install" at 3633(%cp_2274#45) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/cower.cow" file 644 mtime 1795046400 "fd7999050385fa0218b429b0021f62a13fda72c0be49e0acc7db747c58ae368a">
  %install_3633_8 = splice.copy "install" at 3633(%cp_2274#46) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/cupcake.cow" file 644 mtime 1795046400 "c09bbb9aa756900c586e781775b093ee28ead65c2315a61aaf218c0206964f48">
  %install_3633_9 = splice.copy "install" at 3633(%cp_2274#47) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/daemon.cow" file 644 mtime 1795046400 "70d4e2177f5af1fb5f1e88da8ed51e08557aac7742979751562a213117e0f69f">
  %install_3633_10 = splice.copy "install" at 3633(%cp_2274#48) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/default.cow" file 644 mtime 1795046400 "da4d563fdbb2334a7b70a2c916c299696ffc53f546e456d6c3d3a9b3c69a7142">
  %install_3633_11 = splice.copy "install" at 3633(%cp_2274#49) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/dragon-and-cow.cow" file 644 mtime 1795046400 "a6da60034bebd5f93ca83ad2e3b3b55543b824874fc7540817ab3d955dc280fe">
  %install_3633_12 = splice.copy "install" at 3633(%cp_2274#50) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/dragon.cow" file 644 mtime 1795046400 "2d1584769f6d3fbe47fc7713685c012baf889e15ad5224e0340b9b31994c6e78">
  %install_3633_13 = splice.copy "install" at 3633(%cp_2274#51) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/elephant-in-snake.cow" file 644 mtime 1795046400 "869a18dfa0868c51403c90245e6d8d2c2cd19f8933b1897f0641c98eef27844b">
  %install_3633_14 = splice.copy "install" at 3633(%cp_2274#52) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/elephant.cow" file 644 mtime 1795046400 "ae35fee206515047f5226eed21fbdb413e523a20b9a932b9a10f3a1833ab5a78">
  %install_3633_15 = splice.copy "install" at 3633(%cp_2274#53) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/eyes.cow" file 644 mtime 1795046400 "079e48cbe0ec834af46c16e55ef0a5c9f2698c756f5fa24ced56e7a4df155aa4">
  %install_3633_16 = splice.copy "install" at 3633(%cp_2274#54) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/flaming-sheep.cow" file 644 mtime 1795046400 "4486fb19d1b4cfdcd04f5fc067e8f757f7d58881a2ff6fa7f479a1295e01a4ac">
  %install_3633_17 = splice.copy "install" at 3633(%cp_2274#55) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/fox.cow" file 644 mtime 1795046400 "b36d717168cde7cc5fe222fba6384de14d7b0bfd4a60a0e300f1df0414c0f2a5">
  %install_3633_18 = splice.copy "install" at 3633(%cp_2274#56) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/ghostbusters.cow" file 644 mtime 1795046400 "51769e176ac8a7dd1f394923be42a102ab7141eb5b9c8d3161af5cac5c10ae9a">
  %install_3633_19 = splice.copy "install" at 3633(%cp_2274#57) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/head-in.cow" file 644 mtime 1795046400 "194ae212191a2bca94544eeedc42a5b9dd9b1eb3b1acce4b243b3a8579542e2f">
  %install_3633_20 = splice.copy "install" at 3633(%cp_2274#58) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/hellokitty.cow" file 644 mtime 1795046400 "7b851f472108a68f2c9d46b4995d12b9f104d4b51c8d688072c11bdcf248eaeb">
  %install_3633_21 = splice.copy "install" at 3633(%cp_2274#59) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/kiss.cow" file 644 mtime 1795046400 "d850c026bc240896f9ef98667dee1f9d9c9a2b798453226b03025d96c52d4e5a">
  %install_3633_22 = splice.copy "install" at 3633(%cp_2274#60) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/kitty.cow" file 644 mtime 1795046400 "13fdc4ccbd29a372dbd44637c7a102cd757cac199242940fb9dff254d5aba280">
  %install_3633_23 = splice.copy "install" at 3633(%cp_2274#61) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/koala.cow" file 644 mtime 1795046400 "a99068fcc904aa8ba178aa0c7da8d4072fca4fdb02d3f351d389a9b2963bb847">
  %install_3633_24 = splice.copy "install" at 3633(%cp_2274#62) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/kosh.cow" file 644 mtime 1795046400 "7323132a0c8ccccb26ac2c2f56bff26362c9b509fe70232e188c878104d237d4">
  %install_3633_25 = splice.copy "install" at 3633(%cp_2274#63) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/llama.cow" file 644 mtime 1795046400 "1ff84a08491d5d0cc7673cb5b944f40d8437818ae3923e8d66850ce487ac8fe4">
  %install_3633_26 = splice.copy "install" at 3633(%cp_2274#64) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/luke-koala.cow" file 644 mtime 1795046400 "b939031e08a7316c81fa05f9e95793ac5a907c267bfe1166f44ecb04305e8baf">
  %install_3633_27 = splice.copy "install" at 3633(%cp_2274#65) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/mech-and-cow.cow" file 644 mtime 1795046400 "719853d6e24dd84d03f93ea87ef1681ce7d7e86425fbc4c80eee69d48b01b0a9">
  %install_3633_28 = splice.copy "install" at 3633(%cp_2274#66) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/meow.cow" file 644 mtime 1795046400 "70b9cb3472cbe11573369e64bfe7590adcabd3f705492282b6f07d052594bfba">
  %install_3633_29 = splice.copy "install" at 3633(%cp_2274#67) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/milk.cow" file 644 mtime 1795046400 "7196f5672664801f9944027bfada64c5927db72e1027466e2d75bca819bd47af">
  %install_3633_30 = splice.copy "install" at 3633(%cp_2274#68) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/moofasa.cow" file 644 mtime 1795046400 "638f1e9a5909ea492dca4f4d96464b343eb15b03e77be85e593e625d502fee25">
  %install_3633_31 = splice.copy "install" at 3633(%cp_2274#69) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/moose.cow" file 644 mtime 1795046400 "c8275cc4794af5bb21761ba724fa77372a59e3aaa60b3e15ae1c015eb3c94927">
  %install_3633_32 = splice.copy "install" at 3633(%cp_2274#70) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/mutilated.cow" file 644 mtime 1795046400 "53e572d163892c1f43e38114b42d59ce607032b40c744891fbcf60d5a581efa8">
  %install_3633_33 = splice.copy "install" at 3633(%cp_2274#71) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/ren.cow" file 644 mtime 1795046400 "c5b4baa4ed8215be5ceb8939fe0a8423895250c830f88483676cd8c892bb6c09">
  %install_3633_34 = splice.copy "install" at 3633(%cp_2274#72) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/sheep.cow" file 644 mtime 1795046400 "c9bfa802a20827c396fdbe5f002b173acb95e9ac138e23759fc6df89352be8f9">
  %install_3633_35 = splice.copy "install" at 3633(%cp_2274#73) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/skeleton.cow" file 644 mtime 1795046400 "16864e050225f3b7e3644fc861acb9dd1bd050dc37afe95f53a8e13b8bad0745">
  %install_3633_36 = splice.copy "install" at 3633(%cp_2274#74) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/small.cow" file 644 mtime 1795046400 "31f1c6f6221e2924b9c3b801db03f1f185af923c32e2d8773db4f28a6fd9662c">
  %install_3633_37 = splice.copy "install" at 3633(%cp_2274#75) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/stegosaurus.cow" file 644 mtime 1795046400 "2cd04f315f13f3feab7231b49f373900d18880cb7461ae0e6ea86793ba1e33ad">
  %install_3633_38 = splice.copy "install" at 3633(%cp_2274#76) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/stimpy.cow" file 644 mtime 1795046400 "07ad27813d038c1dfb42ce3040dff6bc6a8f60037003f9ddab8251f7620ba2da">
  %install_3633_39 = splice.copy "install" at 3633(%cp_2274#77) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/supermilker.cow" file 644 mtime 1795046400 "e9d0bbdb18fb7b0386eb88bec0465924b8184e040844591648d71b0b200804a2">
  %install_3633_40 = splice.copy "install" at 3633(%cp_2274#78) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/surgery.cow" file 644 mtime 1795046400 "257735413351fa6f2dba4ec2d15786a087244527ddf4c51043d711641844cee3">
  %install_3633_41 = splice.copy "install" at 3633(%cp_2274#79) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/sus.cow" file 644 mtime 1795046400 "571dd5e57453c908e66ea10a8d45e42b99e20fb6f44f3c7a71009398d104b0d7">
  %install_3633_42 = splice.copy "install" at 3633(%cp_2274#80) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/three-eyes.cow" file 644 mtime 1795046400 "cc68f32f395876abc4195fb60e4b3f5d26a1717c473a0454db7ebe6539c1b1bb">
  %install_3633_43 = splice.copy "install" at 3633(%cp_2274#81) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/turkey.cow" file 644 mtime 1795046400 "f04002cbd5d3fca201fa722c7aec3fbed8cea080f7cc30daa1740cd692ab6067">
  %install_3633_44 = splice.copy "install" at 3633(%cp_2274#82) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/turtle.cow" file 644 mtime 1795046400 "796ff5f3e6fe8fb658a78c874e40e0a2fb25cbf15079b152bcb5ac94e626eb07">
  %install_3633_45 = splice.copy "install" at 3633(%cp_2274#83) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/tux.cow" file 644 mtime 1795046400 "2afd7931c855323431b02eeb9450670c5f5d82305ee57a93df27b2c9cde826ee">
  %install_3633_46 = splice.copy "install" at 3633(%cp_2274#84) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/udder.cow" file 644 mtime 1795046400 "5c8b7f6e06fbe59412555f2e2e9b45761d0c38fef4391efd8e032703f827417b">
  %install_3633_47 = splice.copy "install" at 3633(%cp_2274#85) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/vader-koala.cow" file 644 mtime 1795046400 "05ece89aaa3ebca1ea27f5ebecf5056557a71f94ed6887af8322cded8e651fef">
  %install_3633_48 = splice.copy "install" at 3633(%cp_2274#86) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/vader.cow" file 644 mtime 1795046400 "7bf1a1faaf7ab74365fff6ad373abd0ce5e44f99f129e0b551bbc55b2097be9c">
  %install_3633_49 = splice.copy "install" at 3633(%cp_2274#87) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/cows/www.cow" file 644 mtime 1795046400 "81f49ef787d66024118a9876078dcb1da6ad4af652c3ad3115697c73bcc047d1">
  %install_3974 = splice.literal "install" at 3974 folded -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/share/cowsay/site-cows" dir 755 mtime 1795046400>
  ]
  %mv_4039 = splice.copy "mv" at 4039(%cp_2274#22) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/.cowsay-wrapped" file 755 mtime 1795046400 "b19fba7f1e2cbd1f34e5ceb298e3c1e5727c34ffa8fa8a28b9ec621071e2981d">
  %glue_4110 = splice.literal "glue" at 4110 -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/cowsay" file 644 mtime 1795046400 "9e2679f10b077b21d1a11ca39ce779a68c521f3ec9e08780091c399ee006fc74">
  ]
  %chmod_4110 = splice.copy "chmod" at 4110(%glue_4110) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/cowsay" file 755 mtime 1795046400 "9e2679f10b077b21d1a11ca39ce779a68c521f3ec9e08780091c399ee006fc74">
  %glue_4156 = splice.literal "glue" at 4156 -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/cowthink" file 644 mtime 1795046400 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %cat_4156 = splice.exec "cat" at 4156(%sandbox_716, %chmod_2443#0, %mkdir_3239, %install_3371, %glue_4156) -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/cowthink" file 644 mtime 1795046400 "f1898b5ffee7d8782bad95d21b882cf1ab4d89c7f34af3c05ef691e60e1b5519">
  ]
  %chmod_4177 = splice.copy "chmod" at 4177(%cat_4156) -> <"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/cowthink" file 755 mtime 1795046400 "f1898b5ffee7d8782bad95d21b882cf1ab4d89c7f34af3c05ef691e60e1b5519">
  %mkdir_4395:2 = splice.literal "mkdir" at 4395 folded -> [
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share" dir 755 mtime 1795046400>
  ]
  %mv_4416:3 = splice.literal "mv" at 4416 folded -> [
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share/man" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share/man/man1" dir 755 mtime 1795046400>,
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share/man/man1/cowthink.1" link 0 mtime 1795046400 "cowsay.1">
  ]
  %mv_4416_50 = splice.copy "mv" at 4416(%cp_2274#32) -> <"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share/man/man1/cowsay.1" file 644 mtime 1795046400 "0d713f136b623336ea211e0dcf4f4127604a4b2dc91cb6573200ebab8cb5ca78">
  %find_stat_mktemp_sed__10_4820:2 = splice.exec "find|stat|mktemp|sed|+10" at 4820(%sandbox_716, %chmod_2443#0, %mkdir_3239, %install_3371, %mv_4039, %chmod_4177) -> [
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/.cowsay-wrapped" file 755 mtime 1795046400 "46f5eb61fa58fdce01ddfdef53b27d4722fca72240dfbc35d3f1502a0e7a98b6">,
      #splice.entry<"/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4/bin/cowthink" file 755 mtime 1795046400 "c9a29a227143d7fdc3aab4f5289c180b69547e27e5072a997bde188b028d6723">
  ]
  %gzip_5687 = splice.exec "gzip" at 5687(%sandbox_716, %chmod_2443#0, %mkdir_4395#0, %mkdir_4395#1, %mv_4416#0, %mv_4416#1, %mv_4416_50) -> [
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share/man/man1/cowsay.1.gz" file 644 mtime 1795046400 "0e73fe800f0b0c747e7b838681e1d0458ea8b1c5d9b292ef27e2646f69aa0bc9">
  ]
  %ln_6088 = splice.literal "ln" at 6088 folded -> [
      #splice.entry<"/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man/share/man/man1/cowthink.1.gz" link 0 mtime 1795046400 "cowsay.1.gz">
  ]
  splice.output "man" "/nix/store/b5r8bhcls3hn4748zf4ln16771nlkwa5-cowsay-3.8.4-man"(%mkdir_4395#0, %mkdir_4395#1, %mv_4416#0, %mv_4416#1, %gzip_5687, %ln_6088)
  splice.output "out" "/nix/store/s5w9gi7p8m7yx878yxkf8q8480i82qj7-cowsay-3.8.4"(%mkdir_3239, %install_3371, %find_stat_mktemp_sed__10_4820#0, %chmod_4110, %find_stat_mktemp_sed__10_4820#1, %install_3335#0, %install_3335#1, %install_3335#2, %install_3479#0, %install_3588#0, %install_3588#1, %install_3633, %install_3633_0, %install_3633_1, %install_3633_2, %install_3633_3, %install_3633_4, %install_3633_5, %install_3633_6, %install_3633_7, %install_3633_8, %install_3633_9, %install_3633_10, %install_3633_11, %install_3633_12, %install_3633_13, %install_3633_14, %install_3633_15, %install_3633_16, %install_3633_17, %install_3633_18, %install_3633_19, %install_3633_20, %install_3633_21, %install_3633_22, %install_3633_23, %install_3633_24, %install_3633_25, %install_3633_26, %install_3633_27, %install_3633_28, %install_3633_29, %install_3633_30, %install_3633_31, %install_3633_32, %install_3633_33, %install_3633_34, %install_3633_35, %install_3633_36, %install_3633_37, %install_3633_38, %install_3633_39, %install_3633_40, %install_3633_41, %install_3633_42, %install_3633_43, %install_3633_44, %install_3633_45, %install_3633_46, %install_3633_47, %install_3633_48, %install_3633_49, %install_3974)
}

