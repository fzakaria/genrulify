module {
  %sandbox_720:3 = splice.literal "sandbox" at 720 -> [
      #splice.entry<"/build" dir 700 mtime 1794960000>,
      #splice.entry<"/build/.attrs.json" file 644 mtime 1794960000 "69469f4c33423a328b099922bf8876ff47a2f35228a5e62daf57dc127193f027">,
      #splice.entry<"/build/.attrs.sh" file 644 mtime 1794960000 "f85f8fa143873936ad5ba3ce5c45c6c3a954937c9d08b4a39b5a16eab37b4e93">
  ]
  %tar_1268 = splice.literal "tar" at 1268 folded -> [
      #splice.entry<"/build/zlib-1.3.2" dir 755 mtime 1771332426>
  ]
  %tar_1268_0:291 = splice.exec "tar" at 1268(%sandbox_720#0) -> [
      #splice.entry<"/build/zlib-1.3.2" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/.cmake-format.yaml" file 644 mtime 1738382546 "986f0fdc53be34f931d66c1a6fa4935d84991da14f059c7df567ede7cd32b68f">,
      #splice.entry<"/build/zlib-1.3.2/BUILD.bazel" file 644 mtime 1737520175 "67f3be3604f659c45392e84e59e4c6ba975877d2791e5e7b189b487e3520532b">,
      #splice.entry<"/build/zlib-1.3.2/CMakeLists.txt" file 644 mtime 1771332426 "4c3a70936312909462e360ca60b509a71cbad1f651434d100a84e19b4743ccb8">,
      #splice.entry<"/build/zlib-1.3.2/ChangeLog" file 644 mtime 1771332426 "c6f42df0f27486db922d633e7a70757b56c6cd9f742f21af419d232649efbede">,
      #splice.entry<"/build/zlib-1.3.2/FAQ" file 644 mtime 1770888842 "8f64fd44e4773233f22a07c9d7a8cd83646d78c1e7c9bb79c43a9876e6ddb0d5">,
      #splice.entry<"/build/zlib-1.3.2/INDEX" file 644 mtime 1769643431 "ecbca9833dc89a4d725eff611e7f4e6a97f70451dda8e1f8c571418ec27c71e7">,
      #splice.entry<"/build/zlib-1.3.2/LICENSE" file 644 mtime 1771332426 "e32ff4e00d9d94930537635291da39e7e612703334bf6fde8c7f1686fe8a45a2">,
      #splice.entry<"/build/zlib-1.3.2/MODULE.bazel" file 644 mtime 1737520175 "55f8668b57d00e60bf868d7bc564bdcd2dc15f1c1299f109f3975a2e22a3d0a8">,
      #splice.entry<"/build/zlib-1.3.2/Makefile" file 644 mtime 1315636403 "ef23b08ce01239843f1ded3f373bfc432627a477d62f945cbf63b2ac03db118a">,
      #splice.entry<"/build/zlib-1.3.2/Makefile.in" file 644 mtime 1771332426 "33952d61d881fd3b41d087e84f8ef3c3c25a6bc4d6f6e3b115e13004a1d54b2a">,
      #splice.entry<"/build/zlib-1.3.2/README" file 644 mtime 1771332426 "4026d921213bb2e311d8d42b44ef53361c102d5d45ae32f93f8e52eaee8d068f">,
      #splice.entry<"/build/zlib-1.3.2/README-cmake.md" file 644 mtime 1771235860 "9bb3ec62b1f839cc6febcc6211de9809f68917141a650ad973b3297849c57749">,
      #splice.entry<"/build/zlib-1.3.2/adler32.c" file 644 mtime 1681618651 "9cd1443a24ff2a3053961695bd432035c58347386a420d3388232376ebabe211">,
      #splice.entry<"/build/zlib-1.3.2/amiga" dir 755 mtime 1266106951>,
      #splice.entry<"/build/zlib-1.3.2/amiga/Makefile.pup" file 644 mtime 1266106951 "a65cb3cd40b1b8ec77e288974dd9dc53d91ed78bbe495e94ccc84ddd423edf1f">,
      #splice.entry<"/build/zlib-1.3.2/amiga/Makefile.sas" file 644 mtime 1266106938 "0e63cf88b505a1a04327bb666af3a985c5e11835c0c00aed4058c0dcc315d60e">,
      #splice.entry<"/build/zlib-1.3.2/compress.c" file 644 mtime 1771332426 "41f1c7ad886012571cd481a2b1b6a83812e5125e90d995e298fde34d6c015614">,
      #splice.entry<"/build/zlib-1.3.2/configure" file 755 mtime 1771319605 "c07499bd24003913f8488b4100db86c79830a8faa09e4b950f09f5b51a48787d">,
      #splice.entry<"/build/zlib-1.3.2/contrib" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/CMakeLists.txt" file 644 mtime 1771237537 "42062d1b65f23d0329be0dbd035b912b7a9ffb966da064f815eaa243c4466e74">,
      #splice.entry<"/build/zlib-1.3.2/contrib/README.contrib" file 644 mtime 1771237537 "ef017112f077503246c1d4e1bcecc2b5bd2491fcf9eebf33b98696c97546be8e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada" dir 755 mtime 1770888842>,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/CMakeLists.txt" file 644 mtime 1769919309 "d9d9cc869153872205530b9fe7a848da4c7bf03fb2da99b800784de701d57ebd">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/buffer_demo.adb" file 644 mtime 1094453735 "469cf566a6965767fee6b987a239ed8cedcc66614940d45a9b434331fbb435ce">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake" dir 755 mtime 1768244115>,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/Modules" dir 755 mtime 1768244115>,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/Modules/CMakeADACompiler.cmake.in" file 644 mtime 1768244115 "70bca3b0b3d0c3c181049b912dc53e075505f4859ad20885f729ee933136cc88">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/Modules/CMakeADAInformation.cmake" file 644 mtime 1768244115 "4939a1ca74fc345150a243ed537f348b24abb84595e8b627d5c7d7fdc0fe77ef">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/Modules/CMakeDetermineADACompiler.cmake" file 644 mtime 1768244115 "5cd42895a8562103325c49bf962882e3f2e11f948257de600dee386fcf5c51ee">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/Modules/CMakeTestADACompiler.cmake" file 644 mtime 1768244115 "d3a9ab2fcad467a177a7221be5c621be297318735432d47df72ccf70daf7a4b2">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/binder_helper.cmake" file 644 mtime 1768244115 "a14e9d9a674c2319cf5404481e1dab7ab597d3220a17209ab3accba8373bb5bb">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/compile_helper.cmake" file 644 mtime 1768244115 "676aaa3dbc4ab1b5d1c61e5807645732c6bf1a991cf004abd30e301fd35ffb9a">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/exe_link_helper.cmake" file 644 mtime 1768244115 "6f2262e1ad070e5eb88ee1a9223bb4bbbb0baa4b6c0800bf1a3968f78c67ae47">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/shared_link_helper.cmake" file 644 mtime 1768244115 "4172a24be91053c016ae4a589224ddd701d07c4a768b04382298013c8a763ff5">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/cmake/static_link_helper.cmake" file 644 mtime 1768244115 "04cba492e92bd6bfb35632d1c2106f0647a83fb2205daf73563413853ec19f38">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/mtest.adb" file 644 mtime 1090568994 "41b6f31684770334afdc4375871eb1408542f37a823a073556fdbfdb63753160">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/read.adb" file 644 mtime 1086000820 "fa5b989aef0c5715a3fcb15de93985f7f10aeb0a7f5716745c95ed820eb9af9c">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/readme.txt" file 644 mtime 1770888842 "7efc81ce3a1460959eb9dbd58c3ce4bd8b6aa462ed740bf89f51189ab8508b82">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/test.adb" file 644 mtime 1692026242 "ad2b2f61e0603044065887849e2cca394cfe37d3ba08d3cd368f670462b9296e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib-streams.adb" file 644 mtime 1096854909 "f45988e2bac76eb25a0dc981f46576e7432c35dde1790bbc2b650f0090b7fa72">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib-streams.ads" file 644 mtime 1691096004 "2dae2309e863a6ea44731773aabac5fd5f5436b6dcfcf53fd7e6389556ca8c3c">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib-thin.adb" file 644 mtime 1738820616 "d5f8c5344b094fb98eb2c200c9df3691c35bedaea17dfe63de4f309923e8930c">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib-thin.ads" file 644 mtime 1477842541 "631ef170bde16c3ca8d412b54a0e519815b80197d208f8f393e6fe017bb0968e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib.adb" file 644 mtime 1691096004 "8168ac962cd775e1f3dc35dc95a038eb370034c9b1f8cb1511d4bcd6b297a1f5">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib.ads" file 644 mtime 1691096004 "9340f4cfaeafca0efce7a649ef5e9b42a8bcafc5dbdc4abff41f9a19ee08c3cc">,
      #splice.entry<"/build/zlib-1.3.2/contrib/ada/zlib.gpr" file 644 mtime 1096855110 "859bb69dce38dbe9dca06753cf7ae7bd16d48f4fece8b87582dab8e30681d3de">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast" dir 755 mtime 1769919309>,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/CMakeLists.txt" file 644 mtime 1768245003 "39871a5c7aff6f134ccd0d4cb46b761ce944615449e3cb169029e27d3509a243">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/Makefile" file 644 mtime 1768244115 "9d1834dea66a27b02390fb1690cfa217c84b41c35342b0d5d527afc25d7c617a">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/README" file 644 mtime 1046760145 "baa763ae03d88ef7ece6eb80d9a099b43d0b57639d6d281e1c7c6ca79d81daba">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/blast-test.c" file 644 mtime 1768244115 "5dee435776afafe1f2647b0e7ac63ef4a33a83fee542feab599dfc0ad8d5bfa0">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/blast.c" file 644 mtime 1768244115 "ebe6ec1b37dbd2b03959f453a5eab298621dcb6e593954bf22fe88d1abcfa72e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/blast.h" file 644 mtime 1768244115 "2b99276c3b40fd231a09df942a95a7cf007858e6bdf0a051fe29719316cc58a7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/blastConfig.cmake.in" file 644 mtime 1768245003 "f9293b1ce5e946dbb3b2e2142f86207582ac36df3854aa5f860146da0acc95fb">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test" dir 755 mtime 1769919309>,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test.pk" file 644 mtime 1045114659 "5f5c262c545574a5c221132d5ef832478d222d70b015341795b3860204140d7c">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test.txt" file 644 mtime 1045114739 "9679b2c98e1283222d0782b25a1c198dc64ba9ebd1addd6dc6f643a45947cda3">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test/CMakeLists.txt" file 644 mtime 1769919309 "ffa4dc2b94b1d5c3dee2c50496db1ee3fc2b4fd7f7d23ddaa9539917fe791a38">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test/add_subdirectory_exclude_test.cmake.in" file 644 mtime 1769919309 "95ce021d630578b464a0a5f906a9792272d4ba3307e02f90bb50c0556db0fe64">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test/add_subdirectory_test.cmake.in" file 644 mtime 1769919309 "e59e7ea67950ed42ec60333e07dc602d3cc44e06b1438d03b7f2851d3e95860b">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test/find_package_no_components_test.cmake.in" file 644 mtime 1769919309 "baac41f7d12c5fbf5593ec0540ec952796d7601d257fbb9cdaebd319906f9f24">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test/find_package_test.cmake.in" file 644 mtime 1769919309 "4cf7abd57d53bd11b52ab9037fe8456e1461d7302a811a6f511488f85cdf8fdf">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/test/find_package_wrong_components_test.cmake.in" file 644 mtime 1769919309 "32ac0c4397f791122c3c4976f820d6d2bf2504414235961412b38d6eded7a3c7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/blast/tester.cmake" file 644 mtime 1768244115 "11b16608db0599b08f22ff0be40d7e9ba67d9ca0a6ee5cd50971f60e4c404ba5">,
      #splice.entry<"/build/zlib-1.3.2/contrib/crc32vx" dir 755 mtime 1769574137>,
      #splice.entry<"/build/zlib-1.3.2/contrib/crc32vx/CMakeLists.txt" file 644 mtime 1769574137 "56db89925dad95c7d9627c850fd42b22cba9171c11b01a49aa4a7d9fb64872f8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/crc32vx/README" file 644 mtime 1769574137 "6bac5b0d17364abf205d83572948c0ce1e9cb9dac45bc4b63c4d1df05f80aa62">,
      #splice.entry<"/build/zlib-1.3.2/contrib/crc32vx/crc32_vx.c" file 644 mtime 1769574137 "9bf29461af62b20223b52b489dd27c4617deef9a6cfd5fe6e5128e1b40d9436f">,
      #splice.entry<"/build/zlib-1.3.2/contrib/crc32vx/crc32_vx_hooks.h" file 644 mtime 1769574137 "733a86cdc24d8aad85cda37b775a79ab892bf6610374fabab197d3fb10654b8b">,
      #splice.entry<"/build/zlib-1.3.2/contrib/delphi" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/delphi/ZLib.pas" file 644 mtime 1771332426 "bf5eb52021a9a7ba79dd3b638f77cf38188bb8b4df1ccccdbb88cf912f35f320">,
      #splice.entry<"/build/zlib-1.3.2/contrib/delphi/ZLibConst.pas" file 644 mtime 1059340800 "84bcc580bdf397e570f86f3f5a5b8c7bf537828f30b4b72648b81911f6bf5095">,
      #splice.entry<"/build/zlib-1.3.2/contrib/delphi/readme.txt" file 644 mtime 1068619781 "f7420ed2de77d4b498eefbbe6402a1d17dc2d411735289c78a265c7f10fdaee5">,
      #splice.entry<"/build/zlib-1.3.2/contrib/delphi/zlibd32.mak" file 644 mtime 1322432132 "850e91b6c9ea05de61a411cbda16fa0f10118cd88bb32c4b7226988776f8d511">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib.build" file 644 mtime 1095545970 "b96137097669644ecb9f42cdd3399d1fce9c512788374609303f7e50abf597f0">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib.chm" file 644 mtime 1095547418 "20d0e3edd57f849143255a7f0df1cd59d41db464a72c0d5ab42846438a729579">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib.sln" file 644 mtime 1079913106 "a979198c5b8d144c1ac8f993bfb6f4085d135aa58ca9dcf63ebabf52b5c695f7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/AssemblyInfo.cs" file 644 mtime 1095201666 "314afcfb339ea95f5431047b7ab24631b11c3532c7ce5dc2094ed0cf80a7c16d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/ChecksumImpl.cs" file 644 mtime 1770888842 "08721d95d05770039eb19f4c3c952dced9d09a745911eb671bed82129c838f53">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/CircularBuffer.cs" file 644 mtime 1770888842 "0abef0d7bb8079313c42b649f20248567c14ac3e890ebf202dd9011a4dfe6e7e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/CodecBase.cs" file 644 mtime 1770888842 "b6300b39b09f8720a0846fa44c2e2a4e358a2b9f13dddcfaa968ad1b03e2cf12">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/Deflater.cs" file 644 mtime 1770888842 "9021976dc201426c8124db3f99ab475e42d470fc52ac4e707189434a671ed853">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/DotZLib.cs" file 644 mtime 1770888842 "c1c2c9ff0518a3899f3e198f207f644c7482024a5a2adfe8b57003f39a57a8d2">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/DotZLib.csproj" file 644 mtime 1095550368 "21606db31dfef6410dd438b73f1db68856eacabcce6c0f0411fc4f17e17001f3">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/GZipStream.cs" file 644 mtime 1770888842 "f37a6eff01c7c71e91549ae9bfc2b1dd3f55c3c95eb2e978ed9c248242b46c17">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/Inflater.cs" file 644 mtime 1770888842 "22cce1b55a213037c78c94a6e4d81373b03409c3d01ba2aa2c0a2415ba384ed1">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/DotZLib/UnitTests.cs" file 644 mtime 1771332426 "cf71355e993729dfd536b9ee4265a3ff8a4a40bbd884e184307b032eb51493f7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/LICENSE_1_0.txt" file 644 mtime 1080537266 "36266a8fd073568394cb81cdb2b124f7fdae2c64c1a7ed09db34b4d22efa2951">,
      #splice.entry<"/build/zlib-1.3.2/contrib/dotzlib/readme.txt" file 644 mtime 1770888842 "4b4443928397c819105596997474345256223cc38860624f3e635addb61ef115">,
      #splice.entry<"/build/zlib-1.3.2/contrib/gcc_gvmat64" dir 755 mtime 1770888842>,
      #splice.entry<"/build/zlib-1.3.2/contrib/gcc_gvmat64/CMakeLists.txt" file 644 mtime 1768245003 "945784c610d8798cc82e13cb097af04ce07b4572c7533b82962bc5831470b45d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/gcc_gvmat64/gvmat64.S" file 644 mtime 1770888842 "2c38406bf03c41686cc016df0a8798726d02dcba956e02b0bc9c06bc057ea3f0">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/CMakeLists.txt" file 644 mtime 1768244115 "f4b706e59cdf985ee18990689045e8cc40b9eccd708ce18c0b7d8370e1e65ed1">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/README" file 644 mtime 1063082756 "890288f02bb3b1f9cc654b87a07fcea695f90f6b9bd672d25bf6be1da2ec1688">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/infback9.c" file 644 mtime 1711997345 "22c511270c79db1b7939637121304c2b83d6f6319e7e1d8008e283a073d994f2">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/infback9.h" file 644 mtime 1681618732 "c89d926607c1afa1830c17f807de368d2f1afe2d1e7df426763f6d4bf5950379">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/inffix9.h" file 644 mtime 1063495070 "84a2ba4727767c18af6505f0e81d9c814489c8b9ed330a25dad433db72997e43">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/inflate9.h" file 644 mtime 1063490478 "32a907676cc36e27d0fdc0d99adb83a0b23f20ab61896269216d40fecf08d349">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/inftree9.c" file 644 mtime 1771332426 "96bd35636b47fd4ca71b681406a56404108fe68fbf7b4b42c735da83328b5511">,
      #splice.entry<"/build/zlib-1.3.2/contrib/infback9/inftree9.h" file 644 mtime 1700016272 "4ecd9db884bf43e33fbd34273c814029022477e1597676129f9c98e09d8cef56">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream" dir 755 mtime 1061175660>,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream/test.cpp" file 644 mtime 862410840 "0f3c77e013949eb9c91e6b690ea894e19d97944d6b0885b82806fc3ad99680cf">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream/zfstream.cpp" file 644 mtime 1061175660 "8ebb9b3d521cc3392953f27658cf1f6dcb763216079f69a1518ec5ca0e42a63b">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream/zfstream.h" file 644 mtime 1061175660 "4369c35e66f63f52ca4a5e1759bf720507ccabb8f3f132e2f18e68686c812401">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream2" dir 755 mtime 1770888842>,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream2/zstream.h" file 644 mtime 1770888842 "68c6513b1bb805d9724f16ac5999692abc97bd2ef6ea5dca5653ba51f3322a71">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream2/zstream_test.cpp" file 644 mtime 885241715 "f789df183cc58b78751985466380c656308490a9036eb48a7ef79704c3d3f229">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3" dir 755 mtime 1769919309>,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/CMakeLists.txt" file 644 mtime 1768245003 "648409cac3b6a64e0649bb5a1af51331e3005009cce7b95041ba55440f6c602d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/README" file 644 mtime 1055333341 "43ec48ecbd95a8c45db20b107fac73b740bb11595a4737329188f06b713972cc">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/TODO" file 644 mtime 1055332954 "af5ebc83fb88f69706c8af896733784753dead147687e1c046f410c0997fd88b">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/iostream3Config.cmake.in" file 644 mtime 1768245003 "f54c6278f4e8ba0ba4e414f464eb2593c391b5a8a3aa7b307c61c11678d343c0">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test" dir 755 mtime 1769919309>,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test.cc" file 644 mtime 1055345074 "8e17fc48dfdbc6e268838b8b427491b5843b6d18bc97caa6924de9fad7abe3da">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test/CMakeLists.txt" file 644 mtime 1769919309 "fb3883f324cbf2e5ff2636da6d626e12f694d0036d68e6630f5b30ecf0d27417">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test/add_subdirectory_exclude_test.cmake.in" file 644 mtime 1768245003 "e966f4d0ad9baf89c9546d163300455bf4b33a334a5747165907318112295308">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test/add_subdirectory_test.cmake.in" file 644 mtime 1769919309 "f73783257fc84e54fba3b75d205bb618a8d97a19e6d03618aa6f80b65c874209">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test/find_package_no_components_test.cmake.in" file 644 mtime 1769919309 "a693c2fa3a5d51485c9f4630889b8ea78df622b5353b47838f5f0cf240b13dc4">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test/find_package_test.cmake.in" file 644 mtime 1769919309 "f47fdfdf343561a2280b73a0f2caa4b9e77804626dac28dcb6f735f119dc2a6e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/test/find_package_wrong_components_test.cmake.in" file 644 mtime 1769919309 "519596467e3c980869c93af2b087742e6355dbc39e5785df388f8726cdee4d94">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/zfstream.cc" file 644 mtime 1055330100 "8cdd67ed0b13c192c11e5ea90e9d5782d6627eb303fbc4aa5ebda2531ec00ff8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/iostream3/zfstream.h" file 644 mtime 1705528151 "d89587b446f928351565d099decd006a06b7a420cb1ff8ee9bb82e4d8c7235dd">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/CMakeLists.txt" file 644 mtime 1771237537 "9a1c152cb999d12c5aef0118cdaf2905b66a0d05b972d3ca071ccbb330a6bd1e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/LICENSE.Info-Zip" file 644 mtime 1770920046 "fc686023047ce5ce3a18a9b8a777156f0e475929d3de06bac279f3c025d2b2ca">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/Makefile" file 644 mtime 1771320927 "4930d5913df102a3188aa02793ec5dda7e728c8392d4f70a1bdb55d62627f08a">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/Makefile.am" file 644 mtime 1332818261 "2313a3480a2c3745fa7ce216829cd0367058907d3a0902e5832c66c84a2fdfc6">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/MiniZip64_Changes.txt" file 644 mtime 1690699465 "c371d1672b1ec23c6fe0c600543e0c96374400b4d434447ff2596f21255079f1">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/MiniZip64_info.txt" file 644 mtime 1771332426 "8a3aa14b12f22fa91a6cc84b39d76298dc28ea577fb6bbcf0ebe94e4eda77d1d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/configure.ac" file 644 mtime 1771332426 "b63395f6cac6b751765177d6cf39445d47ae12e1d7fe903f4327047b8dcdd5d0">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/crypt.h" file 644 mtime 1771332426 "03f9f73d2fda547427e702d250a2208c56b02f880a63ab2f1da7fc84a6637415">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/ints.h" file 644 mtime 1722490367 "4397ab032db87bcdcb4eacd01886c2a75166a09cf2b99a1739ebce3c811f581a">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/ioapi.c" file 644 mtime 1771332426 "4e769b2ca4f5f05c5bae63f2d7146856f300028b30578aa3f8a98b4b297c4047">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/ioapi.h" file 644 mtime 1771332426 "0311a8d1869dc58acbee0a1c93bb679a38d3ee97d1f0a5b3c3c6d7868746e10e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/iowin32.c" file 644 mtime 1771332426 "8b839d6bfa761b152892a2702299a0e2993dd29356823c5c542504e7411fe22e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/iowin32.h" file 644 mtime 1771332426 "dd98534f7052d64541af13191a40859fb79675724e0a75f496ad8b52580fa9ef">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/make_vms.com" file 644 mtime 1710613130 "82ddf15ce7ac285d6d91b13e1a84be47e4566be8cbb97685e0f8390ba90977a7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/miniunz.c" file 644 mtime 1771332426 "e1ab877ac9a3e207d3803c32d0051f6712dfd9f33a57a60e89116bed82d8019e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/miniunzip.1" file 644 mtime 1364167721 "66d8684392167091ef0fe01598d6a0daa26e7e448e2df6c3cb257487735b83f7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/minizip.1" file 644 mtime 1364167721 "5404596e8e5587a52f563906119f32ceee30a6d97a966afa5c7afbe4d373e210">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/minizip.c" file 644 mtime 1771332426 "0b9ba1667d6f9b38613c043c5e753fd1c910455285978b45cabdb8970a5c37a8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/minizip.pc.in" file 644 mtime 1770841170 "c119f8d2f5e1bf17cb1748767c46949e5527858106fb01731eb735d192104ac0">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/minizip.pc.txt" file 644 mtime 1738382350 "80fdc752f2637bb4ca88b79a7060c5f696f09cd5925f17af477bd876112484b6">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/minizipConfig.cmake.in" file 644 mtime 1769919185 "91acad25a289345f574be16933db6fb56149a493faf68c9d01aac87fbe625645">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/mztools.c" file 644 mtime 1770853253 "392e464099164d90063cbc259593d6ecab198b03121075cb22ec11c0e22bd413">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/mztools.h" file 644 mtime 1327175915 "6f82c52279e8f79165f4446be652e5741a49992ac58632470335aa34c564072a">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/skipset.h" file 644 mtime 1771332426 "5ba8759eabbd45a8500fbca125aa8c6b18f4c266788cb727560b68886e286703">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test" dir 755 mtime 1770508664>,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/CMakeLists.txt" file 644 mtime 1770508664 "45532207eabe332a04dbd2ca984d2d96dff4d387ac486ed2d8eb20b651acd960">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/add_subdirectory_exclude_test.cmake.in" file 644 mtime 1738382546 "9757b56cb0d1298aaf17c31cb1b49e2dd77d934a2f8138256983995281b08bbc">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/add_subdirectory_test.cmake.in" file 644 mtime 1738382546 "313cb312f43891c81485769e69a8616064c314084394fa8807bbccf3659111e8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/find_package_no_components_test.cmake.in" file 644 mtime 1770508664 "666012b0e2c960d2ddb1d5c3023ace05424627d67ec32c47ccf57aed3c92a017">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/find_package_test.cmake.in" file 644 mtime 1770508664 "d6ad8f4f3af94006f62ac1e3bfdf9f9e9fc7c5883733d81b805203b3fb5adfb7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/find_package_wrong_components_test.cmake.in" file 644 mtime 1770508664 "45c0184b398142361319cf5e3942f78dbaca570739ac1306de47732cd625025a">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/test/test_helper.cm" file 644 mtime 1738382350 "7a82f9571c99adead76e6bbf05ebe005860f3ff3a65c4186d3e74db310bd97da">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/unzip.c" file 644 mtime 1771332426 "8b19ab4a0fd4fdd545fa9ff99fa54d8f2b5aeebf00e1716edf38d37cf4ed360f">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/unzip.h" file 644 mtime 1771332426 "38cfbb7dde443d46e7fd320c5c52bc38477b4fc0e08c550b15026a98295eb69d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/zip.c" file 644 mtime 1771332426 "dfdc9aae5e7915d777663b0df1644106978445d1f96fdd088e9151cc4c232875">,
      #splice.entry<"/build/zlib-1.3.2/contrib/minizip/zip.h" file 644 mtime 1771332426 "a58c41ad517c7042fd294af01917a2bacc1f9645756a7a36f8ca7978337a67ad">,
      #splice.entry<"/build/zlib-1.3.2/contrib/nuget" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/nuget/nuget.csproj" file 644 mtime 1771332426 "563aca92925da41164ed009ea189b345bef7bf71a263800a87a950c0e84d815d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/nuget/nuget.sln" file 644 mtime 1692467846 "074a80c6c3898ea4f7935734d81fe81d3c15f5dae5b17806fa7a036b69ad5c33">,
      #splice.entry<"/build/zlib-1.3.2/contrib/pascal" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/pascal/example.pas" file 644 mtime 1061413200 "d842d456ecb6ff80e34cee2da31deb2072cc69ca837497bea8b8bee203403474">,
      #splice.entry<"/build/zlib-1.3.2/contrib/pascal/readme.txt" file 644 mtime 1061154060 "02f997c37991ddae0cb986039f7b4f6fc816b3fd0ffd332cad371d04c12cf1b9">,
      #splice.entry<"/build/zlib-1.3.2/contrib/pascal/zlibd32.mak" file 644 mtime 1322432132 "850e91b6c9ea05de61a411cbda16fa0f10118cd88bb32c4b7226988776f8d511">,
      #splice.entry<"/build/zlib-1.3.2/contrib/pascal/zlibpas.pas" file 644 mtime 1771332426 "643e261c9914fe50e382565ac591dfb6a560b5ad291d7786e33ffb1b5aa16481">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/CMakeLists.txt" file 644 mtime 1769919309 "a6cb476d05d81cdfecfb83f382d47c9a9edb30e853557cd7a8c70831b68755e9">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/Makefile" file 644 mtime 1272247799 "d9d738030464aaae354196c14fd928adf591832fce7d71ac1977c1d8d4923a4b">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/README" file 644 mtime 1661294113 "c5b9852fb11e0d6b6e916e5134cf034524d901b95368972133e0381e480eb479">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/bin-writer.c" file 644 mtime 1768244115 "3e425db304213f97b268a5372b606224e3ea72f3728d277e640bdc1ec5315cd8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/puff.c" file 644 mtime 1770888842 "4247d373526e74d9ec5ae7a81dee201133d0679f500db9726fe6e54963e7d5ae">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/puff.h" file 644 mtime 1358792265 "969b7be2a930db0cdcb19b0e5b29ae6741f5a8f663b6dba6d647e12ec60cfa8e">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/puffConfig.cmake.in" file 644 mtime 1768245003 "17fb7cf999abda7df78ec7b3478e9dcf0ddb1dd0b40245cf9f7d2b09afcdd6fa">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/pufftest.c" file 644 mtime 1771332426 "69dc7d7d4b9c5e4b2149e37562a21c1c2622b7357b4d7bc6e3ab78e921b75367">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test" dir 755 mtime 1769919309>,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/CMakeLists.txt" file 644 mtime 1769919309 "09b4ea541406be442cd7bfcff780b15b373238107b0b36b30931af2cbaf6ab0c">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/add_subdirectory_exclude_test.cmake.in" file 644 mtime 1768245003 "1f6be7dd28aca68f90bc401a51945fb2445d2480cebe57af605fa07a83a75927">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/add_subdirectory_test.cmake.in" file 644 mtime 1768245003 "940bcfe135c2bffb249e96c314cd72bebee5238d309628003b5e114963abc22f">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/find_package_no_components_test.cmake.in" file 644 mtime 1768245003 "6e002dda746535547989bd592c3d2f5ef2cabbfee06043b11baa0badb89a24a7">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/find_package_test.cmake.in" file 644 mtime 1768245003 "29ac5953b3bd0a303ab5d21e1633fcbc093b1c5c1b1174e888a133d685341494">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/find_package_wrong_components_test.cmake.in" file 644 mtime 1768245003 "ff3fc5ae857e5c5989763818b42d4b65429f8563abe051fbee202b2e9c0d8970">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/tester-cov.cmake" file 644 mtime 1769919309 "a3758f1bd0d78eec5308e8ec74b4d61f649243a2acd063392e682e9fadf2df22">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/test/tester.cmake" file 644 mtime 1769919309 "e0d2094dd9bd12ffc2eb0077051542954054d79e13fe1389b60d520c200735a8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/puff/zeros.raw" file 644 mtime 1272001622 "b7b0887089f7af1f6d1e0b4c0a1e8eddd10223b23554299455c6c9be71b653a3">,
      #splice.entry<"/build/zlib-1.3.2/contrib/testzlib" dir 755 mtime 1770888842>,
      #splice.entry<"/build/zlib-1.3.2/contrib/testzlib/CMakeLists.txt" file 644 mtime 1768245003 "f96a955c043f9f59cb7d04271de737ba685c60729c5f97853c801b9c06072de8">,
      #splice.entry<"/build/zlib-1.3.2/contrib/testzlib/testzlib.c" file 644 mtime 1770888842 "6b0b5edb1b9582f4a34e3268c8662be3f745db4e085920c9493392272bb92765">,
      #splice.entry<"/build/zlib-1.3.2/contrib/testzlib/testzlib.txt" file 644 mtime 1770743833 "d9b1d4d0409352a3e8c48542c05ffc3a5afc880773979596c857c1fd38323d94">,
      #splice.entry<"/build/zlib-1.3.2/contrib/vstudio" dir 755 mtime 1771237537>,
      #splice.entry<"/build/zlib-1.3.2/contrib/vstudio/readme.txt" file 644 mtime 1771237537 "e971cb0a1b62a0660ea183114ac2109f39a225b31bb1d4ad7da27bdc789f91ff">,
      #splice.entry<"/build/zlib-1.3.2/contrib/zlib1-dll" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/contrib/zlib1-dll/CMakeLists.txt" file 644 mtime 1771332426 "3cc556175aa08af91e93ed094cc1f3925c7f05d8d0e1a022a20b2f4959dc9a4d">,
      #splice.entry<"/build/zlib-1.3.2/contrib/zlib1-dll/readme.txt" file 644 mtime 1771237537 "67cc078e36cc7fc43853fc9cd7b4cdb468ef8de039991420bfa054b3eb080bc3">,
      #splice.entry<"/build/zlib-1.3.2/crc32.c" file 644 mtime 1771332426 "da37f3483e77c20f64c28cf55d62d7bed9d62af33eb401be906835d84539b9c9">,
      #splice.entry<"/build/zlib-1.3.2/crc32.h" file 644 mtime 1545856012 "9a2223575183ac2ee8a247f20bf3ac066e8bd0140369556bdbdffc777435749e">,
      #splice.entry<"/build/zlib-1.3.2/deflate.c" file 644 mtime 1771332426 "ea9ca4eb51b1a71aaf214b99f4a9fab177253d6268cae8e4c26d44d1812e52c2">,
      #splice.entry<"/build/zlib-1.3.2/deflate.h" file 644 mtime 1771332426 "21f4ea0973dab272fb26e93305ccf8628c8dc07e6c5df09a9861825b1920ba5d">,
      #splice.entry<"/build/zlib-1.3.2/doc" dir 755 mtime 1770888842>,
      #splice.entry<"/build/zlib-1.3.2/doc/algorithm.txt" file 644 mtime 1770888842 "3b29f6d9dd223a02ec9fd155ee9b6d01e7f6f4b25e84b19988211fca035bfaca">,
      #splice.entry<"/build/zlib-1.3.2/doc/crc-doc.1.0.pdf" file 644 mtime 1545856012 "064f9252d6e2e15ea56c2bd18e160e5c9c84bcd137c11a7af497aaa511ace998">,
      #splice.entry<"/build/zlib-1.3.2/doc/rfc1950.txt" file 644 mtime 832709925 "8f0475a5c984657bf26277f73df9456c9b97f175084f0c1748f1eb1f0b9b10b9">,
      #splice.entry<"/build/zlib-1.3.2/doc/rfc1951.txt" file 644 mtime 832709937 "5ebf4b5b7fe1c3a0c0ab9aa3ac8c0f3853a7dc484905e76e03b0b0f301350009">,
      #splice.entry<"/build/zlib-1.3.2/doc/rfc1952.txt" file 644 mtime 833303609 "164ef0897b4cbec63abf1b57f069f3599bd0fb7c72c2a4dee21bd7e03ec9af67">,
      #splice.entry<"/build/zlib-1.3.2/doc/txtvsbin.txt" file 644 mtime 1640998627 "d1549fb75137f03102798f70fd34ff76285e717ddd520dd82274c1c0510eacf0">,
      #splice.entry<"/build/zlib-1.3.2/examples" dir 755 mtime 1770888842>,
      #splice.entry<"/build/zlib-1.3.2/examples/README.examples" file 644 mtime 1539536254 "1bc1c677bbebe1aa5e85015bb62f0cf3fcdbf95652d30494159bee6166c1854a">,
      #splice.entry<"/build/zlib-1.3.2/examples/enough.c" file 644 mtime 1722288650 "528138fffd5f680caceca4b0e430b8e9d8b57a54cdb7873859b0bcbe47318ffc">,
      #splice.entry<"/build/zlib-1.3.2/examples/fitblk.c" file 644 mtime 1691096004 "bec64da6fc0c9a2a37a96722e8b88ca09059148e5be5ecbb486bdba5339e228a">,
      #splice.entry<"/build/zlib-1.3.2/examples/gun.c" file 644 mtime 1711997345 "e203716e306e79f31f73ffe594e4214801f72ae768db7a8f115ac425132ad52f">,
      #splice.entry<"/build/zlib-1.3.2/examples/gzappend.c" file 644 mtime 1661294113 "6de91c8305e37560117bff44136abff72b16b028c0bda0bbac7ea07e4988b0ce">,
      #splice.entry<"/build/zlib-1.3.2/examples/gzjoin.c" file 644 mtime 1344929444 "90b9d6c39a5fc91cf1cc9b96b025a508a8015dc502cd9374c754b44078593f57">,
      #splice.entry<"/build/zlib-1.3.2/examples/gzlog.c" file 644 mtime 1705524721 "d9a2f9871e7f1724f9f9359fd4851dc0eac7af10d8234bab66327badb33d1a38">,
      #splice.entry<"/build/zlib-1.3.2/examples/gzlog.h" file 644 mtime 1661294113 "681f280437f867820bf39880e2f4fc641d402879e399ba2e6a31d73feefe8edc">,
      #splice.entry<"/build/zlib-1.3.2/examples/gznorm.c" file 644 mtime 1707538314 "ef32a4cf70f29843d9298473e0918d8f5c570a2765ab0776262e7a613c9146e9">,
      #splice.entry<"/build/zlib-1.3.2/examples/zlib_how.html" file 644 mtime 1770888842 "48e287c4eca635c937c01baf923bf275086c83922876c22aad1b04e04605017f">,
      #splice.entry<"/build/zlib-1.3.2/examples/zpipe.c" file 644 mtime 1770886904 "e79717cefd20043fb78d730fd3b9d9cdf8f4642307fc001879dc82ddb468509f">,
      #splice.entry<"/build/zlib-1.3.2/examples/zran.c" file 644 mtime 1765071584 "905ea57074995619b25980b95dde0880a7853956515057bfa9122f8defb41cb5">,
      #splice.entry<"/build/zlib-1.3.2/examples/zran.h" file 644 mtime 1765071584 "2973457f2b138ab99e2287d1df13c38250fbcf2229c48a81bfa229945e36cf0e">,
      #splice.entry<"/build/zlib-1.3.2/gzclose.c" file 644 mtime 1681618651 "35ea6e991a63095f797d8c4cc25817fac7a7155c2ba7dcdbbf648f7871c7ea40">,
      #splice.entry<"/build/zlib-1.3.2/gzguts.h" file 644 mtime 1771332426 "db7690315cda93c0742701365d5218932ff0e2e6b8713c95019553502ada7d2b">,
      #splice.entry<"/build/zlib-1.3.2/gzlib.c" file 644 mtime 1771332426 "c899344d02b22fd0bcb78392cdd2d175a801b3ceb5d3fbfde5ec420591537269">,
      #splice.entry<"/build/zlib-1.3.2/gzread.c" file 644 mtime 1771332426 "ee2b1141f7b78065147e787c8b4adb983c09c409aa5fe5782479e2664676d17c">,
      #splice.entry<"/build/zlib-1.3.2/gzwrite.c" file 644 mtime 1771332426 "2ce783294c688330c716bfe106f43167d3dae5be84994176bc304d205d4f5b04">,
      #splice.entry<"/build/zlib-1.3.2/infback.c" file 644 mtime 1771332426 "bf9788af31e08a4242fc9d36bc0ce1a7a667bbfd9edc51ff26146195ee2e528a">,
      #splice.entry<"/build/zlib-1.3.2/inffast.c" file 644 mtime 1771332426 "f96787a11bb7131ffd2221fb40db27f6a5a1dfb12f59c0bc388807010749c34a">,
      #splice.entry<"/build/zlib-1.3.2/inffast.h" file 644 mtime 1681618651 "05cc5dc9ff1da7b8b52a4bd8bda0d8a5c236a2f39efe84b941516ea13857e6c5">,
      #splice.entry<"/build/zlib-1.3.2/inffixed.h" file 644 mtime 1767646984 "fd7c4b1dbdacb283421d0675744aaecda44e840e183b5131448bac94564f6adb">,
      #splice.entry<"/build/zlib-1.3.2/inflate.c" file 644 mtime 1771332426 "90221ea7d762e7044057f6ad5013e969086c6ba3d3051716b7aa786d7a6362ec">,
      #splice.entry<"/build/zlib-1.3.2/inflate.h" file 644 mtime 1710550160 "e6a43bd0e24ab2cf5fa1dca630859e9a2f6a721f033f75faf179f5c0299e4fe2">,
      #splice.entry<"/build/zlib-1.3.2/inftrees.c" file 644 mtime 1771332426 "f7ee9ce5925fc9d1579c76e574feed85f5ca4ccddc446a7795578854bbc65743">,
      #splice.entry<"/build/zlib-1.3.2/inftrees.h" file 644 mtime 1771332426 "d3a7ea301d8ec514823d052a2e42af4636bc81a0cf07052f526030f208068fb8">,
      #splice.entry<"/build/zlib-1.3.2/make_vms.com" file 644 mtime 1661294113 "14ed54bdd391c1648cedfb69d8a73a26dcc7f1187d59b0f18d944b7665cec85b">,
      #splice.entry<"/build/zlib-1.3.2/msdos" dir 755 mtime 1707726795>,
      #splice.entry<"/build/zlib-1.3.2/msdos/Makefile.bor" file 644 mtime 1322432132 "292ab363f7ffbc4ae84d37cd9bdffd2dac1003bee52d223a8489844870f20702">,
      #splice.entry<"/build/zlib-1.3.2/msdos/Makefile.dj2" file 644 mtime 1707726795 "45e24acb4fe34521378ae86a43a68f11b0579e7f864659d099a7d36e87d277dd">,
      #splice.entry<"/build/zlib-1.3.2/msdos/Makefile.emx" file 644 mtime 1438148671 "c749d6ec7f88e8e639d4f03bdbdcbbe9d1c304210be4c4be621ceb22961d3d64">,
      #splice.entry<"/build/zlib-1.3.2/msdos/Makefile.msc" file 644 mtime 1322432132 "0e021a6f42212415b060e4ad468eb415d0a8c1f343137fb9dff2cb8f9ead3027">,
      #splice.entry<"/build/zlib-1.3.2/msdos/Makefile.tc" file 644 mtime 1322432132 "2ae12ee2a3e62f7c5a0520d0fbe4adee772bc07fe816002b07ccb43db3daa76a">,
      #splice.entry<"/build/zlib-1.3.2/os400" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/os400/README400" file 644 mtime 1771332426 "0e9c9a9847c73f9d35a56835bf4b7210441fdd487e13b72899ab978071c580ab">,
      #splice.entry<"/build/zlib-1.3.2/os400/bndsrc" file 644 mtime 1768241608 "889258a28ee9cc2791169928307acd647c38c52956f73b1738feca86a047c6f6">,
      #splice.entry<"/build/zlib-1.3.2/os400/make.sh" file 644 mtime 1771332426 "82219263a11c735719834f0ae0d7812c72c238b5133f7a2028725b2a8261a3ec">,
      #splice.entry<"/build/zlib-1.3.2/os400/zlibfixed.rpgle" file 644 mtime 1771332426 "b2f229b13bef3f6ad499180b63c028805d93ec65b072aeab1fd312ee6738e3ba">,
      #splice.entry<"/build/zlib-1.3.2/os400/zlibfree.rpgle" file 644 mtime 1771332426 "b9df291ebae27d5952f2335d9bb488597d0258d48126e8367ed7c4422a987d15">,
      #splice.entry<"/build/zlib-1.3.2/qnx" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/qnx/package.qpg" file 644 mtime 1771332426 "59e1826e18e0ce4bab6f007a500794a08a34bb20f92dbb4c0d254b8be2d37976">,
      #splice.entry<"/build/zlib-1.3.2/test" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/test/CMakeLists.txt" file 644 mtime 1769919058 "86c420c346fcf52b09d7667d1498652625db42cd4c4f996eaffcf7857fb31a66">,
      #splice.entry<"/build/zlib-1.3.2/test/add_subdirectory_exclude_test.cmake.in" file 644 mtime 1738382546 "ebdd7fc8a0174ed7d5718fd97a022a79d6a7268a8af484581d2a29d56cd0b72b">,
      #splice.entry<"/build/zlib-1.3.2/test/add_subdirectory_test.cmake.in" file 644 mtime 1738382546 "d2fc1b9e9562ac329b2ae1e0d525be2d283a97cdc72a4659415cd8dadad54597">,
      #splice.entry<"/build/zlib-1.3.2/test/example.c" file 644 mtime 1771332426 "be1b050aad808cdb016c01f42568d3a62ee37dd7b2b56bef0ade21be8d9fee0d">,
      #splice.entry<"/build/zlib-1.3.2/test/find_package_no_components_test" dir 755 mtime 1771201101>,
      #splice.entry<"/build/zlib-1.3.2/test/find_package_no_components_test.cmake.in" file 644 mtime 1769919058 "4cdca9463f0b8f07a281be687d012031f5b8e0f183e02a6fd63357e0473b1646">,
      #splice.entry<"/build/zlib-1.3.2/test/find_package_test.cmake.in" file 644 mtime 1769919058 "6277f562ff750863ffe450e2a95cc3d72ab27e86830983414df6362cfd30c351">,
      #splice.entry<"/build/zlib-1.3.2/test/find_package_wrong_components_test" dir 755 mtime 1771201101>,
      #splice.entry<"/build/zlib-1.3.2/test/find_package_wrong_components_test.cmake.in" file 644 mtime 1769919058 "0870d5ea72bb34c251ee09e08ce6770721aa18ff681c776affa88daf7ccf61d0">,
      #splice.entry<"/build/zlib-1.3.2/test/infcover.c" file 644 mtime 1720714967 "37718912b22c68942a469f971cbb47500d24dc4f6258db271edd417f0eb69a5e">,
      #splice.entry<"/build/zlib-1.3.2/test/minigzip.c" file 644 mtime 1771332426 "203b1a4623a11021f4b64c5f6b6a4addc1bcefac694cd48cac71ccce35d82c1d">,
      #splice.entry<"/build/zlib-1.3.2/treebuild.xml" file 644 mtime 1771332426 "e0a62ed0f4b8fe56453dba32de4fe53aed163dba664c8603d15b3c03b767d7ff">,
      #splice.entry<"/build/zlib-1.3.2/trees.c" file 644 mtime 1771332426 "a16217d5ea6d8342ff08afe5207b1dab620f05610e121dda55b4f9aae9de4f68">,
      #splice.entry<"/build/zlib-1.3.2/trees.h" file 644 mtime 1271611958 "bb0a9d3ca88ee00c81adb7c636e73b97085f6ef1b52d6d58edbe2b6dc3adeb4d">,
      #splice.entry<"/build/zlib-1.3.2/uncompr.c" file 644 mtime 1771332426 "953f5381650838d507b01499790bd64524433ea6ea29ea9325bf542af10cfe7d">,
      #splice.entry<"/build/zlib-1.3.2/watcom" dir 755 mtime 1266108074>,
      #splice.entry<"/build/zlib-1.3.2/watcom/watcom_f.mak" file 644 mtime 1266108074 "7e039b912f9cffaa40835281430bb284fa9042b0a0d12f6b34700a06bca6576e">,
      #splice.entry<"/build/zlib-1.3.2/watcom/watcom_l.mak" file 644 mtime 1266108012 "d11b4064604a034725860e63e3f6d347056372e4b1675b183e20a93533b20cc9">,
      #splice.entry<"/build/zlib-1.3.2/win32" dir 755 mtime 1771332426>,
      #splice.entry<"/build/zlib-1.3.2/win32/DLL_FAQ.txt" file 644 mtime 1707348951 "9000c1acd517114f302abd9530f9d403e8f9353ec924c89cd539a2d8aaec2a4b">,
      #splice.entry<"/build/zlib-1.3.2/win32/Makefile.bor" file 644 mtime 1507865234 "7d73a0d2c3e38b7c610bbc9c22f683a4fe1ab9b8b65649a3a8ac4ff7fcc14ba6">,
      #splice.entry<"/build/zlib-1.3.2/win32/Makefile.gcc" file 644 mtime 1771332426 "71135ef48a9fcea23c3946b5b7f41ae866e248b1c1e20fd580045a593054c39f">,
      #splice.entry<"/build/zlib-1.3.2/win32/Makefile.msc" file 644 mtime 1507865234 "235529bd529d4690d5d4b7871fdd0a1f118f2fe18862cbdec5f5ac674c55a60d">,
      #splice.entry<"/build/zlib-1.3.2/win32/README-WIN32.txt" file 644 mtime 1771332426 "22496c33630960c1f36db6e65cafd460fdf58fae0dcf98dedee31a2638184746">,
      #splice.entry<"/build/zlib-1.3.2/win32/VisualC.txt" file 644 mtime 1484500034 "9ec0babd46eaa012371dee2d3a8a55d9c7130f7895512c3371c737e4a7f6a997">,
      #splice.entry<"/build/zlib-1.3.2/win32/zlib.def" file 644 mtime 1771332426 "4495a609d288788bb43efc74d6dc7261ecf184af86e4ef8c63a877e2318c8fa9">,
      #splice.entry<"/build/zlib-1.3.2/win32/zlib1.rc" file 644 mtime 1771332426 "d7a66485b4837b48dbbf8b4adcc71682591a1eb5d6d4c8f44b8efb7ace790a15">,
      #splice.entry<"/build/zlib-1.3.2/zconf.h" file 644 mtime 1771332426 "cb7c2c84211473b4699223edd363d3207b43b9578e739b5bf638f42204ea6e0f">,
      #splice.entry<"/build/zlib-1.3.2/zconf.h.in" file 644 mtime 1771332426 "cb7c2c84211473b4699223edd363d3207b43b9578e739b5bf638f42204ea6e0f">,
      #splice.entry<"/build/zlib-1.3.2/zlib.3" file 644 mtime 1771332426 "5eebcb61a9c1ef91ff6c8e6d37b32554f5eefff825b190b1b5e5982f35d87534">,
      #splice.entry<"/build/zlib-1.3.2/zlib.3.pdf" file 644 mtime 1771332426 "6c19c87d46da17c2be84e30fa690de710f9b5b07ac60dfedb170a4e1e3c5d642">,
      #splice.entry<"/build/zlib-1.3.2/zlib.h" file 644 mtime 1771332426 "818667d6ab6a37fe7469cb06a7f0cb2c2cb2f2c948a03e5accf1a4a74bf3020a">,
      #splice.entry<"/build/zlib-1.3.2/zlib.map" file 644 mtime 1771332426 "684411bd6fbcd5b377ca5a3e813e4195ac5e7db1976c8f975875b6204d1d6a8e">,
      #splice.entry<"/build/zlib-1.3.2/zlib.pc.cmakein" file 644 mtime 1770841170 "654f0fc5633cac92b031f3afdc9622901e222afaf7801ff3c49430f9f1216c0a">,
      #splice.entry<"/build/zlib-1.3.2/zlib.pc.in" file 644 mtime 1770841170 "b40b72f1726380f0575283b6a4a4bec781d4d3d994638b490a10b3156a10f508">,
      #splice.entry<"/build/zlib-1.3.2/zlibConfig.cmake.in" file 644 mtime 1769919058 "2be5bbd8a8ca8e616832a2e14a3deff82996ca454249cc7f95e02bf596973f01">,
      #splice.entry<"/build/zlib-1.3.2/zutil.c" file 644 mtime 1771332426 "1279908a15580224a2c1f377555ffdd150327fed71801aa77fc35978dcb741c8">,
      #splice.entry<"/build/zlib-1.3.2/zutil.h" file 644 mtime 1771332426 "a12243cc6d338ffad0c8e3500fbc05bc7fdcdc25a469393b1c2f7e5df307fff3">
  ]
  %glue_2424 = splice.literal "glue" at 2424 -> [
      #splice.entry<"/build/zlib-1.3.2/configure" file 755 mtime 1794960000 "6d0139b682f1a6b1d41be982b353fbd1d889d7de92e087412d9c06706e09ce87">
  ]
  %find_basename_stat_mktemp__4_2637 = splice.exec "find|basename|stat|mktemp|+4" at 2637(%sandbox_720#0, %tar_1268, %glue_2424) -> [
      #splice.entry<"/build/zlib-1.3.2/configure" file 755 mtime 1794960000 "a3692f53c7228305a0714d1d7abbcc2d0d39a834e49b065cdbb95792ed959ff3">
  ]
  %configure_2780:4 = splice.exec "configure" at 2780(%sandbox_720#0, %tar_1268, %tar_1268_0#9, %tar_1268_0#10, %find_basename_stat_mktemp__4_2637, %tar_1268_0#280, %tar_1268_0#281, %tar_1268_0#284, %tar_1268_0#285, %tar_1268_0#287) -> [
      #splice.entry<"/build/zlib-1.3.2/Makefile" file 644 mtime 1794960000 "7096aaa4a10f8502ee864768867a6d1052abe66f889587f9d105d1a146a73535">,
      #splice.entry<"/build/zlib-1.3.2/configure.log" file 644 mtime 1794960000 "4ce01b82cee7efc1608b7e592cbd9c5d2f66f24b13da8b0730b55a08ca0931c9">,
      #splice.entry<"/build/zlib-1.3.2/zconf.h" file 644 mtime 1794960000 "0718a11beb3295b345fb29a63b44b654b282d82c4cd0513f6225587f2b29b8bb">,
      #splice.entry<"/build/zlib-1.3.2/zlib.pc" file 644 mtime 1794960000 "948322f7dfb5f681d522a9e239dabc3a370126d6aa4db984f88aac552a61eb35">
  ]
  %gcc_6455 = splice.exec "gcc" at 6455 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#13, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/adler32.o" file 644 mtime 1794960000 "b9183f8874808130db1ac72a1d29568a01b9bea00d9508151257de857acfb357">
  ]
  %gcc_6562 = splice.exec "gcc" at 6562 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#199, %tar_1268_0#200, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/crc32.o" file 644 mtime 1794960000 "8240a1c78620ddb806b84bb9d9141cd728ab69799c0d43beaa79cda78f92c0bc">
  ]
  %gcc_6664 = splice.exec "gcc" at 6664 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#201, %tar_1268_0#202, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/deflate.o" file 644 mtime 1794960001 "2f352204cd2922643ad8043695d13fb53253d9fbd7ee78606541f596c62a5da7">
  ]
  %gcc_6766 = splice.exec "gcc" at 6766 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#229, %tar_1268_0#231, %tar_1268_0#234, %tar_1268_0#236, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/infback.o" file 644 mtime 1794960001 "bc90cbeb9471e4a4e9122427177fb8495dc76f5ac17732f4ee0289d3fa75f393">
  ]
  %gcc_6878 = splice.exec "gcc" at 6878 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#230, %tar_1268_0#231, %tar_1268_0#234, %tar_1268_0#236, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/inffast.o" file 644 mtime 1794960001 "9394ce543b1b5fdaf878dc4fd9f68ab5c84210072ab42a31d27fd913f2ba82c3">
  ]
  %gcc_6986 = splice.exec "gcc" at 6986 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#231, %tar_1268_0#233, %tar_1268_0#234, %tar_1268_0#236, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/inflate.o" file 644 mtime 1794960002 "ad8f7283bbec1f9ef7a80719fb413d8752e412cae1d90ad1d91d0260c004312c">
  ]
  %gcc_7088 = splice.exec "gcc" at 7088 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#232, %tar_1268_0#234, %tar_1268_0#235, %tar_1268_0#236, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/inftrees.o" file 644 mtime 1794960002 "2b43462ab2d09f5530cad474fbfc4d3228883757699795827753d8a85a244697">
  ]
  %gcc_7190 = splice.exec "gcc" at 7190 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#202, %tar_1268_0#265, %tar_1268_0#266, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/trees.o" file 644 mtime 1794960002 "1cef8382c48f90c6b781fe5a3f62cd37403d2e38f76b4c87c66decda46d08f06">
  ]
  %gcc_7288 = splice.exec "gcc" at 7288 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#289, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/zutil.o" file 644 mtime 1794960002 "ebf6fabd04857555e731d75d6163de61c84be74aa298811931a92a55930e1a07">
  ]
  %gcc_7399 = splice.exec "gcc" at 7399 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#17, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/compress.o" file 644 mtime 1794960002 "065b157aaccb8d6c559b0c0a87a6b1358e818cde6983288cdeb5efcb67f6251c">
  ]
  %gcc_7491 = splice.exec "gcc" at 7491 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#267, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/uncompr.o" file 644 mtime 1794960002 "a4b5ee4339e40bba14514edfbcb4cf91aac277a7c4e9fbd3fd88cb716a3b8b6c">
  ]
  %gcc_7592 = splice.exec "gcc" at 7592 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#224, %tar_1268_0#225, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/gzclose.o" file 644 mtime 1794960003 "14e4c6d8e459e390f7700d7ab6dbc0b6dee7b677e0a8021c4b226e120d7dc6ae">
  ]
  %gcc_7693 = splice.exec "gcc" at 7693 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %tar_1268_0#226, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/gzlib.o" file 644 mtime 1794960003 "c464c82404ce56edfb67c9df1cea982b4d2bee97d853bf87d4fe802582d08331">
  ]
  %gcc_7795 = splice.exec "gcc" at 7795 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %tar_1268_0#227, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/gzread.o" file 644 mtime 1794960003 "56853c1cc6842c2b9068a01bcaf4d4314819751f8ac8f76160fcbfc0042db5c7">
  ]
  %gcc_7908 = splice.exec "gcc" at 7908 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %tar_1268_0#228, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/gzwrite.o" file 644 mtime 1794960003 "fbb8622d4b88500f987f9e5b6ea8bc32d7c4699353cb29c4ee45c2ba089b0cfe">
  ]
  %ar_7996 = splice.exec "ar" at 7996 as "cc_library"(%sandbox_720#0, %tar_1268, %gcc_6455, %gcc_7399, %gcc_6562, %gcc_6664, %gcc_7592, %gcc_7693, %gcc_7795, %gcc_7908, %gcc_6766, %gcc_6878, %gcc_6986, %gcc_7088, %gcc_7190, %gcc_7491, %gcc_7288) -> [
      #splice.entry<"/build/zlib-1.3.2/libz.a" file 644 mtime 1794960003 "643431af12588b6ef198c19de5352dc2efc2a226d770d3bcf7c40a75bcd6b11f">
  ]
  %mkdir_8698 = splice.literal "mkdir" at 8698 folded -> [
      #splice.entry<"/build/zlib-1.3.2/objs" dir 755 mtime 1794960003>
  ]
  %gcc_8720 = splice.exec "gcc" at 8720 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#13, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/adler32.o" file 644 mtime 1794960003 "b9183f8874808130db1ac72a1d29568a01b9bea00d9508151257de857acfb357">
  ]
  %mv_8816 = splice.copy "mv" at 8816(%gcc_8720) -> <"/build/zlib-1.3.2/adler32.lo" file 644 mtime 1794960003 "b9183f8874808130db1ac72a1d29568a01b9bea00d9508151257de857acfb357">
  %gcc_8859 = splice.exec "gcc" at 8859 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#199, %tar_1268_0#200, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/crc32.o" file 644 mtime 1794960003 "8240a1c78620ddb806b84bb9d9141cd728ab69799c0d43beaa79cda78f92c0bc">
  ]
  %mv_8956 = splice.copy "mv" at 8956(%gcc_8859) -> <"/build/zlib-1.3.2/crc32.lo" file 644 mtime 1794960003 "8240a1c78620ddb806b84bb9d9141cd728ab69799c0d43beaa79cda78f92c0bc">
  %gcc_8998 = splice.exec "gcc" at 8998 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#201, %tar_1268_0#202, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/deflate.o" file 644 mtime 1794960004 "2f352204cd2922643ad8043695d13fb53253d9fbd7ee78606541f596c62a5da7">
  ]
  %mv_9094 = splice.copy "mv" at 9094(%gcc_8998) -> <"/build/zlib-1.3.2/deflate.lo" file 644 mtime 1794960004 "2f352204cd2922643ad8043695d13fb53253d9fbd7ee78606541f596c62a5da7">
  %gcc_9137 = splice.exec "gcc" at 9137 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#229, %tar_1268_0#231, %tar_1268_0#234, %tar_1268_0#236, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/infback.o" file 644 mtime 1794960004 "bc90cbeb9471e4a4e9122427177fb8495dc76f5ac17732f4ee0289d3fa75f393">
  ]
  %mv_9240 = splice.copy "mv" at 9240(%gcc_9137) -> <"/build/zlib-1.3.2/infback.lo" file 644 mtime 1794960004 "bc90cbeb9471e4a4e9122427177fb8495dc76f5ac17732f4ee0289d3fa75f393">
  %gcc_9282 = splice.exec "gcc" at 9282 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#230, %tar_1268_0#231, %tar_1268_0#234, %tar_1268_0#236, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/inffast.o" file 644 mtime 1794960004 "9394ce543b1b5fdaf878dc4fd9f68ab5c84210072ab42a31d27fd913f2ba82c3">
  ]
  %mv_9370 = splice.copy "mv" at 9370(%gcc_9282) -> <"/build/zlib-1.3.2/inffast.lo" file 644 mtime 1794960004 "9394ce543b1b5fdaf878dc4fd9f68ab5c84210072ab42a31d27fd913f2ba82c3">
  %gcc_9417 = splice.exec "gcc" at 9417 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#231, %tar_1268_0#233, %tar_1268_0#234, %tar_1268_0#236, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/inflate.o" file 644 mtime 1794960005 "ad8f7283bbec1f9ef7a80719fb413d8752e412cae1d90ad1d91d0260c004312c">
  ]
  %mv_9521 = splice.copy "mv" at 9521(%gcc_9417) -> <"/build/zlib-1.3.2/inflate.lo" file 644 mtime 1794960005 "ad8f7283bbec1f9ef7a80719fb413d8752e412cae1d90ad1d91d0260c004312c">
  %gcc_9563 = splice.exec "gcc" at 9563 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#232, %tar_1268_0#234, %tar_1268_0#235, %tar_1268_0#236, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/inftrees.o" file 644 mtime 1794960005 "2b43462ab2d09f5530cad474fbfc4d3228883757699795827753d8a85a244697">
  ]
  %mv_9650 = splice.copy "mv" at 9650(%gcc_9563) -> <"/build/zlib-1.3.2/inftrees.lo" file 644 mtime 1794960005 "2b43462ab2d09f5530cad474fbfc4d3228883757699795827753d8a85a244697">
  %gcc_9709 = splice.exec "gcc" at 9709 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#202, %mkdir_8698, %tar_1268_0#265, %tar_1268_0#266, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/trees.o" file 644 mtime 1794960005 "1cef8382c48f90c6b781fe5a3f62cd37403d2e38f76b4c87c66decda46d08f06">
  ]
  %mv_9797 = splice.copy "mv" at 9797(%gcc_9709) -> <"/build/zlib-1.3.2/trees.lo" file 644 mtime 1794960005 "1cef8382c48f90c6b781fe5a3f62cd37403d2e38f76b4c87c66decda46d08f06">
  %gcc_9839 = splice.exec "gcc" at 9839 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %mkdir_8698, %configure_2780#2, %tar_1268_0#284, %tar_1268_0#289, %tar_1268_0#290) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/zutil.o" file 644 mtime 1794960005 "ebf6fabd04857555e731d75d6163de61c84be74aa298811931a92a55930e1a07">
  ]
  %mv_9934 = splice.copy "mv" at 9934(%gcc_9839) -> <"/build/zlib-1.3.2/zutil.lo" file 644 mtime 1794960005 "ebf6fabd04857555e731d75d6163de61c84be74aa298811931a92a55930e1a07">
  %gcc_9981 = splice.exec "gcc" at 9981 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#17, %mkdir_8698, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/compress.o" file 644 mtime 1794960005 "065b157aaccb8d6c559b0c0a87a6b1358e818cde6983288cdeb5efcb67f6251c">
  ]
  %mv_10077 = splice.copy "mv" at 10077(%gcc_9981) -> <"/build/zlib-1.3.2/compress.lo" file 644 mtime 1794960005 "065b157aaccb8d6c559b0c0a87a6b1358e818cde6983288cdeb5efcb67f6251c">
  %gcc_10119 = splice.exec "gcc" at 10119 as "cc_object"(%sandbox_720#0, %tar_1268, %mkdir_8698, %tar_1268_0#267, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/uncompr.o" file 644 mtime 1794960006 "a4b5ee4339e40bba14514edfbcb4cf91aac277a7c4e9fbd3fd88cb716a3b8b6c">
  ]
  %mv_10215 = splice.copy "mv" at 10215(%gcc_10119) -> <"/build/zlib-1.3.2/uncompr.lo" file 644 mtime 1794960006 "a4b5ee4339e40bba14514edfbcb4cf91aac277a7c4e9fbd3fd88cb716a3b8b6c">
  %gcc_10262 = splice.exec "gcc" at 10262 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#224, %tar_1268_0#225, %mkdir_8698, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/gzclose.o" file 644 mtime 1794960006 "14e4c6d8e459e390f7700d7ab6dbc0b6dee7b677e0a8021c4b226e120d7dc6ae">
  ]
  %mv_10358 = splice.copy "mv" at 10358(%gcc_10262) -> <"/build/zlib-1.3.2/gzclose.lo" file 644 mtime 1794960006 "14e4c6d8e459e390f7700d7ab6dbc0b6dee7b677e0a8021c4b226e120d7dc6ae">
  %gcc_10400 = splice.exec "gcc" at 10400 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %tar_1268_0#226, %mkdir_8698, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/gzlib.o" file 644 mtime 1794960006 "c464c82404ce56edfb67c9df1cea982b4d2bee97d853bf87d4fe802582d08331">
  ]
  %mv_10496 = splice.copy "mv" at 10496(%gcc_10400) -> <"/build/zlib-1.3.2/gzlib.lo" file 644 mtime 1794960006 "c464c82404ce56edfb67c9df1cea982b4d2bee97d853bf87d4fe802582d08331">
  %gcc_10543 = splice.exec "gcc" at 10543 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %tar_1268_0#227, %mkdir_8698, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/gzread.o" file 644 mtime 1794960006 "56853c1cc6842c2b9068a01bcaf4d4314819751f8ac8f76160fcbfc0042db5c7">
  ]
  %mv_10640 = splice.copy "mv" at 10640(%gcc_10543) -> <"/build/zlib-1.3.2/gzread.lo" file 644 mtime 1794960006 "56853c1cc6842c2b9068a01bcaf4d4314819751f8ac8f76160fcbfc0042db5c7">
  %gcc_10682 = splice.exec "gcc" at 10682 as "cc_object"(%sandbox_720#0, %tar_1268, %tar_1268_0#225, %tar_1268_0#228, %mkdir_8698, %configure_2780#2, %tar_1268_0#284) -> [
      #splice.entry<"/build/zlib-1.3.2/objs/gzwrite.o" file 644 mtime 1794960006 "fbb8622d4b88500f987f9e5b6ea8bc32d7c4699353cb29c4ee45c2ba089b0cfe">
  ]
  %mv_10788 = splice.copy "mv" at 10788(%gcc_10682) -> <"/build/zlib-1.3.2/gzwrite.lo" file 644 mtime 1794960006 "fbb8622d4b88500f987f9e5b6ea8bc32d7c4699353cb29c4ee45c2ba089b0cfe">
  %collect2_10868 = splice.exec "collect2" at 10868(%sandbox_720#0, %tar_1268, %mv_8816, %mv_10077, %mv_8956, %mv_9094, %mv_10358, %mv_10496, %mv_10640, %mv_10788, %mv_9240, %mv_9370, %mv_9521, %mv_9650, %mv_9797, %mv_10215, %tar_1268_0#285, %mv_9934) -> [
      #splice.entry<"/build/zlib-1.3.2/libz.so.1.3.2" file 755 mtime 1794960006 "47fa2030d9fd209bee8d81b025e165cc11d79ecfcc09f4b3f3165d6a5491e8e9">
  ]
  %mkdir_12869 = splice.literal "mkdir" at 12869 folded -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2" dir 755 mtime 1794960006>
  ]
  %mkdir_12952:2 = splice.literal "mkdir" at 12952 folded -> [
      #splice.entry<"/nix/store/igzrdkid07pdyh30cswrjb7a9yln9mpp-zlib-1.3.2-static" dir 755 mtime 1794960006>,
      #splice.entry<"/nix/store/igzrdkid07pdyh30cswrjb7a9yln9mpp-zlib-1.3.2-static/lib" dir 755 mtime 1794960006>
  ]
  %mkdir_12980 = splice.literal "mkdir" at 12980 folded -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/lib" dir 755 mtime 1794960006>
  ]
  %mkdir_13008:3 = splice.literal "mkdir" at 13008 folded -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/share" dir 755 mtime 1794960006>,
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/share/man" dir 755 mtime 1794960006>,
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/share/man/man3" dir 755 mtime 1794960006>
  ]
  %mkdir_13035:3 = splice.literal "mkdir" at 13035 folded -> [
      #splice.entry<"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev" dir 755 mtime 1794960006>,
      #splice.entry<"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/share" dir 755 mtime 1794960006>,
      #splice.entry<"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/share/pkgconfig" dir 755 mtime 1794960006>
  ]
  %cp_13069 = splice.copy "cp" at 13069(%ar_7996) -> <"/nix/store/igzrdkid07pdyh30cswrjb7a9yln9mpp-zlib-1.3.2-static/lib/libz.a" file 644 mtime 1794960006 "643431af12588b6ef198c19de5352dc2efc2a226d770d3bcf7c40a75bcd6b11f">
  %cp_13173 = splice.copy "cp" at 13173(%collect2_10868) -> <"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/lib/libz.so.1.3.2" file 755 mtime 1794960006 "47fa2030d9fd209bee8d81b025e165cc11d79ecfcc09f4b3f3165d6a5491e8e9">
  %ln_13214 = splice.literal "ln" at 13214 folded -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/lib/libz.so" link 0 mtime 1794960006 "libz.so.1.3.2">
  ]
  %ln_13225 = splice.literal "ln" at 13225 folded -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/lib/libz.so.1" link 0 mtime 1794960006 "libz.so.1.3.2">
  ]
  %cp_13276 = splice.copy "cp" at 13276(%tar_1268_0#282) -> <"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/share/man/man3/zlib.3" file 644 mtime 1794960006 "5eebcb61a9c1ef91ff6c8e6d37b32554f5eefff825b190b1b5e5982f35d87534">
  %cp_13330 = splice.copy "cp" at 13330(%configure_2780#3) -> <"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/share/pkgconfig/zlib.pc" file 644 mtime 1794960006 "948322f7dfb5f681d522a9e239dabc3a370126d6aa4db984f88aac552a61eb35">
  %mkdir_13371 = splice.literal "mkdir" at 13371 folded -> [
      #splice.entry<"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/include" dir 755 mtime 1794960006>
  ]
  %cp_13405 = splice.copy "cp" at 13405(%configure_2780#2) -> <"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/include/zconf.h" file 644 mtime 1794960006 "0718a11beb3295b345fb29a63b44b654b282d82c4cd0513f6225587f2b29b8bb">
  %cp_13405_1 = splice.copy "cp" at 13405(%tar_1268_0#284) -> <"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/include/zlib.h" file 644 mtime 1794960006 "818667d6ab6a37fe7469cb06a7f0cb2c2cb2f2c948a03e5accf1a4a74bf3020a">
  %find_patchelf_13860 = splice.exec "find|patchelf" at 13860(%sandbox_720#0, %tar_1268, %mkdir_12869, %mkdir_12980, %cp_13173) -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/lib/libz.so.1.3.2" file 755 mtime 1794960006 "177a0a0b260e6fe3d2f9003b8c390e7fe33e6901e835aca10f660d4de6008aff">
  ]
  %gzip_14078 = splice.exec "gzip" at 14078(%sandbox_720#0, %tar_1268, %mkdir_12869, %mkdir_13008#0, %mkdir_13008#1, %mkdir_13008#2, %cp_13276) -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/share/man/man3/zlib.3.gz" file 644 mtime 1794960006 "25b9faa4c521255832af1b6fb57b83bd9cd7d17792ceaca20efc6a1665539433">
  ]
  %mktemp_14153 = splice.literal "mktemp" at 14153 folded -> [
      #splice.entry<"/build/striperr.uHQCtJ" file 600 mtime 1794960006 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_14195 = splice.exec "strip" at 14195(%sandbox_720#0, %mktemp_14153, %tar_1268, %mkdir_12869, %mkdir_12980, %find_patchelf_13860) -> [
      #splice.entry<"/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2/lib/libz.so.1.3.2" file 755 mtime 1794960006 "13f262bd1cc2a8a89793fc9caa6b8d5a2e935571cbd87aaf9d736c4b2c98a596">
  ]
  %mktemp_14398 = splice.literal "mktemp" at 14398 folded -> [
      #splice.entry<"/build/striperr.zFVlKo" file 600 mtime 1794960006 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_14440 = splice.exec "strip" at 14440(%sandbox_720#0, %mktemp_14398, %tar_1268, %mkdir_12952#0, %mkdir_12952#1, %cp_13069) -> [
      #splice.entry<"/nix/store/igzrdkid07pdyh30cswrjb7a9yln9mpp-zlib-1.3.2-static/lib/libz.a" file 644 mtime 1794960006 "7e496442cb15e24ca1c246e160493926172c1d4b4ab593fa39e4098a1f61168f">
  ]
  %mkdir_14861 = splice.literal "mkdir" at 14861 folded -> [
      #splice.entry<"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/nix-support" dir 755 mtime 1794960006>
  ]
  %glue_14873 = splice.literal "glue" at 14873 -> [
      #splice.entry<"/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev/nix-support/propagated-build-inputs" file 644 mtime 1794960006 "6570e9111244c548673f1a8c202b122c23e0432b030dbf392219fbdc9339e337">
  ]
  splice.output "dev" "/nix/store/879xd5x23lfd4l93jz71yaz06wa15yc1-zlib-1.3.2-dev"(%mkdir_13035#0, %mkdir_13371, %cp_13405, %cp_13405_1, %mkdir_14861, %glue_14873, %mkdir_13035#1, %mkdir_13035#2, %cp_13330)
  splice.output "out" "/nix/store/wgw25d181h0qks7qsfp1bh7c5nd3f0s7-zlib-1.3.2"(%mkdir_12869, %mkdir_12980, %ln_13214, %ln_13225, %strip_14195, %mkdir_13008#0, %mkdir_13008#1, %mkdir_13008#2, %gzip_14078)
  splice.output "static" "/nix/store/igzrdkid07pdyh30cswrjb7a9yln9mpp-zlib-1.3.2-static"(%mkdir_12952#0, %mkdir_12952#1, %strip_14440)
}

