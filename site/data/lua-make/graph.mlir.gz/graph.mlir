module {
  %0:3 = splice.literal "sandbox" at 720 -> [
      #splice.entry<"/build" dir 700 mtime 1794960000>,
      #splice.entry<"/build/.attrs.json" file 644 mtime 1794960000 "8b9c61c630098b0761acfa1f86c6e3757dc764e4fe98456903b6ce986f475934">,
      #splice.entry<"/build/.attrs.sh" file 644 mtime 1794960000 "bee2b439bdf8dcb06c63393297c6f4b4cfe9bd10c38f5753d1a509c20e288df7">
  ]
  %1:74 = splice.exec "tar" at 1421(%0#0) -> [
      #splice.entry<"/build/lua-5.2.4" dir 755 mtime 1424910717>,
      #splice.entry<"/build/lua-5.2.4/Makefile" file 644 mtime 1424741334 "03bc16024f6b68adc7a044928ddb017869a275eb17b1374f098e825608718538">,
      #splice.entry<"/build/lua-5.2.4/README" file 644 mtime 1424910717 "746ef475168b8efdaf19f8733fb84fa88bf8b4855e8f06ad4a97aceb8fb0664f">,
      #splice.entry<"/build/lua-5.2.4/doc" dir 755 mtime 1424910603>,
      #splice.entry<"/build/lua-5.2.4/doc/contents.html" file 644 mtime 1424741076 "99ce749a42678b3c98755156b04c88f500347f99085749ab2e2f40aacc857fd0">,
      #splice.entry<"/build/lua-5.2.4/doc/logo.gif" file 644 mtime 1003840755 "9c3a3208ef05e12110f9b7b491cef676e650e4ebf3d36c4414268666bcc95d8a">,
      #splice.entry<"/build/lua-5.2.4/doc/lua.1" file 644 mtime 1321463818 "a44ed64aaf16121f193ac0a83322e4b5cd78a6932056dc5de5cc032856d90786">,
      #splice.entry<"/build/lua-5.2.4/doc/lua.css" file 644 mtime 1424779941 "d3bb1d56bc03379397c7f607802d8530ccb599009a5321b26dfc9fdc43ddd8a7">,
      #splice.entry<"/build/lua-5.2.4/doc/luac.1" file 644 mtime 1321463818 "ac60e6992db478539dff611beed7ad01f52622c897657a9152165470039b0494">,
      #splice.entry<"/build/lua-5.2.4/doc/manual.css" file 644 mtime 1384044308 "1a97ea6df44fb79a99160f88dd142aa80552583786d40de47e2d13c38cb0a137">,
      #splice.entry<"/build/lua-5.2.4/doc/manual.html" file 644 mtime 1424741085 "ca14a5d410f4485abb559d8ee30d05fed2c4f50739e56bc6ef21b084327dcee5">,
      #splice.entry<"/build/lua-5.2.4/doc/osi-certified-72x60.png" file 644 mtime 1163705966 "9d6ed62bd2f453c986f1aa1ed9e8920572cc746b944320a9aa0993cea6f55248">,
      #splice.entry<"/build/lua-5.2.4/doc/readme.html" file 644 mtime 1424741109 "a686d9158c8878ee4c6e1c90d719949c2b70031b74d6e945e6e218a063ebcb20">,
      #splice.entry<"/build/lua-5.2.4/src" dir 755 mtime 1424741481>,
      #splice.entry<"/build/lua-5.2.4/src/Makefile" file 644 mtime 1384170349 "440ff273dbf75a7212d5e60c00fa15839482d6f1f2b608ef187e3d1a38f22e2c">,
      #splice.entry<"/build/lua-5.2.4/src/lapi.c" file 644 mtime 1365792527 "0d3e39133f9589fa5481e02023de3282827706c885cd94f1df5d322594218505">,
      #splice.entry<"/build/lua-5.2.4/src/lapi.h" file 644 mtime 1365792527 "bc4b6d44a799257ad640bb220607b3a3c986f807ac8ea75d71632db7e8a3ef36">,
      #splice.entry<"/build/lua-5.2.4/src/lauxlib.c" file 644 mtime 1365792527 "2a6a7a1bb55e4a2021492cb51ba6966a3e32d1eea87c274a1d0734d0a4ed4133">,
      #splice.entry<"/build/lua-5.2.4/src/lauxlib.h" file 644 mtime 1365792527 "6c82fcd9d264a6a028b5fe308007c66bfe2443f6680bb4d6b94203ba296b9922">,
      #splice.entry<"/build/lua-5.2.4/src/lbaselib.c" file 644 mtime 1365792527 "99648b9cf49e601ab8002c640763a50afae151335b2b453c1b1a8cb37ac216c0">,
      #splice.entry<"/build/lua-5.2.4/src/lbitlib.c" file 644 mtime 1373392901 "5f8809a690a6da8fff5bc662262e98a4f7b0431f4b91f4c58d5bafde2cee6ced">,
      #splice.entry<"/build/lua-5.2.4/src/lcode.c" file 644 mtime 1365792527 "0b59a5ef6ad666df1e2833ac201d05418456fcce943ae3b49aa19464ceb4f79d">,
      #splice.entry<"/build/lua-5.2.4/src/lcode.h" file 644 mtime 1365792527 "85698d9239819880dea12bd856ad29c976438afaffe37e5aeda8907d6b60389b">,
      #splice.entry<"/build/lua-5.2.4/src/lcorolib.c" file 644 mtime 1365792527 "d391ce54268a17c2b959c4080e560e350b2c970ce81a5f063f1e42e2368b7098">,
      #splice.entry<"/build/lua-5.2.4/src/lctype.c" file 644 mtime 1365792527 "997f372a3f524d34524e57694d203f820d4b0a6ef2ba84bae556e4eb6d410706">,
      #splice.entry<"/build/lua-5.2.4/src/lctype.h" file 644 mtime 1365792527 "8af05e71837aa8ad8539c4ebd0e17f8a46e02e7b01e7ff1b5c13bf569f64805b">,
      #splice.entry<"/build/lua-5.2.4/src/ldblib.c" file 644 mtime 1424366215 "b03120fc9aa12f48d8d58ba66df9ac7ddfa444c4eaf34053beba8958babf7274">,
      #splice.entry<"/build/lua-5.2.4/src/ldebug.c" file 644 mtime 1424365513 "d1d04b777ed10c7705a8326c9483c8e7f42f5762b22a7c864e2d1b4c47a18ee9">,
      #splice.entry<"/build/lua-5.2.4/src/ldebug.h" file 644 mtime 1365792527 "1b57646b9e4eab27d1e89083b5b53966512304820a19d225d8430b3d51f734b3">,
      #splice.entry<"/build/lua-5.2.4/src/ldo.c" file 644 mtime 1383934970 "be540843fc0a62a7051cb334a4c893ad12773b1e1b2d6554846bca07d74af89d">,
      #splice.entry<"/build/lua-5.2.4/src/ldo.h" file 644 mtime 1365792527 "6b106aa8099f18e125f1481771f90c899d950bf54387aca0a5fc573a77afe7eb">,
      #splice.entry<"/build/lua-5.2.4/src/ldump.c" file 644 mtime 1365792527 "025ba49b676819079582cb59ff8ef36093d80002eb24702ef4eeb6c6fea1e8eb">,
      #splice.entry<"/build/lua-5.2.4/src/lfunc.c" file 644 mtime 1365792527 "1c07865498826785953d08fa97889f913bb11b77a3078e2d49226607b61dc526">,
      #splice.entry<"/build/lua-5.2.4/src/lfunc.h" file 644 mtime 1365792527 "31d8f6a1731edcf6513b13a37061e9b8a09efc37d0493c5fa6cca7f05450480e">,
      #splice.entry<"/build/lua-5.2.4/src/lgc.c" file 644 mtime 1409590508 "d11cafe3bb183dd5a69b3608d97ae7447be66a798c1efdb9e66b520535cfa1a2">,
      #splice.entry<"/build/lua-5.2.4/src/lgc.h" file 644 mtime 1365792527 "a13574f1e9f816ea09d425d33ec8082c41a8febe7f53c76255c81ff22a67cb96">,
      #splice.entry<"/build/lua-5.2.4/src/linit.c" file 644 mtime 1365792527 "2576eb77c85f996f6ffcaa1db11b549be8370cc632e2db87bd2a895c59f0840f">,
      #splice.entry<"/build/lua-5.2.4/src/liolib.c" file 644 mtime 1365792527 "e3cba668db638f0a95c70417e6fdead54106c45cb414490b063ee194eaff543b">,
      #splice.entry<"/build/lua-5.2.4/src/llex.c" file 644 mtime 1423504594 "33dc332cd5ad98e037b28e6448b9005e1f6511567865f0c607ae846fdb64124d">,
      #splice.entry<"/build/lua-5.2.4/src/llex.h" file 644 mtime 1365792527 "813a0bb0e530eff7816130c79433b2baefddc2508d851fde335c371b10fe3d22">,
      #splice.entry<"/build/lua-5.2.4/src/llimits.h" file 644 mtime 1365792527 "7e12687d1c9534b4325907cff9fb63a1d9831ab5e4fb79f9395b5bfb1a54991f">,
      #splice.entry<"/build/lua-5.2.4/src/lmathlib.c" file 644 mtime 1365792527 "f0fc98eb043b701813c79048e50da6527cc994aa827ab3cc72095b9bc88bcde6">,
      #splice.entry<"/build/lua-5.2.4/src/lmem.c" file 644 mtime 1365792527 "8dcaee2b4206d7b6c62f493c9ea06dbe2d6e0f4274d18d81357588d60274bc4b">,
      #splice.entry<"/build/lua-5.2.4/src/lmem.h" file 644 mtime 1365792527 "de1acb69555c0e57a6f0195d7ecd68752fd92c602a558e656c26121186391fa9">,
      #splice.entry<"/build/lua-5.2.4/src/loadlib.c" file 644 mtime 1365792527 "354ea52cc59313d68684f6bc070be9fed2cce23d40c83ecf75934371bcdc8811">,
      #splice.entry<"/build/lua-5.2.4/src/lobject.c" file 644 mtime 1365792527 "afa1f407b9c30620de9dad809998f21f2fe9826dc370cc99127e824181ce564f">,
      #splice.entry<"/build/lua-5.2.4/src/lobject.h" file 644 mtime 1399472098 "69e4a240d6f95511de1815462f5696260973ad74c1da6a9246c39fde5cd363f6">,
      #splice.entry<"/build/lua-5.2.4/src/lopcodes.c" file 644 mtime 1365792527 "0f0456408a3513ea7f1a4f865f38166921ed41a56b311ff807f054c91b96d1f0">,
      #splice.entry<"/build/lua-5.2.4/src/lopcodes.h" file 644 mtime 1413829929 "9af5efd2b0d23119199f53d3d36c238e40f9384c627bbe014811d4e222635d22">,
      #splice.entry<"/build/lua-5.2.4/src/loslib.c" file 644 mtime 1365792527 "d6e0ad34f103f6235ff27871e3dc0530df2e8592dbdcaeab3648d550b292bf6e">,
      #splice.entry<"/build/lua-5.2.4/src/lparser.c" file 644 mtime 1365792527 "26f1cf92c39620afc4b5a6b17864bde0e4fe607fd19be0d2af260a214c979e8d">,
      #splice.entry<"/build/lua-5.2.4/src/lparser.h" file 644 mtime 1365792527 "513ff1818fc101f4e4ab04d2cbc4527fd83096f5908f894c4025fd1c32c6f3e0">,
      #splice.entry<"/build/lua-5.2.4/src/lstate.c" file 644 mtime 1383932731 "9bf9f6504b824a4f4060314b041e13db45dd17f0b4a7f3114d159c403d55708c">,
      #splice.entry<"/build/lua-5.2.4/src/lstate.h" file 644 mtime 1365792527 "7bd5600ac8fa3ab82c5634b19bd961af9aa2a3b6c35ad9bbcda4e37f7e832a0e">,
      #splice.entry<"/build/lua-5.2.4/src/lstring.c" file 644 mtime 1365792527 "c0569349fb9ade9ba14fbda557b38052b2d6348dd1658f6da8aed1c5da973155">,
      #splice.entry<"/build/lua-5.2.4/src/lstring.h" file 644 mtime 1365792527 "a2b1c08e6680c0f3c5245081fcf756f70f6204481e5c9b665f9930ede50f7751">,
      #splice.entry<"/build/lua-5.2.4/src/lstrlib.c" file 644 mtime 1365792527 "219607b495ad420a2beb59d21f8b5e381a75cdb8e9e6e8a021ad60cd853c4ce1">,
      #splice.entry<"/build/lua-5.2.4/src/ltable.c" file 644 mtime 1365792527 "bcb5187916ef09c79fea6277198e81cd424995b2acb43df038fcb7859dd9ca3b">,
      #splice.entry<"/build/lua-5.2.4/src/ltable.h" file 644 mtime 1377877781 "94acdca581cf0f8faf64bb8bc5fee833cdf2359f6891eb7a03925919443ae390">,
      #splice.entry<"/build/lua-5.2.4/src/ltablib.c" file 644 mtime 1399480375 "3a6b7b2549878dd5e0741666a9d4e1d53752d2aa7ac77bfbed8cf3ecc934d43d">,
      #splice.entry<"/build/lua-5.2.4/src/ltm.c" file 644 mtime 1365792527 "98c801c1bd7616520d5b818fa88bdcfd4f0bdfbbb44b00fe7812d75c76f01053">,
      #splice.entry<"/build/lua-5.2.4/src/ltm.h" file 644 mtime 1365792527 "885e878c08709a6296d5fe703e7342dfbab1f616c3c45a918be4fab0a200252f">,
      #splice.entry<"/build/lua-5.2.4/src/lua.c" file 644 mtime 1365792527 "338a75e02b099a3dd6a1aedd70de6ca33bf71faf531cf73775d2cdd6e7b50a55">,
      #splice.entry<"/build/lua-5.2.4/src/lua.h" file 644 mtime 1424527490 "aaa571c445bdafe72c7e116bda8f2a415e8dcb05d988e4072e6dc15029c32fae">,
      #splice.entry<"/build/lua-5.2.4/src/lua.hpp" file 644 mtime 1103763184 "fd83f7e823cfbb03ac2da937ec83f01b4a6ddaac220a4fa1ffd6c6c3842c5890">,
      #splice.entry<"/build/lua-5.2.4/src/luac.c" file 644 mtime 1372899826 "2d7004c66f0847ec58804767161e31e2064cc0fc3cd39818bf234af4cfc4b033">,
      #splice.entry<"/build/lua-5.2.4/src/luaconf.h" file 644 mtime 1385054776 "249e50b06561883a077a4d3ad121754099606ab94a6ae086a058e6192530fe72">,
      #splice.entry<"/build/lua-5.2.4/src/lualib.h" file 644 mtime 1365792527 "471f53456ba85f9c5ff9ab7b3236e5bd5169579455c74794e9d7addf3a3c3534">,
      #splice.entry<"/build/lua-5.2.4/src/lundump.c" file 644 mtime 1365792527 "c9143f5ad8bd2433d1a6f077f809407a2f8b9cb703d5baa9597c6b83ba609df8">,
      #splice.entry<"/build/lua-5.2.4/src/lundump.h" file 644 mtime 1365792527 "a4b5d9b06f297eb9b2fe0d8516e87dd168a6214959accbeda6b782fb0f6abdce">,
      #splice.entry<"/build/lua-5.2.4/src/lvm.c" file 644 mtime 1365792527 "2795e35874bef9d292e669f7b252739ff2007484ce8d57ee3ba2df436e109dd9">,
      #splice.entry<"/build/lua-5.2.4/src/lvm.h" file 644 mtime 1365792527 "b5b759c88780bc150d4438897b177a09b9a633b8eb3511102ca24d27661073aa">,
      #splice.entry<"/build/lua-5.2.4/src/lzio.c" file 644 mtime 1365792527 "655c93deabdf42d6755cd9658d9e09f94a43dc3486d233d102504e5c2d512d1e">,
      #splice.entry<"/build/lua-5.2.4/src/lzio.h" file 644 mtime 1365792527 "85d50d679dd16497b8c4df760f89c60347483e7fc0b102dbe259b61d7bf841ea">
  ]
  %2 = splice.exec "cat|patch" at 1969(%0#0, %1#0, %1#13, %1#50) -> [
      #splice.entry<"/build/lua-5.2.4/src/lparser.c" file 644 mtime 1794960000 "4cb6f9bb076b750ac8b8b4ec79d01809015b9baef3b8cd19ccac217f264ede0b">
  ]
  %3 = splice.exec "sed" at 2017(%0#0, %1#0, %1#13, %1#66) -> [
      #splice.entry<"/build/lua-5.2.4/src/luaconf.h" file 644 mtime 1794960000 "bb401944163eb62091f84a94ada09be5eb04b0aef47325ea47231e649f535ac6">
  ]
  %4 = splice.exec "bash" at 2538(%0#0, %1#0, %1#13, %1#15, %1#16, %1#28, %1#30, %1#33, %1#35, %1#40, %1#43, %1#46, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#69, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lapi.o" file 644 mtime 1794960000 "c5c7cde6a789f443ad3f38d13faf9579d27b144dfb7f7548f5dc672a04088ed2">
  ]
  %5 = splice.exec "bash" at 2666(%0#0, %1#0, %1#13, %1#21, %1#22, %1#28, %1#30, %1#35, %1#39, %1#40, %1#43, %1#46, %1#48, %1#51, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lcode.o" file 644 mtime 1794960000 "6da69b0e1bc7e7545068a69e6fe71462f8b597f55b604d592331f9b61b45c757">
  ]
  %6 = splice.exec "bash" at 2793(%0#0, %1#0, %1#13, %1#24, %1#25, %1#40, %1#63, %3) -> [
      #splice.entry<"/build/lua-5.2.4/src/lctype.o" file 644 mtime 1794960000 "a29fb85801336ea78d5704784d09d7a66325248a20406e7d0ab535d551ffaa5f">
  ]
  %7 = splice.exec "bash" at 2911(%0#0, %1#0, %1#13, %1#16, %1#22, %1#27, %1#28, %1#30, %1#33, %1#35, %1#39, %1#40, %1#43, %1#46, %1#48, %1#51, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldebug.o" file 644 mtime 1794960000 "f52e2de17310990d097713cc5aecfb9c5536e91c62d03430b318e2863df056c8">
  ]
  %8 = splice.exec "bash" at 3025(%0#0, %1#0, %1#13, %1#16, %1#28, %1#29, %1#30, %1#33, %1#35, %1#40, %1#43, %1#46, %1#48, %1#51, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#69, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldo.o" file 644 mtime 1794960000 "f40ae73ad95cc964bfddc4d102b19e22b655b84a78def9e6bb32886802f32211">
  ]
  %9 = splice.exec "bash" at 3147(%0#0, %1#0, %1#13, %1#31, %1#40, %1#43, %1#46, %1#53, %1#61, %1#63, %3, %1#69, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldump.o" file 644 mtime 1794960000 "4e6b5e3e19b396c10be3fdcbe478e6ae1a41daf882032d5d964753f447d591c3">
  ]
  %10 = splice.exec "bash" at 3265(%0#0, %1#0, %1#13, %1#32, %1#33, %1#35, %1#40, %1#43, %1#46, %1#53, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lfunc.o" file 644 mtime 1794960001 "d9b9e40bba32a2b9d474a7bf6860b25528565254e724d84e9474eaeb5e242dc0">
  ]
  %11 = splice.exec "bash" at 3398(%0#0, %1#0, %1#13, %1#28, %1#30, %1#33, %1#34, %1#35, %1#40, %1#43, %1#46, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lgc.o" file 644 mtime 1794960001 "47c7d556721fc067278f0eac2b2bf0a4445a632faa6c57b54a5d8b855fc0d8d8">
  ]
  %12 = splice.exec "bash" at 3512(%0#0, %1#0, %1#13, %1#25, %1#30, %1#35, %1#38, %1#39, %1#40, %1#43, %1#46, %1#51, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/llex.o" file 644 mtime 1794960001 "85e4ed29fed5f6906a97194477f5a0b025c64277b900aed101131a05af883ab5">
  ]
  %13 = splice.exec "bash" at 3640(%0#0, %1#0, %1#13, %1#28, %1#30, %1#35, %1#40, %1#42, %1#43, %1#46, %1#53, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lmem.o" file 644 mtime 1794960001 "d2cddd585feafc284211efc470ba85acfa145c521160c725713b042923950e56">
  ]
  %14 = splice.exec "bash" at 3768(%0#0, %1#0, %1#13, %1#25, %1#28, %1#30, %1#35, %1#40, %1#43, %1#45, %1#46, %1#53, %1#55, %1#61, %1#63, %3, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lobject.o" file 644 mtime 1794960001 "fa2655e4ce5bb4d57964f2ef05cc96ba2a8f997d92857b47e9e6095ef980cbb2">
  ]
  %15 = splice.exec "bash" at 3883(%0#0, %1#0, %1#13, %1#40, %1#47, %1#48, %1#63, %3) -> [
      #splice.entry<"/build/lua-5.2.4/src/lopcodes.o" file 644 mtime 1794960001 "51bf384143be4957d3f28e557a9c982a5886447ee04f64fbc30de2556c8a559d">
  ]
  %16 = splice.exec "bash" at 4001(%0#0, %1#0, %1#13, %1#22, %1#28, %1#30, %1#33, %1#35, %1#39, %1#40, %1#43, %1#46, %1#48, %2, %1#51, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lparser.o" file 644 mtime 1794960001 "9f21868cf8895c985a4c28a4d2b5e44835001c3b0b66d3805b76ce956f0b8384">
  ]
  %17 = splice.exec "bash" at 4126(%0#0, %1#0, %1#13, %1#16, %1#28, %1#30, %1#33, %1#35, %1#39, %1#40, %1#43, %1#46, %1#52, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lstate.o" file 644 mtime 1794960002 "4957aeaca07784a4f41e2734203602e7d4dd6869fd87bb18b6991052bf01f2d7">
  ]
  %18 = splice.exec "bash" at 4239(%0#0, %1#0, %1#13, %1#35, %1#40, %1#43, %1#46, %1#53, %1#54, %1#55, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lstring.o" file 644 mtime 1794960002 "a968f5fa36416fe8a4ba5ab6c4f340e3490b7ef3b9e3960a731ae23e623e252e">
  ]
  %19 = splice.exec "bash" at 4368(%0#0, %1#0, %1#13, %1#28, %1#30, %1#35, %1#40, %1#43, %1#46, %1#53, %1#55, %1#57, %1#58, %1#61, %1#63, %3, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ltable.o" file 644 mtime 1794960002 "72a972fe99f3012bbc47f501c2a17a65ac628e4eb68fddac8397bf2e5782b358">
  ]
  %20 = splice.exec "bash" at 4493(%0#0, %1#0, %1#13, %1#35, %1#40, %1#43, %1#46, %1#53, %1#55, %1#58, %1#60, %1#61, %1#63, %3, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/ltm.o" file 644 mtime 1794960002 "bb84205750eefacaece3a51a7b2baaa85a81a3ff5a3ebf73cb5161e5b8da0fbd">
  ]
  %21 = splice.exec "bash" at 4602(%0#0, %1#0, %1#13, %1#28, %1#30, %1#33, %1#35, %1#40, %1#43, %1#46, %1#53, %1#55, %1#61, %1#63, %3, %1#68, %1#69, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lundump.o" file 644 mtime 1794960002 "f0a1b975b2e88b012d2b7f2d7f0c4d86ba9f140b7ec5d51515376919bf96426c">
  ]
  %22 = splice.exec "bash" at 4727(%0#0, %1#0, %1#13, %1#28, %1#30, %1#33, %1#35, %1#40, %1#43, %1#46, %1#48, %1#53, %1#55, %1#58, %1#61, %1#63, %3, %1#70, %1#71, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lvm.o" file 644 mtime 1794960002 "afe61ba9a57c5daf58c7c2dce99315038d0913667340f5a33e9b7d0567d0f14d">
  ]
  %23 = splice.exec "bash" at 4846(%0#0, %1#0, %1#13, %1#40, %1#43, %1#46, %1#53, %1#61, %1#63, %3, %1#72, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/lzio.o" file 644 mtime 1794960002 "8fb36a3984ac6ba2603d83276b5162a584bf531fbfbc8bbad52a9b3c77016808">
  ]
  %24 = splice.exec "bash" at 4963(%0#0, %1#0, %1#13, %1#17, %1#18, %1#63, %3) -> [
      #splice.entry<"/build/lua-5.2.4/src/lauxlib.o" file 644 mtime 1794960002 "209830029501d099f19cb62fb9dc2267b78b4de4171772e82a2e256e01dad8af">
  ]
  %25 = splice.exec "bash" at 5094(%0#0, %1#0, %1#13, %1#18, %1#19, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lbaselib.o" file 644 mtime 1794960003 "087031e08a8e9d441f4115555cefb5dfe400993bc89daeda26d947005a63b67c">
  ]
  %26 = splice.exec "bash" at 5216(%0#0, %1#0, %1#13, %1#18, %1#20, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lbitlib.o" file 644 mtime 1794960003 "27eb610e6fe68ea99140d714e471d1eefb945546eab6fab25ac068e0a83daaa6">
  ]
  %27 = splice.exec "bash" at 5334(%0#0, %1#0, %1#13, %1#18, %1#23, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lcorolib.o" file 644 mtime 1794960003 "e7c649eb66e8a2cf7773b1b8d4f90630a2ad63a97d6aeb2842bb139da99b14dd">
  ]
  %28 = splice.exec "bash" at 5457(%0#0, %1#0, %1#13, %1#18, %1#26, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/ldblib.o" file 644 mtime 1794960003 "61ae90cb80b61e9a82dcb76c4ec0a02d5d525726402327fd361c0e0511c204fe">
  ]
  %29 = splice.exec "bash" at 5582(%0#0, %1#0, %1#13, %1#18, %1#37, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/liolib.o" file 644 mtime 1794960003 "8d90124ce45772dba68fe431f468d26ac86b4969f638058cc2e75adb7cedcb3e">
  ]
  %30 = splice.exec "bash" at 5705(%0#0, %1#0, %1#13, %1#18, %1#41, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lmathlib.o" file 644 mtime 1794960003 "5a6c54ed28d9935edecd1e1444a47b4c17a8f817606499448eedfa01141e028c">
  ]
  %31 = splice.exec "bash" at 5828(%0#0, %1#0, %1#13, %1#18, %1#49, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/loslib.o" file 644 mtime 1794960003 "1fca5e07abc7065af41307470c927fc47ee4e0106aea738647e9576be08bc262">
  ]
  %32 = splice.exec "bash" at 5947(%0#0, %1#0, %1#13, %1#18, %1#56, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lstrlib.o" file 644 mtime 1794960003 "84198f777839dd7e51b98418bee8e3da1dbaf765cde967d2b67e600bbebc5792">
  ]
  %33 = splice.exec "bash" at 6079(%0#0, %1#0, %1#13, %1#18, %1#59, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/ltablib.o" file 644 mtime 1794960003 "3452909503e5522b0146ef782da3daf5d3681f5c6f99e71e3c0b271b5a853499">
  ]
  %34 = splice.exec "bash" at 6198(%0#0, %1#0, %1#13, %1#18, %1#44, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/loadlib.o" file 644 mtime 1794960004 "145c7f188e6874e93bca0bf25b3024fdff6293889a0d42006c8a9eaf23dec143">
  ]
  %35 = splice.exec "bash" at 6322(%0#0, %1#0, %1#13, %1#18, %1#36, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/linit.o" file 644 mtime 1794960004 "d26394fb5e71ffa18977e99c481a017137bc25762b06919400ffae68b0f93a87">
  ]
  %36 = splice.exec "bash" at 6438(%0#0, %1#0, %1#13, %4, %24, %25, %26, %5, %27, %6, %28, %7, %8, %9, %10, %11, %35, %29, %12, %30, %13, %34, %14, %15, %31, %16, %17, %18, %32, %19, %33, %20, %21, %22, %23) -> [
      #splice.entry<"/build/lua-5.2.4/src/liblua.so.5.2.4" file 755 mtime 1794960004 "000cdac07fe6c607a57f13794ed39489db4d25985cdc8132017cd2606a56bfcd">
  ]
  %37 = splice.exec "bash" at 6849(%0#0, %1#0, %1#13) -> [
      #splice.entry<"/build/lua-5.2.4/src/liblua.so.5.2" link 0 mtime 1794960004 "liblua.so.5.2.4">
  ]
  %38 = splice.exec "bash" at 6885(%0#0, %1#0, %1#13) -> [
      #splice.entry<"/build/lua-5.2.4/src/liblua.so" link 0 mtime 1794960004 "liblua.so.5.2.4">
  ]
  %39 = splice.exec "bash" at 6920(%0#0, %1#0, %1#13, %4, %24, %25, %26, %5, %27, %6, %28, %7, %8, %9, %10, %11, %35, %29, %12, %30, %13, %34, %14, %15, %31, %16, %17, %18, %32, %19, %33, %20, %21, %22, %23) -> [
      #splice.entry<"/build/lua-5.2.4/src/liblua.a" file 644 mtime 1794960004 "4e7031a5d591162a581f1da33e052c8437836215dc2e27fa7df7e85dd67abb21">
  ]
  %40 = splice.exec "bash" at 7005(%0#0, %1#0, %1#13, %1#18, %1#62, %1#63, %3, %1#67) -> [
      #splice.entry<"/build/lua-5.2.4/src/lua.o" file 644 mtime 1794960004 "5e9f5fea696d72fab7d0b81a684f02cac26d92f4fbb7b1807f25889bc3dc3bef">
  ]
  %41 = splice.exec "bash" at 7126(%0#0, %1#0, %1#13, %39, %40) -> [
      #splice.entry<"/build/lua-5.2.4/src/lua" file 755 mtime 1794960004 "d4639f2e4af1f0203b9dd9080af82f5675e915346e996e497ed78e1e391a73bb">
  ]
  %42 = splice.exec "bash" at 7537(%0#0, %1#0, %1#13, %1#18, %1#28, %1#40, %1#43, %1#46, %1#48, %1#53, %1#61, %1#63, %1#65, %3, %1#69, %1#73) -> [
      #splice.entry<"/build/lua-5.2.4/src/luac.o" file 644 mtime 1794960004 "e7552512880549297fee77494a64eb13fcacec92c3dee8ec8582b8ca9f1ef8cb">
  ]
  %43 = splice.exec "bash" at 7659(%0#0, %1#0, %1#13, %39, %42) -> [
      #splice.entry<"/build/lua-5.2.4/src/luac" file 755 mtime 1794960004 "e6e39a6c24e17a93eb83c2501039354c5f0683c97bfa610dfd4d698642e72ef7">
  ]
  %44 = splice.exec "mkdir" at 8157(%0#0, %1#0) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4" dir 755 mtime 1794960004>
  ]
  %45:10 = splice.exec "bash" at 8239(%0#0, %1#0, %1#13, %44) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/lua" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/lua/5.2" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/lua" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/lua/5.2" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1" dir 755 mtime 1794960004>
  ]
  %46:2 = splice.exec "bash" at 8275(%0#0, %1#0, %1#13, %41, %43, %44, %45#0) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/lua" file 755 mtime 1794960004 "d4639f2e4af1f0203b9dd9080af82f5675e915346e996e497ed78e1e391a73bb">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/luac" file 755 mtime 1794960004 "e6e39a6c24e17a93eb83c2501039354c5f0683c97bfa610dfd4d698642e72ef7">
  ]
  %47:5 = splice.exec "bash" at 8323(%0#0, %1#0, %1#13, %1#18, %1#63, %1#64, %3, %1#67, %44, %45#1) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lauxlib.h" file 644 mtime 1794960004 "6c82fcd9d264a6a028b5fe308007c66bfe2443f6680bb4d6b94203ba296b9922">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lua.h" file 644 mtime 1794960004 "aaa571c445bdafe72c7e116bda8f2a415e8dcb05d988e4072e6dc15029c32fae">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lua.hpp" file 644 mtime 1794960004 "fd83f7e823cfbb03ac2da937ec83f01b4a6ddaac220a4fa1ffd6c6c3842c5890">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/luaconf.h" file 644 mtime 1794960004 "bb401944163eb62091f84a94ada09be5eb04b0aef47325ea47231e649f535ac6">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/include/lualib.h" file 644 mtime 1794960004 "471f53456ba85f9c5ff9ab7b3236e5bd5169579455c74794e9d7addf3a3c3534">
  ]
  %48:4 = splice.exec "bash" at 8376(%0#0, %1#0, %1#13, %39, %38, %37, %36, %44, %45#2, %45#3) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.a" file 644 mtime 1794960004 "4e7031a5d591162a581f1da33e052c8437836215dc2e27fa7df7e85dd67abb21">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so" link 0 mtime 1794960004 "liblua.so.5.2.4">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2" link 0 mtime 1794960004 "liblua.so.5.2.4">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2.4" file 755 mtime 1794960004 "000cdac07fe6c607a57f13794ed39489db4d25985cdc8132017cd2606a56bfcd">
  ]
  %49:2 = splice.exec "bash" at 8422(%0#0, %1#0, %1#3, %1#6, %1#8, %44, %45#5, %45#8, %45#9) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/lua.1" file 644 mtime 1794960004 "a44ed64aaf16121f193ac0a83322e4b5cd78a6932056dc5de5cc032856d90786">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/luac.1" file 644 mtime 1794960004 "ac60e6992db478539dff611beed7ad01f52622c897657a9152165470039b0494">
  ]
  %50:4 = splice.exec "mkdir" at 8469(%0#0, %1#0, %44, %45#2, %45#5) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua" dir 755 mtime 1794960004>
  ]
  %51 = splice.exec "cp" at 8490(%0#0, %1#0, %44, %50#1) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support/utils.sh" file 444 mtime 1794960004 "49433a60f3778649a904d7fc9658a3ffc9ca0c232f95d546853e344866a7a1e4">
  ]
  %52:7 = splice.exec "mv" at 8515(%0#0, %1#0, %1#3, %1#4, %1#5, %1#7, %1#9, %1#10, %1#11, %1#12, %44, %45#5, %50#2, %50#3) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/contents.html" file 644 mtime 1424741076 "99ce749a42678b3c98755156b04c88f500347f99085749ab2e2f40aacc857fd0">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/logo.gif" file 644 mtime 1003840755 "9c3a3208ef05e12110f9b7b491cef676e650e4ebf3d36c4414268666bcc95d8a">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/lua.css" file 644 mtime 1424779941 "d3bb1d56bc03379397c7f607802d8530ccb599009a5321b26dfc9fdc43ddd8a7">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/manual.css" file 644 mtime 1384044308 "1a97ea6df44fb79a99160f88dd142aa80552583786d40de47e2d13c38cb0a137">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/manual.html" file 644 mtime 1424741085 "ca14a5d410f4485abb559d8ee30d05fed2c4f50739e56bc6ef21b084327dcee5">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/osi-certified-72x60.png" file 644 mtime 1163705966 "9d6ed62bd2f453c986f1aa1ed9e8920572cc746b944320a9aa0993cea6f55248">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua/readme.html" file 644 mtime 1424741109 "a686d9158c8878ee4c6e1c90d719949c2b70031b74d6e945e6e218a063ebcb20">
  ]
  %53 = splice.literal "glue" at 8614 -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc" file 644 mtime 1794960004 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %54 = splice.exec "cat" at 8614(%0#0, %1#0, %44, %45#2, %50#0, %53) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc" file 644 mtime 1794960004 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  ]
  %55 = splice.exec "ln" at 8638(%0#0, %1#0, %44, %45#2, %50#0) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua-5.2.pc" link 0 mtime 1794960004 "/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc">
  ]
  %56 = splice.exec "ln" at 8656(%0#0, %1#0, %44, %45#2, %50#0) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua5.2.pc" link 0 mtime 1794960004 "/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc">
  ]
  %57 = splice.exec "ln" at 8677(%0#0, %1#0, %44, %45#2, %50#0) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua52.pc" link 0 mtime 1794960004 "/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua.pc">
  ]
  %58:8 = splice.exec "mv" at 8698(%0#0, %1#0, %44, %45#5, %50#2, %50#3, %52#0, %52#1, %52#2, %52#3, %52#4, %52#5, %52#6) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/contents.html" file 644 mtime 1424741076 "99ce749a42678b3c98755156b04c88f500347f99085749ab2e2f40aacc857fd0">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/logo.gif" file 644 mtime 1003840755 "9c3a3208ef05e12110f9b7b491cef676e650e4ebf3d36c4414268666bcc95d8a">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/lua.css" file 644 mtime 1424779941 "d3bb1d56bc03379397c7f607802d8530ccb599009a5321b26dfc9fdc43ddd8a7">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/manual.css" file 644 mtime 1384044308 "1a97ea6df44fb79a99160f88dd142aa80552583786d40de47e2d13c38cb0a137">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/manual.html" file 644 mtime 1424741085 "ca14a5d410f4485abb559d8ee30d05fed2c4f50739e56bc6ef21b084327dcee5">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/osi-certified-72x60.png" file 644 mtime 1163705966 "9d6ed62bd2f453c986f1aa1ed9e8920572cc746b944320a9aa0993cea6f55248">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/doc/lua-5.2.4/readme.html" file 644 mtime 1424741109 "a686d9158c8878ee4c6e1c90d719949c2b70031b74d6e945e6e218a063ebcb20">
  ]
  %59 = splice.exec "chmod" at 8799(%0#0, %1#0, %44, %50#1, %51) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support/utils.sh" file 644 mtime 1794960004 "49433a60f3778649a904d7fc9658a3ffc9ca0c232f95d546853e344866a7a1e4">
  ]
  %60:2 = splice.exec "mkdir" at 8895(%0#0, %1#0) -> [
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share" dir 755 mtime 1794960004>
  ]
  %61:9 = splice.exec "mv" at 8916(%0#0, %1#0, %60#0, %60#1, %44, %45#5, %50#2, %58#0, %58#1, %58#2, %58#3, %58#4, %58#5, %58#6, %58#7) -> [
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4" dir 755 mtime 1794960004>,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/contents.html" file 644 mtime 1424741076 "99ce749a42678b3c98755156b04c88f500347f99085749ab2e2f40aacc857fd0">,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/logo.gif" file 644 mtime 1003840755 "9c3a3208ef05e12110f9b7b491cef676e650e4ebf3d36c4414268666bcc95d8a">,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/lua.css" file 644 mtime 1424779941 "d3bb1d56bc03379397c7f607802d8530ccb599009a5321b26dfc9fdc43ddd8a7">,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/manual.css" file 644 mtime 1384044308 "1a97ea6df44fb79a99160f88dd142aa80552583786d40de47e2d13c38cb0a137">,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/manual.html" file 644 mtime 1424741085 "ca14a5d410f4485abb559d8ee30d05fed2c4f50739e56bc6ef21b084327dcee5">,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/osi-certified-72x60.png" file 644 mtime 1163705966 "9d6ed62bd2f453c986f1aa1ed9e8920572cc746b944320a9aa0993cea6f55248">,
      #splice.entry<"/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc/share/doc/lua-5.2.4/readme.html" file 644 mtime 1424741109 "a686d9158c8878ee4c6e1c90d719949c2b70031b74d6e945e6e218a063ebcb20">
  ]
  %62 = splice.exec "sed" at 9088(%0#0, %1#0, %44, %45#2, %50#0, %55, %54) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua-5.2.pc" file 644 mtime 1794960004 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  ]
  %63 = splice.exec "sed" at 9142(%0#0, %1#0, %44, %45#2, %50#0, %54, %56) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua5.2.pc" file 644 mtime 1794960004 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  ]
  %64 = splice.exec "sed" at 9171(%0#0, %1#0, %44, %45#2, %50#0, %54, %57) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/pkgconfig/lua52.pc" file 644 mtime 1794960004 "31181ecf825654efa89997b82322f8b8b6a9723b8a86ad40b14c55a0a3ee3c05">
  ]
  %65:3 = splice.exec "find|patchelf|patchelf|patchelf" at 9466(%0#0, %1#0, %44, %45#0, %46#0, %46#1, %45#2, %48#3) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/lua" file 755 mtime 1794960004 "9b5095c0de855417438e61ffb96525bea7279195ced62cbc16c754944c5959d7">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/luac" file 755 mtime 1794960004 "d5a95a0487ade4af77549966494fa19644220070a9aa4c8e1a35d682992d20f3">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2.4" file 755 mtime 1794960004 "18bb499494f707d0a327fc792abce7010a4051ae889d625718282be07b8aa2a2">
  ]
  %66:2 = splice.exec "find|xargs" at 9955(%0#0, %1#0, %44, %45#5, %45#8, %45#9, %49#0, %49#1) -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/lua.1.gz" file 644 mtime 1794960004 "80a8d8b22fb75f9adad3d786faad8f8ad42bc02db02a2a716c082e653cc8f074">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/share/man/man1/luac.1.gz" file 644 mtime 1794960004 "59983673b10e7dd1d5a5a0c5b1a58074e00aa073f5828d8fb7f4e0baa5701fc2">
  ]
  %67 = splice.literal "mktemp" at 10143 demoted -> [
      #splice.entry<"/build/striperr.SYBGlO" file 600 mtime 1794960004 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %68:5 = splice.exec "find|sort|cut|xargs" at 10174(%0#0, %1#0, %67, %44, %45#0, %65#0, %65#1, %45#2, %48#0, %65#2, %50#0, %62, %54, %63, %64) -> [
      #splice.entry<"/build/striperr.SYBGlO" file 600 mtime 1794960004 "e50578ed5af4f525a54ce68f1021836f89dfd81bb20f06c9c2beb7d660982d3c">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/lua" file 755 mtime 1794960004 "e85bc886d36d21379a3d6dbf032a52ea6b2ba7c3fbf124ab252bbae9b426bcbc">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/bin/luac" file 755 mtime 1794960004 "5bdb9384b132ca31cee911150adf04f653d181954b0ee3f0738aa506226b2f12">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.a" file 644 mtime 1794960004 "6cbf8d2772191887a38ad2365fe72a2604ee9f96428962cdd83c12080293237e">,
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/lib/liblua.so.5.2.4" file 755 mtime 1794960004 "16af0fb60f0228e8b0588efcb72536a7a8af710b5dd6b6d5efbe531c306591c4">
  ]
  %69 = splice.literal "glue" at 10865 -> [
      #splice.entry<"/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4/nix-support/setup-hook" file 644 mtime 1794960004 "1107b8ed77fca0fb383cc533b5e0d7dfefb327c1da01941c60c0486f1516cee8">
  ]
  splice.output "doc" "/nix/store/4p7a27j5w4xicg024qwr9ynlcdbnrpag-lua-5.2.4-doc"(%60#0, %60#1, %61#0, %61#1, %61#2, %61#3, %61#4, %61#5, %61#6, %61#7, %61#8)
  splice.output "out" "/nix/store/ngrfxya6bawfbkyd0mi4wz4x54ykwx3z-lua-5.2.4"(%44, %45#0, %68#1, %68#2, %45#1, %47#0, %47#1, %47#2, %47#3, %47#4, %45#2, %68#3, %48#1, %48#2, %68#4, %50#0, %62, %54, %63, %64, %50#1, %69, %59, %45#5, %45#8, %45#9, %66#0, %66#1)
}

