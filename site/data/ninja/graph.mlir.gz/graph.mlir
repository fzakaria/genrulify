module {
  %sandbox_720:3 = splice.literal "sandbox" at 720 -> [
      #splice.entry<"/build" dir 700 mtime 1794960000>,
      #splice.entry<"/build/.attrs.json" file 644 mtime 1794960000 "0281420f4d4bd5b268a5b0cfcfaa17aa0f38951c18b30cdf3e3ff8e89fac2001">,
      #splice.entry<"/build/.attrs.sh" file 644 mtime 1794960000 "98ca7ec2d5e423105ae805c4c207065d79f3b7160432508c97fa4420e2115922">
  ]
  %cp_2232:199 = splice.exec "cp" at 2232(%sandbox_720#0) -> [
      #splice.entry<"/build/source" dir 555 mtime 1>,
      #splice.entry<"/build/source/.clang-format" file 444 mtime 1 "7b7f50552a3f95d31694c9d77ed2070bb8f07931d29c5c6ab64862c05b8bedee">,
      #splice.entry<"/build/source/.clang-tidy" file 444 mtime 1 "0b7fb3eaec9b6fd2febcb7f03e61bfa8dd3a7e2d053425c48576cb4a503322e6">,
      #splice.entry<"/build/source/.editorconfig" file 444 mtime 1 "4b3fdc0a26286e8e6d5e2c3e8036d02e000cc30887e09728ad22c45ed1b2e6c8">,
      #splice.entry<"/build/source/.github" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/dependabot.yml" file 444 mtime 1 "35d83d89e663e3dc35d880f09399ec4b38969c1faedd8da9f65fc0d605ab9c79">,
      #splice.entry<"/build/source/.github/workflows" dir 555 mtime 1>,
      #splice.entry<"/build/source/.github/workflows/linux-musl.yml" file 444 mtime 1 "7b1d755c0c8850211c6889ef6228f23bdb14032dd3072df3506f86aba65bc98a">,
      #splice.entry<"/build/source/.github/workflows/linux.yml" file 444 mtime 1 "e135fc460e0eb468be5d9fc31902fa494e47f09b6c3d5c5ebb1b54e26bc65ce2">,
      #splice.entry<"/build/source/.github/workflows/macos.yml" file 444 mtime 1 "4b628ca36eb3af058415c71f2901174569661cdaafa14d41e45d00b241392855">,
      #splice.entry<"/build/source/.github/workflows/windows.yml" file 444 mtime 1 "9583f657518581ece942153095be77ef52fb67d394974591579bab938f8b444b">,
      #splice.entry<"/build/source/.gitignore" file 444 mtime 1 "4bfcc8bfc40cc5b27efa88896711130b6e781e14a622aa9f09d14afc5caf5253">,
      #splice.entry<"/build/source/CMakeLists.txt" file 444 mtime 1 "4cb1d04827f6f1e24e99e746aeef6a3bf0dbea79f73a5894cd6c30644c135332">,
      #splice.entry<"/build/source/CONTRIBUTING.md" file 444 mtime 1 "f588ccbb140590580d593d43c55760a94ff911bd03761d2840082b1d0ee76e7c">,
      #splice.entry<"/build/source/COPYING" file 444 mtime 1 "eb7e9ab9690124c5c9f42bdc81383d886a3dede26345b6ed15bbad7caf81f7ea">,
      #splice.entry<"/build/source/README.md" file 444 mtime 1 "b31e9700c752fa214773c1b799d90efcbf3330c8062da9f45c6064e023b347b0">,
      #splice.entry<"/build/source/RELEASING.md" file 444 mtime 1 "0c94d70ced5f00d7cf431d5e00d180c14fb2802bd5fa379d3d5509c720ad4d4f">,
      #splice.entry<"/build/source/appveyor.yml" file 444 mtime 1 "61d88a9eea1867b191765f649f991256a00afcccb84758c3aa48e17d5479f08b">,
      #splice.entry<"/build/source/configure.py" file 555 mtime 1 "6fc95ecba127c4151e42a896368b035215544da8971022ebfdf70b07004472b1">,
      #splice.entry<"/build/source/doc" dir 555 mtime 1>,
      #splice.entry<"/build/source/doc/README.md" file 444 mtime 1 "12a964babb1e07861359ea0ad3cc0cb931eca74ad6914be29272b260a893fe92">,
      #splice.entry<"/build/source/doc/dblatex.xsl" file 444 mtime 1 "1bcfde99e8bd82949b9d7fd9b8af9aae8045a735389dcb49aebe1fc2dd1b6085">,
      #splice.entry<"/build/source/doc/docbook.xsl" file 444 mtime 1 "c1081af70cbc7ac7778540b6773e95afe7b474a5b614f397590bd129c7c0ce3f">,
      #splice.entry<"/build/source/doc/doxygen.config" file 444 mtime 1 "23400d161d5b85155fb035aa9ea240a20fa64f300c861f28014be030cf01815f">,
      #splice.entry<"/build/source/doc/manual.asciidoc" file 444 mtime 1 "0b7148678b1a4c7751acbb443d5cfec41ceacf3a7b2a0ad2d511407fbe056226">,
      #splice.entry<"/build/source/doc/style.css" file 444 mtime 1 "a39322df8ce8a7e02b7d8d4076489aaf8d98bb0e5ac4322692d7f76aecfe5f59">,
      #splice.entry<"/build/source/misc" dir 555 mtime 1>,
      #splice.entry<"/build/source/misc/afl-fuzz" dir 555 mtime 1>,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens" dir 555 mtime 1>,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/kw_build" file 444 mtime 1 "44575cf5b28512d75644bf54a517dcef304ff809fd511747621b4d64f19aac66">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/kw_default" file 444 mtime 1 "37a8eec1ce19687d132fe29051dca629d164e2c4958ba141d5f4133a33f0688f">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/kw_include" file 444 mtime 1 "c0cbff04cc90f5b4cd53a53533285f7d741f24a5279f746b8370ad0f2c982f3e">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/kw_pool" file 444 mtime 1 "27cac5503836765cd10751d27ab4a6e17d7a80d4c948430a5a81513973f9b51e">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/kw_rule" file 444 mtime 1 "7369949b47ef2c6ba26fbbee659cedc76123a75c17d321a52d8d1ef35e948042">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/kw_subninja" file 444 mtime 1 "5d24281d0bfa33d8cc98f75217e914ccb426a6beceab5df659721866a7e1b581">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_a" file 444 mtime 1 "ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_b" file 444 mtime 1 "3e23e8160039594a33894f6564e1b1348bbd7a0088d42c4acb73eeaed59c009d">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_colon" file 444 mtime 1 "e7ac0786668e0ff0f02b62bd04f45ff636fd82db63b1104601c975dc005f3a67">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_cont" file 444 mtime 1 "4c6afee9df8587377332e57628a67e6c138f3c271d20b08d2d1423e59a0c06df">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_dollar" file 444 mtime 1 "09fc96082d34c2dfc1295d92073b5ea1dc8ef8da95f14dfded011ffb96d3e54b">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_eq" file 444 mtime 1 "380918b946a526640a40df5dced6516794f3d97bbd9e6bb553d037c4439f31c3">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_indent" file 444 mtime 1 "6c179f21e6f62b629055d8ab40f454ed02e48b68563913473b857d3638e23b28">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_pipe" file 444 mtime 1 "cbe5cfdf7c2118a9c3d78ef1d684f3afa089201352886449a06a6511cfef74a7">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_pipepipe" file 444 mtime 1 "565d240f5343e625ae579a4d45a770f1f02c6368b5ed4d06da4fbe6f47c28866">,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens/misc_space" file 444 mtime 1 "36a9e7f1c95b82ffb99743e0c5c4ce95d83c9a430aac59f84ef3cbfab6145068">,
      #splice.entry<"/build/source/misc/afl-fuzz/build.ninja" file 444 mtime 1 "759f0500e7796c1eb55be01807ca6d4255caf46d74e2cde5f3ec757c51b20fdb">,
      #splice.entry<"/build/source/misc/bash-completion" file 444 mtime 1 "536a81b4d5fac9dd74e4842c59f2b5ab0cce27882e3638fd7219d1ad78fa149d">,
      #splice.entry<"/build/source/misc/ci.py" file 555 mtime 1 "adc278f963cda6e77754e0525b31e310f32dd7132d07e337bad61750145dd824">,
      #splice.entry<"/build/source/misc/inherited-fds.ninja" file 444 mtime 1 "49dbd1856ad0ae2dc46283256da58b4d79459605d2c925e341559bf59bb90fa1">,
      #splice.entry<"/build/source/misc/jobserver_pool.py" file 555 mtime 1 "5a3ae98df00c522914db0299773c3999338d9e6b4e963339a1c09cbfd5a11237">,
      #splice.entry<"/build/source/misc/jobserver_pool_test.py" file 555 mtime 1 "b7ed2c3d6cafbfe105daa7cf087c28639122d2eea0060d55c3b4f04745e3ac65">,
      #splice.entry<"/build/source/misc/jobserver_test.py" file 555 mtime 1 "37b2082d404053e0d1f4810c565cb2aa29ba66bd2628722e5d318e09204b55a5">,
      #splice.entry<"/build/source/misc/jobserver_test_helper.py" file 555 mtime 1 "d0d74b03fcfc1d7abe5d1ad2c938b741888a8bb904787a8b297907b1cf9802f1">,
      #splice.entry<"/build/source/misc/long-slow-build.ninja" file 444 mtime 1 "6687e1de9c5819a632ca71eb1755eddf20929a658cb7847ff393865c08da574b">,
      #splice.entry<"/build/source/misc/manifest_fuzzer.cc" file 444 mtime 1 "07ec328cadd1819bfe5c9feb0c1b47b93677ff26c6c3233886aa8d919bfdfcbf">,
      #splice.entry<"/build/source/misc/measure.py" file 555 mtime 1 "ef158684ddeacdec396d319775bdba7a848297f51465c48c3da638c72521b2ab">,
      #splice.entry<"/build/source/misc/ninja.vim" file 444 mtime 1 "b5fe687d3e73aa9a66683e1854214caba6d524ac2aa3591643a6e5dba9743823">,
      #splice.entry<"/build/source/misc/ninja_syntax.py" file 444 mtime 1 "4425d9e91a1d6b79709db86d430e88e9b25ca44f7c997519f63a1c9ef0b82106">,
      #splice.entry<"/build/source/misc/ninja_syntax_test.py" file 555 mtime 1 "d0bfd59e49fd1fe70a2ecf1e6bdaf76fb516304a3893b3401582b2731aa33cd0">,
      #splice.entry<"/build/source/misc/oss-fuzz" dir 555 mtime 1>,
      #splice.entry<"/build/source/misc/oss-fuzz/build.sh" file 444 mtime 1 "0347e51b7af9d10c9c12cbd04dc4d77f9d229d6d16976ec91f17b8a0829692d3">,
      #splice.entry<"/build/source/misc/oss-fuzz/sample_ninja_build" file 444 mtime 1 "218d3e1f379746131297b3cbc7fce307c183ab5e39d92b1d0caaebe3a7ef359e">,
      #splice.entry<"/build/source/misc/output_test.py" file 555 mtime 1 "c4d4acb6b70b0cb902d1285b8595cb3e02460e3fb49937f69c2830f279f3601e">,
      #splice.entry<"/build/source/misc/packaging" dir 555 mtime 1>,
      #splice.entry<"/build/source/misc/packaging/ninja.spec" file 444 mtime 1 "9f1ebc61a5e11e4c2fdcdeaf57c81a70aae3053476cccb7df09a62ddc2ca9abc">,
      #splice.entry<"/build/source/misc/packaging/rpmbuild.sh" file 555 mtime 1 "a93c42af665007e7f5c8774bdc2176d86e388be2857136143297004781dad105">,
      #splice.entry<"/build/source/misc/write_fake_manifests.py" file 555 mtime 1 "af0fa35bb80549d028963793941f1a50962377795734078664be801bb674b5fb">,
      #splice.entry<"/build/source/misc/zsh-completion" file 444 mtime 1 "a4b8b63ac381db23da0a5624ea3092d5c7e433dd608afdf07792aa586d79effa">,
      #splice.entry<"/build/source/src" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/browse.cc" file 444 mtime 1 "c626cb4e22350fffcda2723451e7ee85cb8705c90723ea0f7d214db12915dadd">,
      #splice.entry<"/build/source/src/browse.h" file 444 mtime 1 "af30ade6dde2ddc880e9ade506c08eb0225da20a84ec1d1030c552f56d08f573">,
      #splice.entry<"/build/source/src/browse.py" file 555 mtime 1 "8c5dc6696a1496f1e06e7cee04e717ceaf0d7e59cf067941176e2282d2a2e1b2">,
      #splice.entry<"/build/source/src/build.cc" file 444 mtime 1 "afd4ececbb6462ff55aa67414dca9963d069bed338e7855548e6527f427544ae">,
      #splice.entry<"/build/source/src/build.h" file 444 mtime 1 "6668e22969a2d8b601b5972361ed0385cc9bf4710d933158ee6c9cfc7d114902">,
      #splice.entry<"/build/source/src/build_log.cc" file 444 mtime 1 "378d1fd92e9b44a6ee8b34bc83c6220ea3d702b9a7d215307ed7c1874bb8e7c6">,
      #splice.entry<"/build/source/src/build_log.h" file 444 mtime 1 "f0675a0ca11126488395fea1d459bc9c50ec742684b0b89b424f2e27b4b3717a">,
      #splice.entry<"/build/source/src/build_log_perftest.cc" file 444 mtime 1 "640b3bbcddc0216cd8873cd10509fddf9fe18e339831d32655757f62d68e9430">,
      #splice.entry<"/build/source/src/build_log_test.cc" file 444 mtime 1 "a705e179c7e4f6fa54456f4e9b19a6fd3ede3feb489f04f74dc2e429e2f8027e">,
      #splice.entry<"/build/source/src/build_test.cc" file 444 mtime 1 "ddc12c4c251540745281c4ef1bfb1dad26f4ee4afef58551bbaae7c382f600cc">,
      #splice.entry<"/build/source/src/canon_perftest.cc" file 444 mtime 1 "eb350509bb6173818d22700bed689771db2f065cb4632422c8c705814e20b3a9">,
      #splice.entry<"/build/source/src/clean.cc" file 444 mtime 1 "b833b3275474655ce30e7d6e33a53f2a002f9c09e9ed11eafc5492354087d6ef">,
      #splice.entry<"/build/source/src/clean.h" file 444 mtime 1 "9e802c85af45cf548d31cac67cf6b8d1d67a8c1fabfb1c894b820d9a242521dd">,
      #splice.entry<"/build/source/src/clean_test.cc" file 444 mtime 1 "0cfe4a180bc763e1aaf2e67dd11346ebbc3fcadc800c94e1b242202fce19adc0">,
      #splice.entry<"/build/source/src/clparser.cc" file 444 mtime 1 "9d758a927372e28ec63b3921e30e6c2107220bcb53b601dd5f1af56a7d34c89a">,
      #splice.entry<"/build/source/src/clparser.h" file 444 mtime 1 "7fd40755a9437f63fda72b781e3a0326c5ba43cf3342ddc86af1806832d53ffa">,
      #splice.entry<"/build/source/src/clparser_perftest.cc" file 444 mtime 1 "49285c180b3d1b640c31ab9f870b76c66b35a0b616763e2f1e50953e9dabe9e8">,
      #splice.entry<"/build/source/src/clparser_test.cc" file 444 mtime 1 "a5011462b7ca189cb7656a6d80f24e5a1d5dfad2744be5642480ed6d07f09434">,
      #splice.entry<"/build/source/src/command_collector.h" file 444 mtime 1 "3647baefbbea22b4ccc32c026cad9257a58fe9ee25bd4ed026533829f457f08a">,
      #splice.entry<"/build/source/src/debug_flags.cc" file 444 mtime 1 "8fad28f2dd7993d30063dc6916620ac18eb9d2f9d01d921aa9d57b6b0aaa8e53">,
      #splice.entry<"/build/source/src/debug_flags.h" file 444 mtime 1 "e91f069e0d29280b5b3de3ef3dccbf30d5b8d3878e56c1f0d04da7f6d4b2b994">,
      #splice.entry<"/build/source/src/depfile_parser.cc" file 444 mtime 1 "ec38bf63111f827ace793226b32bea7c87436619ca0d7603ce6011b41732b417">,
      #splice.entry<"/build/source/src/depfile_parser.h" file 444 mtime 1 "c0dacf2fa12b286a208123bd161f2d8993086ea6f97cb5249a0afec4e088bbee">,
      #splice.entry<"/build/source/src/depfile_parser.in.cc" file 444 mtime 1 "0564b48a9f1b7f61e5688fc162a656d31b99894e170ad2a3c85e12e9ac6db506">,
      #splice.entry<"/build/source/src/depfile_parser_perftest.cc" file 444 mtime 1 "a6b36a5fb404774ae7f5341624a56375c363f134845d6e320d757c907e48feaf">,
      #splice.entry<"/build/source/src/depfile_parser_test.cc" file 444 mtime 1 "9b481ec75ec2f019e54910e0dd5f612bf1f6445f49780983f9887edce901f06f">,
      #splice.entry<"/build/source/src/deps_log.cc" file 444 mtime 1 "2082de317ab4e987c4b3d4a5017225d1a779b27f50bf9484087a22ee6cf764fd">,
      #splice.entry<"/build/source/src/deps_log.h" file 444 mtime 1 "26fea3f35f5472156a6f119e90c508f5b618ebcedff691e4a5c432ff5059f6ba">,
      #splice.entry<"/build/source/src/deps_log_test.cc" file 444 mtime 1 "a6e2177eca5c44ee5db7a94f1ba2b30fe805fb89007b6324a847f4682086dff6">,
      #splice.entry<"/build/source/src/disk_interface.cc" file 444 mtime 1 "3abb519615b6c9744ad028684e9797a2abf82f722bc58025d98e83355279644e">,
      #splice.entry<"/build/source/src/disk_interface.h" file 444 mtime 1 "d89f1cf65804e00b5d417099190201606be40dfeff36fdd6fddaddb8dded5ed7">,
      #splice.entry<"/build/source/src/disk_interface_test.cc" file 444 mtime 1 "7dde4141cf0344f0a79508e3fc67e0ed394a64f8b292a6d1b713b84d72220c9f">,
      #splice.entry<"/build/source/src/dyndep.cc" file 444 mtime 1 "443ef071047e32035e098d84ff5423b694c9672b5e5361fe31290e2b88a0b6c6">,
      #splice.entry<"/build/source/src/dyndep.h" file 444 mtime 1 "1f8c1258fbcb38743649bc0f7e13a23b1ea6d7fa2f7c5ddf4c018f70ffa008c7">,
      #splice.entry<"/build/source/src/dyndep_parser.cc" file 444 mtime 1 "79244f51c25d9bbfd55448305861553f1de9afb0a5a2dbafc51a2cc939136130">,
      #splice.entry<"/build/source/src/dyndep_parser.h" file 444 mtime 1 "eb022cc6bcbfc4fcb26de1b1e6edf280856d9bfeba350e588d937fc343ff8927">,
      #splice.entry<"/build/source/src/dyndep_parser_test.cc" file 444 mtime 1 "0adf8c6dc89eae5c9bf5580c75610d6c35aa71da45e36e175a1c8e9dcf239f65">,
      #splice.entry<"/build/source/src/edit_distance.cc" file 444 mtime 1 "1188176a4a180141cf55ebcce7ed4fa20b3507a4fd93225fc8143324e3d9c1b6">,
      #splice.entry<"/build/source/src/edit_distance.h" file 444 mtime 1 "77bd8c4bb0a17cbcc8ed50b4a9cc7d4ecea14a967288f990f03893caa8adaae0">,
      #splice.entry<"/build/source/src/edit_distance_test.cc" file 444 mtime 1 "fc16ea891a66797e3d7075117acba0092a1ce94ff59ee5a73032632fc477ef92">,
      #splice.entry<"/build/source/src/elide_middle.cc" file 444 mtime 1 "944ec06eda4375bee90b161b7854c4476f7108a1a6292b97120a11daad386fab">,
      #splice.entry<"/build/source/src/elide_middle.h" file 444 mtime 1 "0261ca78b0afecb0e37f12323f06aa648b44ec76c6dc6b14c3a5bba5dfc3a0f4">,
      #splice.entry<"/build/source/src/elide_middle_perftest.cc" file 444 mtime 1 "f592eff3a19ea633c6f24d8656a0a7c20dff744ffd2e1998f1b63c9cbca3eff3">,
      #splice.entry<"/build/source/src/elide_middle_test.cc" file 444 mtime 1 "5d5679342b23ee07173c6e358c2cde439d78c8b8477e7d32525c7925d605f45b">,
      #splice.entry<"/build/source/src/eval_env.cc" file 444 mtime 1 "8a6c4227983e889be66a847b0451b8f6ff5bde271e1f200b6597b8b046b78940">,
      #splice.entry<"/build/source/src/eval_env.h" file 444 mtime 1 "6097e6cec7fc4e9db289c8b6c39dad7d70689c8b2fc759c5f6c426f9be8f2dbd">,
      #splice.entry<"/build/source/src/exit_status.h" file 444 mtime 1 "39e981b1fd4ca32c65299422d0e9082d6060228aebc33b0f89001a64ff131feb">,
      #splice.entry<"/build/source/src/explanations.h" file 444 mtime 1 "6cc15e090a055593e555a38972b69ad4471db6bf6645ee1a6aa9e84448a16594">,
      #splice.entry<"/build/source/src/explanations_test.cc" file 444 mtime 1 "811a87be2850225b942944c39dd17662450814e9c55bdf5b169fe7efd8bf020a">,
      #splice.entry<"/build/source/src/gen_doxygen_mainpage.sh" file 555 mtime 1 "98aa7787019a4fe45af14d9826470d0728c3a0f926f3e15f20153f808fa73c73">,
      #splice.entry<"/build/source/src/getopt.c" file 444 mtime 1 "a0e40f26252d08a127b7c6fb16499447c543252f883154322207fa8b1d8d460a">,
      #splice.entry<"/build/source/src/getopt.h" file 444 mtime 1 "e4a6457946944871fdc86ea4b3a3481510bdef280a1db7f0d55cc884bda52b04">,
      #splice.entry<"/build/source/src/graph.cc" file 444 mtime 1 "cc0f3578325e77600c2979bccce28f9139cf38f333d51c5f5fc8b57809413e37">,
      #splice.entry<"/build/source/src/graph.h" file 444 mtime 1 "78bcf15a52fafe90fe94b82c9e00d58822df2217d90868d976dbedc3a46bf86f">,
      #splice.entry<"/build/source/src/graph_test.cc" file 444 mtime 1 "b1dc13cede15fcd67a8ed6a05a6976ffd743a6aa2512661b0b0af627bae841ee">,
      #splice.entry<"/build/source/src/graphviz.cc" file 444 mtime 1 "8bd20be6f365647860d84bede96a5629b94b3cd603f726de3772c27adb96cbd6">,
      #splice.entry<"/build/source/src/graphviz.h" file 444 mtime 1 "b721eb396cc09b2c3dfc8be97910dd025d6a7607b86d9a0a672c48931c587313">,
      #splice.entry<"/build/source/src/hash_collision_bench.cc" file 444 mtime 1 "e7cc2f803713c6147930ce61f5a4c899d7e7cfaa9ed60fa1681dcdd9a9433db9">,
      #splice.entry<"/build/source/src/hash_map.h" file 444 mtime 1 "c0ee50e8a9b1806961c6db2e7213cfaffb4afa3a16e91b6047715a55f4e36c45">,
      #splice.entry<"/build/source/src/includes_normalize-win32.cc" file 444 mtime 1 "f6df9a471e05ca22793981ba046e58f9531ed6015d950626d96bbfebbd2dff6a">,
      #splice.entry<"/build/source/src/includes_normalize.h" file 444 mtime 1 "594c8c17faf0ab9540f2f58f1fad000a4b48fd881aedc971c11505cab4471d05">,
      #splice.entry<"/build/source/src/includes_normalize_test.cc" file 444 mtime 1 "3d5c3da3be0748b4cd2850bfcadae6bb73f77b0d5054398c05c41c2780286307">,
      #splice.entry<"/build/source/src/inline.sh" file 555 mtime 1 "261c279f257152c42c150d6023651d798a3afbd7f0719123d88fc55f8af07233">,
      #splice.entry<"/build/source/src/jobserver-posix.cc" file 444 mtime 1 "fee3b0c611c1679b320ed8fc36fcb627615ba1c1daef2858b3e761d9f2929c51">,
      #splice.entry<"/build/source/src/jobserver-win32.cc" file 444 mtime 1 "eca87071f381bced982261456827f138375be39ee93aebb7af1647fa1fd98e7b">,
      #splice.entry<"/build/source/src/jobserver.cc" file 444 mtime 1 "f339af72963ee72c2ed7a7e6b88b782a652dadaf22cb1f014b8676e90893d20b">,
      #splice.entry<"/build/source/src/jobserver.h" file 444 mtime 1 "b20f53af431c1499c07d4a4be1686df17b4d48afc6a6a3882a01ead5095dd487">,
      #splice.entry<"/build/source/src/jobserver_test.cc" file 444 mtime 1 "665ab8ac6bd49c222c35f6af96a492b38f55c75ec2497331b535008869a20a17">,
      #splice.entry<"/build/source/src/json.cc" file 444 mtime 1 "12f6e9e1d49868a31a7d66d90e40978005471c95564d77e8cb34ab4c97eb3ff6">,
      #splice.entry<"/build/source/src/json.h" file 444 mtime 1 "10c12d3226e9c37fc908f87937d9cbadb473396c4b5a7504c356ad727b040b77">,
      #splice.entry<"/build/source/src/json_test.cc" file 444 mtime 1 "df3b891b24b37c5521ee48550d6336df9f04f245c24113cc3f855ee508a35fa8">,
      #splice.entry<"/build/source/src/lexer.cc" file 444 mtime 1 "fbdb828487f63f4a7d9184d2b71ea0f517b749c4450092f711baa5ae58a8991b">,
      #splice.entry<"/build/source/src/lexer.h" file 444 mtime 1 "4bd99a386d0e69ba4cf95825ab956e77c10e65b6c12fcb287576c6b1783b53b9">,
      #splice.entry<"/build/source/src/lexer.in.cc" file 444 mtime 1 "c6f41eba7f1cfcef242e50f2d10a88bdb7b9a0696cdd131d2b9ba7f4f565e216">,
      #splice.entry<"/build/source/src/lexer_test.cc" file 444 mtime 1 "64c90a489b1d778f70abfa7584e605e950638de07b7627da978f7d9837972e07">,
      #splice.entry<"/build/source/src/line_printer.cc" file 444 mtime 1 "823fd0eeed402aad5bf9d2c4f3f37cdc9bf02936e96f343d8bbc5c861dae7e41">,
      #splice.entry<"/build/source/src/line_printer.h" file 444 mtime 1 "e9f8e7959423ac4c6b4dec66969fa507b84d33d896b4a16d80a16722f07103a3">,
      #splice.entry<"/build/source/src/load_status.h" file 444 mtime 1 "dd27fc585e640863cca90acdf40bd16556bdc78fce47faea2da0879610b15cad">,
      #splice.entry<"/build/source/src/manifest_parser.cc" file 444 mtime 1 "bf283240bfdf315366dbca5296d8ad1f2f32ce7a80fdbd4201713eab88c3cd97">,
      #splice.entry<"/build/source/src/manifest_parser.h" file 444 mtime 1 "3a2b29f292e6917bd9c5e8a265cc49f78c908381a42207976e1866f84a192b98">,
      #splice.entry<"/build/source/src/manifest_parser_perftest.cc" file 444 mtime 1 "ff9cd76e7585f94257cc10a5092ed03531ef542aef0bfb0420055b5b807d29c0">,
      #splice.entry<"/build/source/src/manifest_parser_test.cc" file 444 mtime 1 "fc350726841ffe4b05d5e0dad9950099b9080578cd1be861e4eed7fdc03e86c4">,
      #splice.entry<"/build/source/src/metrics.cc" file 444 mtime 1 "75f45539033dfd19bfc6f46894a562a98ab5958e9169c373babf7949ff1542f2">,
      #splice.entry<"/build/source/src/metrics.h" file 444 mtime 1 "ec8eadc15c40ad35f8cfcc21392cc2bae5edcc8f1d83a55c6a0c4a4bc09cc95c">,
      #splice.entry<"/build/source/src/minidump-win32.cc" file 444 mtime 1 "72c085c7bf9cb5d951509b19cdf112004fa3fac75a23a55868989daba3b58608">,
      #splice.entry<"/build/source/src/missing_deps.cc" file 444 mtime 1 "c7abb23fdf26ba7a33750fe58f0a9801e5edba14935d2986b15e079aaff04c67">,
      #splice.entry<"/build/source/src/missing_deps.h" file 444 mtime 1 "dd8d1b1af3872384b457771bb4f15b88d81208d7fb186df2a9613b393187bada">,
      #splice.entry<"/build/source/src/missing_deps_test.cc" file 444 mtime 1 "e1587d32126b38b6a25f0345065ca42f44e0596e316099eb15af094bc8840db1">,
      #splice.entry<"/build/source/src/msvc_helper-win32.cc" file 444 mtime 1 "33efb0c698b1de4c5fc5b282e2e59b2c085be283278e9c7ca8d3df85c2425aac">,
      #splice.entry<"/build/source/src/msvc_helper.h" file 444 mtime 1 "74b31287cb1f541e155b07c9a86154df5a9c33c1abeee5347f0bea6ddea46f07">,
      #splice.entry<"/build/source/src/msvc_helper_main-win32.cc" file 444 mtime 1 "4337dadad050e1e0fafb57fb6456f6fb356f27c44af12ca3a61d02366bc6a59a">,
      #splice.entry<"/build/source/src/msvc_helper_test.cc" file 444 mtime 1 "0862d27abe0c9cbb6e9c139f8d92648a111f1a0233c98766a0077572130d042a">,
      #splice.entry<"/build/source/src/ninja.cc" file 444 mtime 1 "9d671f4d44eb06a548bbd97adbc9af33e49d72ef2a9ee11fb6aa59f681ab02c8">,
      #splice.entry<"/build/source/src/ninja_test.cc" file 444 mtime 1 "7aa839982936364dad2c617f680a1fa7faab756aff9a2c5f2d240d70c9fe676d">,
      #splice.entry<"/build/source/src/parser.cc" file 444 mtime 1 "cb852cf39db05a055f6c37ed7fa1da10af46b84e4602770ab6c60b76b607331d">,
      #splice.entry<"/build/source/src/parser.h" file 444 mtime 1 "84266a174a97dc38c61c3cb05fe7c722da31bf554f4dfefd9c2d87f08ab0677b">,
      #splice.entry<"/build/source/src/real_command_runner.cc" file 444 mtime 1 "c097b908df41d182dcf72824fb6c5bbbc56be78c7ea82dbdd3ae5edcfd02f656">,
      #splice.entry<"/build/source/src/state.cc" file 444 mtime 1 "413155e79563ae114d8bd08ae46552c6201b529a5ecf881edbe3ccb0148c3f06">,
      #splice.entry<"/build/source/src/state.h" file 444 mtime 1 "3eea6889e958fda7d36e2358d7172c5d427381bd42c1f2af5ccb0467ac65d87b">,
      #splice.entry<"/build/source/src/state_test.cc" file 444 mtime 1 "247d592e2cddeab97e715fb7120b03e8c0a48cdcd8504a9ac3ee44b10a5d0d30">,
      #splice.entry<"/build/source/src/status.h" file 444 mtime 1 "313a680880e0cbc3f84cc682e97f844ead5e32b9ee89ee4287e2c9d16b694f02">,
      #splice.entry<"/build/source/src/status_printer.cc" file 444 mtime 1 "524d2eeef040c22ce65278649f8f06542125596063fec034cc883d5b620faf66">,
      #splice.entry<"/build/source/src/status_printer.h" file 444 mtime 1 "2ae4cc416fa1b1d1e040951a7f87b843ee6d8c84e771c5b62c9262895d72b6a9">,
      #splice.entry<"/build/source/src/status_test.cc" file 444 mtime 1 "4d7d784f5d765f2e94732cd6c583f70fc681f5bafe10eb4ba9abe1b2bb2e6bff">,
      #splice.entry<"/build/source/src/string_piece.h" file 444 mtime 1 "0d5acbcd5337bd3e345a38ac4ac48d0f9eb8950ffb928993de7de3790e16dffb">,
      #splice.entry<"/build/source/src/string_piece_util.cc" file 444 mtime 1 "935fabb62c6255a4fbe8981afa444990fdbffd88b7d2824d2bb2a4c5e0f2b05f">,
      #splice.entry<"/build/source/src/string_piece_util.h" file 444 mtime 1 "79c0c63b9bc59551b685fddd69f18a144dfb5a2495f08ac8ea5e66168a6d96f4">,
      #splice.entry<"/build/source/src/string_piece_util_test.cc" file 444 mtime 1 "a670cbb13a07bd8222a2bf0feea3d1f1fe73ecf0156ad141333fda2f5d0be0de">,
      #splice.entry<"/build/source/src/subprocess-posix.cc" file 444 mtime 1 "a9a4ea4280ac4e9e3d275dc4458c30baf0c067c8cd51b3c6d2034fe6eab88fdc">,
      #splice.entry<"/build/source/src/subprocess-win32.cc" file 444 mtime 1 "2ebc7c0606625e4a84359c0e9a0a763feb77f3d18c0787b03cf1a8e641515f81">,
      #splice.entry<"/build/source/src/subprocess.h" file 444 mtime 1 "ed017388a81f29d9768a3352b366c6177d1c668614cb3bf531fe542840e9b1dd">,
      #splice.entry<"/build/source/src/subprocess_test.cc" file 444 mtime 1 "f4eec807c9f67bae5670d873d21db1cfb725af57114c9cc79c27da73bde8101e">,
      #splice.entry<"/build/source/src/test.cc" file 444 mtime 1 "a65e4e42596691bf10540c5a7d1ee10148627ba3021ddd757da8ec6125e40c5f">,
      #splice.entry<"/build/source/src/test.h" file 444 mtime 1 "7457abfabacd9462fda23fa4c983c1c423c84a555baac6f46d6c1770668be3e2">,
      #splice.entry<"/build/source/src/third_party" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/third_party/emhash" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/third_party/emhash/README.ninja" file 444 mtime 1 "871523bf3637a5ec3865239902e097982e69acf4a612f367f244319aeb9ca24e">,
      #splice.entry<"/build/source/src/third_party/emhash/hash_table8.hpp" file 444 mtime 1 "1d13b3e96ac5cf84a573e9727c4dc937fa5b4b70e4604761aa279ca5fe65607d">,
      #splice.entry<"/build/source/src/third_party/rapidhash" dir 555 mtime 1>,
      #splice.entry<"/build/source/src/third_party/rapidhash/README.ninja" file 444 mtime 1 "55172435065167117f170d0312501aafc63e824c759c458e2ead05684e40bef9">,
      #splice.entry<"/build/source/src/third_party/rapidhash/rapidhash.h" file 555 mtime 1 "263b42cbe8d4093ee0b1b8b6beaf3c24652babbbabddadb71103af2c814b40df">,
      #splice.entry<"/build/source/src/timestamp.h" file 444 mtime 1 "1ce299ddbf344157fd9cad9093883678349070e628925fbdcaaf477277108d9e">,
      #splice.entry<"/build/source/src/util.cc" file 444 mtime 1 "bdb91b207eba44bcc1086dd30a08339959a1c2dad39bd4efb8e168290e036a33">,
      #splice.entry<"/build/source/src/util.h" file 444 mtime 1 "286e18213bb93b1d7fba8865782416f524736c4be968350b54b88b58553290f7">,
      #splice.entry<"/build/source/src/util_test.cc" file 444 mtime 1 "87874465a30d60a4311e394d5c40f13baa7717282f295daa81b02fecb80b4611">,
      #splice.entry<"/build/source/src/version.cc" file 444 mtime 1 "1095717b6444205b1d705dc0db9bf6ef0609a8397e1cb0980a14497c9d99b9bd">,
      #splice.entry<"/build/source/src/version.h" file 444 mtime 1 "ca8e5d8cf6c5734276bb34e5b320bbd897d45cd40e0a3d9907351e17ed66a8a3">,
      #splice.entry<"/build/source/src/win32port.h" file 444 mtime 1 "66d277b30e8296999e77e4c802f212852a3263bf9e73ce5f86eff72b4238a654">,
      #splice.entry<"/build/source/windows" dir 555 mtime 1>,
      #splice.entry<"/build/source/windows/ninja.manifest" file 444 mtime 1 "acdf92007cfac05b9b784353ed589b2bcab3facf983fffe1775c16fb31dddc91">
  ]
  %chmod_2624:13 = splice.literal "chmod" at 2624 folded -> [
      #splice.entry<"/build/source" dir 755 mtime 1>,
      #splice.entry<"/build/source/.github" dir 755 mtime 1>,
      #splice.entry<"/build/source/doc" dir 755 mtime 1>,
      #splice.entry<"/build/source/misc" dir 755 mtime 1>,
      #splice.entry<"/build/source/misc/afl-fuzz" dir 755 mtime 1>,
      #splice.entry<"/build/source/misc/afl-fuzz-tokens" dir 755 mtime 1>,
      #splice.entry<"/build/source/misc/oss-fuzz" dir 755 mtime 1>,
      #splice.entry<"/build/source/misc/packaging" dir 755 mtime 1>,
      #splice.entry<"/build/source/src" dir 755 mtime 1>,
      #splice.entry<"/build/source/src/third_party" dir 755 mtime 1>,
      #splice.entry<"/build/source/src/third_party/emhash" dir 755 mtime 1>,
      #splice.entry<"/build/source/src/third_party/rapidhash" dir 755 mtime 1>,
      #splice.entry<"/build/source/windows" dir 755 mtime 1>
  ]
  %chmod_2624_0 = splice.copy "chmod" at 2624(%cp_2232#1) -> <"/build/source/.clang-format" file 644 mtime 1 "7b7f50552a3f95d31694c9d77ed2070bb8f07931d29c5c6ab64862c05b8bedee">
  %chmod_2624_1 = splice.copy "chmod" at 2624(%cp_2232#2) -> <"/build/source/.clang-tidy" file 644 mtime 1 "0b7fb3eaec9b6fd2febcb7f03e61bfa8dd3a7e2d053425c48576cb4a503322e6">
  %chmod_2624_2 = splice.copy "chmod" at 2624(%cp_2232#3) -> <"/build/source/.editorconfig" file 644 mtime 1 "4b3fdc0a26286e8e6d5e2c3e8036d02e000cc30887e09728ad22c45ed1b2e6c8">
  %chmod_2624_3 = splice.copy "chmod" at 2624(%cp_2232#11) -> <"/build/source/.gitignore" file 644 mtime 1 "4bfcc8bfc40cc5b27efa88896711130b6e781e14a622aa9f09d14afc5caf5253">
  %chmod_2624_4 = splice.copy "chmod" at 2624(%cp_2232#12) -> <"/build/source/CMakeLists.txt" file 644 mtime 1 "4cb1d04827f6f1e24e99e746aeef6a3bf0dbea79f73a5894cd6c30644c135332">
  %chmod_2624_5 = splice.copy "chmod" at 2624(%cp_2232#13) -> <"/build/source/CONTRIBUTING.md" file 644 mtime 1 "f588ccbb140590580d593d43c55760a94ff911bd03761d2840082b1d0ee76e7c">
  %chmod_2624_6 = splice.copy "chmod" at 2624(%cp_2232#14) -> <"/build/source/COPYING" file 644 mtime 1 "eb7e9ab9690124c5c9f42bdc81383d886a3dede26345b6ed15bbad7caf81f7ea">
  %chmod_2624_7 = splice.copy "chmod" at 2624(%cp_2232#15) -> <"/build/source/README.md" file 644 mtime 1 "b31e9700c752fa214773c1b799d90efcbf3330c8062da9f45c6064e023b347b0">
  %chmod_2624_8 = splice.copy "chmod" at 2624(%cp_2232#16) -> <"/build/source/RELEASING.md" file 644 mtime 1 "0c94d70ced5f00d7cf431d5e00d180c14fb2802bd5fa379d3d5509c720ad4d4f">
  %chmod_2624_9 = splice.copy "chmod" at 2624(%cp_2232#17) -> <"/build/source/appveyor.yml" file 644 mtime 1 "61d88a9eea1867b191765f649f991256a00afcccb84758c3aa48e17d5479f08b">
  %chmod_2624_10 = splice.copy "chmod" at 2624(%cp_2232#22) -> <"/build/source/doc/docbook.xsl" file 644 mtime 1 "c1081af70cbc7ac7778540b6773e95afe7b474a5b614f397590bd129c7c0ce3f">
  %chmod_2624_11 = splice.copy "chmod" at 2624(%cp_2232#24) -> <"/build/source/doc/manual.asciidoc" file 644 mtime 1 "0b7148678b1a4c7751acbb443d5cfec41ceacf3a7b2a0ad2d511407fbe056226">
  %chmod_2624_12 = splice.copy "chmod" at 2624(%cp_2232#25) -> <"/build/source/doc/style.css" file 644 mtime 1 "a39322df8ce8a7e02b7d8d4076489aaf8d98bb0e5ac4322692d7f76aecfe5f59">
  %chmod_2624_13 = splice.copy "chmod" at 2624(%cp_2232#46) -> <"/build/source/misc/bash-completion" file 644 mtime 1 "536a81b4d5fac9dd74e4842c59f2b5ab0cce27882e3638fd7219d1ad78fa149d">
  %chmod_2624_14 = splice.copy "chmod" at 2624(%cp_2232#47) -> <"/build/source/misc/ci.py" file 755 mtime 1 "adc278f963cda6e77754e0525b31e310f32dd7132d07e337bad61750145dd824">
  %chmod_2624_15 = splice.copy "chmod" at 2624(%cp_2232#48) -> <"/build/source/misc/inherited-fds.ninja" file 644 mtime 1 "49dbd1856ad0ae2dc46283256da58b4d79459605d2c925e341559bf59bb90fa1">
  %chmod_2624_16 = splice.copy "chmod" at 2624(%cp_2232#49) -> <"/build/source/misc/jobserver_pool.py" file 755 mtime 1 "5a3ae98df00c522914db0299773c3999338d9e6b4e963339a1c09cbfd5a11237">
  %chmod_2624_17 = splice.copy "chmod" at 2624(%cp_2232#50) -> <"/build/source/misc/jobserver_pool_test.py" file 755 mtime 1 "b7ed2c3d6cafbfe105daa7cf087c28639122d2eea0060d55c3b4f04745e3ac65">
  %chmod_2624_18 = splice.copy "chmod" at 2624(%cp_2232#51) -> <"/build/source/misc/jobserver_test.py" file 755 mtime 1 "37b2082d404053e0d1f4810c565cb2aa29ba66bd2628722e5d318e09204b55a5">
  %chmod_2624_19 = splice.copy "chmod" at 2624(%cp_2232#52) -> <"/build/source/misc/jobserver_test_helper.py" file 755 mtime 1 "d0d74b03fcfc1d7abe5d1ad2c938b741888a8bb904787a8b297907b1cf9802f1">
  %chmod_2624_20 = splice.copy "chmod" at 2624(%cp_2232#53) -> <"/build/source/misc/long-slow-build.ninja" file 644 mtime 1 "6687e1de9c5819a632ca71eb1755eddf20929a658cb7847ff393865c08da574b">
  %chmod_2624_21 = splice.copy "chmod" at 2624(%cp_2232#54) -> <"/build/source/misc/manifest_fuzzer.cc" file 644 mtime 1 "07ec328cadd1819bfe5c9feb0c1b47b93677ff26c6c3233886aa8d919bfdfcbf">
  %chmod_2624_22 = splice.copy "chmod" at 2624(%cp_2232#55) -> <"/build/source/misc/measure.py" file 755 mtime 1 "ef158684ddeacdec396d319775bdba7a848297f51465c48c3da638c72521b2ab">
  %chmod_2624_23 = splice.copy "chmod" at 2624(%cp_2232#56) -> <"/build/source/misc/ninja.vim" file 644 mtime 1 "b5fe687d3e73aa9a66683e1854214caba6d524ac2aa3591643a6e5dba9743823">
  %chmod_2624_24 = splice.copy "chmod" at 2624(%cp_2232#57) -> <"/build/source/misc/ninja_syntax.py" file 644 mtime 1 "4425d9e91a1d6b79709db86d430e88e9b25ca44f7c997519f63a1c9ef0b82106">
  %chmod_2624_25 = splice.copy "chmod" at 2624(%cp_2232#58) -> <"/build/source/misc/ninja_syntax_test.py" file 755 mtime 1 "d0bfd59e49fd1fe70a2ecf1e6bdaf76fb516304a3893b3401582b2731aa33cd0">
  %chmod_2624_26 = splice.copy "chmod" at 2624(%cp_2232#62) -> <"/build/source/misc/output_test.py" file 755 mtime 1 "c4d4acb6b70b0cb902d1285b8595cb3e02460e3fb49937f69c2830f279f3601e">
  %chmod_2624_27 = splice.copy "chmod" at 2624(%cp_2232#66) -> <"/build/source/misc/write_fake_manifests.py" file 755 mtime 1 "af0fa35bb80549d028963793941f1a50962377795734078664be801bb674b5fb">
  %chmod_2624_28 = splice.copy "chmod" at 2624(%cp_2232#67) -> <"/build/source/misc/zsh-completion" file 644 mtime 1 "a4b8b63ac381db23da0a5624ea3092d5c7e433dd608afdf07792aa586d79effa">
  %chmod_2624_29 = splice.copy "chmod" at 2624(%cp_2232#69) -> <"/build/source/src/browse.cc" file 644 mtime 1 "c626cb4e22350fffcda2723451e7ee85cb8705c90723ea0f7d214db12915dadd">
  %chmod_2624_30 = splice.copy "chmod" at 2624(%cp_2232#70) -> <"/build/source/src/browse.h" file 644 mtime 1 "af30ade6dde2ddc880e9ade506c08eb0225da20a84ec1d1030c552f56d08f573">
  %chmod_2624_31 = splice.copy "chmod" at 2624(%cp_2232#71) -> <"/build/source/src/browse.py" file 755 mtime 1 "8c5dc6696a1496f1e06e7cee04e717ceaf0d7e59cf067941176e2282d2a2e1b2">
  %chmod_2624_32 = splice.copy "chmod" at 2624(%cp_2232#72) -> <"/build/source/src/build.cc" file 644 mtime 1 "afd4ececbb6462ff55aa67414dca9963d069bed338e7855548e6527f427544ae">
  %chmod_2624_33 = splice.copy "chmod" at 2624(%cp_2232#73) -> <"/build/source/src/build.h" file 644 mtime 1 "6668e22969a2d8b601b5972361ed0385cc9bf4710d933158ee6c9cfc7d114902">
  %chmod_2624_34 = splice.copy "chmod" at 2624(%cp_2232#74) -> <"/build/source/src/build_log.cc" file 644 mtime 1 "378d1fd92e9b44a6ee8b34bc83c6220ea3d702b9a7d215307ed7c1874bb8e7c6">
  %chmod_2624_35 = splice.copy "chmod" at 2624(%cp_2232#75) -> <"/build/source/src/build_log.h" file 644 mtime 1 "f0675a0ca11126488395fea1d459bc9c50ec742684b0b89b424f2e27b4b3717a">
  %chmod_2624_36 = splice.copy "chmod" at 2624(%cp_2232#80) -> <"/build/source/src/clean.cc" file 644 mtime 1 "b833b3275474655ce30e7d6e33a53f2a002f9c09e9ed11eafc5492354087d6ef">
  %chmod_2624_37 = splice.copy "chmod" at 2624(%cp_2232#81) -> <"/build/source/src/clean.h" file 644 mtime 1 "9e802c85af45cf548d31cac67cf6b8d1d67a8c1fabfb1c894b820d9a242521dd">
  %chmod_2624_38 = splice.copy "chmod" at 2624(%cp_2232#83) -> <"/build/source/src/clparser.cc" file 644 mtime 1 "9d758a927372e28ec63b3921e30e6c2107220bcb53b601dd5f1af56a7d34c89a">
  %chmod_2624_39 = splice.copy "chmod" at 2624(%cp_2232#84) -> <"/build/source/src/clparser.h" file 644 mtime 1 "7fd40755a9437f63fda72b781e3a0326c5ba43cf3342ddc86af1806832d53ffa">
  %chmod_2624_40 = splice.copy "chmod" at 2624(%cp_2232#87) -> <"/build/source/src/command_collector.h" file 644 mtime 1 "3647baefbbea22b4ccc32c026cad9257a58fe9ee25bd4ed026533829f457f08a">
  %chmod_2624_41 = splice.copy "chmod" at 2624(%cp_2232#88) -> <"/build/source/src/debug_flags.cc" file 644 mtime 1 "8fad28f2dd7993d30063dc6916620ac18eb9d2f9d01d921aa9d57b6b0aaa8e53">
  %chmod_2624_42 = splice.copy "chmod" at 2624(%cp_2232#89) -> <"/build/source/src/debug_flags.h" file 644 mtime 1 "e91f069e0d29280b5b3de3ef3dccbf30d5b8d3878e56c1f0d04da7f6d4b2b994">
  %chmod_2624_43 = splice.copy "chmod" at 2624(%cp_2232#90) -> <"/build/source/src/depfile_parser.cc" file 644 mtime 1 "ec38bf63111f827ace793226b32bea7c87436619ca0d7603ce6011b41732b417">
  %chmod_2624_44 = splice.copy "chmod" at 2624(%cp_2232#91) -> <"/build/source/src/depfile_parser.h" file 644 mtime 1 "c0dacf2fa12b286a208123bd161f2d8993086ea6f97cb5249a0afec4e088bbee">
  %chmod_2624_45 = splice.copy "chmod" at 2624(%cp_2232#92) -> <"/build/source/src/depfile_parser.in.cc" file 644 mtime 1 "0564b48a9f1b7f61e5688fc162a656d31b99894e170ad2a3c85e12e9ac6db506">
  %chmod_2624_46 = splice.copy "chmod" at 2624(%cp_2232#95) -> <"/build/source/src/deps_log.cc" file 644 mtime 1 "2082de317ab4e987c4b3d4a5017225d1a779b27f50bf9484087a22ee6cf764fd">
  %chmod_2624_47 = splice.copy "chmod" at 2624(%cp_2232#96) -> <"/build/source/src/deps_log.h" file 644 mtime 1 "26fea3f35f5472156a6f119e90c508f5b618ebcedff691e4a5c432ff5059f6ba">
  %chmod_2624_48 = splice.copy "chmod" at 2624(%cp_2232#98) -> <"/build/source/src/disk_interface.cc" file 644 mtime 1 "3abb519615b6c9744ad028684e9797a2abf82f722bc58025d98e83355279644e">
  %chmod_2624_49 = splice.copy "chmod" at 2624(%cp_2232#99) -> <"/build/source/src/disk_interface.h" file 644 mtime 1 "d89f1cf65804e00b5d417099190201606be40dfeff36fdd6fddaddb8dded5ed7">
  %chmod_2624_50 = splice.copy "chmod" at 2624(%cp_2232#101) -> <"/build/source/src/dyndep.cc" file 644 mtime 1 "443ef071047e32035e098d84ff5423b694c9672b5e5361fe31290e2b88a0b6c6">
  %chmod_2624_51 = splice.copy "chmod" at 2624(%cp_2232#102) -> <"/build/source/src/dyndep.h" file 644 mtime 1 "1f8c1258fbcb38743649bc0f7e13a23b1ea6d7fa2f7c5ddf4c018f70ffa008c7">
  %chmod_2624_52 = splice.copy "chmod" at 2624(%cp_2232#103) -> <"/build/source/src/dyndep_parser.cc" file 644 mtime 1 "79244f51c25d9bbfd55448305861553f1de9afb0a5a2dbafc51a2cc939136130">
  %chmod_2624_53 = splice.copy "chmod" at 2624(%cp_2232#104) -> <"/build/source/src/dyndep_parser.h" file 644 mtime 1 "eb022cc6bcbfc4fcb26de1b1e6edf280856d9bfeba350e588d937fc343ff8927">
  %chmod_2624_54 = splice.copy "chmod" at 2624(%cp_2232#106) -> <"/build/source/src/edit_distance.cc" file 644 mtime 1 "1188176a4a180141cf55ebcce7ed4fa20b3507a4fd93225fc8143324e3d9c1b6">
  %chmod_2624_55 = splice.copy "chmod" at 2624(%cp_2232#107) -> <"/build/source/src/edit_distance.h" file 644 mtime 1 "77bd8c4bb0a17cbcc8ed50b4a9cc7d4ecea14a967288f990f03893caa8adaae0">
  %chmod_2624_56 = splice.copy "chmod" at 2624(%cp_2232#109) -> <"/build/source/src/elide_middle.cc" file 644 mtime 1 "944ec06eda4375bee90b161b7854c4476f7108a1a6292b97120a11daad386fab">
  %chmod_2624_57 = splice.copy "chmod" at 2624(%cp_2232#110) -> <"/build/source/src/elide_middle.h" file 644 mtime 1 "0261ca78b0afecb0e37f12323f06aa648b44ec76c6dc6b14c3a5bba5dfc3a0f4">
  %chmod_2624_58 = splice.copy "chmod" at 2624(%cp_2232#113) -> <"/build/source/src/eval_env.cc" file 644 mtime 1 "8a6c4227983e889be66a847b0451b8f6ff5bde271e1f200b6597b8b046b78940">
  %chmod_2624_59 = splice.copy "chmod" at 2624(%cp_2232#114) -> <"/build/source/src/eval_env.h" file 644 mtime 1 "6097e6cec7fc4e9db289c8b6c39dad7d70689c8b2fc759c5f6c426f9be8f2dbd">
  %chmod_2624_60 = splice.copy "chmod" at 2624(%cp_2232#115) -> <"/build/source/src/exit_status.h" file 644 mtime 1 "39e981b1fd4ca32c65299422d0e9082d6060228aebc33b0f89001a64ff131feb">
  %chmod_2624_61 = splice.copy "chmod" at 2624(%cp_2232#116) -> <"/build/source/src/explanations.h" file 644 mtime 1 "6cc15e090a055593e555a38972b69ad4471db6bf6645ee1a6aa9e84448a16594">
  %chmod_2624_62 = splice.copy "chmod" at 2624(%cp_2232#121) -> <"/build/source/src/graph.cc" file 644 mtime 1 "cc0f3578325e77600c2979bccce28f9139cf38f333d51c5f5fc8b57809413e37">
  %chmod_2624_63 = splice.copy "chmod" at 2624(%cp_2232#122) -> <"/build/source/src/graph.h" file 644 mtime 1 "78bcf15a52fafe90fe94b82c9e00d58822df2217d90868d976dbedc3a46bf86f">
  %chmod_2624_64 = splice.copy "chmod" at 2624(%cp_2232#124) -> <"/build/source/src/graphviz.cc" file 644 mtime 1 "8bd20be6f365647860d84bede96a5629b94b3cd603f726de3772c27adb96cbd6">
  %chmod_2624_65 = splice.copy "chmod" at 2624(%cp_2232#125) -> <"/build/source/src/graphviz.h" file 644 mtime 1 "b721eb396cc09b2c3dfc8be97910dd025d6a7607b86d9a0a672c48931c587313">
  %chmod_2624_66 = splice.copy "chmod" at 2624(%cp_2232#127) -> <"/build/source/src/hash_map.h" file 644 mtime 1 "c0ee50e8a9b1806961c6db2e7213cfaffb4afa3a16e91b6047715a55f4e36c45">
  %chmod_2624_67 = splice.copy "chmod" at 2624(%cp_2232#131) -> <"/build/source/src/inline.sh" file 755 mtime 1 "261c279f257152c42c150d6023651d798a3afbd7f0719123d88fc55f8af07233">
  %chmod_2624_68 = splice.copy "chmod" at 2624(%cp_2232#132) -> <"/build/source/src/jobserver-posix.cc" file 644 mtime 1 "fee3b0c611c1679b320ed8fc36fcb627615ba1c1daef2858b3e761d9f2929c51">
  %chmod_2624_69 = splice.copy "chmod" at 2624(%cp_2232#134) -> <"/build/source/src/jobserver.cc" file 644 mtime 1 "f339af72963ee72c2ed7a7e6b88b782a652dadaf22cb1f014b8676e90893d20b">
  %chmod_2624_70 = splice.copy "chmod" at 2624(%cp_2232#135) -> <"/build/source/src/jobserver.h" file 644 mtime 1 "b20f53af431c1499c07d4a4be1686df17b4d48afc6a6a3882a01ead5095dd487">
  %chmod_2624_71 = splice.copy "chmod" at 2624(%cp_2232#137) -> <"/build/source/src/json.cc" file 644 mtime 1 "12f6e9e1d49868a31a7d66d90e40978005471c95564d77e8cb34ab4c97eb3ff6">
  %chmod_2624_72 = splice.copy "chmod" at 2624(%cp_2232#138) -> <"/build/source/src/json.h" file 644 mtime 1 "10c12d3226e9c37fc908f87937d9cbadb473396c4b5a7504c356ad727b040b77">
  %chmod_2624_73 = splice.copy "chmod" at 2624(%cp_2232#140) -> <"/build/source/src/lexer.cc" file 644 mtime 1 "fbdb828487f63f4a7d9184d2b71ea0f517b749c4450092f711baa5ae58a8991b">
  %chmod_2624_74 = splice.copy "chmod" at 2624(%cp_2232#141) -> <"/build/source/src/lexer.h" file 644 mtime 1 "4bd99a386d0e69ba4cf95825ab956e77c10e65b6c12fcb287576c6b1783b53b9">
  %chmod_2624_75 = splice.copy "chmod" at 2624(%cp_2232#142) -> <"/build/source/src/lexer.in.cc" file 644 mtime 1 "c6f41eba7f1cfcef242e50f2d10a88bdb7b9a0696cdd131d2b9ba7f4f565e216">
  %chmod_2624_76 = splice.copy "chmod" at 2624(%cp_2232#144) -> <"/build/source/src/line_printer.cc" file 644 mtime 1 "823fd0eeed402aad5bf9d2c4f3f37cdc9bf02936e96f343d8bbc5c861dae7e41">
  %chmod_2624_77 = splice.copy "chmod" at 2624(%cp_2232#145) -> <"/build/source/src/line_printer.h" file 644 mtime 1 "e9f8e7959423ac4c6b4dec66969fa507b84d33d896b4a16d80a16722f07103a3">
  %chmod_2624_78 = splice.copy "chmod" at 2624(%cp_2232#146) -> <"/build/source/src/load_status.h" file 644 mtime 1 "dd27fc585e640863cca90acdf40bd16556bdc78fce47faea2da0879610b15cad">
  %chmod_2624_79 = splice.copy "chmod" at 2624(%cp_2232#147) -> <"/build/source/src/manifest_parser.cc" file 644 mtime 1 "bf283240bfdf315366dbca5296d8ad1f2f32ce7a80fdbd4201713eab88c3cd97">
  %chmod_2624_80 = splice.copy "chmod" at 2624(%cp_2232#148) -> <"/build/source/src/manifest_parser.h" file 644 mtime 1 "3a2b29f292e6917bd9c5e8a265cc49f78c908381a42207976e1866f84a192b98">
  %chmod_2624_81 = splice.copy "chmod" at 2624(%cp_2232#151) -> <"/build/source/src/metrics.cc" file 644 mtime 1 "75f45539033dfd19bfc6f46894a562a98ab5958e9169c373babf7949ff1542f2">
  %chmod_2624_82 = splice.copy "chmod" at 2624(%cp_2232#152) -> <"/build/source/src/metrics.h" file 644 mtime 1 "ec8eadc15c40ad35f8cfcc21392cc2bae5edcc8f1d83a55c6a0c4a4bc09cc95c">
  %chmod_2624_83 = splice.copy "chmod" at 2624(%cp_2232#154) -> <"/build/source/src/missing_deps.cc" file 644 mtime 1 "c7abb23fdf26ba7a33750fe58f0a9801e5edba14935d2986b15e079aaff04c67">
  %chmod_2624_84 = splice.copy "chmod" at 2624(%cp_2232#155) -> <"/build/source/src/missing_deps.h" file 644 mtime 1 "dd8d1b1af3872384b457771bb4f15b88d81208d7fb186df2a9613b393187bada">
  %chmod_2624_85 = splice.copy "chmod" at 2624(%cp_2232#161) -> <"/build/source/src/ninja.cc" file 644 mtime 1 "9d671f4d44eb06a548bbd97adbc9af33e49d72ef2a9ee11fb6aa59f681ab02c8">
  %chmod_2624_86 = splice.copy "chmod" at 2624(%cp_2232#163) -> <"/build/source/src/parser.cc" file 644 mtime 1 "cb852cf39db05a055f6c37ed7fa1da10af46b84e4602770ab6c60b76b607331d">
  %chmod_2624_87 = splice.copy "chmod" at 2624(%cp_2232#164) -> <"/build/source/src/parser.h" file 644 mtime 1 "84266a174a97dc38c61c3cb05fe7c722da31bf554f4dfefd9c2d87f08ab0677b">
  %chmod_2624_88 = splice.copy "chmod" at 2624(%cp_2232#165) -> <"/build/source/src/real_command_runner.cc" file 644 mtime 1 "c097b908df41d182dcf72824fb6c5bbbc56be78c7ea82dbdd3ae5edcfd02f656">
  %chmod_2624_89 = splice.copy "chmod" at 2624(%cp_2232#166) -> <"/build/source/src/state.cc" file 644 mtime 1 "413155e79563ae114d8bd08ae46552c6201b529a5ecf881edbe3ccb0148c3f06">
  %chmod_2624_90 = splice.copy "chmod" at 2624(%cp_2232#167) -> <"/build/source/src/state.h" file 644 mtime 1 "3eea6889e958fda7d36e2358d7172c5d427381bd42c1f2af5ccb0467ac65d87b">
  %chmod_2624_91 = splice.copy "chmod" at 2624(%cp_2232#169) -> <"/build/source/src/status.h" file 644 mtime 1 "313a680880e0cbc3f84cc682e97f844ead5e32b9ee89ee4287e2c9d16b694f02">
  %chmod_2624_92 = splice.copy "chmod" at 2624(%cp_2232#170) -> <"/build/source/src/status_printer.cc" file 644 mtime 1 "524d2eeef040c22ce65278649f8f06542125596063fec034cc883d5b620faf66">
  %chmod_2624_93 = splice.copy "chmod" at 2624(%cp_2232#171) -> <"/build/source/src/status_printer.h" file 644 mtime 1 "2ae4cc416fa1b1d1e040951a7f87b843ee6d8c84e771c5b62c9262895d72b6a9">
  %chmod_2624_94 = splice.copy "chmod" at 2624(%cp_2232#173) -> <"/build/source/src/string_piece.h" file 644 mtime 1 "0d5acbcd5337bd3e345a38ac4ac48d0f9eb8950ffb928993de7de3790e16dffb">
  %chmod_2624_95 = splice.copy "chmod" at 2624(%cp_2232#174) -> <"/build/source/src/string_piece_util.cc" file 644 mtime 1 "935fabb62c6255a4fbe8981afa444990fdbffd88b7d2824d2bb2a4c5e0f2b05f">
  %chmod_2624_96 = splice.copy "chmod" at 2624(%cp_2232#175) -> <"/build/source/src/string_piece_util.h" file 644 mtime 1 "79c0c63b9bc59551b685fddd69f18a144dfb5a2495f08ac8ea5e66168a6d96f4">
  %chmod_2624_97 = splice.copy "chmod" at 2624(%cp_2232#177) -> <"/build/source/src/subprocess-posix.cc" file 644 mtime 1 "a9a4ea4280ac4e9e3d275dc4458c30baf0c067c8cd51b3c6d2034fe6eab88fdc">
  %chmod_2624_98 = splice.copy "chmod" at 2624(%cp_2232#179) -> <"/build/source/src/subprocess.h" file 644 mtime 1 "ed017388a81f29d9768a3352b366c6177d1c668614cb3bf531fe542840e9b1dd">
  %chmod_2624_99 = splice.copy "chmod" at 2624(%cp_2232#186) -> <"/build/source/src/third_party/emhash/hash_table8.hpp" file 644 mtime 1 "1d13b3e96ac5cf84a573e9727c4dc937fa5b4b70e4604761aa279ca5fe65607d">
  %chmod_2624_100 = splice.copy "chmod" at 2624(%cp_2232#189) -> <"/build/source/src/third_party/rapidhash/rapidhash.h" file 755 mtime 1 "263b42cbe8d4093ee0b1b8b6beaf3c24652babbbabddadb71103af2c814b40df">
  %chmod_2624_101 = splice.copy "chmod" at 2624(%cp_2232#190) -> <"/build/source/src/timestamp.h" file 644 mtime 1 "1ce299ddbf344157fd9cad9093883678349070e628925fbdcaaf477277108d9e">
  %chmod_2624_102 = splice.copy "chmod" at 2624(%cp_2232#191) -> <"/build/source/src/util.cc" file 644 mtime 1 "bdb91b207eba44bcc1086dd30a08339959a1c2dad39bd4efb8e168290e036a33">
  %chmod_2624_103 = splice.copy "chmod" at 2624(%cp_2232#192) -> <"/build/source/src/util.h" file 644 mtime 1 "286e18213bb93b1d7fba8865782416f524736c4be968350b54b88b58553290f7">
  %chmod_2624_104 = splice.copy "chmod" at 2624(%cp_2232#194) -> <"/build/source/src/version.cc" file 644 mtime 1 "1095717b6444205b1d705dc0db9bf6ef0609a8397e1cb0980a14497c9d99b9bd">
  %chmod_2624_105 = splice.copy "chmod" at 2624(%cp_2232#195) -> <"/build/source/src/version.h" file 644 mtime 1 "ca8e5d8cf6c5734276bb34e5b320bbd897d45cd40e0a3d9907351e17ed66a8a3">
  %cat_patch_2847 = splice.exec "cat|patch" at 2847(%sandbox_720#0, %chmod_2624#0, %chmod_2624#8, %chmod_2624_97) -> [
      #splice.entry<"/build/source/src/subprocess-posix.cc" file 644 mtime 1794960000 "aa09bdf3a0acc58c5e157b1dd7dfcbc7fff5325ba15fc57e930abb793e0075d5">
  ]
  %glue_2916 = splice.literal "glue" at 2916 -> [
      #splice.entry<"/build/source/configure.py" file 755 mtime 1794960000 "35fd8359328364c250ff1a90f4b26a9094bd92073157697239f7124396a0eaf7">
  ]
  %python_3266:2 = splice.literal "python" at 3266 folded -> [
      #splice.entry<"/build/source/build" dir 755 mtime 1794960023>,
      #splice.entry<"/build/source/misc/__pycache__" dir 755 mtime 1794960000>
  ]
  %python_3266_106:77 = splice.exec "python" at 3266(%sandbox_720#0, %chmod_2624#0, %glue_2916, %chmod_2624#3, %chmod_2624_24, %chmod_2624#8, %chmod_2624_29, %chmod_2624_30, %chmod_2624_31, %chmod_2624_32, %chmod_2624_33, %chmod_2624_34, %chmod_2624_35, %chmod_2624_36, %chmod_2624_37, %chmod_2624_38, %chmod_2624_39, %chmod_2624_40, %chmod_2624_41, %chmod_2624_42, %chmod_2624_43, %chmod_2624_44, %chmod_2624_45, %chmod_2624_46, %chmod_2624_47, %chmod_2624_48, %chmod_2624_49, %chmod_2624_50, %chmod_2624_51, %chmod_2624_52, %chmod_2624_53, %chmod_2624_54, %chmod_2624_55, %chmod_2624_56, %chmod_2624_57, %chmod_2624_58, %chmod_2624_59, %chmod_2624_60, %chmod_2624_61, %chmod_2624_62, %chmod_2624_63, %chmod_2624_64, %chmod_2624_65, %chmod_2624_66, %chmod_2624_67, %chmod_2624_68, %chmod_2624_69, %chmod_2624_70, %chmod_2624_71, %chmod_2624_72, %chmod_2624_73, %chmod_2624_74, %chmod_2624_75, %chmod_2624_76, %chmod_2624_77, %chmod_2624_78, %chmod_2624_79, %chmod_2624_80, %chmod_2624_81, %chmod_2624_82, %chmod_2624_83, %chmod_2624_84, %chmod_2624_85, %chmod_2624_86, %chmod_2624_87, %chmod_2624_88, %chmod_2624_89, %chmod_2624_90, %chmod_2624_91, %chmod_2624_92, %chmod_2624_93, %chmod_2624_94, %chmod_2624_95, %chmod_2624_96, %cat_patch_2847, %chmod_2624_98, %chmod_2624#9, %chmod_2624#10, %chmod_2624_99, %chmod_2624#11, %chmod_2624_100, %chmod_2624_101, %chmod_2624_102, %chmod_2624_103, %chmod_2624_104, %chmod_2624_105) -> [
      #splice.entry<"/build/source/build" dir 755 mtime 1794960023>,
      #splice.entry<"/build/source/build.ninja" file 644 mtime 1794960024 "c6b764e8d65851c6ba1615ddcb7f17ffa525a30135febebe7012150518206023">,
      #splice.entry<"/build/source/build/browse.o" file 644 mtime 1794960000 "9626a2890e5a0b44ff2947a8cd283e69718935784f99e1c913014eaad8a4a894">,
      #splice.entry<"/build/source/build/browse.o.d" file 644 mtime 1794960000 "82902f3d889466a111b0179a7e0283e96f0c5861a0198e374a43aed49c1d41f3">,
      #splice.entry<"/build/source/build/browse_py.h" file 644 mtime 1794960000 "4dd1455da9b09646416a2e465a696e934fe36113317a5e509a18922ab01c608c">,
      #splice.entry<"/build/source/build/build.o" file 644 mtime 1794960003 "51cb2f83bdae61f01b585839f9db76dbbce4c81bd428d0280170bee411a39e3f">,
      #splice.entry<"/build/source/build/build.o.d" file 644 mtime 1794960003 "805c7c6618a838de30e11d75fde327395ac6e7a0e5995c982ab2dafb9107fd3c">,
      #splice.entry<"/build/source/build/build_log.o" file 644 mtime 1794960004 "045e04601a6913862e5fe55ab56cd3fc7258fcafbbd40bceb54cef970bd72697">,
      #splice.entry<"/build/source/build/build_log.o.d" file 644 mtime 1794960004 "bfc2b10ddfed7b0e74e77641e1d324272f83c5594117f3ca59f1cb792fb1c739">,
      #splice.entry<"/build/source/build/clean.o" file 644 mtime 1794960004 "1927941de14f3a9075a9d393d4db08b79f0461eebcf6c26a3a2b1508e9e7500d">,
      #splice.entry<"/build/source/build/clean.o.d" file 644 mtime 1794960004 "69a51c947b3911f8ec66098856d85e8c01076e26dd76082201d86ef9f3afa346">,
      #splice.entry<"/build/source/build/clparser.o" file 644 mtime 1794960005 "16a6e84d26487b42164d919ec98576d5d1796d9ef9df4346079c281b879cd5ac">,
      #splice.entry<"/build/source/build/clparser.o.d" file 644 mtime 1794960005 "0097e5b0d965ccf2c885124cb306e09c0e9c4a71517ec19ca08dd1fbc5883a1a">,
      #splice.entry<"/build/source/build/debug_flags.o" file 644 mtime 1794960005 "ef979700b76ce45f65847a286b15c330054225cbfa1e375afafbdab5538cde3d">,
      #splice.entry<"/build/source/build/debug_flags.o.d" file 644 mtime 1794960005 "9964ce0415b33e5367bc9c0eb97ec1a52c022eed31a16c1675e8ad8592b08613">,
      #splice.entry<"/build/source/build/depfile_parser.o" file 644 mtime 1794960000 "74a40229a88af654cecce304bc49b008fc52c35e94fb329c99647c450d07303e">,
      #splice.entry<"/build/source/build/depfile_parser.o.d" file 644 mtime 1794960000 "5551bd7ff48e97856991a81c0ddc22b125a9aa78149578cff20db67a871700d6">,
      #splice.entry<"/build/source/build/deps_log.o" file 644 mtime 1794960006 "8358fbcc3dfd1c27e2688df302cebebd2c582bb1c229e4511dcb739392c13801">,
      #splice.entry<"/build/source/build/deps_log.o.d" file 644 mtime 1794960006 "a7473e3b1f4345da4b8a0cb266c97e1d11b4df128b040ba51de63170bdae97df">,
      #splice.entry<"/build/source/build/disk_interface.o" file 644 mtime 1794960006 "bb9428084642eab1315413f0c4a49f89e07c910c552c0815d050040c5d0e7166">,
      #splice.entry<"/build/source/build/disk_interface.o.d" file 644 mtime 1794960006 "32127bd4eecbb16ba3de605c890d88e12a1c51dabe7e88fbed8dc12d678cbcfb">,
      #splice.entry<"/build/source/build/dyndep.o" file 644 mtime 1794960007 "4c1052cd16385a94eb358e7f2d78ff76e6806766937abce3a40bba4196a400a0">,
      #splice.entry<"/build/source/build/dyndep.o.d" file 644 mtime 1794960007 "53435e64e90619efb30610e146a2198749855d364536139ea94bbb82cfa41709">,
      #splice.entry<"/build/source/build/dyndep_parser.o" file 644 mtime 1794960008 "882ad09f07a122b030c1e4376af2da35c2899142e90ef97798a0b2fa7969cfa9">,
      #splice.entry<"/build/source/build/dyndep_parser.o.d" file 644 mtime 1794960008 "790c42507634419581d26d19eecd55de38101356177f519ca0b5493ed93f252b">,
      #splice.entry<"/build/source/build/edit_distance.o" file 644 mtime 1794960008 "c4a3d378f73b865520e8cb560875a943096b92bb6526cd2e01a21075baeb719d">,
      #splice.entry<"/build/source/build/edit_distance.o.d" file 644 mtime 1794960008 "49877071d5f3fca64cce6ec36782ec2221875a3a9f717faef1fa3703163e17fb">,
      #splice.entry<"/build/source/build/elide_middle.o" file 644 mtime 1794960009 "58f037e6b106946ad33f5808d7d5c863ab669950e27955f3a13e8dd78f40109e">,
      #splice.entry<"/build/source/build/elide_middle.o.d" file 644 mtime 1794960009 "811b035ad1f7594da23e5d2e83d21fab1d6df60b0a4f437d21572a51f17a6c40">,
      #splice.entry<"/build/source/build/eval_env.o" file 644 mtime 1794960010 "71584959d93c2695837f825b9ecbda505c5a41087d494d85eb1b8fa3bd4737cd">,
      #splice.entry<"/build/source/build/eval_env.o.d" file 644 mtime 1794960010 "37db4a71534b6b9a1359f58a95d4fc4ce48438d38b4590a693fdac9b84839064">,
      #splice.entry<"/build/source/build/graph.o" file 644 mtime 1794960011 "f2ea6dfcba7b576d052c2123efae75ed3a2df83fdfa2411970a9d6afa48864fe">,
      #splice.entry<"/build/source/build/graph.o.d" file 644 mtime 1794960011 "11b359ae48826d89314f270ab39b6ba8ce00e934152dceb040d2370feb77bf76">,
      #splice.entry<"/build/source/build/graphviz.o" file 644 mtime 1794960012 "b34dd7824790361bb205c4855a5a708fe811f064f56d18437ce20cc2d27f23ec">,
      #splice.entry<"/build/source/build/graphviz.o.d" file 644 mtime 1794960012 "08f2c47dfcf6a50b53a16140d35f2c5281a5da6a935814431b7b7d461b17b456">,
      #splice.entry<"/build/source/build/jobserver-posix.o" file 644 mtime 1794960020 "4cac3325fe3ebc4e437f7e91c2bdbf50381139a93dc8954caadd32768395ad41">,
      #splice.entry<"/build/source/build/jobserver-posix.o.d" file 644 mtime 1794960020 "3926a042dd3b75273b450d44c9a810f24ca91dd5addb725729a6d17d14e996b3">,
      #splice.entry<"/build/source/build/jobserver.o" file 644 mtime 1794960012 "7ebc78b3a794990af5ef852f06fe8d44c0a502cd708ca95bafb7da36f28871b7">,
      #splice.entry<"/build/source/build/jobserver.o.d" file 644 mtime 1794960012 "8f47e663ca638dc81c3ce765ba301e84eca671513eaf5e5808d68f61c9a3d30d">,
      #splice.entry<"/build/source/build/json.o" file 644 mtime 1794960012 "c05a0e5dc28ba8e70518ddf5534b5703e369cb506fd59eff04958114579957ad">,
      #splice.entry<"/build/source/build/json.o.d" file 644 mtime 1794960012 "2f5a9f258d32f5ecbefcc3c74670af231b530e2557b1f2306bafb6deef2bfb23">,
      #splice.entry<"/build/source/build/lexer.o" file 644 mtime 1794960001 "8c71fd84c4a6a84112f4e8e580ca0dd724161b227b106d8a3ce9ae52e3123565">,
      #splice.entry<"/build/source/build/lexer.o.d" file 644 mtime 1794960001 "90d72ddd4dc836b65ed6c7aac44e97433d8d5d49c33feb5e47ff8a7b1d55b0f7">,
      #splice.entry<"/build/source/build/libninja-re2c.a" file 644 mtime 1794960001 "0b1a1e0b2de60a362fc05cd9e0f7d9bf60504c10fae8a4ffa155eaf943f6b183">,
      #splice.entry<"/build/source/build/libninja.a" file 644 mtime 1794960021 "70f02b1e292afc0c023c74032ee8cd445a17bab9faeec17ca1b4465bf3bbae20">,
      #splice.entry<"/build/source/build/line_printer.o" file 644 mtime 1794960013 "311a7b36405764af5fed5fb56db4ce0033753cb909e33f6eeca1966ecd9dd72f">,
      #splice.entry<"/build/source/build/line_printer.o.d" file 644 mtime 1794960013 "cb776269f701ea5839084360377b0e3522a2828142d4768e1472d929352718e0">,
      #splice.entry<"/build/source/build/manifest_parser.o" file 644 mtime 1794960014 "8b73f696867429cd45c2f84529ceee9b8e9995c060c0c58f6c297b68f28f1a47">,
      #splice.entry<"/build/source/build/manifest_parser.o.d" file 644 mtime 1794960014 "1ea514934e3e479bbe93a24a81af854c3d0248c8839487667119714e3e4afa54">,
      #splice.entry<"/build/source/build/metrics.o" file 644 mtime 1794960015 "887365650c98094824f292aee4b300d8ad70b7c7dc8fda1606d2f0233dce4202">,
      #splice.entry<"/build/source/build/metrics.o.d" file 644 mtime 1794960015 "5012909a1ae3ec559936fe634e870b1e2cea625782e9bec132e3b152c714c23e">,
      #splice.entry<"/build/source/build/missing_deps.o" file 644 mtime 1794960016 "4773653e931cf4839c79200956baa758476e743f8fdc386174651d43244a47f3">,
      #splice.entry<"/build/source/build/missing_deps.o.d" file 644 mtime 1794960016 "c64c73ef54a519d452940dae788a63d6d7046462b8505b888c85a8412c523e3e">,
      #splice.entry<"/build/source/build/ninja.o" file 644 mtime 1794960023 "58b1a3ae60a73319aead3bdbbb455bbc0d587530afa4decf7444c5019f5985d9">,
      #splice.entry<"/build/source/build/ninja.o.d" file 644 mtime 1794960023 "a3595fd6f783c4fb17b4665ddca960e45a84ae2040d599382d5467808044e1ae">,
      #splice.entry<"/build/source/build/parser.o" file 644 mtime 1794960016 "094ab2b0c5b4bd12f750a8ad3699b29e09b35022de4448b68eeef5ef36dad8f2">,
      #splice.entry<"/build/source/build/parser.o.d" file 644 mtime 1794960016 "5d071012341ba1c066969fbffdc09ce711ad43daafdb1286d895764aca449887">,
      #splice.entry<"/build/source/build/real_command_runner.o" file 644 mtime 1794960016 "90b14e2f2749057b9ada787d96ed5fa0a59075c5ebb9e76d69e92fd3c2158730">,
      #splice.entry<"/build/source/build/real_command_runner.o.d" file 644 mtime 1794960016 "873d406dc6a858b9b9c1bfdcec8b54940a261b891960b1a29e99561bc3447418">,
      #splice.entry<"/build/source/build/state.o" file 644 mtime 1794960018 "7cf48eb8a80109e10b78d10211636ad755d9238054803f5025f3ef1d4f0c2d20">,
      #splice.entry<"/build/source/build/state.o.d" file 644 mtime 1794960018 "ee59d8a219198f15039d04db1153dfa178d043e5c25fa4556499885f3d5b47d3">,
      #splice.entry<"/build/source/build/status_printer.o" file 644 mtime 1794960018 "24269a840e8e9fd62bcb51673e81bb28193500fe9826e9a7bc0383bed7fa70e5">,
      #splice.entry<"/build/source/build/status_printer.o.d" file 644 mtime 1794960018 "1ab3d6e4abce2fb9805d995a4119108dd859ebf09c4d8b0290f30b98de41921f">,
      #splice.entry<"/build/source/build/string_piece_util.o" file 644 mtime 1794960019 "4459d56731d39b58352e90775c826484f6d0327870f724f6d8a30f2a3b6b0e41">,
      #splice.entry<"/build/source/build/string_piece_util.o.d" file 644 mtime 1794960019 "4d3be22d751fa1dbcd8616a6612d7f0a3e89ab18c57fbe49eaac61f0bb4193d6">,
      #splice.entry<"/build/source/build/subprocess-posix.o" file 644 mtime 1794960021 "8a4122b842281c2598418f186230897de8d3c895f4858c5254860394645f3680">,
      #splice.entry<"/build/source/build/subprocess-posix.o.d" file 644 mtime 1794960021 "af49cf9c7a777691103640c0e14b2be1f642aaee42f3c7f63219bbfdf0ac03ed">,
      #splice.entry<"/build/source/build/util.o" file 644 mtime 1794960020 "4d4d68448fc0b391665aeea1597d30266cb3daabe95fc677e4d91dd90dc502dc">,
      #splice.entry<"/build/source/build/util.o.d" file 644 mtime 1794960020 "4690927801e65a4cb05319efda45c8d0fb449d403cf8b2185e3fb13f102f8e73">,
      #splice.entry<"/build/source/build/version.o" file 644 mtime 1794960020 "731b22859332afe3fb3bfa5e9674353bf8da3bf2599c54649a534dc63b60a045">,
      #splice.entry<"/build/source/build/version.o.d" file 644 mtime 1794960020 "5971d3b0f97328ff7fff5ffe9e312712255bece060eeaada7b3eb3ab3a9e8aa6">,
      #splice.entry<"/build/source/misc/__pycache__" dir 755 mtime 1794960000>,
      #splice.entry<"/build/source/misc/__pycache__/ninja_syntax.cpython-314.pyc" file 644 mtime 1794960000 "3e8556a9f6826c3d619449742853fe66e3ff4218041b2396b253472f8d7fed49">,
      #splice.entry<"/build/source/ninja" file 755 mtime 1794960023 "7f9ff242e864b09b104e14759ed767f6c5fafc93243d7dcd719a81fcb01ee0e2">,
      #splice.entry<"/build/source/rebuild_args" file 644 mtime 1794960024 "ff09c2581ec0e4b4153e9d813f120eb16585ae1c08e15e0f579a56c8becb920d">,
      #splice.entry<"/build/source/src/depfile_parser.cc" file 600 mtime 1794960000 "ca94be8260cf998f53f1a640b48ea462014a787992f586d26f898cf6123e3b55">,
      #splice.entry<"/build/source/src/lexer.cc" file 600 mtime 1794960000 "f33a85dccee1a7c15d00196f12a0532a6080509fce394cdce7b6005476399b62">
  ]
  %python_18308 = splice.exec "python" at 18308(%sandbox_720#0, %chmod_2624#0, %chmod_2624_0, %chmod_2624_1, %chmod_2624_2, %chmod_2624#1, %chmod_2624_3, %chmod_2624_4, %chmod_2624_5, %chmod_2624_6, %chmod_2624_7, %chmod_2624_8, %chmod_2624_9, %python_3266#0, %python_3266_106#1, %glue_2916, %chmod_2624#2, %chmod_2624#3, %python_3266#1, %python_3266_106#72, %chmod_2624#4, %chmod_2624#5, %chmod_2624_13, %chmod_2624_14, %chmod_2624_15, %chmod_2624_16, %chmod_2624_17, %chmod_2624_18, %chmod_2624_19, %chmod_2624_20, %chmod_2624_21, %chmod_2624_22, %chmod_2624_23, %chmod_2624_24, %chmod_2624_25, %chmod_2624#6, %chmod_2624_26, %chmod_2624#7, %chmod_2624_27, %chmod_2624_28, %python_3266_106#73, %python_3266_106#74, %chmod_2624#8, %chmod_2624#12) -> [
      #splice.entry<"/build/source/build.ninja" file 644 mtime 1794960024 "892c8c9f580237a52344bc304dae7afeb4b271cf2bbae9ede8383d69cd2fccb4">
  ]
  %ninja_18707:40 = splice.exec "ninja" at 18707(%sandbox_720#0, %chmod_2624#0, %python_3266#0, %python_18308, %python_3266_106#2, %python_3266_106#3, %python_3266_106#4, %python_3266_106#5, %python_3266_106#6, %python_3266_106#7, %python_3266_106#8, %python_3266_106#9, %python_3266_106#10, %python_3266_106#11, %python_3266_106#12, %python_3266_106#13, %python_3266_106#14, %python_3266_106#15, %python_3266_106#16, %python_3266_106#17, %python_3266_106#18, %python_3266_106#19, %python_3266_106#20, %python_3266_106#21, %python_3266_106#22, %python_3266_106#23, %python_3266_106#24, %python_3266_106#25, %python_3266_106#26, %python_3266_106#27, %python_3266_106#28, %python_3266_106#29, %python_3266_106#30, %python_3266_106#31, %python_3266_106#32, %python_3266_106#33, %python_3266_106#34, %python_3266_106#35, %python_3266_106#36, %python_3266_106#37, %python_3266_106#38, %python_3266_106#39, %python_3266_106#40, %python_3266_106#41, %python_3266_106#42, %python_3266_106#44, %python_3266_106#45, %python_3266_106#46, %python_3266_106#47, %python_3266_106#48, %python_3266_106#49, %python_3266_106#50, %python_3266_106#51, %python_3266_106#52, %python_3266_106#53, %python_3266_106#54, %python_3266_106#55, %python_3266_106#56, %python_3266_106#57, %python_3266_106#58, %python_3266_106#59, %python_3266_106#60, %python_3266_106#61, %python_3266_106#62, %python_3266_106#63, %python_3266_106#64, %python_3266_106#65, %python_3266_106#66, %python_3266_106#67, %python_3266_106#68, %python_3266_106#69, %python_3266_106#70, %glue_2916, %chmod_2624#3, %chmod_2624_24, %python_3266_106#73, %chmod_2624#8, %chmod_2624_29, %chmod_2624_30, %chmod_2624_31, %chmod_2624_32, %chmod_2624_33, %chmod_2624_34, %chmod_2624_35, %chmod_2624_36, %chmod_2624_37, %chmod_2624_38, %chmod_2624_39, %chmod_2624_40, %chmod_2624_41, %chmod_2624_42, %python_3266_106#75, %chmod_2624_44, %chmod_2624_45, %chmod_2624_46, %chmod_2624_47, %chmod_2624_48, %chmod_2624_49, %chmod_2624_50, %chmod_2624_51, %chmod_2624_52, %chmod_2624_53, %chmod_2624_54, %chmod_2624_55, %chmod_2624_56, %chmod_2624_57, %chmod_2624_58, %chmod_2624_59, %chmod_2624_60, %chmod_2624_61, %chmod_2624_62, %chmod_2624_63, %chmod_2624_64, %chmod_2624_65, %chmod_2624_66, %chmod_2624_67, %chmod_2624_68, %chmod_2624_69, %chmod_2624_70, %chmod_2624_71, %chmod_2624_72, %python_3266_106#76, %chmod_2624_74, %chmod_2624_75, %chmod_2624_76, %chmod_2624_77, %chmod_2624_78, %chmod_2624_79, %chmod_2624_80, %chmod_2624_81, %chmod_2624_82, %chmod_2624_83, %chmod_2624_84, %chmod_2624_85, %chmod_2624_86, %chmod_2624_87, %chmod_2624_88, %chmod_2624_89, %chmod_2624_90, %chmod_2624_91, %chmod_2624_92, %chmod_2624_93, %chmod_2624_94, %chmod_2624_95, %chmod_2624_96, %cat_patch_2847, %chmod_2624_98, %chmod_2624#9, %chmod_2624#10, %chmod_2624_99, %chmod_2624#11, %chmod_2624_100, %chmod_2624_101, %chmod_2624_102, %chmod_2624_103, %chmod_2624_104, %chmod_2624_105) -> [
      #splice.entry<"/build/source/build/.ninja_deps" file 644 mtime 1794960047 "db0c2ab9861ad5091feb098fd8b23d027a56aa321e67b2b6a207f78a77222a56">,
      #splice.entry<"/build/source/build/.ninja_log" file 644 mtime 1794960047 "b14ec0f73b31487be4e3fd8e1f8584fd65abdaa259223691404511500daa2554">,
      #splice.entry<"/build/source/build/browse.o" file 644 mtime 1794960025 "bcb17417218b19d0a5faf638035424af8929c735dd203482648aea60c347eb97">,
      #splice.entry<"/build/source/build/browse_py.h" file 644 mtime 1794960024 "4dd1455da9b09646416a2e465a696e934fe36113317a5e509a18922ab01c608c">,
      #splice.entry<"/build/source/build/build.o" file 644 mtime 1794960028 "78d4aa11f46fd408b40320041d3eff5dae416873d716671124b8bab77f721744">,
      #splice.entry<"/build/source/build/build_log.o" file 644 mtime 1794960027 "5e6dc938a165065095cf3f546009c395d7a273fab51ca8fdc93322047a1f6d6d">,
      #splice.entry<"/build/source/build/clean.o" file 644 mtime 1794960028 "febadbc35d0a20f1043b74f5bc443ea5223a369132c3481222d29c7e853cf82d">,
      #splice.entry<"/build/source/build/clparser.o" file 644 mtime 1794960029 "92d964f03c30490d63125228d18e82a89638eb5db91c345027c89c1a01763208">,
      #splice.entry<"/build/source/build/debug_flags.o" file 644 mtime 1794960030 "801f5b53c03a7c01d36c6722d8830ae03e09ed69c5d9c62314f3890ceec0420f">,
      #splice.entry<"/build/source/build/depfile_parser.o" file 644 mtime 1794960024 "a130f00a23e044db92ed6bd0e9ec059c29564c46ff44a984319f38d3ffecbbc0">,
      #splice.entry<"/build/source/build/deps_log.o" file 644 mtime 1794960030 "c9f4d6330aa6f1ed62354f6f7fac055ff7371485317ddc0ca4dadc87c4e361b5">,
      #splice.entry<"/build/source/build/disk_interface.o" file 644 mtime 1794960030 "963afbf82e8b5e6b4be2acd524acf47166b28061757ddf826cdedab542be0215">,
      #splice.entry<"/build/source/build/dyndep.o" file 644 mtime 1794960032 "51cc326ec6ff1fff812437254a2caa8c8c00bea1bcb63963e4bd0fba2613f662">,
      #splice.entry<"/build/source/build/dyndep_parser.o" file 644 mtime 1794960032 "4b5db451596a48d6646c03dbcc83176d338f52af0dc0808372b0b82ae5fb2f59">,
      #splice.entry<"/build/source/build/edit_distance.o" file 644 mtime 1794960032 "6d94a02eae3f38242ee151b7c971cd2d175d85df64d6ba5c08b8a6e9093242cb">,
      #splice.entry<"/build/source/build/elide_middle.o" file 644 mtime 1794960033 "d47060b1ba3e503181d26df5d408f946d375be34ddce4c9bde3eeaddb4d645d7">,
      #splice.entry<"/build/source/build/eval_env.o" file 644 mtime 1794960034 "855673cd55caa90757fb905d7a727c7200d75d28a44341566547285e8c645c79">,
      #splice.entry<"/build/source/build/graph.o" file 644 mtime 1794960037 "4c70077532c444a611fc91df1107641d231cc51e966c76388caaaae25e664f38">,
      #splice.entry<"/build/source/build/graphviz.o" file 644 mtime 1794960036 "9074ddbec3fca69e9d434f7777fddd1987fd50f7bfd42fe4d2ac315f1af62378">,
      #splice.entry<"/build/source/build/jobserver-posix.o" file 644 mtime 1794960044 "5f243878b0cfa4943c735891485b2a166e865b780918c590b16c047615d00ca5">,
      #splice.entry<"/build/source/build/jobserver.o" file 644 mtime 1794960036 "81c1217bffd5f8c3cbad759cb8a2d421c88859ea7922165f1af84b86b432f7c2">,
      #splice.entry<"/build/source/build/json.o" file 644 mtime 1794960036 "61fc77517b1712e0a4eae0f86540706b344e0956648b244765dd49ee665446bd">,
      #splice.entry<"/build/source/build/lexer.o" file 644 mtime 1794960025 "5da7b42c23834b44d5778cfbefc89200b125b7ce35ccd5ca849714a6f65502b4">,
      #splice.entry<"/build/source/build/libninja.a" file 644 mtime 1794960046 "2a1d148eaa6789986b8c7b2ac8abae8f3dd199ae04d789b7b9bfae9b38c1ea90">,
      #splice.entry<"/build/source/build/line_printer.o" file 644 mtime 1794960037 "44e5899ab78488a83d0b3018582784ece84fe068f23560c2f90fe87a910df33e">,
      #splice.entry<"/build/source/build/manifest_parser.o" file 644 mtime 1794960039 "38d54f61f635e7a243ceaf3e3f3188832a1106ebe5baa1b3ed968f4ffcc865e4">,
      #splice.entry<"/build/source/build/metrics.o" file 644 mtime 1794960038 "7190075ff1a5cf4bcf4747646f8757166914dbd36c0068c3ac0a0707af302181">,
      #splice.entry<"/build/source/build/missing_deps.o" file 644 mtime 1794960039 "b03c1a5c34ced445d1952a82acdf10ecad408804256f32915106591b7dddc039">,
      #splice.entry<"/build/source/build/ninja.o" file 644 mtime 1794960047 "c0c8031c56bbf0410f91a19628d2de9cdfb085da14116457b5da39db87f059ae">,
      #splice.entry<"/build/source/build/parser.o" file 644 mtime 1794960040 "53559aeb49f53b66742bf59e319db998b8b165853d34784e27b2ee69468c942a">,
      #splice.entry<"/build/source/build/real_command_runner.o" file 644 mtime 1794960041 "0f8e36578103ace1e28a533570ba2ba371d4f72178cf1bc1b8b64008e8b25907">,
      #splice.entry<"/build/source/build/state.o" file 644 mtime 1794960042 "4715e7b4bc2a68c1d613f37660c3fb95fad32f75e78f05273a1e9c8c5bb9a846">,
      #splice.entry<"/build/source/build/status_printer.o" file 644 mtime 1794960042 "18f2e07deaba96b36f260c3084986fad929c82abe583b82585a4b94b7340395c">,
      #splice.entry<"/build/source/build/string_piece_util.o" file 644 mtime 1794960043 "f838e0a2605cf0a58a2b6da5914e21fc8e4874557c1da7116851b8a70fe3f52d">,
      #splice.entry<"/build/source/build/subprocess-posix.o" file 644 mtime 1794960045 "807bf01f5e12afa3cf4b24e46569a7ec5f52cd9222cd0a5a55c26609a80c5e12">,
      #splice.entry<"/build/source/build/util.o" file 644 mtime 1794960046 "6955d794e62b348480770a41522672f59fb099acef9fad3d990b588992a8038a">,
      #splice.entry<"/build/source/build/version.o" file 644 mtime 1794960043 "11ab23b8e8cb73729c229ca70aca8a5e248cda0a3bd816772d1427bee901c844">,
      #splice.entry<"/build/source/ninja" file 755 mtime 1794960047 "21026ed4fd6e0a95a059eba1d9ae92125e56fa3b12d7215571d852dfd7b7fbfe">,
      #splice.entry<"/build/source/src/depfile_parser.cc" file 600 mtime 1794960024 "ca94be8260cf998f53f1a640b48ea462014a787992f586d26f898cf6123e3b55">,
      #splice.entry<"/build/source/src/lexer.cc" file 600 mtime 1794960024 "f33a85dccee1a7c15d00196f12a0532a6080509fce394cdce7b6005476399b62">
  ]
  %_asciidoc_wrapped_30581 = splice.exec ".asciidoc-wrapped" at 30581(%sandbox_720#0, %chmod_2624#0, %python_3266#0, %chmod_2624#2, %chmod_2624_11) -> [
      #splice.entry<"/build/source/build/manual.xml" file 644 mtime 1794960048 "43704024f520158343ea4cf514bea346bf38575838a561e31de4572e611f285d">
  ]
  %glue_31727 = splice.literal "glue" at 31727 -> [
      #splice.entry<"/build/source/doc/manual.html" file 644 mtime 1794960048 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %xsltproc_31727 = splice.exec "xsltproc" at 31727(%sandbox_720#0, %chmod_2624#0, %python_3266#0, %_asciidoc_wrapped_30581, %chmod_2624#2, %chmod_2624_10, %glue_31727, %chmod_2624_12) -> [
      #splice.entry<"/build/source/doc/manual.html" file 644 mtime 1794960048 "40de7437071ef90e5120147a6a77c511a6167662de56417d28d7af8669248643">
  ]
  %install_31829:2 = splice.literal "install" at 31829 folded -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2" dir 755 mtime 1794960048>,
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/bin" dir 755 mtime 1794960048>
  ]
  %install_31892:3 = splice.literal "install" at 31892 folded -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share" dir 755 mtime 1794960048>,
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/bash-completion" dir 755 mtime 1794960048>,
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/bash-completion/completions" dir 755 mtime 1794960048>
  ]
  %install_31892_107 = splice.copy "install" at 31892(%cp_2232#46) -> <"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/bash-completion/completions/ninja" file 644 mtime 1794960048 "536a81b4d5fac9dd74e4842c59f2b5ab0cce27882e3638fd7219d1ad78fa149d">
  %install_31953:2 = splice.literal "install" at 31953 folded -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/zsh" dir 755 mtime 1794960048>,
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/zsh/site-functions" dir 755 mtime 1794960048>
  ]
  %install_31953_108 = splice.copy "install" at 31953(%cp_2232#67) -> <"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/zsh/site-functions/_zsh-completion" file 644 mtime 1794960048 "a4b8b63ac381db23da0a5624ea3092d5c7e433dd608afdf07792aa586d79effa">
  %install_31978:2 = splice.literal "install" at 31978 folded -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/doc" dir 755 mtime 1794960048>,
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/doc/ninja" dir 755 mtime 1794960048>
  ]
  %chmod_32085 = splice.copy "chmod" at 32085(%ninja_18707#37) -> <"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/bin/ninja" file 755 mtime 1794960048 "21026ed4fd6e0a95a059eba1d9ae92125e56fa3b12d7215571d852dfd7b7fbfe">
  %chmod_32085_109 = splice.copy "chmod" at 32085(%cp_2232#24) -> <"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/doc/ninja/manual.asciidoc" file 644 mtime 1794960048 "0b7148678b1a4c7751acbb443d5cfec41ceacf3a7b2a0ad2d511407fbe056226">
  %chmod_32085_110 = splice.copy "chmod" at 32085(%xsltproc_31727) -> <"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/share/doc/ninja/manual.html" file 644 mtime 1794960048 "40de7437071ef90e5120147a6a77c511a6167662de56417d28d7af8669248643">
  %find_patchelf_32223 = splice.exec "find|patchelf" at 32223(%sandbox_720#0, %chmod_2624#0, %install_31829#0, %install_31829#1, %chmod_32085) -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/bin/ninja" file 755 mtime 1794960048 "a3df76d1eb2fded6e7b56f558cae699fab1f11ae084653adc1812b47b9f19c33">
  ]
  %mktemp_32573 = splice.literal "mktemp" at 32573 folded -> [
      #splice.entry<"/build/striperr.co0Upa" file 600 mtime 1794960048 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855">
  ]
  %strip_32679 = splice.exec "strip" at 32679(%sandbox_720#0, %chmod_2624#0, %mktemp_32573, %install_31829#0, %install_31829#1, %find_patchelf_32223) -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/bin/ninja" file 755 mtime 1794960048 "fd2f69e8847237aba338090bc5a28189df545ccc1a922a3baa92ab619d75c27c">
  ]
  %mkdir_32761 = splice.literal "mkdir" at 32761 folded -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/nix-support" dir 755 mtime 1794960048>
  ]
  %glue_32821 = splice.literal "glue" at 32821 -> [
      #splice.entry<"/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2/nix-support/setup-hook" file 644 mtime 1794960048 "5f0ca464c7cf2ca7c8e4166b62d703a0089f905caf650a89910593492301bc4f">
  ]
  splice.output "out" "/nix/store/4nsdla28c4177ssp0hlyv5l2yzj8wcba-ninja-1.13.2"(%install_31829#0, %install_31829#1, %strip_32679, %mkdir_32761, %glue_32821, %install_31892#0, %install_31892#1, %install_31892#2, %install_31892_107, %install_31978#0, %install_31978#1, %chmod_32085_109, %chmod_32085_110, %install_31953#0, %install_31953#1, %install_31953_108)
}

